@extends('layouts.app', ['pagetitle'=>'Training Calendar Management'])


<style>
    .select2-container {
    display: block !important;
    z-index: 0 !important; 
}

label.btn.btn-tertiary.js-labelFile {
    background: #dc3545;
    color:#fff;
        padding: 7px;
}
/* Global style */

.donloadcsv {
    position: absolute;
    margin: -86px;
}


/* input file style */

.input-file {
	width: 0.1px;
	height: 0.1px;
	opacity: 0;
	overflow: hidden;
	position: absolute;
	z-index: -1;
  + .js-labelFile {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding: 0 10px;
    cursor: pointer;
    .icon:before {
      //font-awesome
      content: "\f093";
    }
    &.has-file {
      .icon:before {
        //font-awesome
        content: "\f00c";
        color: #5AAC7B;
      }
    }
  }
}
.buttonabsent {
    border: 0px;
 padding: 9px 25px;
    background: #DD1144 ;
    color: #fff;
    cursor: pointer;
       border-radius: 50px !important;
}

.buttonpresent {
    border: 0px;
   padding: 9px 25px;
    background: #000;
    color: #fff;
    cursor: pointer;
       border-radius: 50px !important;
}

a.print {
    border: 1px solid #ddd;
    padding: 10px 43px;
    font-size: 16px;
    text-align: right;
    float: right;
    margin-top: 20px;
}

</style>
@section('content')
    <div class="row">
         
                           <div class="col">
                           <div class="card">

  <div class="card-body">

    <div class=" pd-x-0">
        <div class="row row-xs">
            <!--<div class="col-sm-12 col-lg-12">-->
            <!--    <div class="alert alert-success" style="display: none;" role="alert" id="success-alert"></div>-->
            <!--</div>-->
        </div>
        <div class="row row-xs">
            <div class="col-sm-12 col-lg-12 mg-t-20">
                <div data-label="" class="df-example demo-forms">
                    
         
                    <form id="coursecategoryForm" action="{{route('store_lms_enrolled')}}" method="POST" class="form-horizontal" enctype="multipart/form-data">
                        @csrf
                        
                        
                
                        
                  
                          <input type="hidden" name="partcipant_id" class="form-control"  placeholder="Course Name" value="<?php echo $_GET['id']; ?>">
                        <div class="row row-sm">
                            
                      
                
                       
                         

        <?php if(empty($_GET['status'])){?>
       <div class="col-sm-12 col-lg-12" style="margin-top:20px;">
     
           </div>
                
                                 <div class="col-sm-12 mg-t-10">
                                     
                            <div class="field_wrapper">
                                <div>
 <div class="row row-sm">
        
<div class="col-sm-2 mg-t-10">
    

                                <label>Participants Name <span class="text-danger">*</span></label>
                                
                                
                                <select class="form-control js-example-basic-multiple" name="p_name" id="userlist"   required>
                                  <option value="">Select User</option> 
                                  
                                  @php $getUsersList = Helper::getUsersList() @endphp
                                    @if ($getUsersList)
                                        @foreach ($getUsersList as $user)
                                            <option value="{{ $user->id }}">{{ $user->employer_fullname ?? '' }}</option>
                                        @endforeach
                                    @endif
                                </select>
                                
                             
                 

</div>

<div class="col-sm-2 mg-t-10">
<label>Mobile Number <span class="text-danger">*</span></label>
<input type="text" name="roll_number" class="form-control" id="roll_number" placeholder="Mobile Number" >
</div>


<div class="col-sm-2 mg-t-10">
<label>Email <span class="text-danger">*</span></label>
<input type="text" name="email" class="form-control" id="getemail" placeholder="Email" >
</div>



    </form>
      </form>
  
<div class="col-sm-2 mg-t-10">


   <button type="submit" style="margin-top: 20px;background: #dc3545;border: 1px solid #dc3545;" class="btn btn-success" value="create">Save</button>
   
    <button type="button" class="btn btn-success" style="margin-top: 19px;padding: 7px;" data-toggle="modal" data-target="#myModal">Add Manually </button>

</div>

<div class="col-sm-3 mg-t-10">
    
     <div class="row row-sm">
         <div class="col-sm-10 ">
       <form action="{{route('importfile11')}}" class="form-horizontal" enctype="multipart/form-data" method="post" style="margin-top: 20px;margin-left: -17px;">
        @csrf
              <input type="hidden" name="partcipant_id1" value="<?php echo $_GET['id']; ?>">
              
              <div class="form-group" style="    float: left;
    width: 50%;">
  <input type="file" name="uploaddoc" id="file" class="input-file" required="required" accept="csv,.csv" name="uploaddoc" id="uploaddoc" oninvalid="this.setCustomValidity('Please Browse for document to upload')" oninput="setCustomValidity('')">
  <label for="file" class="btn btn-tertiary js-labelFile">
    <span class="js-fileName">Import Users</span>
  </label>
</div>


    <!--          <input style="    width: 33%;-->
    <!--float: left;margin-top: 20px;" type="file" class="form-control" required="required" accept="csv,.csv" name="uploaddoc" id="uploaddoc" oninvalid="this.setCustomValidity('Please Browse for document to upload')" oninput="setCustomValidity('')">-->
                             <button style="" type="submit" class="btn btn-success" id="btn-save" value="create">Save</button>
          
          
       </form>
       </div>
       
          <div class="col-sm-1 mg-t-10">
       
                        <div style="margin-top: 12px;" class="donloadcsv"><a style="font-size: 12px;" class="text-primary" href="https://www.safefoodmitra.com/admin/public/users.csv" target="_new"><i title="Download Template" class="fas fa-file-excel fa-3x"></i></a>
</div>
     </div>    
    </div>
    </div>



</div>

</div>
</div>
</div>



      
                        <?php } ?>


 <?php if(empty($_GET['status'])){?>
 
             <div class="col-sm-12 ">
                                 
        @csrf
    
        <table class="table table-bordered mx-auto " id="ingredientsTable"
               data-toggle="table"
        
             
               data-pagination="true"
               data-id-field="id"
               data-page-list="[10, 25, 50, 100, all]"
               data-side-pagination="client"
               data-page-number="1"
               data-page-size="1000"
               data-onblur="submit"
               data-click-to-select="true"
               data-maintain-meta-data="true"
        >
          
            <thead>
            <tr>
                <th ><input type="checkbox" class="checkboxclick"></th>
       
                <th>S no.</th>
                <th>Employee Name</th>
                <th>Employee Id</th>
                <th>Mobile Number</th>
                <th>Designation</th>
                <th>Absent/Present</th>

            </tr>
            </thead>
            <tbody>
  <?php 
  
 // $ingredients =  DB::table('enrolled_member_lms')->where('payment_status',"Success")->where('enrolled_id',$_GET['id'])->get();
	$ingredients =  DB::table('student_enrolled')->where('payment_status',"Success")->where('course_id',$_GET['id'])->get();
	
	
  ?>
          @php
                $sno = 1;
            @endphp
            @foreach($ingredients as $keys=>$values)
                <tr>
                    <td><input class="checkboxvalue" type="checkbox" value="{{ $values->id }}"></td>

       
                    <th>{{$sno++}}</th>
             
                    <th>
             
                      <?php   $users_details = DB::table('unit_users')->where('id', $values->user_id)->First(); ?>
                     <p> {{$users_details->employer_fullname ?? ''}}  </p>
                   
                    </th>
                    
                          <th>
                        
                     
                       <p> {{$users_details->employe_id ?? ''}} </p>
                           
             
                    </th>
                    <th>
                        
                        
                      <p> {{$users_details->contact_number ?? ''}}</p>
                           
                  
                    </th>
                    
     
                    
                          <th>
                        
                        
                  <p> {{$users_details->designation ?? ''}}</p>
                           
                  
                    </th>
                    


                        <th>
                            
                            
                            <?php if(!empty($values->attendance)){?>
                            
                             <?php if($values->attendance=="1"){?>
                             <span >Absent</span> 
                             
                             <?php } else {?>
                              <span >Present</span> 
                            <?php  } ?>
                            <?php } else {?>
                                <span class="buttonabsent" onclick="myFunction('<?php echo $values->id; ?>')">Absent</span> 
                        <span  class="buttonpresent" onclick="myFunction1('<?php echo $values->id; ?>')">Present</span> 
                            <?php } ?>
                       
                  
                       
                    </th>
   
                </tr>
            @endforeach
            </tbody>
        </table>
        
      <div class="col-sm-12 col-lg-12 mg-b-20">
      <button type="button" id="delbutton1" class="btn btn-danger btn-xs" value="delete">Delete Selected</button>
    </div>
        
      
                            </div>
 <?php } else{?>
 
             <div class="col-sm-12 mg-t-10">
      
 
        <table class="table table-bordered  " id="ingredientsTable"
               data-toggle="table"
        
             
               data-pagination="true"
               data-id-field="id"
               data-page-list="[10, 25, 50, 100, all]"
               data-side-pagination="client"
               data-page-number="1"
               data-page-size="1000"
               data-onblur="submit"
               data-click-to-select="true"
               data-maintain-meta-data="true"
        >
          
            <thead>
            <tr>
        
                <th>S no.</th>
                <th>Participants Name</th>
                <th>Mobile Number</th>
                <th>Participants Comments</th>
                 <th>Participants Image</th>
                 <th>Signature</th>
                     
                          
                 <th style="text-align: center;">Status</th>
           
            </tr>
            </thead>
            <tbody>
  <?php 
  
  $ingredients =  DB::table('enrolled_member')->where('enrolled_id',$_GET['id'])->get();
  


          //$ingredients = Ingredient::where('name','!=','NULL')->orderBy('created_at','desc')->get();
          
  ?>
          @php
                $sno = 1;
            @endphp
            @foreach($ingredients as $keys=>$values)
            
        
                <tr>
         

           
                    <th>{{$sno++}}</th>
             
                    <th>
                        
                      <?php   $users_details = DB::table('users')->where('id', $values->participant_name)->First(); ?>
                      <p> {{$users_details->name ?? ''}}  </p>
                           
                     
                    </th>
                    <th>
                        <p> {{$values->mobile_number ?? ''}}</p>
                           
                        </a>
                    </th>
             
                <th>
                        
                         <p>
                             
                          <?php   
                         $text= $values->comments;
                          
                        echo  $newtext = wordwrap($text, 60, "<br />\n"); ?>  </p> 
                        
                    </th>
                    
                      <th>
                      <p><img width="50px;" src="https://www.safefoodmitra.com/admin/public/cmimage/{{$values->image ?? ''}}"></p>
                            
                    
                    </th>
                    
                       <th>
                 <p>  <img width="50px;" src="https://www.safefoodmitra.com/admin/public/cmimage/{{$values->signature ?? ''}}"></p>
                             
                            
                      
                    </th>
                 
                   <?php if(!empty($values->signature )){?>
                        <th>
                            
                            
                            <?php if(!empty($values->attendance)){?>
                            
                             <?php if($values->attendance=="1"){?>
                             <span >Absent</span> 
                             
                             <?php } else {?>
                              <span >Present</span> 
                            <?php  } ?>
                            <?php } else {?>
                                <span class="buttonabsent" onclick="myFunction('<?php echo $values->id; ?>')">Absent</span> 
                        <span  class="buttonpresent" onclick="myFunction1('<?php echo $values->id; ?>')">Present</span> 
                            <?php } ?>
                       
                  
                       
                    </th>
                     <?php } else {?>
                      <th>
                          <span >Unmarked</span> 
                           </th>
                    <?php  } ?>
                </tr>
       
            @endforeach
            </tbody>
        </table>
  
                            </div>
 <?php } ?>



                
                        </div>
                  
                </div>
            </div>
        </div>
    </div>
    
    <a class="print">Print</a>
</div>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">


 <form id="userForm" method="post" action="{{ route('add_lms_store_user') }}" class="form-horizontal">
     @csrf
    <!-- Modal content-->
    <div class="modal-content">
        
        <input type="hidden" name="partcipant_id" value="<?php echo $_GET['id']; ?>">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
    
      </div>
      <div class="modal-body">
              <div class="row row-sm">
                  <div class="col-sm-12 mg-t-10">
              <label>Select Title<span class="text-danger">*</span></label>
              
              <select name="title" class="form-control">
                  
                  <option value="Mr">Mr</option>
                  <option value="Miss">Miss</option>
                  <option value="Other">Other</option>
              </select>
            </div>
            <div class="col-sm-6 mg-t-10">
              <label>Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" required="required" name="name" id="name" oninvalid="this.setCustomValidity('Please Enter Name')" oninput="setCustomValidity('')">
            </div>
            
               <div class="col-sm-6 mg-t-10">
              <label>Email<span class="text-danger">*</span></label>
              <input type="email" class="form-control" name="email" id="email" required="required" oninvalid="this.setCustomValidity('Please Enter Email Address')" oninput="setCustomValidity('')">
            </div>
            
                  <div class="col-sm-6 mg-t-10">
              <label>Mobile<span class="text-danger">*</span></label>
              <input type="number" class="form-control" name="mobile_no" id="mobile_no" required="required" maxlength="10" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" oninvalid="this.setCustomValidity('Please Enter Mobile Number')" oninput="setCustomValidity('')">
            </div>
            
            
                  <div class="col-sm-6 mg-t-10">
                      <label>USER ROLE<span class="text-danger">*</span></label>
                            <select class="select2 form-control" name="userroles_id" id="userroles_id" required="required" oninvalid="this.setCustomValidity('Please Select user Role')" oninput="setCustomValidity('')">
     <option selected value="3">App User</option>
     </select>
            </div> </div>
      </div>
      <div class="modal-footer">
   <button type="submit" id="createUser" class="btn btn-success" id="btn-save" value="create">Save User</button>
          <button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
      </div>
    </div>
    
    </div>

  </div>
</div>  </div>

  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
    $(document).ready(function(){
        
           var SITEURL = 'https://efsm.safefoodmitra.com/admin/public/index.php/';
  $("#userlist").change(function(){
      if(this.value!=""){
            var id = this.value;
            $.ajax({
                type: "GET",
                url: SITEURL+'enrollparticipants/getusermobile/'+id,
                contentType: "application/json",
                dataType: "json",
                success: function(response){
                  console.log(response.email);
                  $("#getemail").val(response.email);
                  $("#roll_number").val(response.contact_number);
                }
            });
        } else {
           
        }
  });
  
  
  
  $("#roll_number").keyup(function(){
           if(this.value.length > 9){
               

            var id = this.value;
            $.ajax({
                type: "GET",
                url: SITEURL+'enrollparticipants/getusernamebynumber/'+id,
                contentType: "application/json",
                dataType: "json",
                success: function(response){
                  console.log(response.email);
                  $("#getemail").val(response.email);
                  $("#roll_number").val(response.contact_number);
                  
                  
                  
                  $('#userlist option[value='+response.id+']').prop('selected','selected');
                  $('#select2-userlist-container').html(response.first_name);

                }
            });
        } else {
           
        }
 
});



});
</script>




<script type="text/javascript">


function myFunction(id){
 var SITEURL = 'https://efsm.safefoodmitra.com/admin/public/index.php/';
            $.ajax({
                type: "GET",
                url: SITEURL+'enrollparticipants/add_enrolled_store1/'+id,
                contentType: "application/json",
                dataType: "json",
                success: function(response){
                    
                    alert("Absent Sucessfully Updated");
                    location.reload();
                }
            });
}

function myFunction1(id){
var SITEURL = 'https://efsm.safefoodmitra.com/admin/public/index.php/';
            $.ajax({
                type: "GET",
                url: SITEURL+'enrollparticipants/add_enrolled_store2/'+id,
                contentType: "application/json",
                dataType: "json",
                success: function(response){
                        alert("Present Sucessfully Updated");
                        location.reload();
                }
            });
}

 $(document).ready(function() {
        $('.js-example-basic-multiple').select2();
    });
    
    
$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
   
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = '<div><div class="row row-sm"><div class="col-sm-2 mg-t-10"><label>Participants Name <span class="text-danger">*</span></label><input type="type" name="p_name[]" class="form-control" id="dateInput" placeholder="Enter Participants Name" required></div><div class="col-sm-2 mg-t-10"><label>Roll Number <span class="text-danger">*</span></label><input type="type" name="roll_number[]" class="form-control" id="dateInput" placeholder="Roll Number" ></div><div class="col-sm-3 mg-t-10"><label>Participants Comments <span class="text-danger">*</span></label><input type="type" name="p_comment[]" class="form-control" id="dateInput" placeholder="Participants Comments" ></div><div class="col-sm-2 mg-t-10"><label>Signature <span class="text-danger">*</span></label><input type="type" name="signature[]" class="form-control" id="dateInput" placeholder="Signature" ></div><div class="col-sm-2 mg-t-10"><label>absent/present <span class="text-danger">*</span></label><input type="type" name="present_status[]" class="form-control" id="dateInput" placeholder="absent/present" ></div><a href="javascript:void(0);" style="margin-top: 42px;margin-left: 10px;display: block;" class="remove_button"><i class="fa fa-remove"></i></a></div></div>';
    var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});
</script>

<script>
    $(document).ready(function() {
  $(".alert-success").hide();

    $(".alert-success").fadeTo(2000, 500).slideUp(500, function() {
      $(".alert-success").slideUp(500);
    });

});
</script>

<script>
    (function() {
  
  'use strict';

  $('.input-file').each(function() {
    var $input = $(this),
        $label = $input.next('.js-labelFile'),
        labelVal = $label.html();
    
   $input.on('change', function(element) {
      var fileName = '';
      if (element.target.value) fileName = element.target.value.split('\\').pop();
      fileName ? $label.addClass('has-file').find('.js-fileName').html(fileName) : $label.removeClass('has-file').html(labelVal);
   });
  });

})();
</script>

<script>

  $('body').on('click', '.deleteProdparam', function () {
    var rowID=$(this).data("rowid");
    if (confirm("Are you sure you want to delete this product?\nThis action can not be reversed!")) {
      $.get(SITEURL + 'prodparams/'+rowID+'/delete', function (data) {
        $("#success-alert").html('Product deleted successfully!!');
        $("#success-alert").fadeTo(500, 2000);
        $("#success-alert").slideDown(1000);
        $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
          $("#success-alert").slideUp(2000);
        });
        var oTable = $('#prodparamsList').dataTable();
        oTable.fnDraw(false);
      })
    }
  });
  
  
    $('body').on('click', '.checkboxclick', function () {
$(".checkboxvalue").prop('checked', this.checked);
  });
  

$(document).ready(function(){
  $("#delbutton1").click(function(){
      
         if (confirm("Are you sure you want to Delete Users!")) {
             
    
      
      
          $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      
      var id=[];
      
      $.each($(".checkboxvalue"), function(){
id.push($(this).val());

});


            
                 $.ajax({
           type:'POST',
           url:"{{ route('deletemember_lms') }}",
           data:{ id:id},
           success:function(data){
          location.reload(true);
           }
        });
        
                 
         }

  });
});
</script>

<script>
					function update_recipe_details_item(id){
							var name = $("#recipe_name_"+id).val();
				
									$.ajax({
					'headers': {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type : 'POST',
					dataType: 'json',
					cache: false,
					url: "{{route('edit_lms_user')}}",
					data: {id:id,name:name},

					success : function(resp)
					{
					
					}
				});
			}
						function video_status(user_id,status,enroll_id){
		
									$.ajax({
					'headers': {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type : 'POST',
					dataType: 'json',
					cache: false,
					url: "{{route('edit_lms_video_status')}}",
					data: {user_id:user_id,status,status,enroll_id:enroll_id},

					success : function(resp)
					{
					location.reload();
					}
				});
			}
</script>
@endsection
@section('footerscript')
@endsection