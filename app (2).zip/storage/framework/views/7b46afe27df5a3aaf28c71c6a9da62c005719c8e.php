<div class="container">
    <div class="header">
      <h1>
        <i class="fas fa-user-shield" style="margin-right: 10px;"></i>
        Staff Competency Mapping
      </h1>
      <div class="header-controls">
        <button class="btn btn-outline btn-sm">
          <i class="fas fa-download" style="margin-right: 5px;"></i> Export
        </button>
        <button class="btn btn-primary btn-sm">
          <i class="fas fa-sync-alt" style="margin-right: 5px;"></i> Refresh Data
        </button>
      </div>
    </div>

    <div class="filter-section">
      <div class="filter-section-header">Filter Options</div>
      <div class="filter-controls">
        <div class="filter-group">
          <label for="dept-filter" class="filter-label">Department:</label>
          <select id="dept-filter">
        
            <option>All Departments</option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($department->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--<option>All Departments</option>-->
            <!--<option>Operations</option>-->
            <!--<option>Security</option>-->
            <!--<option>Human Resources</option>-->
          </select>
        </div>
        <div class="filter-group">
          <label for="status-filter" class="filter-label">Status:</label>
          <select id="status-filter">
            <option>All Statuses</option>
            <option>Completed</option>
            <option>In Progress</option>
            <option>Not Started</option>
          </select>
        </div>
        <div class="filter-group">
          <label for="level-filter" class="filter-label">Competency Level:</label>
          <select id="level-filter">
            <option>Any Level</option>
            <option>1 - Awareness</option>
            <option>2 - Basic Knowledge</option>
            <option>3 - Can Perform w/ Supervision</option>
            <option>4 - Can Perform Independently</option>
            <option>5 - Can Train Others</option>
          </select>
        </div>
        <div class="filter-actions">
          <button class="btn btn-primary btn-sm"><i class="fas fa-filter" style="margin-right: 5px;"></i> Apply</button>
          <button class="btn btn-outline btn-sm"><i class="fas fa-times" style="margin-right: 5px;"></i> Clear</button>
        </div>
      </div>
    </div>

    <div class="legend">
      <p><strong>Competency Levels:</strong> 1 - Awareness | 2 - Basic Knowledge | 3 - Can Perform with Supervision | 4 - Can Perform Independently | 5 - Can Train Others</p>
    </div>

    <div class="table-responsive" style="max-height: 80vh; overflow: auto;">
      <table>
        <thead class="make-sticky-head">
          <tr>
            <!--<th class="hierarchical-column-header col-department sticky-col sticky-col-1" rowspan="2">Department</th>-->
            <th class="hierarchical-column-header col-category sticky-col sticky-col-2" rowspan="4">Staff Category (Department)</th>
            <?php $__currentLoopData = $sops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $subSops = DB::table('sub_sops')->where('sops_id', $sop->id)->get();
                    $colspan = count($subSops);
                ?>
                <th class="category-header" colspan="<?php echo e($colspan); ?>"><?php echo e($sop->name ?? ""); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
          <tr>
             <?php $__currentLoopData = $sops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $subSops = DB::table('sub_sops')->where('sops_id', $sop->id)->get();
                ?>
                 <?php $__empty_1 = true; $__currentLoopData = $subSops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <th><?php echo e($sub->name); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <th>---</th>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        </thead>
   
   <?php echo csrf_field(); ?>
<tbody>
    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $auth = Auth::user();
            $user_id = $auth->id;
            $user_ids = [$user_id];

            if ($auth->is_role == 1) {
                $user = DB::table('users')->where('id', $user_id)->first();
                if ($user && $user->created_by) {
                    $user_ids[] = $user->created_by;
                }
            } elseif (!in_array($auth->is_role, [0, 2])) {
                $user = DB::table('users')->where('id', $user_id)->first();
                if ($user) {
                    if ($user->created_by) $user_ids[] = $user->created_by;
                    if ($user->created_by1) $user_ids[] = $user->created_by1;
                }
            }

            $user_ids = array_unique($user_ids);
            $staffs = DB::table('staff_list')->whereIn('created_by', $user_ids)->get();
            $allSubSops = DB::table('sub_sops')->get()->groupBy('sops_id');
            $staffCount = $staffs->count();
        ?>

        <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $isFirst = ($index === 0);
                $isLast = ($index === $staffCount - 1);
                $rowClass = ($isFirst ? 'department-block-top ' : '') . ($isLast ? 'department-block-bottom' : '');
                $next = $staffs[$index + 1] ?? null;
                $endOfCategory = !$next || ($next->category_id ?? null) !== ($staff->category_id ?? null);
            ?>

            <tr class="<?php echo e($rowClass); ?>" style="<?php echo e($endOfCategory ? 'border-bottom: 2px solid #999;' : ''); ?>">
            <!--<?php if($index === 0): ?>-->
            <!--    <th class="sticky-col sticky-col-1" rowspan="<?php echo e($staffCount); ?>" style="padding: 0;">-->
            <!--        <div style="-->
            <!--            display: flex;-->
            <!--            align-items: center;-->
            <!--            justify-content: center;-->
            <!--            height: 100%;-->
            <!--            width: 100%;-->
            <!--            border-bottom: 1px solid black;-->
            <!--        ">-->
            <!--            <?php echo e($department->name ?? ''); ?>-->
            <!--        </div>-->
            <!--    </th>-->
            <!--<?php endif; ?>-->


                <th class="sticky-col sticky-col-2"><?php echo e($staff->name ?? ''); ?> (<?php echo e($department->name ?? ''); ?>)</th>

                <?php $__currentLoopData = $sops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $subSops = $allSubSops[$sop->id] ?? collect(); ?>

                    <?php $__empty_1 = true; $__currentLoopData = $subSops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $existingScore = DB::table('training_subsop_tni_scores')
                                ->where('department_id', $department->id)
                                ->where('staff_id', $staff->id)
                                ->where('sop_id', $sop->id)
                                ->where('sub_sop_id', $sub->id)
                                ->value('score');
                                
                                $role = auth()->user()->is_role;
                        ?>
                        <td>
                            <select
                                class="form-control competency-select"
                                data-staff-id="<?php echo e($staff->id); ?>"
                                data-sop-id="<?php echo e($sop->id); ?>"
                                data-sub-id="<?php echo e($sub->id); ?>"
                                data-dept-id="<?php echo e($department->id); ?>"
                                data-cat-id="<?php echo e($staff->category_id ?? ''); ?>"
                                <?php echo e($role != 2 ? 'disabled' : ''); ?>

                            >
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e($existingScore == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                <?php endfor; ?>
                                <option value="NA" <?php echo e($existingScore == 'NA' || $existingScore === null ? 'selected' : ''); ?>>N/A</option>
                            </select>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td>N/A</td>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>



      </table>
    </div>
  </div>
  
  <?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/training/rolewise_mapping/content.blade.php ENDPATH**/ ?>