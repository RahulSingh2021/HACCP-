
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/css/select2.min.css" rel="stylesheet" />
<!-- Add Loader HTML -->
<!--<div id="loader" style="display: none;">-->
<!--    <div class="spinner">-->
        <!-- Loader spinner, replace with your loader gif or CSS spinner -->
<!--       <img src="https://i.gifer.com/ZZ5H.gif" alt="Loading..." />-->
<!--    </div>-->
<!--</div>-->

<style type="text/css">
* {
    padding: 0px;
    margin: 0px;
    box-sizing: border-box;
}
.table-box-spc {
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 56px -37px #ccc;
}
.form-media {
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 56px -34px #ccc;
    margin-top: 29px;
}

.box-sedl-fst h6 {fi
    font-size: 16px;
    text-align: center;
}

.box-sedl-fst {
    display: flex;
    flex-direction: column;

}

/*.farst-box-full {*/
/*    margin-top: 131px;*/
/*}*/
.box-top {
    border: 1px solid #83a2c361;
    padding: 15px 15px;
    display: flex;
    justify-content: space-between;
    border-radius: 5px;
    background-color: #25cee208;
}

.box-sedl-fst a {
    font-size: 17px;
    color: #06115a;
    font-weight: 700;
}
.box-sedl-fst a:hover {
    font-size: 17px;
    color: #06115ada;
    font-weight: 700;
}
.content-tp-box {
    display: flex;
    width: 100%;
    justify-content: space-between;
}
.box-top.mt-3.box-img-content {
    display: block;
}
.img-box-set {
    padding-top: 25px;
}
.images-box {
    display: flex;
    justify-content: space-between;
}
.img-box-set img {
    height: 210px;
}
.box-top.mt-3.box-img-content {
    margin-bottom: 22px;
}
:nth-child(1) .box-border-1{
    border-left: 6px solid red;
}
:nth-child(1) .box-border-2{
    border-left: 6px solid rgb(17, 137, 146);
}
:nth-child(1) .box-border-3{
    border-left: 6px solid rgb(238, 129, 4);
}
:nth-child(1) .box-border-4{
    border-left: 6px solid rgb(197, 22, 145);
}
.tbale-top table {
    width: 100%;
}

.form-label{
    position: relative;
    display: flex;
    align-items: center;
    justify-content: left;
    padding: 10px 15px;
    color: #5f5f5f;
    outline-width: 0;
    transition: all .3s ease-out;
}

.tbale-top th {
    text-align: center;
    padding: 8px;
    background: #8e24aa;
    color: #fff;
}

.tbale-top td {
    padding: 8px;
    background: #ffffff24;
}
td.midlle-td {
    background: #efe0f3ee;
    text-align: center;
    font-weight: 700;
}
td.btm-tb-ssops {
    background: #efe0f3ee;
}
.list-conducted p {
    font-size: 18px;
    font-weight: 400;
    color: #645c87;
}

.list-conducted {
    background: #fff;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 16px;
    margin: 10px 0;
    width: 100%;
}
.form-media {
    max-width: 800px;
    margin: 5px auto;
}
.inputbtn-btm-btn {
    display: flex;
    justify-content: space-between;
    margin-top: 15px;
    margin-bottom: 20px;
}
.inputbtn-btm-btn .btn-yes-point-1,
.inputbtn-btm-btn .btn-yes-point-2,
.inputbtn-btm-btn .btn-yes-point-3 {
    width: 33.3333%;
    border: 1px solid #8e24aa61;
    color: #8e24aa;
    height: 42px;
    border-radius: 10px;
    background-color: #fff;
    margin: 10px;
}
.list-conducted ul {
    display: flex;
    justify-content: end;
    margin: 0;
    list-style: none;
}

.list-conducted ul li.attach-media {
    position: relative;
    width: 120px;
}
.list-conducted ul input {
    width: 100px;
}
.list-conducted ul a,
.list-conducted ul input {
    margin: 0px;
    border: 1px solid transparent;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    font-size: 0.875rem;
    line-height: 11px;
    transition: background-color 200ms;
    user-select: none;
    border-radius: 0.5rem;
    padding: 0.25rem 0.75rem;
    gap: 0.25rem;
    text-decoration: none;
    color: #6e6e72;
    background: transparent;
}
input[type="file"] {
    position: absolute;
    width: 100%;
    height: 100%;
    opacity: 0;
    z-index: 99999;
    cursor: pointer;
}
.attach-media span {
    color: #6e6e72;
}
.btn-save-attch a {
    justify-content: end;
    padding: 8px 43px;
    background: #8e24aa;
    color: #fff;
    border-radius: 10px;
    text-decoration: none;
    font-size: 18px;
}
.btn-save-attch a:hover {
    background: #8e24aae3;
    color: #fff;
}

.btn-save-attch {
    display: flex;
    justify-content: end;
}

.container, .container-lg, .container-md, .container-sm, .container-xl {
    max-width: 1260px !important;
}

.select-search--single {

        display: block;
    width: 100%;
    padding: .375rem .75rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: .25rem;
    transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
}


@media (max-width: 767px) {
    .img-box-set img {
        height: auto;
        width: 100%;
    }
    .box-top {
        display: block;
    }
    .images-box {
        display: block;
    }
    .content-tp-box {
       display: block;
    }
    .box-sedl-fst {
       width: 100%;
    }
    .box-sedl-fst {
        margin-top: 15px;
    }
}

@media (min-width: 768px) and (max-width:1024px) {
    .img-box-set img {
        height: 162px;
    }
    .box-sedl-fst h6 {
        font-size: 15px;
    }
    .box-sedl-fst a {
        font-size: 15px;
    }
}

/* Loader CSS */
#loader {
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: rgba(255, 255, 255, 0.7);
    display: flex;
    justify-content: center;
    align-items: center;
}

.spinner img {
    width: 50px;
    height: 50px;
}

.staticdiv span {
    display: block;
    line-height: 26px;
}
</style>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('content'); ?>
<div class="farst-box-full">
    <div class="col">
        <div class="card">
            <div class="card-body">
                   <?php $is_role = Auth::user()->is_role; ?>
                <!-- Tab Navigation -->
                <ul class="nav nav-pills nav-pills-success mb-3" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" href="<?php echo e(route('facility_hygiene')); ?>">
                            <div class="d-flex align-items-center">
                                <div class="tab-title">Equipment Master List</div>
                            </div>
                        </a>
                    </li>
                    
                     <?php if(($is_role ===0 || $is_role ===2) && empty($session_id)): ?>
                    <!--<li class="nav-item" role="presentation" style="margin-left: 20px;">-->
                    <!--    <a class="nav-link active" href="<?php echo e(route('facility_hygiene_fhmcat')); ?>">-->
                    <!--        <div class="d-flex align-items-center">-->
                    <!--            <div class="tab-title">Fhm Category</div>-->
                    <!--        </div>-->
                    <!--    </a>-->
                    <!--</li>-->
                    <?php endif; ?>

                    <li class="nav-item" role="presentation" style="margin-left: 20px;">
                        <a class="nav-link active" href="<?php echo e(route('facility_hygiene_cleaning_schedule')); ?>">
                            <div class="d-flex align-items-center">
                                <div class="tab-title">Cleaning Schedule</div>
                            </div>
                        </a>
                    </li>
                    
                    
	                <li class="nav-item" role="presentation" style="margin-left: 20px;">
                        <a class="nav-link active"  href="<?php echo e(route('facility_hygiene_pm_schedule')); ?>" >
                            <div class="d-flex align-items-center">
                             
                                <div class="tab-title">PM Schedule</div>
                            </div>
                        </a>
                    </li>
                    
                      <li class="nav-item" role="presentation" style="margin-left: 20px;">
                                            <a class="nav-link active"  href="<?php echo e(route('breakdown')); ?>" >
                                                <div class="d-flex align-items-center">
                                                 
                                                    <div class="tab-title">Breakdown</div>
                                                </div>
                                            </a>
                                        </li>
                                        
                                                    <li class="nav-item" role="presentation" style="margin-left: 20px;">
                                            <a class="nav-link active"  href="<?php echo e(route('templatetypelist','Cleaning')); ?>" >
                                                <div class="d-flex align-items-center">
                                                 
                                                    <div class="tab-title">Add Cleaning Check list</div>
                                                </div>
                                            </a>
                                        </li>
										
                </ul>

                <!-- Search Form -->
                <div class="tab-content">
                 
    
    <form action="" method="get" id="filter_form">
    <div class="row row-cols-auto g-3 mb-3 filter-box">
        
        <!-- Entries Selection -->
        <div class="col-1">
            <select class="form-select selectlocation select-search" name="entries" onchange="this.form.submit()">
                <option value="">Select entries</option>
                <?php $__currentLoopData = [1, 10, 20, 50, 75, 100, 200, 300]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($entry); ?>" <?php echo e(request('entries') == $entry ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

     
        
        <!-- Regional Selection -->
        <?php if($is_role == 2): ?>
            <div class="mb-2 col-md-2">
                <select name="regional_id" id="regional_id" class="form-control regional_id select-search" >
                    <option value="">Please Select Regional</option>
                    <?php
                        $regional_list = DB::table('users')->where('is_role', 1)->where('created_by', Auth::user()->id)->get();
                    ?>
                    <?php $__currentLoopData = $regional_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($regional->id); ?>" <?php echo e(request('regional_id') == $regional->id ? 'selected' : ''); ?>><?php echo e($regional->company_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php endif; ?>

        <!-- Unit Selection -->
        <?php if($is_role == 2 || $is_role == 1): ?>
            <div class="mb-2 col-md-2">
                <select name="unit_id" id="unit_id" class="form-control hotel_name select-search"  onchange="this.form.submit()">
                    <option value="">Please Select Unit</option>
                    <?php if(request('regional_id')): ?>
                        <?php
                            $unit_list = DB::table('users')->where('is_role', 3)->where('created_by1', request('regional_id'))->get();
                        ?>
                        <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($unit->id); ?>" <?php echo e(request('unit_id') == $unit->id ? 'selected' : ''); ?>><?php echo e($unit->company_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
        <?php endif; ?>
        
     

 <div class="col-2">
            <select class="form-select select-search" name="department" onchange="this.form.submit()">
                <option value="">Department</option>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($department->id ?? ''); ?>" <?php echo e(( $department->id == @$_GET['department']) ? 'selected' : ''); ?>><?php echo e($department->name); ?> (<?php echo e(Helper::userInfoShortName($department->unit_id ?? '')); ?>)</option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Location and Other Filters (unchanged) -->
        <div class="col-2">
            <select class="form-select select-search" name="location" onchange="this.form.submit()">
                <option value="">Location</option>
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($location->id); ?>" <?php echo e(request('location') == $location->id ? 'selected' : ''); ?>><?php echo e($location->name); ?> (<?php echo e(Helper::userInfoShortName($location->created_by ?? '')); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!--<div class="col-2">-->
        <!--    <select class="form-select select-search" name="sublocation" onchange="this.form.submit()">-->
        <!--        <option value="">Select SubLocation</option>-->
        <!--        <?php if(!empty($sub_location)): ?>-->
        <!--            <?php $__currentLoopData = $sub_location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subloc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
        <!--                <option value="<?php echo e($subloc->id); ?>" <?php echo e(request('sublocation') == $subloc->id ? 'selected' : ''); ?>><?php echo e($subloc->name); ?></option>-->
        <!--            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
        <!--        <?php endif; ?>-->
        <!--    </select>-->
        <!--</div>-->

        <div class="col-2">
            <select class="form-select select-search" name="responsibilitys" onchange="this.form.submit()">
                <option value="">Responsibility</option>
                <?php $__currentLoopData = $responsibility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($resp->id); ?>" <?php echo e(request('responsibilitys') == $resp->id ? 'selected' : ''); ?>><?php echo e($resp->name); ?> (<?php echo e(Helper::userInfoShortName($resp->unit_id ?? '')); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-2">
            <select class="form-select selectconcern select-search" name="status" onchange="this.form.submit()">
                <option value="">Select Status</option>
                <?php $__currentLoopData = ['missed', 'active', 'upcoming', 'completed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>><?php echo e(ucfirst($status)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-2 col-md-2">
            <select class="form-select selectconcern select-search" name="equipment" onchange="this.form.submit()">
                <option value="">Select Equipment Name</option>
                <?php $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($equip->id); ?>" <?php echo e(request('equipment') == $equip->id ? 'selected' : ''); ?>><?php echo e($equip->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-2"><input type="date" name="s_date" value="<?php echo e(request('s_date')); ?>" class="form-control" onchange="this.form.submit()"></div>
        <div class="col-md-2"><input type="date" name="e_date" value="<?php echo e(request('e_date')); ?>" class="form-control" onchange="this.form.submit()"></div>

        <div class="col-md-4">
            <a class="btn btn-outline-dark px-3" href="<?php echo e(url()->current()); ?>">Clear Filter</a>
            <!--<button type="submit" class="btn btn-outline-dark px-3">Filter</button>-->
            <!--<a class="btn btn-outline-dark px-3" onclick="createPDF()">Export to PDF</a>-->
            <a href="<?php echo e(route('fhm-cleaning-export')); ?>" class="btn btn-primary px-3" download> Export</a>
        </div>
    </div>
</form>

                </div>

                <!-- Schedule List -->
                <div style="margin-top:10px">
                                          <table  class="table table-bordered" style="border: 2px solid #fff;">
                              <thead>
      <tr style="padding: 9px !important;background: #156080 !important;color: #fff;height: 47px;">
          
            <!--<th scope="col" style="text-align: center; margin: 30px !important;padding: 9px;vertical-align: middle;">SI.No</th>-->

            
              <th style="width: 10%;">Scheduled Date
        
            </th>
            
             <th style="width: 15%;">Equipment Details
        
            </th>
            
            <th style="width: 50%;">Cleaning Check list
        
            </th>
            
        
            
             <th style="width: 5%;">Evidence
        
            </th>
            
               <th >Completed By</th>
               <th >Verfied by</th>

                                                                 
      </tr>
    </thead>
       <tbody>
           <?php if($cleaning_schedule && count($cleaning_schedule) > 0): ?>
                            <?php $__currentLoopData = $cleaning_schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $facility_equipment = DB::table('facility_equipment')->where('id', $schedule->facility_equipment_id ?? '')->first();
                                    $responsibilityName = DB::table('authority')->where('id', $facility_equipment->responsibility_id ?? '')->value('name');
                                    
                                    
                                    $nextDueDate = DB::table('facility_equipment_cleaning_schedules')
    ->where('facility_equipment_id', $schedule->facility_equipment_id) // Same equipment ka record filter
    ->where('cleaning_task_start_date', '>', function ($query) use ($schedule) {
        $query->select('cleaning_task_start_date')
            ->from('facility_equipment_cleaning_schedules')
            ->where('id', $schedule->id);
    })
    ->value('cleaning_task_start_date');
    
    
    
                                ?>
    <tr style="background: #cdd2d8;">
        <td>  <div class="">
                                        <h6>Date:<br/> <?php echo e($schedule->cleaning_task_start_date); ?> </h6>
                                        <h6>(<?php echo e(\Carbon\Carbon::parse($schedule->cleaning_task_start_date)->format('l')); ?>)</h6>
                                        
                                        <h6>Next Due Date:<br/> <?php echo e($nextDueDate ?? ''); ?> </h6>
                                        <h6>(<?php echo e(\Carbon\Carbon::parse($nextDueDate ?? '')->format('l')); ?>)</h6>
                                        
                                    </div>
                               </td>
        <td>   <div class="">
                                        <h6>Equipment Name: <?php echo e($facility_equipment->name ?? ''); ?></h6>
                                        <h6>Equipment ID: <?php echo e($facility_equipment->equipment_id  ?? ''); ?></h6>
                                        <h6>Status: <?php echo e($schedule->status ?? 'Active/Inactive'); ?></h6>
                                        
                                        
                                            <?php $AddChecklist = DB::table('template_equpiments')->where('equpiments',$schedule->facility_equipment_id)->first(); ?>
                <?php if(!empty($AddChecklist)): ?>
       
            <?php    $equpiments3 = DB::table('template_question')->where('template_id', $AddChecklist->template_id)->value('cleaning_frequency'); ?>
                <?php else: ?>
                 <?php $equpiments3=''; ?>

                <?php endif; ?>
                
                
                                        
                             
                                
                                                              
                                        <h6>Frequency: <?php echo e($equpiments3 ?? ''); ?>,(<?php echo e($facility_equipment->c_frequency ?? ''); ?>)</h6>
                                        
                                        <a  href="<?php echo e(route('Calibration_history', $facility_equipment->id ?? '')); ?>" >
   View History
</a>

                                    </div></td>
        <td style="padding: 0;">                   <?php $AddChecklist = DB::table('template_equpiments')->where('equpiments',$schedule->facility_equipment_id)->first(); ?>
                <?php if(!empty($AddChecklist)): ?>
                <br>
                <?php
                $questionlist = DB::table('template_question')->where('type', "1")->where('template_id', $AddChecklist->template_id)->get();
                
                ?>
                
                <?php $colorIndex = 0; ?>

<?php $__currentLoopData = $questionlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionlists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $color = $colorIndex % 2 == 0 ? '' : '#e6eaed';
        $colorIndex++;
    ?>
    <p style="background-color: <?php echo e($color); ?>;margin: 0px !important "><span style="margin: 8px !important;font-size: 14px !important;display: inline-block;line-height: 24px;"><?php echo e($questionlists->question ?? ''); ?></span>:Yes</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                -

                <?php endif; ?></td>

        <td><button class="btn btn-primary px-3" style="background: #155f82;">Video</button></td>
<td>
<div class="staticdiv" style="text-align: center;font-weight: 500;line-height: 16px;">

<span>C D:12:02:2025</span>
<span>(Sunday)</span>
<span>By: Mr. Shreekant Prasad</span>
<span>Sign</span>
<span>Comments:Found ok</span>
</div></td>  
<td>
<div class="staticdiv" style="text-align: center;font-weight: 500;line-height: 16px;">
<span>V D:16:02:2025</span>
<span>(Sunday)</span>
<span>By: Mr. Shreekant Prasad</span>
<span>Sign:</span>
<span>Comments:Found ok</span>

</div></td>
        
    </tr>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No cleaning schedules available at the moment.</p>
                        <?php endif; ?>


       </tbody>
                              </table>
                    <div class="container-fluid"  id="htmlContent1" style="display:none;">
                        

                        <?php if($cleaning_schedule && count($cleaning_schedule) > 0): ?>
                            <?php $__currentLoopData = $cleaning_schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $facility_equipment = DB::table('facility_equipment')->where('id', $schedule->facility_equipment_id ?? '')->first();
                                    $responsibilityName = DB::table('authority')->where('id', $facility_equipment->responsibility_id ?? '')->value('name');
                                ?>

                                <div class="box-top box-border-1">
                                    <!-- Schedule Details -->
                                    <div class="">
                                        <h6>Cleaning Scheduled Date:<br/> <?php echo e($schedule->cleaning_task_start_date); ?> <?php echo e($schedule->id); ?></h6>
                                        <h6><?php echo e(\Carbon\Carbon::parse($schedule->cleaning_task_start_date)->format('l')); ?></h6>
                                    </div>
                                    <div class="">
                                        <h6>Equipment Name: <?php echo e($facility_equipment->name ?? ''); ?></h6>
                                        <h6>Brand: <?php echo e($facility_equipment->brand ?? ''); ?></h6>
                                        <h6>Equipment ID: <?php echo e($facility_equipment->equipment_id  ?? ''); ?></h6>
                                        <h6>Status: <?php echo e($schedule->status ?? 'Active/Inactive'); ?></h6>
                                        <a href="<?php echo e(route('facility_hygiene_cleaning_schedule_history',$schedule->facility_equipment_id)); ?>">View History</a>
                                    </div>
                                    <div class="">
                                     
                          
                                    <?php 
                                    $result = DB::table('users')->where('id',$schedule->created_by)->first();
                                    
                                    $corporate_id = $result->created_by ?? 0;
                                    $regional_id = $result->created_by1 ?? 0;
                                    ?>
                                      <h6>Corporate: <?php echo e(Helper::user_info($corporate_id)->company_name ?? 'N/A'); ?></h6>
                                    <h6>RegionalName: <?php echo e(Helper::user_info($regional_id)->company_name ?? 'N/A'); ?></h6>
                             
                                    <h6>Unit: <?php echo e(Helper::user_info($schedule->created_by)->company_name ?? 'N/A'); ?></h6>
                                   
                                    
                                    
                                    
             


                                        <h6>Department:
                                       <?php if(isset($facility_equipment) && $facility_equipment->department): ?>
                                            <?php echo e(Helper::departmentName($facility_equipment->department) ?? 'NA'); ?>

                                        <?php else: ?>
                                            --
                                        <?php endif; ?>

                                        </h6>
                                        <h6>Location:
                                         <?php if(isset($facility_equipment) && $facility_equipment->location_id): ?>
                                            <?php echo e(Helper::locationName($facility_equipment->location_id) ?? 'NA'); ?>

                                        <?php else: ?>
                                            --
                                        <?php endif; ?>
                                        </h6>
                                    </div>
                                    <div class="">
                                        <h6>Frequency in days: <?php echo e($facility_equipment->c_frequency  ?? ''); ?></h6>
                                    </div>
                                    <div class="">
                                        <!-- Schedule Status -->
                                        <?php if(\Carbon\Carbon::parse($schedule->cleaning_task_start_date)->lt(\Carbon\Carbon::now()->subDays(2)) && empty($schedule->cleaning_task_end_date)): ?>
                                            <h6>Missed</h6>
                                        <?php elseif(!empty($schedule->cleaning_task_end_date)): ?>
                                            <h6>Attended</h6>
                                        <?php elseif(\Carbon\Carbon::parse($schedule->cleaning_task_start_date)->gt(\Carbon\Carbon::now()->addDays(3))): ?>
                                            <h6>Upcoming</h6>
                                        <?php else: ?>
                                         <h6> Active</h6>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No cleaning schedules available at the moment.</p>
                        <?php endif; ?>

                        
                       

                    </div>
                    
                     <?php if($cleaning_schedule->total() > 1 && $cleaning_schedule->count() > 0): ?>
    <nav aria-label="Page navigation mt-4">
        <ul class="pagination justify-content-center">
            <?php echo e($cleaning_schedule->links()); ?>

        </ul>
    </nav>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerscript'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!-- jQuery and Select2 JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/js/select2.min.js"></script>
<script>
    $(document).ready(function(){
        $('#loader').show();
        
        $(window).on('load', function(){
            $('#loader').fadeOut('slow');
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('.select-search').select2({
            // placeholder: "Select entries",
            // allowClear: true
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['pagetitle'=>'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/fhm/cleaning_schedule.blade.php ENDPATH**/ ?>