<?php

// This class file to define all general functions
namespace App\Library\Helper;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Models\User;

use Protocol;

/**
* Helper Class
*/
class Helper
{

    /************ Make Database date readable ************/
    public static function date_ago($date)
    {
        return Carbon::createFromFormat('Y-m-d H:i:s', $date)->diffForHumans();
    }

    /*********** Date format IN d/m/Y ***************/
    public static function dateformatDmy($date)
    {
        return Carbon::parse($date)->format('d/m/Y');
    }

    /*********** Date format string IN M d, Y ***************/
    public static function dateformatmdy($date)
    {
        return Carbon::parse($date)->format('M d, Y');
    }

    /*********** Date format IN d/m/Y ***************/
    public static function date_string($date)
    {
        return Carbon::parse($date)->format('d/m/Y');
    }

    /*********** Date format ***************/
    public static function dateFormat($date)
    {
        return Carbon::parse($date)->format('M-d-Y');
    }

    /*********** Date format (june 09,2018) ***************/
    public static function dateFormatMdYs($date)
    {
        return Carbon::parse($date)->format('M d,Y');
    }

    /*********** Date format ***************/
    public static function timeFormat($time)
    {
        return Carbon::parse($time)->format('h:i:s A');
    }

    /*********** Time format for order ***************/
    public static function ordertimeFormat($time)
    {
        return Carbon::parse($time)->format('h:i a');
    }

    /*********** Month Date format ***************/
    public static function dateFormatMonth($date)
    {
        return Carbon::parse($date)->format('M');
    }

    /*********** Date format ***************/
    public static function dateformatDate($date)
    {
        return Carbon::parse($date)->format('d');
    }


    /*********** Week format ***************/
    public static function weekFormat($date)
    {
        return Carbon::parse($date)->format('l');
    }

    /*********** Time format ***************/
    public static function formatTime($time)
    {
        return Carbon::parse($time)->format('H:i');
    }

    /**
     * String Date
     */
    public static function dateToFormatted($date)
    {
        return Carbon::parse($date)->toFormattedDateString();
    }


    /*********** Created date format ***************/
    public static function createdformatDate($date)
    {
        return Carbon::parse($date)->format('H:i');
    }



	
	
    /*********** ResponsibilityName ***************/
    public static function ResponsibilityName($id)
    {
		return DB::table('authority')->where('id',$id)->pluck('name')->first();
    }
	
	
	   /*********** CorporateName ***************/
    public static function CorporateName($id)
    {
		return User::where('id',$id)->pluck('company_name')->first();
    }
	
	
		   /*********** RegionalName ***************/
    public static function RegionalName($id)
    {
		return User::where('created_by',$id)->pluck('company_name')->first();
    }
	
	
		   /*********** UnitName ***************/
    public static function UnitName($id)
    {
		return User::where('created_by1',$id)->pluck('company_name')->first();
    }
	
	
			   /*********** Loginid ***************/
    public static function Loginid($id)
    {
		return User::where('id',$id)->pluck('login_id')->first();
    }
	
	
	
	    public static function refrences()
    {
			return DB::table('refrences')->get();
    }
	
	
		    public static function Ingredients($type)
    {
			return DB::table('product_Ingredients')->where('type',$type)->get();
    }
	
	
			    public static function IngredientsName($id)
    {
			return DB::table('product_Ingredients')->where('id',$id)->pluck('name')->first();
    }
	
	
			    public static function Ingredientsimage($id)
    {
			return DB::table('product_Ingredients')->where('id',$id)->pluck('company_logo')->first();
    }
				    public static function refrencesName($id)
    {
			
			return DB::table('refrences')->where('id',$id)->pluck('name')->first();
    }
	
	
					    public static function refrencesName1($id)
    {
			
			return DB::table('refrences')->where('id',$id)->pluck('name')->first();
    }
	
				    public static function RecipeSlug($id)
    {
			return DB::table('Recipe')->where('id',$id)->pluck('slug')->first();
    }
    
    
    				    public static function IngredientsLogo($id)
    {
			 $ID = DB::table('Ingredient')->where('id',$id)->pluck('Ingredients_Symbol')->first();
			return DB::table('product_Ingredients')->where('id',$ID)->pluck('name')->first();
    }
    
    				    public static function RecipeServiceSize($id)
    {
			return DB::table('Recipe')->where('id',$id)->pluck('serving_size')->first();
    }
	
	

}
