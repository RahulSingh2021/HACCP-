<style>
.tbale-top table {
    width: 100%;
}

.tbale-top th {
    text-align: center;
    padding: 6px;
    background: #35078f;
    color: #fff;
}

.tbale-top td {
    padding: 6px;
    border: 1px solid #35078f36;
    background: #ffffff;
}
td.midlle-td {
    background: #dae7f16b;
    text-align: center;
    font-weight: 700;
}
td.btm-tb-ssops {
    background: #e6eaed;
}
.sec-box-table td {
    padding: 22px 15px;
    font-weight: 500;
    font-size: 17px;
    text-align: center;
    padding: 14px;
}
.fst-tbl-box th {
    background: #e6eaed;
    color: #000;
    border: 1px solid #000;
    border-top: none;
}
.fst-tbl-box th:first-child {
    border-left: none;
    border-top: none;
    border-right: none;
}
.fst-tbl-box th:last-child {
    border-left: none;
    border-top: none;
    border-right: none;
}
.fst-table-td td {
    background: #dae7f16b;
    color: #000;
    border: 1px solid #35078f36;
    border-top: none;
    text-align: center;
    width: 88px;
}
.fst-table-td td:last-child {
    border-right: none;
}
/*.fst-table-td td:first-child {*/
/*    border-left: none;*/
    /* width: 40px; */
/*    font-weight: 500;*/
/*    width: 206px;*/
/*    font-size: 18px;*/
/*}*/
.forth-tble th {
    background-color: #35078f;
    color: #ffffff;
    border: 1px solid #fff;
}
.forth-tble-tr-td td {
    padding: 17px;
}
.forth-tbl-btm th {
    background: #ffffff;
    color: #000;
}
.btm-colam-fst td {
    padding: 8px;
    background: #ffffff;
    border: 1px solid #d9cbdb;
    text-align: center;
}
tr.forth-tble-tr-td.table-4 td {
    padding: 6px;
    font-weight: 700;
}
tr.btm-colam-fst.table-6 td {
    padding: 6px;
    text-align: center;
    color: #000;
}
.tbale-top table {
    width: 100%;
    min-width: 950px;
    overflow-x: auto;
}
tr.btm-colam-fst.table-7 td {
    background: white;
}
tr.forth-tbl-btm.table-5 th {
    border: 1px solid #c1c1c1;
}
.forth-tble-tr-td td {
    text-align: center;
    padding: 5px;
    font-weight: 500;
    background: #eff5f9;
}
.table-5 td {
    padding: 9px;
}
td.set-size {
    width: 339px;
}

td.set-size1 {
    width: 396px;
}
.table-fst-boxes {
    padding: 20px;
    margin-top: 30px;
    background: #fff;
    box-shadow: 0px 0px 80px -33px #ccc;
    border-radius: 10px;
}
.second-table-box{
    padding: 20px;
    margin-top: 30px;
    background: #fff;
    box-shadow: 0px 0px 80px -33px #ccc;
    border-radius: 10px;
}

.thrd-table-boxes{
    padding: 20px;
    margin-top: 30px;
    background: #fff;
    box-shadow: 0px 0px 80px -33px #ccc;
    border-radius: 10px;
}
.forth-table-boxes{
    padding: 20px;
    margin-top: 30px;
    background: #fff;
    box-shadow: 0px 0px 80px -33px #ccc;
    border-radius: 10px;
}

</style>
<?php $__env->startSection('content'); ?>
     <div class="container" style="margin-top:135px">
 <div class="tbale-top mb-5">
    <div class="table-fst-boxes">
    <table>
       <thead>
    <?php
        $facility_equipment = DB::table('facility_equipment')->where('id', $id)->first();
        $responsibilityName = DB::table('authority')->where('id', $facility_equipment->responsibility_id ?? '')->value('name');
    ?>
    <tr>
        <th colspan="3">
            <div style="position: relative;">
                <a href="javascript:history.back()" style="position: absolute; left: 0; top: 0;">
                  <<  Back
                </a>
                <span style="display: block; text-align: center;">Equipment Name: <?php echo e($facility_equipment->name ?? ''); ?></span>
            </div>
        </th>
    </tr>
</thead>

        <tbody>
            <tr class="sec-box-table">
                <td>Make/Brand Name: <?php echo e($facility_equipment->brand ?? ''); ?></td>
                <td>Equipment ID: <?php echo e($facility_equipment->equipment_id ?? ''); ?></td>
                <td>Location: 
                <?php if(!empty($facility_equipment->location_id)): ?>
                <?php echo e(Helper::locationName($facility_equipment->location_id) ?? 'NA'); ?>

                <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td colspan="3" class="midlle-td">Special Cleaning Schedule</td>
            </tr>
            <tr class="sec-box-table">
                <td class="set-size1">Frequency: <?php echo e($facility_equipment->c_frequency ?? ''); ?></td>
                <td>Responsibility: <?php echo e($responsibilityName ?? ''); ?></td>
                <td class="set-size">Tools & Chemical:</td>
            </tr>
          </tbody>

    </table>
   <table>
 <?php if($cleaning_schedules && count($cleaning_schedules) > 0): ?>
    <?php $__empty_1 = true; $__currentLoopData = $cleaning_schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            $facility_equipment = DB::table('facility_equipment')->where('id', $schedule->facility_equipment_id ?? '')->first();
            $responsibilityName = DB::table('authority')->where('id', $facility_equipment->responsibility_id ?? '')->value('name');
            $completedByName = DB::table('users')->where('id', $schedule->scheduled_by)->value('name');

        ?>
        <tr class="fst-table-td">
            <td>Scheduled At: <?php echo e($schedule->cleaning_task_start_date ?? 'N/A'); ?></td>
            <td>Completed On: <?php echo e($schedule->cleaning_task_end_date ?? 'N/A'); ?></td>
            <td>Completed At: <?php echo e($schedule->cleaning_task_end_time ? \Carbon\Carbon::createFromFormat('H:i:s', $schedule->cleaning_task_end_time)->format('h:i A') : 'N/A'); ?></td>
            <td>Completed By: <?php echo e($completedByName ?? 'N/A'); ?></td>
            <td>
                <?php if(\Carbon\Carbon::parse($schedule->cleaning_task_start_date)->isToday()): ?>
                    Status: Scheduled for today
                <?php elseif(empty($schedule->cleaning_task_end_date)): ?>
                    Status: Missed
                <?php else: ?>
                    Status: Attended
                <?php endif; ?>
            </td>
          
           <td>
    
            <?php if($schedule->image): ?>
                <?php
                    $images = explode(',', $schedule->image);
                ?>
            
                <div class="image-gallery">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageIndex => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal<?php echo e($loop->parent->index ?? 0); ?>_<?php echo e($imageIndex); ?>">
                            <img style="height:50px;width:50px;border-radius:20px" src="https://efsm.safefoodmitra.com/admin/public/<?php echo e(trim($image)); ?>" alt="Image" />
                        </a>
                        <div class="modal fade" id="imageModal<?php echo e($loop->parent->index ?? 0); ?>_<?php echo e($imageIndex); ?>" tabindex="-1" aria-labelledby="imageModalLabel<?php echo e($loop->parent->index ?? 0); ?>_<?php echo e($imageIndex); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-hecader">
                                        <h5 class="modal-title" id="imageModalLabel<?php echo e($loop->parent->index ?? 0); ?>_<?php echo e($imageIndex); ?>">Image</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <img src="https://efsm.safefoodmitra.com/admin/public/<?php echo e(trim($image)); ?>" alt="Image" style="max-width:100%; height:auto; max-height: 80vh;" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                Image N/A
            <?php endif; ?>
</td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5">No cleaning schedules available at the moment.</td>
        </tr>
    <?php endif; ?>
<?php else: ?>
    <tr>
        <td colspan="5">No cleaning schedules found.</td>
    </tr>
<?php endif; ?>

        
    </table>
</div>
<!--<div class="second-table-box">-->
<!--    <table>-->
<!--        <tr class="forth-tble">-->
<!--            <th colspan="9">Calibration History</th>-->
<!--        </tr>-->
<!--        <tr class="forth-tble-tr-td">-->
<!--            <td colspan="9">Frequency: Yearly										-->
<!--            </td>-->
<!--        </tr>-->
<!--        <tr class="forth-tble-tr-td">-->
<!--            <td colspan="9">Calibration: 1										-->
<!--            </td>-->
<!--        </tr>-->
     
<!--        <tr class="btm-colam-fst">-->
<!--            <td>Unique Id:</td>-->
<!--            <td>Type: Temperature Indicator</td>-->
<!--            <td>Capacity Range: (-30 to +50°C)</td>-->
<!--            <td>Current utility Range: (-18 to -22°C)</td>-->
<!--            <td>Calibration Range: (+10 to -22)</td>-->
<!--            <td>Least Count: 1</td>-->
            
<!--        </tr>-->
<!--        <tr class="btm-colam-fst">-->
<!--            <td>Calibration Date:</td>-->
<!--            <td colspan="2">Certificate Number:</td>-->
<!--            <td>Calibration Due Date:</td>-->
<!--            <td>Calibration Status: Expired</td>-->
<!--            <td>View Certificate</td>-->
        
<!--        </tr>-->
<!--        <tr class="btm-colam-fst">-->
<!--            <td>Calibration Date</td>-->
<!--            <td colspan="2">Certificate Number:</td>-->
<!--            <td>Calibration Due Date:</td>-->
<!--            <td>Calibration Status: Expired</td>-->
<!--            <td>View Certificate</td>-->
            
        
<!--        </tr>-->
        
<!--    </table>-->
<!--</div>-->
<!--<div class="thrd-table-boxes">-->
<!--    <table>-->
<!--        <tr class="forth-tble table-3">-->
<!--            <th colspan="5">PM: Yes</th>-->
<!--        </tr>-->
<!--        <tr class="forth-tble table-ten">-->
<!--            <th colspan="5">Frequency: Monthly</th>-->
<!--        </tr>-->
        
<!--        <tr class="forth-tbl-btm table-5">-->
<!--            <th>Completion Date:</th>-->
<!--            <th>View Report :</th>-->
<!--            <th>Comments:</th>-->
            
            
<!--        </tr>-->

<!--   </table>-->
<!--</div>-->
<!--<div class="forth-table-boxes">-->
<!--   <table>-->
<!--    <tr class="fives-tble table-3">-->
<!--        <th colspan="6">Break down: Yes</th>-->
<!--    </tr>-->
<!--   <tr class="fives-tbl-btm table-5">-->
<!--        <td>Date:</td>-->
<!--        <td>Reason </td>-->
<!--        <td>Tentative Completion</td>-->
<!--        <td>date Completed on</td>-->
<!--        <td>Completed on</td>-->
<!--        <td>Cost</td>-->
        
        
<!--    </tr>-->

<!--</table>-->
<!--</div>-->

</div>
</div>



<?php $__env->startSection('footerscript'); ?>

<?php echo $__env->make('layouts.app', ['pagetitle'=>'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/fhm/cleaning_schedule_history.blade.php ENDPATH**/ ?>