@extends('layouts.app', ['pagetitle'=>'Dashboard'])

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Bootstrap 5 CSS (from FSSAI page - will affect License tab) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-fssai-style">

    <style>
    
    .btn i {
     vertical-align: middle; 
     
        margin-top: 0px !important; 
     margin-bottom: 0px !important; 
     margin-right: 5px; 
}

        /* Main Tab Interface Styles */
        body.main-tab-interface {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }

        .tabs-container-main { /* Renamed to avoid conflict with FSSAI's .container */
            max-width: 95%; /* Wider to accommodate FSSAI content */
            margin: 20px auto;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .tabs-nav-main { /* Renamed */
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            background-color: #e9ecef;
            border-bottom: 1px solid #dee2e6;
        }

        .tabs-nav-main li {
            flex-grow: 1;
        }

        .tabs-nav-main li button {
            width: 100%;
            padding: 15px 10px;
            border: none;
            background-color: transparent;
            color: #495057;
            cursor: pointer;
            font-size: 0.9em;
            text-align: center;
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
            border-bottom: 3px solid transparent;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .tabs-nav-main li button i {
            margin-right: 8px;
        }

        .tabs-nav-main li button:hover {
            background-color: #dee2e6;
            color: #212529;
        }

        .tabs-nav-main li button.active {
            background-color: #fff;
            color: #007bff;
            font-weight: bold;
            border-bottom-color: #007bff;
        }

        .tabs-nav-main li button#tab-dashboard.active {
            background-color: transparent;
            color: #495057;
            font-weight: bold;
            border-bottom-color: #ffc107;
        }
        .tabs-nav-main li button#tab-dashboard.active:hover {
            background-color: #dee2e6;
        }

        .tabs-nav-main li button:focus {
            outline: 2px solid #007bff;
            outline-offset: -2px;
        }

        .tabs-content-main { /* Renamed */
            padding: 0; /* Remove padding to allow FSSAI container to manage its own */
        }

        .tab-panel-main { /* Renamed */
            display: none;
            animation: fadeInMain 0.5s ease-in-out;
            /* Padding will be handled by content within, esp. for FSSAI */
        }
        /* Ensure FSSAI panel takes full width and applies its styles */
        #panel-license {
            padding: 0; /* Reset padding here */
        }


        .tab-panel-main.active {
            display: block;
        }

        /* Generic content panel styling for non-FSSAI tabs */
        .tab-panel-main:not(#panel-license) {
            padding: 20px;
        }
        .tab-panel-main:not(#panel-license) h2 {
            margin-top: 0;
            color: #333;
            display: flex;
            align-items: center;
        }
        .tab-panel-main:not(#panel-license) h2 i {
            margin-right: 8px;
            color: #007bff;
        }


        @keyframes fadeInMain {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .tabs-nav-main {
                overflow-x: auto;
                overflow-y: hidden;
                white-space: nowrap;
                -webkit-overflow-scrolling: touch;
            }
            .tabs-nav-main li {
                flex-grow: 0;
                flex-shrink: 0;
            }
            .tabs-nav-main li button {
                padding: 12px 15px;
            }
        }

        /* ================================= */
        /* ===== FSSAI EMBEDDED CSS ====== */
        /* ================================= */
        #panel-license .fssai-content-wrapper { /* Wrapper to contain FSSAI styles */
            /*font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa; /* This might be overridden by tab container */
            /*color: #495057;
            line-height: 1.6;
            padding-top: 20px; /* Let FSSAI container handle this */
        }


        /* FSSAI specific global styles - these might conflict or affect other tabs if not scoped */
        #panel-license :root { /* This won't work as expected when embedded. Define vars directly or scope. */
            --primary-color: #2c5f9e;
            --primary-light: #e1eaf2;
            --secondary-color: #f58220;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #17a2b8;
            --dark-color: #343a40;
            --light-color: #f8f9fa;
            --gray-color: #6c757d;
            --border-color: #dee2e6;
            --shadow-sm: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            --shadow-md: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            --transition: all 0.3s ease;
        }
        /* More specific selector for FSSAI container if :root causes issues */
        #panel-license .fssai-container-embed {
            --primary-color: #2c5f9e;
            --primary-light: #e1eaf2;
            --secondary-color: #f58220;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --info-color: #17a2b8;
            --dark-color: #343a40;
            --light-color: #f8f9fa;
            --gray-color: #6c757d;
            --border-color: #dee2e6;
            --shadow-sm: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            --shadow-md: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            --transition: all 0.3s ease;

            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: white; /* FSSAI page's container background */
            color: #495057;
            line-height: 1.6;
            padding-top: 0px; /* Let FSSAI container handle this */
            max-width: 100%; /* Override FSSAI's max-width if needed */
            /* background-color: white; /* Overridden by .tabs-container-main? */
            border-radius: 0; /* FSSAI content is inside tab, remove its rounding */
            box-shadow: none; /* Remove FSSAI container shadow, tab container has it */
            padding: 25px;
            margin-bottom: 0px; /* No bottom margin inside tab */
        }


        #panel-license .fssai-container-embed h1,
        #panel-license .fssai-container-embed h2,
        #panel-license .fssai-container-embed h3,
        #panel-license .fssai-container-embed h4,
        #panel-license .fssai-container-embed h5,
        #panel-license .fssai-container-embed h6 {
            color: var(--dark-color, #343a40); /* Use fallback if var not defined */
            font-weight: 600;
        }

        #panel-license .page-header {
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color, #dee2e6);
        }

        #panel-license .cards-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        #panel-license .dashboard-card {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: var(--shadow-sm, 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075));
            border-left: 4px solid transparent;
            transition: var(--transition, all 0.3s ease);
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        #panel-license .dashboard-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-md, 0 0.5rem 1rem rgba(0, 0, 0, 0.15));
        }

        #panel-license .dashboard-card-green { border-left-color: var(--success-color, #28a745); }
        #panel-license .dashboard-card-orange { border-left-color: var(--warning-color, #ffc107); }
        #panel-license .dashboard-card-blue { border-left-color: var(--info-color, #17a2b8); }
        #panel-license .dashboard-card-red { border-left-color: var(--danger-color, #dc3545); }
        #panel-license .dashboard-card-gray { border-left-color: var(--gray-color, #6c757d); }


        #panel-license .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--dark-color, #343a40);
            margin-bottom: 15px;
        }

        #panel-license .card-status-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        #panel-license .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        #panel-license .status-compliant {
            background-color: rgba(40, 167, 69, 0.1);
            color: var(--success-color, #28a745);
        }

        #panel-license .status-due-soon {
            background-color: rgba(255, 193, 7, 0.1);
            color: var(--warning-color, #ffc107);
        }

        #panel-license .status-expired {
            background-color: rgba(220, 53, 69, 0.1);
            color: var(--danger-color, #dc3545);
        }
         #panel-license .status-pending { /* This class name is duplicated, ensure proper usage */
            background-color: rgba(23, 162, 184, 0.1);
            color: var(--info-color, #17a2b8);
         }

        #panel-license .due-date {
            font-size: 0.85rem;
            color: var(--gray-color, #6c757d);
        }

        #panel-license .progress-container {
            margin-bottom: 10px;
        }

        #panel-license .progress-bar {
            background-color: #e9ecef;
            border-radius: 5px;
            height: 8px;
            overflow: hidden;
        }

        #panel-license .progress-fill {
            height: 100%;
            border-radius: 5px;
            transition: width 0.5s ease-in-out;
        }

        #panel-license .progress-fill-green { background-color: var(--success-color, #28a745); }
        #panel-license .progress-fill-orange { background-color: var(--warning-color, #ffc107); }
        #panel-license .progress-fill-blue { background-color: var(--info-color, #17a2b8); }
        #panel-license .progress-fill-red { background-color: var(--danger-color, #dc3545); }


        #panel-license .card-info-row {
            display: flex;
            justify-content: flex-end;
            font-size: 0.85rem;
            color: var(--gray-color, #6c757d);
            margin-bottom: 15px;
        }

        /* ====== TABLE STYLES ====== */
        #panel-license .table-section {
            margin-top: 30px;
        }

        #panel-license .table-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
            align-items: center;
        }

        #panel-license .table-responsive {
            border-radius: 8px;
            overflow-x: auto;
            box-shadow: var(--shadow-sm, 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075));
        }

        #panel-license .table {
            margin-bottom: 0;
            min-width: 1200px;
        }

        #panel-license .table th {
            background-color: var(--primary-color, #2c5f9e);
            color: white;
            font-weight: 500;
            padding: 12px 15px;
            vertical-align: middle;
            white-space: nowrap;
            position: relative;
        }

        #panel-license .table td {
            padding: 12px 15px;
            vertical-align: middle;
             white-space: nowrap;
        }
         #panel-license .table td:nth-child(2),
         #panel-license .table td:nth-child(9)
         {
            white-space: normal;
         }


        #panel-license,#ingredients-block .table tr:hover {
            background-color: rgba(44, 95, 158, 0.03);
        }

        #panel-license .editable-row {
            background-color: #fffde7 !important;
        }
         #panel-license .editable-row input.is-invalid,
         #panel-license .editable-row select.is-invalid {
            border-color: var(--danger-color, #dc3545);
         }

         #panel-license .table tr.has-draft {
             background-color: #fffde7 !important;
             font-style: italic;
         }
         #panel-license .table tr.has-draft:hover {
              background-color: #fffacd !important;
         }

        /* ====== STATUS BADGES ====== */
        #panel-license .status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        #panel-license .status-active {
            background-color: rgba(40, 167, 69, 0.1);
            color: var(--success-color, #28a745);
        }

        /* This class name is duplicated in your original CSS for .status-badge and .status.
           Ensure the correct one is targeted or combine them if they are the same.
           I'll assume they are meant for the table status here. */
        #panel-license .table .status-pending {
            background-color: rgba(23, 162, 184, 0.1);
            color: var(--info-color, #17a2b8);
        }

        #panel-license .status-expired { /* Also duplicated, assuming table context */
            background-color: rgba(220, 53, 69, 0.1);
            color: var(--danger-color, #dc3545);
        }


        /* ====== FILE UPLOAD & DOCUMENT PREVIEW ====== */
        #panel-license .file-upload {
            position: relative;
            display: inline-block;
            padding: 8px 16px;
            background-color: var(--light-color, #f8f9fa);
            border: 1px dashed var(--border-color, #dee2e6);
            border-radius: 4px;
            cursor: pointer;
            transition: var(--transition, all 0.3s ease);
            font-size: 0.85rem;
        }

        #panel-license .file-upload:hover {
            background-color: #e9ecef;
            border-color: var(--gray-color, #6c757d);
        }

        #panel-license .file-upload input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        #panel-license .uploaded-file {
            font-size: 0.8rem;
            color: var(--success-color, #28a745);
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        #panel-license .document-preview {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 5px;
            background-color: #f8f9fa;
            border-radius: 4px;
            cursor: pointer;
            transition: var(--transition, all 0.3s ease);
            max-width: 200px;
            min-width: 150px;
        }

        #panel-license .document-preview:hover {
            background-color: #e9ecef;
        }

        #panel-license .document-icon {
            /* color: var(--danger-color); /* General - overridden below */
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        #panel-license .document-icon.fa-file-pdf { color: #e74c3c; }
        #panel-license .document-icon.fa-file-image { color: #3498db; }
        #panel-license .document-icon.fa-file-word { color: #2b579a; }
        #panel-license .document-icon.fa-file-excel { color: #217346; }
        #panel-license .document-icon.fa-file:not(.fa-file-pdf):not(.fa-file-image):not(.fa-file-word):not(.fa-file-excel) { color: var(--gray-color, #6c757d); }


        #panel-license .document-name {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 0.85rem;
        }

        /* ====== BUTTON STYLES ====== */
        /* Bootstrap handles .btn, these are custom variants */
        #panel-license .btn-renew {
            background-color: var(--success-color, #28a745);
            color: white;
        }
        #panel-license .btn-renew:hover { background-color: #218838; color: white; }

        #panel-license .btn-history {
            background-color: var(--info-color, #17a2b8);
            color: white;
        }
        #panel-license .btn-history:hover { background-color: #138496; color: white; }

        #panel-license .btn-save {
            background-color: var(--success-color, #28a745);
            color: white;
        }
        #panel-license .btn-save:hover { background-color: #218838; color: white; }

        #panel-license .btn-cancel {
            background-color: var(--danger-color, #dc3545);
            color: white;
        }
        #panel-license .btn-cancel:hover { background-color: #c82333; color: white; }

        #panel-license .btn-view {
            background-color: var(--primary-color, #2c5f9e);
            color: white;
        }
        #panel-license .btn-view:hover { background-color: #1f4b85; color: white; }

        #panel-license .btn-schedule {
            background-color: var(--warning-color, #ffc107);
            color: var(--dark-color, #343a40);
        }
        #panel-license .btn-schedule:hover { background-color: #e0a800; color: var(--dark-color, #343a40); }

        #panel-license .btn-download {
            background-color: var(--gray-color, #6c757d);
            color: white;
        }
        #panel-license .btn-download:hover { background-color: #5a6268; color: white; }

         #panel-license #submitDraftsButton:disabled {
             cursor: not-allowed;
             opacity: 0.65;
         }

        /* ====== ACTION BUTTONS IN TABLE ====== */
        #panel-license .action-btns {
            display: flex;
            flex-wrap: nowrap;
            gap: 6px;
        }

        /* ====== MODAL STYLES ====== */
        /* Bootstrap handles .modal-content, .modal-body, etc. */
        #panel-license .modal-header {
            background-color: var(--primary-color, #2c5f9e);
            color: white;
            padding: 15px 20px;
        }
         #panel-license .modal-header .btn-close {
             filter: brightness(0) invert(1);
         }

        #panel-license .modal-title {
            font-weight: 600;
        }


        /* ====== PAGINATION STYLES ====== */
        #panel-license .pagination-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            margin-top: 20px;
            border-top: 1px solid var(--border-color, #dee2e6);
            flex-wrap: wrap;
        }
        /* Bootstrap handles .page-item, .page-link styling mostly */
        #panel-license .pagination-controls .page-item.active .page-link {
            background-color: var(--primary-color, #2c5f9e);
            border-color: var(--primary-color, #2c5f9e);
        }
        #panel-license .pagination-controls .page-link {
            color: var(--primary-color, #2c5f9e);
        }
        #panel-license .pagination-controls .page-link:hover {
            color: #0a58ca; /* Bootstrap's default link hover */
        }

        #panel-license .rows-per-page-select {
            width: auto;
            display: inline-block;
            margin-left: 10px;
        }
         #panel-license .pagination-info {
             font-size: 0.9rem;
             color: var(--gray-color, #6c757d);
             margin-bottom: 10px;
         }
         #panel-license .pagination-nav {
             margin-bottom: 10px;
         }


        /* ====== UTILITY CLASSES ====== */
        #panel-license .text-ellipsis {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* ====== TABLE HEADER FILTER STYLES ====== */
        #panel-license .th-filterable {
             position: relative;
        }

        #panel-license .th-content-wrapper {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        #panel-license .th-filter-icon {
            margin-left: 8px;
            color: rgba(255, 255, 255, 0.7);
            cursor: pointer;
            font-size: 0.9em;
        }
         #panel-license .th-filter-icon:hover {
             color: white;
         }

        #panel-license .th-filter-icon.active {
            color: white;
        }

        #panel-license .th-filter-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1050; /* Ensure above Bootstrap components */
            min-width: 250px;
            background-color: #fff;
            border: 1px solid var(--border-color, #dee2e6);
            border-radius: 4px;
            box-shadow: var(--shadow-md, 0 0.5rem 1rem rgba(0, 0, 0, 0.15));
            color: var(--dark-color, #343a40);
            font-weight: normal;
            font-size: 14px;
            text-align: left;
            white-space: normal;
        }

        #panel-license .th-filter-dropdown[data-column-key="category"] .filter-search,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .filter-search,
        #panel-license .th-filter-dropdown[data-column-key="status"] .filter-search {
            padding: 8px 10px;
            border-bottom: 1px solid #eee;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .filter-search input[type="text"],
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .filter-search input[type="text"],
        #panel-license .th-filter-dropdown[data-column-key="status"] .filter-search input[type="text"] {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 13px;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-container,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-container,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-container {
            max-height: 180px;
            overflow-y: auto;
            border: 1px solid #ccc;
            margin: 10px;
            border-radius: 4px;
            position: relative;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-list,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-list,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-list li,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-list li,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-list li {
            padding: 6px 10px;
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: background-color 0.2s ease;
            white-space: normal;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-list li:hover,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-list li:hover,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-list li:hover {
            background-color: #f0f0f0;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-list input[type="checkbox"],
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-list input[type="checkbox"],
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-list input[type="checkbox"] {
            margin-right: 8px;
            cursor: pointer;
            width: 14px;
            height: 14px;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-list label,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-list label,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-list label {
            font-size: 13px;
            color: #333;
            flex-grow: 1;
            cursor: pointer;
            margin-bottom: 0;
            font-weight: normal;
        }

        #panel-license .th-filter-dropdown .filter-actions {
            padding: 8px 10px;
            display: flex;
            justify-content: space-between;
            border-top: 1px solid #eee;
            background-color: #f9f9f9;
            border-bottom-left-radius: 4px;
            border-bottom-right-radius: 4px;
        }
        #panel-license .th-filter-dropdown .filter-actions .btn {
            padding: 6px 12px;
            font-size: 13px;
            font-weight: 500;
        }
        #panel-license .th-filter-dropdown .filter-actions .btn-apply {
            background-color: #3498db; /* FSSAI specific color */
            color: white;
            border: none;
        }
        #panel-license .th-filter-dropdown .filter-actions .btn-apply:hover {
            background-color: #2980b9;
        }
        #panel-license .th-filter-dropdown .filter-actions .btn-clear {
            background-color: #ecf0f1;
            color: #333;
            border: 1px solid #bdc3c7;
        }
        #panel-license .th-filter-dropdown .filter-actions .btn-clear:hover {
            background-color: #dde1e2;
        }

        #panel-license .th-filter-dropdown[data-column-key="category"] .options-container::-webkit-scrollbar,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-container::-webkit-scrollbar,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-container::-webkit-scrollbar {
          width: 10px;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-container::-webkit-scrollbar-track,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-container::-webkit-scrollbar-track,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-container::-webkit-scrollbar-track {
          background: #f1f1f1;
           border-radius: 4px;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-container::-webkit-scrollbar-thumb,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-container::-webkit-scrollbar-thumb,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-container::-webkit-scrollbar-thumb {
          background: #aaa;
          border-radius: 5px;
          border: 2px solid #f1f1f1;
        }
        #panel-license .th-filter-dropdown[data-column-key="category"] .options-container::-webkit-scrollbar-thumb:hover,
        #panel-license .th-filter-dropdown[data-column-key="licenseType"] .options-container::-webkit-scrollbar-thumb:hover,
        #panel-license .th-filter-dropdown[data-column-key="status"] .options-container::-webkit-scrollbar-thumb:hover {
          background: #777;
        }

        #panel-license .unit-hierarchy-filter-dropdown .hierarchical-filter-content {
            padding: 15px;
            min-width: 250px;
        }
        #panel-license .unit-hierarchy-filter-dropdown .filter-group {
            margin-bottom: 15px;
        }
        #panel-license .unit-hierarchy-filter-dropdown .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-size: 0.85em;
            font-weight: 600;
            color: #4a5568;
        }
        #panel-license .unit-hierarchy-filter-dropdown .select-wrapper {
            position: relative;
        }
        #panel-license .unit-hierarchy-filter-dropdown select {
            width: 100%;
            padding: 8px 30px 8px 12px;
            font-size: 0.9em;
            border: 1px solid #e2e8f0;
            border-radius: 4px;
            background-color: #f8f9fa;
            color: #495057;
            cursor: pointer;
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg fill="%236c757d" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/><path d="M0 0h24v24H0z" fill="none"/></svg>');
            background-repeat: no-repeat;
            background-position: right 8px center;
            background-size: 18px;
        }
        #panel-license .unit-hierarchy-filter-dropdown .corporate-wrapper select {
            border: 2px solid #000;
            background-color: #fff;
            font-weight: 500;
        }
        #panel-license .unit-hierarchy-filter-dropdown select:focus {
            outline: none;
            border-color: #3b82f6; /* FSSAI specific */
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3);
        }
        #panel-license .unit-hierarchy-filter-dropdown .button-group.filter-actions {
            margin-top: 15px;
            margin-left: -15px;
            margin-right: -15px;
            margin-bottom: -15px;
            padding-left: 15px;
            padding-right: 15px;
            padding-bottom: 10px;
        }

        #panel-license .th-filter-dropdown[data-column-key="licenseNo"] .filter-content-padding,
        #panel-license .th-filter-dropdown[data-column-key="expiryDate"] .filter-content-padding {
             padding: 10px 15px;
        }
        #panel-license .th-filter-dropdown .date-range-filter label {
             margin-bottom: 3px;
             font-size: 0.85em;
             font-weight: 600;
             color: #4a5568;
        }
        #panel-license .th-filter-dropdown .date-range-filter input[type="date"] {
            width: 100%;
        }
        #panel-license .th-filter-dropdown[data-column-key="licenseNo"] label {
            font-size: 0.85em;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 3px;
        }


        /* ====== FSSAI RESPONSIVE ADJUSTMENTS (scoped) ====== */
        @media (max-width: 768px) { /* This might conflict with main tab's responsive */
            #panel-license .fssai-container-embed {
                padding: 15px;
            }

            #panel-license .cards-container {
                grid-template-columns: 1fr;
            }

            #panel-license #addNewButton,
            #panel-license #submitDraftsButton,
            #panel-license #exportButton,
            #panel-license #refreshTableButton {
                display: none !important; /* FSSAI original style */
            }

            #panel-license .table-actions .ms-auto {
                width: 100%;
                margin-left: 0 !important;
                justify-content: space-between;
            }

            #panel-license .table-actions .ms-auto .show-select-wrapper {
                flex-shrink: 0;
            }

            #panel-license .table-actions .ms-auto .input-group {
                flex-grow: 1;
                flex-basis: 150px;
                max-width: 100%;
            }


            #panel-license .action-btns {
                flex-wrap: wrap;
            }
            #panel-license .action-btns .btn { /* Scoped this */
                width: 100%;
            }

             #panel-license .pagination-controls {
                flex-direction: column;
                align-items: center;
            }
            #panel-license .pagination-info,
            #panel-license .pagination-nav {
                margin-bottom: 10px;
                width: 100%;
                text-align: center;
            }
            #panel-license .pagination-nav ul {
                 justify-content: center;
            }
        }

        @media (min-width: 992px) {
            #panel-license .cards-container {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
       button#exportButton
 {
    background: transparent;
    border: 1px solid;
}

/* Hover effect */
button#exportButton:hover
 {
    background: #0d6efd;
    border: 1px solid #0d6efd;
    cursor: pointer;
}

button#refreshTableButton {
    background: transparent;
    border: 1px solid #6c757d;
    color: #6c757d;
}

button#refreshTableButton:hover {
    background: #6c757d; /* Optional */
    border-color: #6c757d;
    color: #fff;
    cursor: pointer;
}
button#searchButton {
    background: transparent;
    border: 1px solid;
}

button#searchButton:hover {
    background: transparent;
    border: 1px solid !important;
}

.btn-danger {
    color: #fff;
    background-color: #d10b1e !important;
    border-color: #b02a37;
}


.switch {
  position: relative;
  display: inline-block;
  width: 40px;
  height: 20px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0; left: 0;
  right: 0; bottom: 0;
  background-color: #ccc;
  transition: 0.4s;
  border-radius: 20px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 2px;
  bottom: 2px;
  background-color: white;
  transition: 0.4s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: #28a745; /* green */
}

input:checked + .slider:before {
  transform: translateX(20px);
}

    </style>
    
    
@section('content')
 

 <div class="tabs-container-main">
        <!-- Tab Navigations -->
        <ul class="tabs-nav-main" role="tablist">
            <li>
                <button role="tab" aria-selected="true" aria-controls="panel-dashboard" id="tab-dashboard" >
                                        <a   href="{{route('linces')}}" >

                    <i class="fas fa-tachometer-alt"></i>Dashboard
                    </a>
                </button>
            </li>
            <li>
                <button role="tab" aria-selected="false" aria-controls="panel-license" id="tab-license" class="active">
                    <a     href="{{route('fssailinces')}}" >
                    <i class="fas fa-id-card"></i>License
                    </a>
                </button>
            </li>
            <li>
                <button role="tab" aria-selected="false" aria-controls="panel-medical" id="tab-medical">
                                        <a   href="{{route('medical')}}" >

                    <i class="fas fa-briefcase-medical"></i>Medical
                    </a>
                </button>
            </li>
            <li>
                <button role="tab" aria-selected="false" aria-controls="panel-testing" id="tab-testing">
                                        <a   href="{{route('food')}}" >

                    <i class="fas fa-vial"></i>Food
                    </a>
                </button>
            </li>
            <li>
                <button role="tab" aria-selected="false" aria-controls="panel-fostac" id="tab-fostac">
                    <a   href="{{route('fostac')}}" >

                    <i class="fas fa-award"></i>FoSTaC

</a>
                </button>
            </li>
        </ul>

        <!-- Tab Content Panels -->
        <div class="tabs-content-main">
            <div role="tabpanel" id="panel-dashboard" aria-labelledby="tab-dashboard" class="tab-panel-main ">
                <h2><i class="fas fa-tachometer-alt"></i>Dashboard Content</h2>
                <p>This is the content for the Dashboard tab. You can put any relevant information here, like charts, summaries, or quick links.</p>
            </div>

            <div role="tabpanel" id="panel-license" aria-labelledby="tab-license" class="tab-panel-main active">
                <!-- EMBEDDED FSSAI CONTENT START -->
                <div class="fssai-content-wrapper">
                    <div class="container fssai-container-embed"> <!-- Original FSSAI container, renamed class for safety -->
                        <!-- Header (already empty in your provided HTML for FSSAI) -->
                        <header class="page-header">
            <div class="my-3 p-3 bg-light border rounded">
                <div class="row align-items-center">
                    <div class="col-md-auto"><h5 class="mb-0">Simulate User Role:</h5></div>
                    <div class="col-md-5">
                        <select id="roleSelector" class="form-select form-select-sm">
                            <option value="Super Admin">Super Admin</option>
                            <option value="Corporate_Stark Industries">Corporate: Stark Industries</option>
                            <option value="Regional_Stark Industries_North">Regional: Stark Industries - North</option>
                            <option value="Regional_Stark Industries_South">Regional: Stark Industries - South</option>
                            <option value="Unit_Stark Industries_North_Main Plant A">Unit: Stark Industries - North - Main Plant A</option>
                            <option value="Unit_Stark Industries_South_South Warehouse Beta">Unit: Stark Industries - South - South Warehouse Beta</option>
                            <option value="Unit_Wayne Enterprises_Central_Gotham Central">Unit: Wayne Enterprises - Central - Gotham Central</option>
                        </select>
                    </div>
                    <div class="col-md-auto"><button class="btn btn-sm btn-info" onclick="applyUserRoleSelection()">Apply Role</button></div>
                </div>
                <p class="mt-2 mb-0 small text-muted">Note: Client-side simulation for demonstration.</p>
            </div>
        </header>
                        
                        <div class="my-3">
            <button class="btn btn-outline-secondary btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#categoryManagementSection" aria-expanded="false" aria-controls="categoryManagementSection">
                <i class="fas fa-cogs me-2"></i>Manage Categories
            </button>
        </div>
        
         <div class="collapse mb-4" id="categoryManagementSection">
            <div class="card card-body">
                <h4 class="mb-3">Add New Custom Category</h4>
                
                <form method="post" action="{{route('License_catageory')}}" id="customCategoryForm">
                    @csrf
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="newCustomCategoryName" class="form-label">Category Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-sm" name="cat_name" id="newCustomCategoryName" placeholder="e.g., Water Testing Certificate">
                    </div>
                    <div class="col-md-3" id="customCategoryScopeWrapper">
                        {/* Scope selection will be dynamically populated */}
                    </div>
                    <div class="col-md-auto">
                        <button class="btn btn-sm btn-primary" onclick="addNewCustomCategory()"><i class="fas fa-plus me-1"></i>Add Category</button>
                    </div>
                </div>
                
                </form>
                <hr>
                <h5>Existing Custom Categories (<span id="customCategoryListScope">Current Scope</span>)</h5>
                <ul id="customCategoryList" class="list-group list-group-flush">
                    @foreach($License_catageory as $License_catageorys)
             
                    
                    <li class="list-group-item d-flex justify-content-between align-items-center">{{$License_catageorys->name ?? ''}} <span class="badge bg-primary rounded-pill">Global</span> <a class="btn btn-sm btn-outline-danger py-0 px-1" href="{{route('License_catageory_delete',$License_catageorys->id)}}" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fas fa-times"></i></a></li>
                    
                    
                      @endforeach
                </ul>
            </div>
        </div>
        <!-- CUSTOM CATEGORY MANAGEMENT - END -->

                        <!-- Dashboard Cards Section -->
                        <section class="dashboard-section">
                            <h2 class="h5 mb-3 text-muted">Compliance Overview</h2>
                            <div class="cards-container">
                                 <div id="card-license" class="dashboard-card dashboard-card-green">
                                    <h3 class="card-title">FSSAI License</h3>
                                    <div class="card-status-row">
                                        <span id="card-license-status" class="status-badge">N/A</span>
                                        <span id="card-license-due" class="due-date">Next Due: N/A</span>
                                    </div>
                                    <div class="progress-container">
                                        <div class="progress-bar">
                                            <div id="card-license-progress" class="progress-fill" style="width: 0%;"></div>
                                        </div>
                                    </div>
                                    <div class="card-info-row">
                                        <span id="card-license-info" class="validity-text">No Data</span>
                                    </div>
                                </div>
                                <div id="card-hra" class="dashboard-card dashboard-card-orange">
                                    <h3 class="card-title">Hygiene Rating Audit</h3>
                                    <div class="card-status-row">
                                        <span id="card-hra-status" class="status-badge">N/A</span>
                                        <span id="card-hra-due" class="due-date">Next Due: N/A</span>
                                    </div>
                                    <div class="progress-container">
                                        <div class="progress-bar">
                                            <div id="card-hra-progress" class="progress-fill" style="width: 0%;"></div>
                                        </div>
                                    </div>
                                    <div class="card-info-row">
                                        <span id="card-hra-info" class="validity-text">No Data</span>
                                    </div>
                                </div>
                                <div id="card-tpa" class="dashboard-card dashboard-card-blue">
                                    <h3 class="card-title">Third Party Audit</h3>
                                    <div class="card-status-row">
                                        <span id="card-tpa-status" class="status-badge">N/A</span>
                                        <span id="card-tpa-due" class="due-date">Next Due: N/A</span>
                                    </div>
                                    <div class="progress-container">
                                        <div class="progress-bar">
                                            <div id="card-tpa-progress" class="progress-fill" style="width: 0%;"></div>
                                        </div>
                                    </div>
                                    <div class="card-info-row">
                                        <span id="card-tpa-info" class="validity-text">No Data</span>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <!-- License Table Section -->
                        <section class="table-section">
                            <h2 class="h5 mb-3 text-muted">License Management</h2>

                            <div class="table-actions">
                                <button id="addNewButton" class="btn btn-primary" onclick="addNewLicense()">
                                    <i class="fas fa-plus me-2"></i> Add New
                                </button>
                                <button id="submitDraftsButton" class="btn btn-success" title="Apply all saved drafts" disabled>
                                    <i class="fas fa-check-double me-2"></i> Submit Drafts (<span id="draftCount">0</span>)
                                </button>
                                <button id="exportButton" class="btn btn-outline-primary" onclick="exportTableToCSV('fssai_licenses.csv')">
                                    <i class="fas fa-download me-2"></i> Export
                                </button>
                                 <button id="refreshTableButton" class="btn btn-outline-secondary" title="Refresh Table Data & Clear Filters">
                                     <i class="fas fa-sync-alt me-2"></i> Refresh
                                 </button>

                                <div class="ms-auto d-flex align-items-center flex-wrap">
                                    <div class="show-select-wrapper d-flex align-items-center me-md-3 mb-2 mb-md-0">
                                        <span class="me-2 text-muted small">Show:</span>
                                        <select id="rowsPerPageSelect" class="form-select form-select-sm rows-per-page-select">
                                            <option value="5">5</option>
                                            <option value="10" selected>10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select>
                                    </div>
                                    <div class="input-group mb-2 mb-md-0">
                                        <input type="text" id="searchInput" class="form-control" placeholder="Global Search...">
                                        <button class="btn btn-outline-secondary" type="button" id="searchButton">
                                            <i class="fas fa-search" style="    margin-top: -7px;"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-hover" id="fssaiTable">
                                     <thead>
                                        <tr>
                                            <th>SL No</th>
                                            <th class="th-filterable" data-column-key="unitName">
                                                <div class="th-content-wrapper">
                                                    <span>Unit Name</span>
                                                    <i class="fas fa-filter th-filter-icon" data-column-key="unitName"></i>
                                                </div>
                                                <div class="th-filter-dropdown unit-hierarchy-filter-dropdown" data-column-key="unitName">
                                                    <div class="hierarchical-filter-content">
                                                        <div class="filter-group">
                                                            <label for="unit-filter-corporate-select">Corporate:</label>
                                                            <div class="select-wrapper corporate-wrapper">
                                                                <select id="unit-filter-corporate-select" name="corporate">
                                                                    <option value="" selected>-- All --</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="filter-group">
                                                            <label for="unit-filter-regional-select">Regional:</label>
                                                            <div class="select-wrapper">
                                                                <select id="unit-filter-regional-select" name="regional">
                                                                    <option value="" selected>-- All --</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="filter-group">
                                                            <label for="unit-filter-unit-select">Unit:</label>
                                                            <div class="select-wrapper">
                                                                <select id="unit-filter-unit-select" name="unit">
                                                                    <option value="" selected>-- All --</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="button-group filter-actions">
                                                            <button type="button" class="btn btn-sm btn-apply unit-filter-apply">Apply</button>
                                                            <button type="button" class="btn btn-sm btn-clear unit-filter-clear">Clear</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </th>
                                            <th class="th-filterable" data-column-key="category">
                                                 <div class="th-content-wrapper">
                                                    <span>Category</span>
                                                    <i class="fas fa-filter th-filter-icon" data-column-key="category"></i>
                                                 </div>
                                                 <div class="th-filter-dropdown" data-column-key="category">
                                                    <div class="filter-search">
                                                        <input type="text" placeholder="Search Categories...">
                                                    </div>
                                                    <div class="options-container">
                                                        <ul class="options-list"></ul>
                                                    </div>
                                                    <div class="filter-actions">
                                                        <button class="btn btn-sm btn-apply">Apply</button>
                                                        <button class="btn btn-sm btn-clear">Clear</button>
                                                    </div>
                                                 </div>
                                            </th>
                                            <th class="th-filterable" data-column-key="licenseNo">
                                                <div class="th-content-wrapper">
                                                    <span>License Number</span>
                                                    <i class="fas fa-filter th-filter-icon" data-column-key="licenseNo"></i>
                                                </div>
                                                <div class="th-filter-dropdown" data-column-key="licenseNo">
                                                    <div class="filter-content-padding">
                                                        <div class="mb-2">
                                                            <label for="licenseNoSearchInput" class="form-label small fw-semibold">Search:</label>
                                                            <input type="text" id="licenseNoSearchInput" class="form-control form-control-sm" placeholder="Enter License No...">
                                                        </div>
                                                    </div>
                                                    <div class="filter-actions">
                                                        <button type="button" class="btn btn-sm btn-apply licenseNo-filter-apply">Apply</button>
                                                        <button type="button" class="btn btn-sm btn-clear licenseNo-filter-clear">Clear</button>
                                                    </div>
                                                </div>
                                            </th>
                                            <th class="th-filterable" data-column-key="expiryDate">
                                                 <div class="th-content-wrapper">
                                                     <span>Expiry Date</span>
                                                     <i class="fas fa-filter th-filter-icon" data-column-key="expiryDate"></i>
                                                 </div>
                                                 <div class="th-filter-dropdown" data-column-key="expiryDate">
                                                    <div class="filter-content-padding">
                                                        <div class="date-range-filter mb-2">
                                                             <div class="mb-2">
                                                                 <label for="expiryDateFromInput" class="form-label small fw-semibold">From:</label>
                                                                 <input type="date" id="expiryDateFromInput" class="form-control form-control-sm">
                                                             </div>
                                                             <div>
                                                                 <label for="expiryDateToInput" class="form-label small fw-semibold">To:</label>
                                                                 <input type="date" id="expiryDateToInput" class="form-control form-control-sm">
                                                             </div>
                                                        </div>
                                                    </div>
                                                     <div class="filter-actions">
                                                         <button type="button" class="btn btn-sm btn-apply expiryDate-filter-apply">Apply</button>
                                                         <button type="button" class="btn btn-sm btn-clear expiryDate-filter-clear">Clear</button>
                                                     </div>
                                                 </div>
                                            </th>
                                            <th class="th-filterable" data-column-key="licenseType">
                                                <div class="th-content-wrapper">
                                                    <span>License Type</span>
                                                    <i class="fas fa-filter th-filter-icon" data-column-key="licenseType"></i>
                                                </div>
                                                <div class="th-filter-dropdown" data-column-key="licenseType">
                                                    <div class="filter-search">
                                                        <input type="text" placeholder="Search License Types...">
                                                    </div>
                                                    <div class="options-container">
                                                        <ul class="options-list"></ul>
                                                    </div>
                                                    <div class="filter-actions">
                                                        <button class="btn btn-sm btn-apply">Apply</button>
                                                        <button class="btn btn-sm btn-clear">Clear</button>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>License Copy</th>
                                            <th class="th-filterable" data-column-key="status">
                                                <div class="th-content-wrapper">
                                                    <span>Status</span>
                                                    <i class="fas fa-filter th-filter-icon" data-column-key="status"></i>
                                                </div>
                                                <div class="th-filter-dropdown" data-column-key="status">
                                                    <div class="filter-search">
                                                        <input type="text" placeholder="Search Statuses...">
                                                    </div>
                                                    <div class="options-container">
                                                        <ul class="options-list"></ul>
                                                    </div>
                                                    <div class="filter-actions">
                                                        <button class="btn btn-sm btn-apply">Apply</button>
                                                        <button class="btn btn-sm btn-clear">Clear</button>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="fssaiTableBody">
                                    </tbody>
                                </table>
                            </div>

                            <div class="pagination-controls">
                                 <div class="pagination-info">
                                    Showing <span id="showingStart">1</span> to <span id="showingEnd">10</span> of <span id="totalEntries">0</span> entries
                                </div>
                                <nav class="pagination-nav" aria-label="Table navigation">
                                    <ul class="pagination pagination-sm mb-0" id="paginationUl">
                                    </ul>
                                </nav>
                            </div>
                        </section>
                    </div> <!-- End of FSSAI original container -->

                    <!-- FSSAI Modals -->
                    <!--<div class="modal fade" id="documentModal" tabindex="-1" aria-hidden="true">-->
                    <!--    <div class="modal-dialog modal-lg">-->
                    <!--        <div class="modal-content">-->
                    <!--            <div class="modal-header">-->
                    <!--                <h5 class="modal-title">Document Preview</h5>-->
                    <!--                <button type="button" class="btn-close btn-light" data-bs-dismiss="modal" aria-label="Close"></button>-->
                    <!--            </div>-->
                    <!--            <div class="modal-body text-center p-4">-->
                    <!--                <iframe id="documentFrame" style="width: 100%; height: 500px; border: none;" data-filename=""></iframe>-->
                    <!--                 <div id="docErrorMsg" class="alert alert-danger d-none mt-3">Error loading preview.</div>-->
                    <!--                <div class="mt-3">-->
                    <!--                    <button class="btn btn-primary" onclick="downloadDocument()">-->
                    <!--                        <i class="fas fa-download me-2"></i> Download Document-->
                    <!--                    </button>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    
                                        <div id="ingredients-block"></div>

                    
                    <!-- Modal -->
<div class="modal fade" id="documentModal" tabindex="-1" aria-labelledby="documentModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="documentModalLabel">Document Preview</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="documentPreview">
        <!-- Dynamic content will appear here -->
      </div>
      
    </div>
  </div>
</div>

                    <div class="modal fade" id="renewModal" tabindex="-1" aria-hidden="true">
                        
                        <form method="post" action="{{route('lincesupload')}}" enctype="multipart/form-data">
                            @csrf
                            
                   
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Renew / Update License</h5>
                                    <button type="button" class="btn-close btn-light" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                    <div class="modal-body">
                                        <input type="hidden" id="renewLicenseNumber">
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Current License Number</label>
                                            <p id="displayLicenseNumber" class="form-control bg-light"></p>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Current Expiry Date</label>
                                            <p id="currentExpiryDate" class="form-control bg-light"></p>
                                        </div>
                                        <div class="mb-3">
                                            <label for="newExpiryDate" class="form-label">New Expiry Date</label>
                                            <input type="date" id="newExpiryDate" name="due_date" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Upload New Document (Optional)</label>
                                            <label class="file-upload">
                                                <i class="fas fa-cloud-upload-alt me-1"></i> Choose File
                                                <input type="file" name="image" id="renewalDocument">
                                            </label>
                                            <span id="renewalFileName" class="uploaded-file">
                                                <i class="fas fa-file-alt"></i> No file selected
                                            </span>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-warning w-100" >
                                            <i class="fas fa-save me-2"></i> Save
                                        </button>
                                    </div>
                            </div>
                        </div>
                             </form>
                    </div>
                    

                   
                </div> <!-- End of FSSAI content wrapper -->
                <!-- EMBEDDED FSSAI CONTENT END -->
            </div>

            <div role="tabpanel" id="panel-medical" aria-labelledby="tab-medical" class="tab-panel-main">
                <h2><i class="fas fa-briefcase-medical"></i>Medical Content</h2>
                <p>Information related to medical records, appointments, or health certifications.</p>
            </div>
            <div role="tabpanel" id="panel-testing" aria-labelledby="tab-testing" class="tab-panel-main">
                <h2><i class="fas fa-vial"></i>Testing Content</h2>
                <p>Results from various tests, schedules for upcoming tests, or testing guidelines.</p>
            </div>
            <div role="tabpanel" id="panel-fostac" aria-labelledby="tab-fostac" class="tab-panel-main">
                <h2><i class="fas fa-award"></i>FoSTaC Content</h2>
                <p>FoSTaC (Food Safety Training and Certification) related information, training modules, certification status, etc.</p>
            </div>
        </div>
    </div>

                          
                    

@endsection

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" id="bootstrap-fssai-script"></script>

    <script>
        // Main Tab Interface JavaScript
        document.addEventListener('DOMContentLoaded', function () {
            const mainTabs = document.querySelectorAll('.tabs-nav-main li button');
            const mainPanels = document.querySelectorAll('.tab-panel-main');

            mainTabs.forEach(tab => {
                tab.addEventListener('click', function () {
                    const targetPanelId = this.getAttribute('aria-controls');

                    mainTabs.forEach(t => {
                        t.classList.remove('active');
                        t.setAttribute('aria-selected', 'false');
                    });
                    mainPanels.forEach(p => {
                        p.classList.remove('active');
                    });

                    this.classList.add('active');
                    this.setAttribute('aria-selected', 'true');

                    const targetPanel = document.getElementById(targetPanelId);
                    if (targetPanel) {
                        targetPanel.classList.add('active');
                        // If the license tab is activated, and its script hasn't run,
                        // you might need to manually trigger its initialization logic
                        // if it's not purely DOMContentLoaded based.
                        // For now, assuming FSSAI script runs on its own DOMContentLoaded or is structured to work.
                        if (targetPanelId === 'panel-license' && typeof initializeFSSAIApp === 'function' && !fssaiAppInitialized) {
                             // initializeFSSAIApp(); // Hypothetical function
                             // fssaiAppInitialized = true;
                        }
                    }
                });

                tab.addEventListener('keydown', function (event) {
                    if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        this.click();
                    }
                });
            });

            const mainTabList = document.querySelector('.tabs-nav-main');
            if (mainTabList) {
                mainTabList.addEventListener('keydown', function (event) {
                    let currentTab = document.activeElement;
                    if (!currentTab || !Array.from(mainTabs).includes(currentTab)) {
                        return;
                    }
                    let currentIndex = Array.from(mainTabs).indexOf(currentTab);

                    if (event.key === 'ArrowRight') {
                        event.preventDefault();
                        let nextIndex = (currentIndex + 1) % mainTabs.length;
                        mainTabs[nextIndex].focus();
                    } else if (event.key === 'ArrowLeft') {
                        event.preventDefault();
                        let prevIndex = (currentIndex - 1 + mainTabs.length) % mainTabs.length;
                        mainTabs[prevIndex].focus();
                    }
                });
            }
        });

        // ========================================= */
        // ==== FSSAI EMBEDDED SCRIPT (Scoped) ==== */
        // ========================================= */
        // Wrap FSSAI script in a function to avoid immediate execution if panel is hidden
        // and to potentially re-initialize if needed, though DOMContentLoaded usually handles it.
        // Note: The FSSAI script uses DOMContentLoaded, so it should run when its content is in the DOM.
        // We might not need to call this explicitly unless there are issues with Bootstrap components
        // initializing correctly when the tab is initially hidden.

        (function() { // IIFE to scope FSSAI variables
            const DATA_KEYS = [
                'slNo', 'unitName', 'category', 'licenseNo', 'expiryDate',
                'licenseType', 'licenseCopy', 'status', 'actions'
            ];
            const ALL_OPTION_VALUE = "";

            let allLicenseData = [ // Sample Data from FSSAI
            
             @foreach($result as $results)
                 { slNo: 1, unitName: '<?= Auth::user()->company_name ?>', corporate: 'Stark Industries', regional: 'North', category: '{{$results->document_type ?? ''}}', licenseNo: '{{$results->lincess_number ?? ''}}', expiryDate: '{{$results->due_date ?? ''}}', licenseType: '{{$results->cat_type ?? ''}}', licenseCopy: '{{asset('documents')}}/{{$results->image ?? ''}}', status: 'Active' },
                 @endforeach
            ];
            let filteredLicenseData = [...allLicenseData];
            let draftUpdates = [];
            let currentPage = 1;
            let rowsPerPage = 10;
            let activeFilters = {
                selectedCorporate: null,
                selectedRegional: null,
                selectedUnit: null,
                licenseNoSearch: null,
                expiryDateFrom: null,
                expiryDateTo: null
            };
            let currentlyOpenFilterDropdown = null;
            var tooltipTriggerList, tooltipList, documentModal, renewModal, historyModal; // These will be Bootstrap instances

            function getFileIconClass(filename) {
                if (!filename) return 'fa-file';
                const extension = filename.split('.').pop().toLowerCase();
                if (['pdf'].includes(extension)) return 'fa-file-pdf document-icon';
                if (['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(extension)) return 'fa-file-image document-icon';
                if (['doc', 'docx'].includes(extension)) return 'fa-file-word document-icon';
                if (['xls', 'xlsx'].includes(extension)) return 'fa-file-excel document-icon';
                return 'fa-file document-icon';
             }
            window.viewDocument = function(filename) { // Expose to global for onclick
                const docPath = `documents/${filename}`; // Ensure 'documents' folder exists at root or adjust path
                const frame = document.getElementById('documentFrame');
                const errorMsgDiv = document.getElementById('docErrorMsg');
                frame.src = 'about:blank';
                frame.setAttribute('data-filename', filename);
                errorMsgDiv.classList.add('d-none');
                frame.classList.remove('d-none');
                setTimeout(() => { frame.src = docPath; }, 50);
                frame.onload = () => { errorMsgDiv.classList.add('d-none'); frame.classList.remove('d-none'); };
                frame.onerror = () => { errorMsgDiv.textContent = `Error loading preview for '${filename}'. This often means the file is not found at the expected path or there's a server/CORS issue if loading remotely. Ensure 'documents/${filename}' is accessible.`; errorMsgDiv.classList.remove('d-none'); frame.classList.add('d-none'); };
                if (documentModal) documentModal.show();
            }
            window.downloadDocument = function() { // Expose to global for onclick
                const frame = document.getElementById('documentFrame');
                const errorMsgDiv = document.getElementById('docErrorMsg');
                const frameSrc = frame.getAttribute('src');
                if (errorMsgDiv.classList.contains('d-none') === false || !frameSrc || frameSrc === 'about:blank') { alert("Cannot download: Document preview failed or no document loaded."); return; }
                const filename = frame.getAttribute('data-filename') || frameSrc.split('/').pop();
                const link = document.createElement('a'); link.href = frameSrc; link.download = filename;
                document.body.appendChild(link); link.click(); document.body.removeChild(link);
             }
            window.handleLicenseUpload = function(licenseNumber, input) { // Expose
                const file = input.files[0]; if (!file) return;
                const dataIndex = findDataIndexByLicenseNo(licenseNumber); if (dataIndex === -1) return;
                const simulatedFilename = file.name; allLicenseData[dataIndex].licenseCopy = simulatedFilename;
                const currentTableBody = document.getElementById('fssaiTableBody');
                const row = currentTableBody.querySelector(`tr[data-license-no="${licenseNumber}"]`);
                if (row) { const cellIndex = DATA_KEYS.indexOf('licenseCopy'); if (cellIndex > -1) row.cells[cellIndex].innerHTML = generateLicenseCopyHTML(simulatedFilename, licenseNumber); }
                addHistoryEntry(licenseNumber, 'Document Upload', `Uploaded: ${simulatedFilename}`, 'User');
                initializeStatuses();
                const metrics = calculateDashboardMetrics(allLicenseData);
                updateDashboardCards(metrics);
             }
            window.handleNewLicenseUpload = function(input) { // Expose
                const file = input.files[0]; const uploadedFileSpan = input.closest('td').querySelector('.uploaded-file');
                if (file) { uploadedFileSpan.innerHTML = `<i class="fas ${getFileIconClass(file.name)}"></i> ${file.name}`; input.dataset.uploadedFileName = file.name; }
                else { uploadedFileSpan.innerHTML = ''; delete input.dataset.uploadedFileName; }
             }
            window.handleCategoryChange = function(categorySelect) { // Expose
                const row = categorySelect.closest('tr'); const licenseTypeSelect = row.querySelector('select[name="licenseType"]'); if (!licenseTypeSelect) return;
                if (categorySelect.value === 'License') { licenseTypeSelect.disabled = false; if (licenseTypeSelect.value === 'NA') { const naOption = licenseTypeSelect.querySelector('option[value="NA"]'); if (naOption) naOption.removeAttribute('selected'); } }
                else { licenseTypeSelect.disabled = true; licenseTypeSelect.value = 'NA'; }
             }
            window.openRenewModal = function(licenseNumber) { // Expose
                 const dataIndex = findDataIndexByLicenseNo(licenseNumber);
                 if (dataIndex === -1) { alert("Error: Could not find license details."); return; }
                 const originalData = allLicenseData[dataIndex];
                 const existingDraft = draftUpdates.find(draft => draft.licenseNo === licenseNumber);
                 document.getElementById('renewLicenseNumber').value = originalData.licenseNo;
                 document.getElementById('renewUnitName').textContent = originalData.unitName;
                 document.getElementById('displayLicenseNumber').textContent = originalData.licenseNo;
                 document.getElementById('currentExpiryDate').textContent = originalData.expiryDate || 'N/A';
                 document.getElementById('newExpiryDate').value = existingDraft ? existingDraft.newExpiryDate : '';
                 const renewalDocInput = document.getElementById('renewalDocument');
                 const renewalFileNameSpan = document.getElementById('renewalFileName');
                 renewalDocInput.value = null;
                 if (existingDraft && existingDraft.newDocumentName) {
                     renewalFileNameSpan.innerHTML = `<i class="fas ${getFileIconClass(existingDraft.newDocumentName)}"></i> ${existingDraft.newDocumentName}`;
                 } else {
                      renewalFileNameSpan.innerHTML = '<i class="fas fa-file-alt"></i> No new file selected';
                 }
                 if (renewModal) renewModal.show();
              }
            const licenseHistoryData = { // Sample from FSSAI
                '123456789012': [{ date: '2022-01-15', action: 'Issued', details: 'Initial License Issued', user: 'System' }, { date: '2023-11-01', action: 'Document Upload', details: 'Uploaded: FSSAI_License_123456789012.pdf', user: 'User1' }],
                'SOUTHBETA999': [{ date: '2024-11-30', action: 'Issued', details: 'Initial HRA Issued', user: 'System' }],
                'NORTHC001234': [{ date: '2023-08-15', action: 'Issued', details: 'Initial TPA Issued', user: 'System' }],
                'SYSTEM': [{ date: new Date().toISOString().split('T')[0], action: 'System', details: 'Dashboard loaded', user: 'System' }],
            };
            function addHistoryEntry(licenseNumber, action, details, user = 'System') {
                if (!licenseNumber || !action || !details) { console.warn("Skipping history entry due to missing data:", {licenseNumber, action, details}); return; } if (!licenseHistoryData[licenseNumber]) { licenseHistoryData[licenseNumber] = []; }
                const entry = { date: new Date().toISOString().split('T')[0], action: action, details: details, user: user }; licenseHistoryData[licenseNumber].unshift(entry);
            }
            window.openHistoryModal = function(licenseNumber) { // Expose
                const dataIndex = findDataIndexByLicenseNo(licenseNumber); if (dataIndex === -1 && licenseNumber !== 'SYSTEM') { alert("Error: Could not find license details for history."); return; } const data = licenseNumber === 'SYSTEM' ? { unitName: 'System Log', licenseNo: 'SYSTEM'} : allLicenseData[dataIndex];
                document.getElementById('historyUnitName').textContent = data.unitName; document.getElementById('historyLicenseNumber').textContent = data.licenseNo; const history = licenseHistoryData[licenseNumber] || []; const historyTableBody = document.getElementById('historyTableBody'); historyTableBody.innerHTML = '';
                if (history.length === 0) { historyTableBody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No history available.</td></tr>'; } else { history.forEach(entry => { const row = historyTableBody.insertRow(); row.insertCell(0).textContent = entry.date; row.insertCell(1).textContent = entry.action; row.insertCell(2).textContent = entry.details; row.insertCell(3).textContent = entry.user; }); }
                if (historyModal) historyModal.show();
            }
            function findDataIndexByLicenseNo(licenseNo) {
                if (!licenseNo) return -1; return allLicenseData.findIndex(item => item.licenseNo === licenseNo);
             }
            function getStatusBadge(statusText) {
                if (!statusText) statusText = 'Unknown'; let s = statusText.toLowerCase(); let badgeClass = 'status-pending';
                if (s === 'active') badgeClass = 'status-active'; else if (s === 'expired') badgeClass = 'status-expired'; else if (s === 'pending') badgeClass = 'status-pending'; else if (s === 'unknown') badgeClass = 'status-pending';
                return `<span class="status ${badgeClass}">${statusText.charAt(0).toUpperCase() + statusText.slice(1)}</span>`;
             }
            function updateStatusBasedOnDate(dateString, currentStatus = 'Active') {
                 if (!['License', 'HRA', 'TPA', 'Others'].includes(currentStatus) && !dateString || dateString === 'NA' || currentStatus === 'Pending') {
                     if (dateString && dateString !== 'NA') {
                         try {
                             const expiryDate = new Date(dateString);
                             const today = new Date(); today.setHours(0,0,0,0);
                             if (!isNaN(expiryDate.getTime()) && expiryDate < today) return 'Expired';
                         } catch(e) { /* Ignore date parse error */ }
                     }
                     return currentStatus;
                 }
                try { const expiryDate = new Date(dateString); const today = new Date(); today.setHours(0, 0, 0, 0); if (isNaN(expiryDate.getTime())) return 'Unknown'; return expiryDate < today ? 'Expired' : 'Active'; } catch (e) { console.error("Error parsing date:", dateString, e); return 'Unknown'; }
             }
            function initializeStatuses() {
                allLicenseData.forEach(item => {
                    item.corporate = item.corporate || null;
                    item.regional = item.regional || null;
                    if (item.category && !['License', 'HRA', 'TPA', 'Others'].includes(item.category)) {
                       item.licenseType = 'NA';
                    }
                    item.status = updateStatusBasedOnDate(item.expiryDate, item.status);
                });
             }
            function generateLicenseCopyHTML(filename, licenseNumber) {
                 if (filename) { return `<div class="document-preview" onclick="viewDocument('${filename}')" title="View ${filename}"><i class="fas ${getFileIconClass(filename)}"></i><span class="document-name">${filename}</span></div>`; }
                 else { const itemIndex = findDataIndexByLicenseNo(licenseNumber); if (itemIndex === -1) { return `<div class="file-upload"><i class="fas fa-cloud-upload-alt me-1"></i> Upload<input type="file" onchange="handleNewLicenseUpload(this)" accept=".pdf,.jpg,.jpeg,.png" name="licenseCopyFile"></div><span class="uploaded-file"></span>`; }
                 const item = allLicenseData[itemIndex]; if (item.category && ['License', 'HRA', 'TPA', 'Others'].includes(item.category)) { return `<div class="file-upload"><i class="fas fa-cloud-upload-alt me-1"></i> Upload<input type="file" id="license-${licenseNumber}" onchange="handleLicenseUpload('${licenseNumber}', this)" accept=".pdf,.jpg,.jpeg,.png"></div><span id="upload-status-${licenseNumber}" class="uploaded-file"></span>`; }
                 else { return `<!-- NA -->`; } }
             }
            function generateActionsHTML(item) {
                 const licenseNumber = item.licenseNo;
                 const expiryDate = item.expiryDate;
                 let buttons = '';
                 if (!item || !item.status) return '<!-- Invalid Item -->';
                 const hasDraft = draftUpdates.some(draft => draft.licenseNo === licenseNumber);
                 if (hasDraft) {
                     buttons = `<button class="btn btn-sm btn-success" onclick="submitSingleDraft('${licenseNumber}', this)" title="Submit the saved draft for this license">
                                    <i class="fas fa-check"></i> Final Submit
                                </button>`;
                 } else if (item.status === 'Pending') {
                     buttons = `<button class="btn btn-sm btn-primary" onclick="alert('Update Status functionality for ${licenseNumber} not fully implemented.')">
                                   <i class="fas fa-edit"></i> Update Status
                               </button>`;
                 } else if (['Corporate', 'Regional'].includes(item.category)) {
                     buttons = `<button class="btn btn-sm btn-view" onclick="alert('View Details for ${licenseNumber} not implemented.')">
                                   <i class="fas fa-eye"></i> View
                               </button>`;
                 } else if (['License', 'HRA', 'TPA', 'Others'].includes(item.category)) {
                     buttons = `<button class="btn btn-sm btn-renew" onclick="openRenewModal('${licenseNumber}','${expiryDate}')">
                                    Renew/Update
                               </button>`;
                 }
                 if(licenseNumber) {
                     buttons += `<button class="btn btn-sm btn-history" onclick="openHistoryModal('${licenseNumber}','${expiryDate}')">
                                    History
                               </button>`;
                 }
                 
                 let status = "active"; // Or "inactive"
let isChecked = (status === "active") ? "checked" : "";

buttons += `
  <label class="switch">
    <input type="checkbox" onchange="toggleStatus('${licenseNumber}', this.checked)" ${isChecked}>
    <span class="slider"></span>
  </label>
`;

                 
                
                 return `<div class="action-btns">${buttons || 'No Actions'}</div>`;
             }
             

function populateHierarchicalOptions(data, selectElement, key, parentFilter = null) {
                const currentValue = selectElement.value; selectElement.innerHTML = `<option value="${ALL_OPTION_VALUE}" selected>-- All --</option>`; let filteredData = data;
                if (parentFilter) { if (parentFilter.corporate && parentFilter.corporate !== ALL_OPTION_VALUE) { filteredData = filteredData.filter(item => item.corporate === parentFilter.corporate); } if (parentFilter.regional && parentFilter.regional !== ALL_OPTION_VALUE) { filteredData = filteredData.filter(item => item.regional === parentFilter.regional); } }
                const uniqueValues = [...new Set(filteredData.map(item => item[key]).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true }));
                uniqueValues.forEach(value => { const option = document.createElement('option'); option.value = value; option.textContent = value; selectElement.appendChild(option); });
                if (Array.from(selectElement.options).some(opt => opt.value === currentValue)) { selectElement.value = currentValue; } else { if (key === 'corporate') selectElement.value = activeFilters.selectedCorporate || ALL_OPTION_VALUE; else if (key === 'regional') selectElement.value = activeFilters.selectedRegional || ALL_OPTION_VALUE; else if (key === 'unitName') selectElement.value = activeFilters.selectedUnit || ALL_OPTION_VALUE; }
                selectElement.disabled = selectElement.options.length <= 1;
             }
            function updateHierarchicalFilters() {
                const corporateSelect = document.getElementById('unit-filter-corporate-select'); const regionalSelect = document.getElementById('unit-filter-regional-select'); const unitSelect = document.getElementById('unit-filter-unit-select');
                if (!corporateSelect || !regionalSelect || !unitSelect) return; const selectedCorporate = corporateSelect.value; const selectedRegional = regionalSelect.value;
                populateHierarchicalOptions(allLicenseData, corporateSelect, 'corporate'); populateHierarchicalOptions(allLicenseData, regionalSelect, 'regional', { corporate: selectedCorporate }); populateHierarchicalOptions(allLicenseData, unitSelect, 'unitName', { corporate: selectedCorporate, regional: selectedRegional });
                if (Array.from(corporateSelect.options).some(opt => opt.value === activeFilters.selectedCorporate)) corporateSelect.value = activeFilters.selectedCorporate || ALL_OPTION_VALUE;
                if (Array.from(regionalSelect.options).some(opt => opt.value === activeFilters.selectedRegional)) regionalSelect.value = activeFilters.selectedRegional || ALL_OPTION_VALUE;
                if (Array.from(unitSelect.options).some(opt => opt.value === activeFilters.selectedUnit)) unitSelect.value = activeFilters.selectedUnit || ALL_OPTION_VALUE;
             }
            function getUniqueColumnValues(columnKey) {
                const values = allLicenseData.map(item => item[columnKey] || '(Empty)'); return [...new Set(values)].filter(Boolean).sort((a, b) => String(a).localeCompare(String(b)));
             }
            function populateFilterOptions(dropdownElement, columnKey) {
                if (columnKey === 'unitName' || columnKey === 'licenseNo' || columnKey === 'expiryDate') return;
                const optionsList = dropdownElement.querySelector('.options-list'); const searchInput = dropdownElement.querySelector('.filter-search input'); if (!optionsList) return;
                const uniqueValues = getUniqueColumnValues(columnKey);
                const currentColumnFilters = Array.isArray(activeFilters[columnKey]) ? activeFilters[columnKey] : []; optionsList.innerHTML = '';
                uniqueValues.forEach(value => { const listItem = document.createElement('li'); const safeValue = String(value).replace(/[^a-zA-Z0-9-_]/g, ''); const checkboxId = `filter-${columnKey}-${safeValue || 'empty'}-${Math.random().toString(36).substring(2, 7)}`; const isChecked = currentColumnFilters.includes(value); listItem.innerHTML = `<input type="checkbox" id="${checkboxId}" value="${value}" ${isChecked ? 'checked' : ''}><label for="${checkboxId}">${value}</label>`; optionsList.appendChild(listItem); });
                if (searchInput) {
                     searchInput.value = '';
                     filterDropdownOptions(searchInput);
                }
             }
            function filterDropdownOptions(searchInput) {
                if(!searchInput) return;
                const filterText = searchInput.value.toLowerCase(); const optionsList = searchInput.closest('.th-filter-dropdown').querySelector('.options-list'); if (!optionsList) return;
                optionsList.querySelectorAll('li').forEach(item => { const label = item.querySelector('label'); if (label) { item.style.display = label.textContent.toLowerCase().includes(filterText) ? '' : 'none'; } });
             }
            function closeAllFilterDropdowns(exceptElement = null) {
                document.querySelectorAll('#panel-license .th-filter-dropdown').forEach(dropdown => { if (dropdown !== exceptElement) { dropdown.style.display = 'none'; } }); if (currentlyOpenFilterDropdown && currentlyOpenFilterDropdown !== exceptElement) { currentlyOpenFilterDropdown = null; }
             }

             function resetAllFilters() {
                 activeFilters = {
                     selectedCorporate: null,
                     selectedRegional: null,
                     selectedUnit: null,
                     licenseNoSearch: null,
                     expiryDateFrom: null,
                     expiryDateTo: null
                 };
                 Object.keys(activeFilters).forEach(key => {
                     if (Array.isArray(activeFilters[key])) {
                         delete activeFilters[key]; // Remove array type filters
                     }
                 });
                 const searchInput = document.getElementById('searchInput');
                 if (searchInput) searchInput.value = '';
                 const corporateSelect = document.getElementById('unit-filter-corporate-select');
                 const regionalSelect = document.getElementById('unit-filter-regional-select');
                 const unitSelect = document.getElementById('unit-filter-unit-select');
                 if (corporateSelect) corporateSelect.value = ALL_OPTION_VALUE;
                 if (regionalSelect) regionalSelect.value = ALL_OPTION_VALUE;
                 if (unitSelect) unitSelect.value = ALL_OPTION_VALUE;
                 updateHierarchicalFilters(); // This will also reset select values if needed
                 const licenseNoSearchInput = document.getElementById('licenseNoSearchInput');
                 if (licenseNoSearchInput) licenseNoSearchInput.value = '';
                 const expiryDateFromInput = document.getElementById('expiryDateFromInput');
                 const expiryDateToInput = document.getElementById('expiryDateToInput');
                 if (expiryDateFromInput) expiryDateFromInput.value = '';
                 if (expiryDateToInput) expiryDateToInput.value = '';
                 // Uncheck all checkboxes in specific filter dropdowns
                 document.querySelectorAll('#panel-license .th-filter-dropdown[data-column-key="category"] input[type="checkbox"], #panel-license .th-filter-dropdown[data-column-key="licenseType"] input[type="checkbox"], #panel-license .th-filter-dropdown[data-column-key="status"] input[type="checkbox"]').forEach(cb => {
                     cb.checked = false;
                 });
                  // Clear search inputs within those dropdowns
                  document.querySelectorAll('#panel-license .th-filter-dropdown[data-column-key="category"] .filter-search input, #panel-license .th-filter-dropdown[data-column-key="licenseType"] .filter-search input, #panel-license .th-filter-dropdown[data-column-key="status"] .filter-search input').forEach(input => {
                      if (input) {
                         input.value = '';
                         filterDropdownOptions(input); // Re-filter to show all options
                      }
                  });
                 // Deactivate filter icons
                 document.querySelectorAll('#panel-license .th-filter-icon.active').forEach(icon => {
                     icon.classList.remove('active');
                 });
                  closeAllFilterDropdowns();
             }

            const DUE_SOON_DAYS = 90;
            function calculateDashboardMetrics(data) {
                const categories = ['License', 'HRA', 'TPA'];
                const metrics = {};
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const dueSoonDate = new Date(today);
                dueSoonDate.setDate(today.getDate() + DUE_SOON_DAYS);
                categories.forEach(category => {
                    const categoryData = data.filter(item => item.category === category);
                    let totalCount = categoryData.length;
                    let activeCount = 0;
                    let expiredCount = 0;
                    let dueSoonCount = 0;
                    let earliestDueDate = null;
                    categoryData.forEach(item => {
                        if (item.status === 'Active') {
                            activeCount++;
                            if (item.expiryDate && item.expiryDate !== 'N/A') {
                                try {
                                    const expiry = new Date(item.expiryDate);
                                    if (!isNaN(expiry.getTime())) {
                                         expiry.setHours(0,0,0,0);
                                        if (!earliestDueDate || expiry < earliestDueDate) {
                                            earliestDueDate = expiry;
                                        }
                                        if (expiry >= today && expiry <= dueSoonDate) {
                                            dueSoonCount++;
                                        }
                                    }
                                } catch (e) { console.error("Error parsing expiry date for metric:", item.expiryDate); }
                            }
                        } else if (item.status === 'Expired') {
                            expiredCount++;
                        }
                    });
                    metrics[category] = {
                        total: totalCount,
                        active: activeCount,
                        expired: expiredCount,
                        dueSoon: dueSoonCount,
                        earliestDueDate: earliestDueDate
                    };
                });
                return metrics;
            }

            function updateDashboardCards(metrics) {
                const cardMap = {
                    'License': { idPrefix: 'card-license', cardElementId: 'card-license', defaultClass: 'dashboard-card-green' },
                    'HRA':     { idPrefix: 'card-hra', cardElementId: 'card-hra', defaultClass: 'dashboard-card-orange' },
                    'TPA':     { idPrefix: 'card-tpa', cardElementId: 'card-tpa', defaultClass: 'dashboard-card-blue' }
                };
                Object.keys(cardMap).forEach(category => {
                    const metric = metrics[category];
                    const config = cardMap[category];
                    const prefix = config.idPrefix;
                    const statusEl = document.getElementById(`${prefix}-status`);
                    const dueEl = document.getElementById(`${prefix}-due`);
                    const progressEl = document.getElementById(`${prefix}-progress`);
                    const infoEl = document.getElementById(`${prefix}-info`);
                    const cardEl = document.getElementById(config.cardElementId);
                    if (!statusEl || !dueEl || !progressEl || !infoEl || !cardEl) {
                        console.warn(`Card elements for category ${category} not found. Ensure IDs are correct and within #panel-license.`);
                        return;
                    }
                    statusEl.className = 'status-badge'; // Reset classes
                    progressEl.className = 'progress-fill'; // Reset classes
                    cardEl.className = `dashboard-card`; // Reset base class

                    if (metric.total === 0) {
                        statusEl.textContent = 'N/A';
                        statusEl.classList.add('status-pending');
                        dueEl.textContent = 'Next Due: N/A';
                        progressEl.style.width = '0%';
                        infoEl.textContent = 'No Data';
                        // Ensure all color classes are removed before adding gray
                        cardEl.classList.remove('dashboard-card-green', 'dashboard-card-orange', 'dashboard-card-blue', 'dashboard-card-red', 'dashboard-card-gray');
                        cardEl.classList.add('dashboard-card-gray');
                        return;
                    }

                    let overallStatusText = 'COMPLIANT';
                    let overallStatusClass = 'status-compliant';
                    let progressColorClass = 'progress-fill-green';
                    let cardBorderClass = config.defaultClass;

                    if (metric.expired > 0) {
                        overallStatusText = 'EXPIRED';
                        overallStatusClass = 'status-expired';
                        progressColorClass = 'progress-fill-red';
                        cardBorderClass = 'dashboard-card-red';
                    } else if (metric.dueSoon > 0) {
                        overallStatusText = 'DUE SOON';
                        overallStatusClass = 'status-due-soon';
                        progressColorClass = 'progress-fill-orange';
                         cardBorderClass = 'dashboard-card-orange';
                    } else { // Compliant
                        overallStatusText = 'COMPLIANT';
                        overallStatusClass = 'status-compliant';
                        progressColorClass = 'progress-fill-green';
                         // Default border based on category if compliant
                         if (category === 'License') cardBorderClass = 'dashboard-card-green';
                         else if (category === 'HRA') cardBorderClass = 'dashboard-card-orange';
                         else if (category === 'TPA') cardBorderClass = 'dashboard-card-blue';
                         else cardBorderClass = 'dashboard-card-green'; // Fallback
                    }

                    statusEl.textContent = overallStatusText;
                    statusEl.classList.add(overallStatusClass);

                    if (metric.earliestDueDate) {
                        dueEl.textContent = `Next Due: ${metric.earliestDueDate.toISOString().split('T')[0]}`;
                    } else if (metric.active === 0 && metric.total > 0) { // All are expired or pending, no active to give a due date
                         dueEl.textContent = 'Next Due: N/A (None Active)';
                     } else {
                        dueEl.textContent = 'Next Due: N/A';
                    }

                     const compliancePercent = metric.total > 0 ? (metric.active / metric.total) * 100 : 0;
                     progressEl.style.width = `${compliancePercent.toFixed(0)}%`;
                     progressEl.classList.add(progressColorClass);

                     infoEl.textContent = `Active: ${metric.active} / Total: ${metric.total}`;

                     // Ensure all color classes are removed before adding the determined one
                     cardEl.classList.remove('dashboard-card-green', 'dashboard-card-orange', 'dashboard-card-blue', 'dashboard-card-red', 'dashboard-card-gray');
                     cardEl.classList.add(cardBorderClass);
                });
            }

            window.saveDraftUpdate = function() { // Expose
                const licenseNumber = document.getElementById('renewLicenseNumber').value;
                const newExpiryDate = document.getElementById('newExpiryDate').value;
                const fileInput = document.getElementById('renewalDocument');
                const file = fileInput.files[0];
                let newDocumentName = null;
                if (!newExpiryDate) {
                    alert('Please select a new expiry date to save a draft.');
                    return;
                }
                if (file) {
                    newDocumentName = file.name;
                } else {
                    // If no new file, check if there was a doc in an existing draft for this item
                    const existingDraft = draftUpdates.find(draft => draft.licenseNo === licenseNumber);
                    if (existingDraft && existingDraft.newDocumentName) {
                        newDocumentName = existingDraft.newDocumentName;
                    }
                }
                const draftIndex = draftUpdates.findIndex(draft => draft.licenseNo === licenseNumber);
                const draftData = {
                    licenseNo: licenseNumber,
                    newExpiryDate: newExpiryDate,
                    newDocumentName: newDocumentName // Can be null if no file was ever selected for this draft
                };
                if (draftIndex > -1) {
                    draftUpdates[draftIndex] = draftData;
                } else {
                    draftUpdates.push(draftData);
                }
                // Visually mark the row in the table
                const tableBody = document.getElementById('fssaiTableBody');
                const row = tableBody.querySelector(`tr[data-license-no="${licenseNumber}"]`);
                if (row) {
                    row.classList.add('has-draft');
                     // Update actions cell to show "Final Submit"
                     const actionsCellIndex = DATA_KEYS.indexOf('actions');
                     const originalDataIndex = findDataIndexByLicenseNo(licenseNumber); // Get original data for context
                     if (actionsCellIndex > -1 && originalDataIndex > -1) {
                         row.cells[actionsCellIndex].innerHTML = generateActionsHTML(allLicenseData[originalDataIndex]);
                     }
                }
                updateDraftCount();
                if (renewModal) renewModal.hide();
                alert(`Draft saved for license ${licenseNumber}. Click 'Final Submit' in the table or 'Submit All Drafts' to apply changes.`);
            }

            function updateDraftCount() {
                 const count = draftUpdates.length;
                 const draftCountEl = document.getElementById('draftCount');
                 const submitDraftsBtnEl = document.getElementById('submitDraftsButton');
                 if(draftCountEl) draftCountEl.textContent = count;
                 if(submitDraftsBtnEl) submitDraftsBtnEl.disabled = (count === 0);
             }

             function reapplyDraftStyles() {
                 const tableBody = document.getElementById('fssaiTableBody');
                 if (!tableBody) return;
                 draftUpdates.forEach(draft => {
                     const row = tableBody.querySelector(`tr[data-license-no="${draft.licenseNo}"]`);
                     if (row) {
                         row.classList.add('has-draft');
                     }
                 });
             }

            window.submitSingleDraft = function(licenseNumber, buttonElement) { // Expose
                const draftIndex = draftUpdates.findIndex(draft => draft.licenseNo === licenseNumber);
                if (draftIndex === -1) {
                    alert(`Error: Could not find draft for ${licenseNumber}. Please refresh.`);
                     const row = buttonElement?.closest('tr'); // Safely access closest
                     if(row) row.classList.remove('has-draft');
                    return;
                }
                const draft = draftUpdates[draftIndex];
                const dataIndex = findDataIndexByLicenseNo(licenseNumber);
                if (dataIndex === -1) {
                    alert(`Error: Could not find original data for ${licenseNumber}. Cannot submit draft.`);
                    draftUpdates.splice(draftIndex, 1); // Remove invalid draft
                    updateDraftCount();
                     const row = buttonElement?.closest('tr');
                     if(row) row.classList.remove('has-draft');
                    return;
                }
                const item = allLicenseData[dataIndex];
                const oldExpiry = item.expiryDate;
                const oldDoc = item.licenseCopy;

                // Apply draft changes
                item.expiryDate = draft.newExpiryDate;
                item.licenseCopy = draft.newDocumentName; // This can be null if no new doc was part of the draft
                item.status = updateStatusBasedOnDate(item.expiryDate, item.status); // Recalculate status

                // Log history
                let details = `Applied draft: Expiry ${oldExpiry || 'N/A'} -> ${item.expiryDate}`;
                if (draft.newDocumentName && draft.newDocumentName !== oldDoc) {
                    details += `, Doc Updated: ${draft.newDocumentName}`;
                } else if (!draft.newDocumentName && oldDoc) { // Document was removed
                    details += `, Doc Removed`;
                }
                addHistoryEntry(item.licenseNo, 'Draft Submitted', details, 'User');

                // Remove from drafts
                draftUpdates.splice(draftIndex, 1);
                updateDraftCount();

                // Refresh UI
                initializeStatuses(); // This will re-evaluate all statuses
                const metrics = calculateDashboardMetrics(allLicenseData);
                updateDashboardCards(metrics);
                 applyAllFilters(); // This will re-render the table with updated data & styles
                alert(`Draft for license ${licenseNumber} submitted successfully!`);
            }

            function applyAllFilters() {
                const searchInputEl = document.getElementById('searchInput');
                if (!searchInputEl) {
                    console.warn("FSSAI search input not found. Cannot apply filters if License tab is not active/rendered.");
                    filteredLicenseData = [...allLicenseData]; // Show all data if elements aren't ready
                    renderTablePage(1);
                    return;
                }

                const globalSearchTerm = searchInputEl.value.toLowerCase().trim();
                let dataResult = [...allLicenseData];

                // Hierarchical Unit Filters
                const selCorp = activeFilters.selectedCorporate;
                const selReg = activeFilters.selectedRegional;
                const selUnit = activeFilters.selectedUnit;
                if (selCorp && selCorp !== ALL_OPTION_VALUE) { dataResult = dataResult.filter(item => item.corporate === selCorp); }
                if (selReg && selReg !== ALL_OPTION_VALUE) { dataResult = dataResult.filter(item => item.regional === selReg); }
                if (selUnit && selUnit !== ALL_OPTION_VALUE) { dataResult = dataResult.filter(item => item.unitName === selUnit); }

                // Column-specific filters (Category, License Type, Status, License No)
                Object.keys(activeFilters).forEach(columnKey => {
                    const filterValue = activeFilters[columnKey];
                    // Skip hierarchical keys already handled, and date range keys
                    if (['selectedCorporate', 'selectedRegional', 'selectedUnit', 'expiryDateFrom', 'expiryDateTo'].includes(columnKey) || !filterValue) return;

                    if (Array.isArray(filterValue) && filterValue.length > 0) { // For checkbox-based filters
                         if (activeFilters[columnKey]) { // Should always be true if filterValue is a non-empty array
                               dataResult = dataResult.filter(item => activeFilters[columnKey].includes(item[columnKey] || '(Empty)'));
                         }
                    }
                    else if (columnKey === 'licenseNoSearch' && typeof filterValue === 'string') { // For License No search
                        const searchTerm = filterValue.toLowerCase();
                        dataResult = dataResult.filter(item => item.licenseNo && item.licenseNo.toLowerCase().includes(searchTerm));
                    }
                });

                // Date Range Filter (Expiry Date)
                const dateFrom = activeFilters.expiryDateFrom;
                const dateTo = activeFilters.expiryDateTo;
                if (dateFrom || dateTo) {
                    const fromDate = dateFrom ? new Date(dateFrom) : null;
                    const toDate = dateTo ? new Date(dateTo) : null;
                    if (fromDate) fromDate.setHours(0, 0, 0, 0); // Start of the day
                    if (toDate) toDate.setHours(23, 59, 59, 999); // End of the day

                    dataResult = dataResult.filter(item => {
                        if (!item.expiryDate || item.expiryDate === 'N/A') return false;
                        try {
                            const itemDate = new Date(item.expiryDate); itemDate.setHours(0,0,0,0); // Normalize item date for comparison
                            if (isNaN(itemDate.getTime())) return false; // Invalid item date

                            const afterFrom = fromDate ? itemDate >= fromDate : true;
                            const beforeTo = toDate ? itemDate <= toDate : true;
                            return afterFrom && beforeTo;
                        } catch (e) { return false; } // Error parsing item's date
                    });
                }

                // Apply global search on the already column-filtered data
                const columnFilteredData = [...dataResult];
                if (globalSearchTerm) {
                    filteredLicenseData = columnFilteredData.filter(item =>
                        Object.values(item).some(val => val && val.toString().toLowerCase().includes(globalSearchTerm))
                    );
                } else {
                    filteredLicenseData = columnFilteredData;
                }

                // Update filter icon active states
                document.querySelectorAll('#panel-license .th-filter-icon').forEach(icon => {
                    const key = icon.dataset.columnKey; let isActive = false;
                    if (key === 'unitName') { isActive = !!(activeFilters.selectedCorporate || activeFilters.selectedRegional || activeFilters.selectedUnit); }
                    else if (key === 'licenseNo') { isActive = !!activeFilters.licenseNoSearch; }
                    else if (key === 'expiryDate') { isActive = !!(activeFilters.expiryDateFrom || activeFilters.expiryDateTo); }
                    else { isActive = Array.isArray(activeFilters[key]) && activeFilters[key].length > 0; }
                    icon.classList.toggle('active', isActive);
                });

                renderTablePage(1); // Render page 1 of the final filtered data
            }

            function setupEventListeners() {
                // Ensure event listeners are only set up if the panel is active or elements exist
                const panelLicense = document.getElementById('panel-license');
                if (!panelLicense) return; // Don't setup if panel isn't in DOM (e.g. another tab active on load)

                panelLicense.querySelectorAll('.th-filter-icon').forEach(icon => {
                    icon.addEventListener('click', (event) => {
                        event.stopPropagation(); const columnKey = icon.dataset.columnKey; const dropdown = icon.closest('th').querySelector('.th-filter-dropdown'); if (!dropdown) return;
                        if (dropdown === currentlyOpenFilterDropdown) { closeAllFilterDropdowns(); }
                        else {
                            closeAllFilterDropdowns(dropdown);
                            if (columnKey === 'unitName') { updateHierarchicalFilters(); }
                            else if (columnKey === 'licenseNo') { const i = dropdown.querySelector('#licenseNoSearchInput'); if(i) { i.value = activeFilters.licenseNoSearch || ''; i.focus();} }
                            else if (columnKey === 'expiryDate') { const f = dropdown.querySelector('#expiryDateFromInput'); const t = dropdown.querySelector('#expiryDateToInput'); if(f) f.value = activeFilters.expiryDateFrom || ''; if(t) t.value = activeFilters.expiryDateTo || ''; }
                            else { populateFilterOptions(dropdown, columnKey); const s = dropdown.querySelector('.filter-search input'); if(s) s.focus(); }
                            dropdown.style.display = 'block'; currentlyOpenFilterDropdown = dropdown;
                        }
                    });
                });
                 panelLicense.querySelectorAll('.th-filter-dropdown[data-column-key="category"] .btn-apply, .th-filter-dropdown[data-column-key="licenseType"] .btn-apply, .th-filter-dropdown[data-column-key="status"] .btn-apply').forEach(button => {
                    button.addEventListener('click', () => { const dropdown = button.closest('.th-filter-dropdown'); const columnKey = dropdown.dataset.columnKey; const selectedValues = Array.from(dropdown.querySelectorAll('.options-list input:checked')).map(cb => cb.value); if (selectedValues.length > 0) activeFilters[columnKey] = selectedValues; else delete activeFilters[columnKey]; closeAllFilterDropdowns(); applyAllFilters(); reapplyDraftStyles(); }); });
                 panelLicense.querySelectorAll('.th-filter-dropdown[data-column-key="category"] .btn-clear, .th-filter-dropdown[data-column-key="licenseType"] .btn-clear, .th-filter-dropdown[data-column-key="status"] .btn-clear').forEach(button => {
                    button.addEventListener('click', () => { const dropdown = button.closest('.th-filter-dropdown'); const columnKey = dropdown.dataset.columnKey; dropdown.querySelectorAll('.options-list input').forEach(cb => cb.checked = false); const searchInput = dropdown.querySelector('.filter-search input'); if (searchInput) { searchInput.value = ''; filterDropdownOptions(searchInput); } delete activeFilters[columnKey]; applyAllFilters(); reapplyDraftStyles(); }); });
                 panelLicense.querySelectorAll('.th-filter-dropdown[data-column-key="category"] .filter-search input, .th-filter-dropdown[data-column-key="licenseType"] .filter-search input, .th-filter-dropdown[data-column-key="status"] .filter-search input').forEach(input => {
                    input.addEventListener('input', () => filterDropdownOptions(input)); });
                const corporateSelect = document.getElementById('unit-filter-corporate-select'); const regionalSelect = document.getElementById('unit-filter-regional-select'); const unitSelect = document.getElementById('unit-filter-unit-select'); const unitFilterApplyButton = panelLicense.querySelector('.unit-filter-apply'); const unitFilterClearButton = panelLicense.querySelector('.unit-filter-clear');
                if (corporateSelect) corporateSelect.addEventListener('change', () => { if (regionalSelect) regionalSelect.value = ALL_OPTION_VALUE; if (unitSelect) unitSelect.value = ALL_OPTION_VALUE; updateHierarchicalFilters(); });
                if (regionalSelect) regionalSelect.addEventListener('change', () => { if (unitSelect) unitSelect.value = ALL_OPTION_VALUE; updateHierarchicalFilters(); });
                if (unitFilterApplyButton && corporateSelect && regionalSelect && unitSelect) unitFilterApplyButton.addEventListener('click', () => { activeFilters.selectedCorporate = corporateSelect.value !== ALL_OPTION_VALUE ? corporateSelect.value : null; activeFilters.selectedRegional = regionalSelect.value !== ALL_OPTION_VALUE ? regionalSelect.value : null; activeFilters.selectedUnit = unitSelect.value !== ALL_OPTION_VALUE ? unitSelect.value : null; closeAllFilterDropdowns(); applyAllFilters(); reapplyDraftStyles(); });
                if (unitFilterClearButton && corporateSelect && regionalSelect && unitSelect) unitFilterClearButton.addEventListener('click', () => { corporateSelect.value = ALL_OPTION_VALUE; regionalSelect.value = ALL_OPTION_VALUE; unitSelect.value = ALL_OPTION_VALUE; activeFilters.selectedCorporate = null; activeFilters.selectedRegional = null; activeFilters.selectedUnit = null; updateHierarchicalFilters(); applyAllFilters(); reapplyDraftStyles(); });
                const licenseNoApplyButton = panelLicense.querySelector('.licenseNo-filter-apply'); const licenseNoClearButton = panelLicense.querySelector('.licenseNo-filter-clear'); const licenseNoSearchInput = document.getElementById('licenseNoSearchInput');
                if (licenseNoApplyButton && licenseNoSearchInput) { licenseNoApplyButton.addEventListener('click', () => { const searchTerm = licenseNoSearchInput.value.trim(); activeFilters.licenseNoSearch = searchTerm ? searchTerm : null; closeAllFilterDropdowns(); applyAllFilters(); reapplyDraftStyles(); }); licenseNoSearchInput.addEventListener('keypress', (event) => { if (event.key === 'Enter') { event.preventDefault(); licenseNoApplyButton.click(); } }); }
                if (licenseNoClearButton && licenseNoSearchInput) { licenseNoClearButton.addEventListener('click', () => { licenseNoSearchInput.value = ''; activeFilters.licenseNoSearch = null; applyAllFilters(); reapplyDraftStyles(); }); }
                const expiryDateApplyButton = panelLicense.querySelector('.expiryDate-filter-apply'); const expiryDateClearButton = panelLicense.querySelector('.expiryDate-filter-clear'); const expiryDateFromInput = document.getElementById('expiryDateFromInput'); const expiryDateToInput = document.getElementById('expiryDateToInput');
                if (expiryDateApplyButton && expiryDateFromInput && expiryDateToInput) { expiryDateApplyButton.addEventListener('click', () => { activeFilters.expiryDateFrom = expiryDateFromInput.value || null; activeFilters.expiryDateTo = expiryDateToInput.value || null; closeAllFilterDropdowns(); applyAllFilters(); reapplyDraftStyles(); }); }
                if (expiryDateClearButton && expiryDateFromInput && expiryDateToInput) { expiryDateClearButton.addEventListener('click', () => { expiryDateFromInput.value = ''; expiryDateToInput.value = ''; activeFilters.expiryDateFrom = null; activeFilters.expiryDateTo = null; applyAllFilters(); reapplyDraftStyles(); }); }
                document.addEventListener('click', (event) => { if (currentlyOpenFilterDropdown && !currentlyOpenFilterDropdown.contains(event.target) && !event.target.closest('#panel-license .th-filter-icon')) { if (!event.target.closest('#panel-license .th-filter-dropdown .filter-actions button')) { closeAllFilterDropdowns(); } } });
                panelLicense.querySelectorAll('.th-filter-dropdown').forEach(dropdown => { dropdown.addEventListener('click', event => event.stopPropagation()); });
                 const searchInput = document.getElementById('searchInput'); const searchButton = document.getElementById('searchButton');
                 if (searchButton) searchButton.addEventListener('click', () => { applyAllFilters(); reapplyDraftStyles(); });
                 if (searchInput) { searchInput.addEventListener('keypress', (event) => { if (event.key === 'Enter') { applyAllFilters(); reapplyDraftStyles(); } }); searchInput.addEventListener('input', () => { applyAllFilters(); reapplyDraftStyles(); }); } // Live search on input change
                 const rowsPerPageSelect = document.getElementById('rowsPerPageSelect');
                 if (rowsPerPageSelect) {
                     rowsPerPageSelect.addEventListener('change', function() {
                         rowsPerPage = parseInt(this.value, 10);
                         renderTablePage(1); // Go to page 1 with new rows per page
                         reapplyDraftStyles();
                     });
                 }
                 const submitDraftsBtn = document.getElementById('submitDraftsButton');
                 if (submitDraftsBtn) {
                     submitDraftsBtn.addEventListener('click', () => {
                         if (draftUpdates.length === 0) {
                             alert("No drafts to submit.");
                             return;
                         }
                         if (!confirm(`Are you sure you want to submit all ${draftUpdates.length} draft(s)?`)) {
                            return;
                         }
                         let updatesApplied = 0;
                         const draftsToSubmit = [...draftUpdates]; // Iterate over a copy
                         draftsToSubmit.forEach(draft => {
                             const dataIndex = findDataIndexByLicenseNo(draft.licenseNo);
                             if (dataIndex > -1) {
                                 const item = allLicenseData[dataIndex];
                                 const oldExpiry = item.expiryDate;
                                 const oldDoc = item.licenseCopy;
                                 item.expiryDate = draft.newExpiryDate;
                                 item.licenseCopy = draft.newDocumentName;
                                 item.status = updateStatusBasedOnDate(item.expiryDate, item.status);
                                 let details = `Applied draft: Expiry ${oldExpiry || 'N/A'} -> ${item.expiryDate}`;
                                 if (draft.newDocumentName && draft.newDocumentName !== oldDoc) {
                                     details += `, Doc Updated: ${draft.newDocumentName}`;
                                 } else if (!draft.newDocumentName && oldDoc) {
                                     details += `, Doc Removed`;
                                 }
                                 addHistoryEntry(item.licenseNo, 'Draft Submitted', details, 'User');
                                 // Remove from the original draftUpdates array
                                 const originalDraftIndex = draftUpdates.findIndex(d => d.licenseNo === draft.licenseNo);
                                 if (originalDraftIndex > -1) {
                                     draftUpdates.splice(originalDraftIndex, 1);
                                 }
                                 updatesApplied++;
                             } else {
                                  // If original data not found, still remove from drafts
                                  const originalDraftIndex = draftUpdates.findIndex(d => d.licenseNo === draft.licenseNo);
                                  if (originalDraftIndex > -1) {
                                      draftUpdates.splice(originalDraftIndex, 1);
                                  }
                             }
                         });
                         updateDraftCount();
                         initializeStatuses();
                         const metrics = calculateDashboardMetrics(allLicenseData);
                         updateDashboardCards(metrics);
                         applyAllFilters(); // Re-render table
                         alert(`${updatesApplied} draft(s) submitted successfully!`);
                     });
                 }
                 const refreshTableBtn = document.getElementById('refreshTableButton');
                 if (refreshTableBtn) {
                     refreshTableBtn.addEventListener('click', () => {
                        resetAllFilters();
                        initializeStatuses();
                        const metrics = calculateDashboardMetrics(allLicenseData);
                        updateDashboardCards(metrics);
                        applyAllFilters(); // This will render table page 1 with no filters
                        addHistoryEntry('SYSTEM', 'Table Refresh', 'Table view refreshed and filters cleared.', 'User');
                        reapplyDraftStyles();
                     });
                 }
            }

            function renderTablePage(page) {
                currentPage = page;
                const tableBody = document.getElementById('fssaiTableBody');
                if (!tableBody) { /* console.warn("FSSAI table body not found for rendering."); */ return; }
                tableBody.innerHTML = '';

                const dataToRender = filteredLicenseData;
                const totalItems = dataToRender.length;
                const totalPages = Math.ceil(totalItems / rowsPerPage) || 1;

                page = Math.max(1, Math.min(page, totalPages)); // Ensure page is within bounds
                currentPage = page;

                const start = (page - 1) * rowsPerPage;
                const end = start + rowsPerPage;
                const pageData = dataToRender.slice(start, end);

                pageData.forEach((item, index) => {
                    const actualSlNo = start + index + 1; // SL No based on current page and position
                    const row = tableBody.insertRow();
                    row.setAttribute('data-license-no', item.licenseNo || `temp-${index}`); // Unique ID for row
                    const hasDraft = draftUpdates.some(draft => draft.licenseNo === item.licenseNo);
                    if (hasDraft) {
                        row.classList.add('has-draft');
                    }

                    row.insertCell().textContent = actualSlNo;
                    row.insertCell().textContent = item.unitName || '';
                    row.insertCell().textContent = item.category || '';
                    row.insertCell().textContent = item.licenseNo || '';
                    row.insertCell().textContent = item.expiryDate || 'N/A';
                    row.insertCell().textContent = item.licenseType || 'N/A';
                    row.insertCell().innerHTML = generateLicenseCopyHTML(item.licenseCopy, item.licenseNo);
                    row.insertCell().innerHTML = getStatusBadge(item.status);
                    row.insertCell().innerHTML = generateActionsHTML(item);
                });

                updatePaginationControls(page, totalPages, totalItems);
             }
            function updatePaginationControls(currentPage, totalPages, totalItems) {
                const paginationUl = document.getElementById('paginationUl'); const showingStart = document.getElementById('showingStart'); const showingEnd = document.getElementById('showingEnd'); const totalEntries = document.getElementById('totalEntries');
                if (!paginationUl || !showingStart || !showingEnd || !totalEntries) { /* console.warn("FSSAI pagination elements not found."); */ return; }
                paginationUl.innerHTML = '';
                if (totalItems === 0) { showingStart.textContent = 0; showingEnd.textContent = 0; totalEntries.textContent = 0; paginationUl.innerHTML = '<li class="page-item disabled"><span class="page-link">No data</span></li>'; return; } const startEntry = (currentPage - 1) * rowsPerPage + 1; const endEntry = Math.min(startEntry + rowsPerPage - 1, totalItems); showingStart.textContent = startEntry; showingEnd.textContent = endEntry; totalEntries.textContent = totalItems;
                let liPrev = document.createElement('li'); liPrev.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`; liPrev.innerHTML = `<a class="page-link" href="#" ${currentPage > 1 ? `onclick="event.preventDefault(); changePage(${currentPage - 1})"` : ''}>Previous</a>`; paginationUl.appendChild(liPrev);
                const maxPagesToShow = 5; let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2)); let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1); startPage = Math.max(1, endPage - maxPagesToShow + 1); if (startPage > 1) { paginationUl.appendChild(createPageItem(1)); if (startPage > 2) paginationUl.appendChild(createEllipsisItem()); } for (let i = startPage; i <= endPage; i++) paginationUl.appendChild(createPageItem(i, currentPage === i)); if (endPage < totalPages) { if (endPage < totalPages - 1) paginationUl.appendChild(createEllipsisItem()); paginationUl.appendChild(createPageItem(totalPages)); }
                let liNext = document.createElement('li'); liNext.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`; liNext.innerHTML = `<a class="page-link" href="#" ${currentPage < totalPages ? `onclick="event.preventDefault(); changePage(${currentPage + 1})"` : ''}>Next</a>`; paginationUl.appendChild(liNext);
            }
            function createPageItem(pageNumber, isActive = false) {
                 let li = document.createElement('li'); li.className = `page-item ${isActive ? 'active' : ''}`; li.innerHTML = `<a class="page-link" href="#" onclick="event.preventDefault(); changePage(${pageNumber})">${pageNumber}</a>`; return li;
            }
            function createEllipsisItem() {
                 let li = document.createElement('li'); li.className = 'page-item disabled'; li.innerHTML = `<span class="page-link">...</span>`; return li;
            }
            window.changePage = function(page) { // Expose for onclick
                const dataToRender = filteredLicenseData;
                const totalPages = Math.ceil(dataToRender.length / rowsPerPage) || 1;
                if (page < 1 || page > totalPages) return;
                renderTablePage(page);
                reapplyDraftStyles();
            }

            window.addNewLicense = function() { // Expose
                const tableBody = document.getElementById('fssaiTableBody'); if (tableBody.querySelector('.editable-row')) { alert('Please save or cancel the current new entry first.'); return; } const newRow = tableBody.insertRow(0); newRow.classList.add('editable-row'); const categoryOptions = ['License', 'HRA', 'TPA', 'Others']; let categorySelectHTML = '<select class="form-select form-select-sm" name="category" onchange="handleCategoryChange(this)"><option value="" selected disabled>-- Select Category --</option>'; categoryOptions.forEach(opt => categorySelectHTML += `<option value="${opt}">${opt}</option>`); categorySelectHTML += '</select>'; const licenseTypeOptions = ['NA', 'Registration', 'State', 'Central']; let licenseTypeSelectHTML = '<select class="form-select form-select-sm" name="licenseType" disabled>'; licenseTypeOptions.forEach(opt => licenseTypeSelectHTML += `<option value="${opt}" ${opt === 'NA' ? 'selected' : ''}>${opt}</option>`); licenseTypeSelectHTML += '</select>'; newRow.insertCell().textContent = '*'; newRow.insertCell().innerHTML = '<input type="text" class="form-control form-control-sm" placeholder="Unit Name" name="unitName">'; newRow.insertCell().innerHTML = categorySelectHTML; newRow.insertCell().innerHTML = '<input type="text" class="form-control form-control-sm" placeholder="License Number" name="licenseNo">'; newRow.insertCell().innerHTML = '<input type="date" class="form-control form-control-sm" name="expiryDate">'; newRow.insertCell().innerHTML = licenseTypeSelectHTML; newRow.insertCell().innerHTML = `<div class="file-upload"><i class="fas fa-cloud-upload-alt me-1"></i> Upload<input type="file" onchange="handleNewLicenseUpload(this)" accept=".pdf,.jpg,.jpeg,.png" name="licenseCopyFile"></div><span class="uploaded-file"></span>`; newRow.insertCell().innerHTML = getStatusBadge('Pending'); newRow.insertCell().innerHTML = `<div class="action-btns"><button class="btn btn-sm btn-save" onclick="saveNewLicense(this)"><i class="fas fa-save"></i> Save</button><button class="btn btn-sm btn-cancel" onclick="cancelNewLicense(this)"><i class="fas fa-times"></i> Cancel</button></div>`; newRow.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
            window.saveNewLicense = function(button) { // Expose
                const row = button.closest('tr'); const inputs = row.querySelectorAll('input[name], select[name]'); let newData = { slNo: 0, corporate: null, regional: null }; let isValid = true; let licenseNumber = ''; let expiryDate = ''; inputs.forEach(input => { const value = input.value; const name = input.getAttribute('name'); input.classList.remove('is-invalid'); if (input.tagName === 'SELECT' && !value && name === 'category') { input.classList.add('is-invalid'); isValid = false; } else if (input.type === 'file') { newData.licenseCopy = input.dataset.uploadedFileName || null; delete input.dataset.uploadedFileName; } else if (input.type !== 'file' && !value.trim() && ['unitName', 'licenseNo', 'expiryDate'].includes(name) && !(input.tagName === 'SELECT' && name === 'licenseType' && input.disabled)) {
                        input.classList.add('is-invalid'); isValid = false;
                     } else if (input.type !== 'file') { newData[name] = value.trim(); } if(name === 'licenseNo') licenseNumber = value.trim(); if(name === 'expiryDate') expiryDate = value; }); if (newData.category === 'License' && (!newData.licenseType || newData.licenseType === 'NA')) { const licenseTypeSelect = row.querySelector('select[name="licenseType"]'); if(licenseTypeSelect && !licenseTypeSelect.disabled) { licenseTypeSelect.classList.add('is-invalid'); isValid = false; } } else if (newData.category !== 'License') { newData.licenseType = 'NA'; } if (!isValid) { alert('Please fill in all required fields (Unit Name, Category, License No, Expiry Date) and select a License Type if applicable.'); return; } if (!licenseNumber) { alert('License Number cannot be empty.'); row.querySelector('input[name="licenseNo"]').classList.add('is-invalid'); return; } if (findDataIndexByLicenseNo(licenseNumber) !== -1) { alert(`Error: License number ${licenseNumber} already exists.`); row.querySelector('input[name="licenseNo"]').classList.add('is-invalid'); return; } newData.status = updateStatusBasedOnDate(expiryDate, 'Pending'); newData.slNo = Math.max(0, ...allLicenseData.map(d => d.slNo)) + 1; allLicenseData.unshift(newData);
                initializeStatuses();
                const latestMetrics = calculateDashboardMetrics(allLicenseData);
                updateDashboardCards(latestMetrics);
                addHistoryEntry(licenseNumber, 'License Created', `Unit: ${newData.unitName}, Cat: ${newData.category}, Type: ${newData.licenseType}, Exp: ${expiryDate}`, 'User'); if (newData.licenseCopy) { addHistoryEntry(licenseNumber, 'Document Upload', `Initial upload: ${newData.licenseCopy}`, 'User'); } alert('License added successfully!'); document.getElementById('searchInput').value = ''; applyAllFilters();
                reapplyDraftStyles();
            }
            window.cancelNewLicense = function(button) { button.closest('tr').remove(); } // Expose
            function downloadCSV(csv, filename) { const csvFile = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" }); const downloadLink = document.createElement("a"); downloadLink.download = filename; downloadLink.href = window.URL.createObjectURL(csvFile); downloadLink.style.display = "none"; document.body.appendChild(downloadLink); downloadLink.click(); document.body.removeChild(downloadLink); }
            window.exportTableToCSV = function(filename) { // Expose
                const csv = []; const exportHeaders = ['SL No', 'Corporate', 'Regional', 'Unit Name', 'Category', 'License Number', 'Expiry Date', 'License Type', 'License Copy File', 'Status']; csv.push(exportHeaders.join(",")); const dataToExport = filteredLicenseData; if (dataToExport.length === 0) { alert("No data available to export based on current filters."); return; } dataToExport.forEach((item, index) => { const row = []; row.push(`"${index + 1}"`); row.push(`"${item.corporate?.replace(/"/g, '""') || ''}"`); row.push(`"${item.regional?.replace(/"/g, '""') || ''}"`); row.push(`"${item.unitName?.replace(/"/g, '""') || ''}"`); row.push(`"${item.category?.replace(/"/g, '""') || ''}"`); row.push(`"${item.licenseNo?.replace(/"/g, '""') || ''}"`); row.push(`"${item.expiryDate || ''}"`); row.push(`"${item.licenseType?.replace(/"/g, '""') || ''}"`); row.push(`"${item.licenseCopy ? item.licenseCopy.replace(/"/g, '""') : 'No'}"`); row.push(`"${item.status?.replace(/"/g, '""') || ''}"`); csv.push(row.join(",")); }); downloadCSV(csv.join("\n"), filename); addHistoryEntry('SYSTEM', 'Export', `Exported ${dataToExport.length} records to CSV.`, 'User');
            }

            // FSSAI specific DOMContentLoaded
            document.addEventListener('DOMContentLoaded', () => {
                 // Check if elements are available, as this might run before the tab is active
                 if (!document.getElementById('panel-license')) return;

                 tooltipTriggerList = [].slice.call(document.querySelectorAll('#panel-license [data-bs-toggle="tooltip"]'));
                 tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) { return new bootstrap.Tooltip(tooltipTriggerEl); });

                 if (document.getElementById('documentModal')) {
                    documentModal = new bootstrap.Modal(document.getElementById('documentModal'));
                 }
                 if (document.getElementById('renewModal')) {
                    renewModal = new bootstrap.Modal(document.getElementById('renewModal'));
                 }
                 if (document.getElementById('historyModal')) {
                    historyModal = new bootstrap.Modal(document.getElementById('historyModal'));
                 }

                 initializeStatuses();
                 const initialMetrics = calculateDashboardMetrics(allLicenseData);
                 updateDashboardCards(initialMetrics);

                 const rowsPerPageSelectEl = document.getElementById('rowsPerPageSelect');
                 if (rowsPerPageSelectEl) {
                    rowsPerPage = parseInt(rowsPerPageSelectEl.value, 10);
                 } else {
                    rowsPerPage = 10; // Default if element not found
                 }

                 updateHierarchicalFilters();
                 setupEventListeners(); // This function now checks for panel-license existence
                 updateDraftCount();
                 applyAllFilters(); // This also checks for searchInputEl
                 reapplyDraftStyles();
                 addHistoryEntry('SYSTEM', 'System', 'FSSAI License Tab Initialized', 'System');
            });
        })(); // End of FSSAI IIFE

    </script>

 <script>
        // Function to open document preview modal
        function viewDocument(filename) {
   

    const modalElement = document.getElementById('documentModal');
    const previewContainer = document.getElementById('documentPreview');

    if (!previewContainer) {
        console.error("Element with id 'documentPreview' not found.");
        return;
    }

    const filePath = `${filename}`;
    const fileExtension = filename.split('.').pop().toLowerCase();

    // Clear previous content
    previewContainer.innerHTML = '';

    if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExtension)) {
        const img = document.createElement('img');
        img.src = filePath;
        img.alt = filename;
        img.classList.add('img-fluid');
        previewContainer.appendChild(img);
    } else if (fileExtension === 'pdf') {
        const iframe = document.createElement('iframe');
        iframe.src = filePath;
        iframe.width = '100%';
        iframe.height = '600px';
        iframe.frameBorder = '0';
        previewContainer.appendChild(iframe);
    } else {
        previewContainer.innerHTML = `<div class="alert alert-warning">Cannot preview this file type.</div>`;
    }

    const modal = new bootstrap.Modal(modalElement);
    modal.show();
}



        // Function to download the current document
        function downloadDocument() {
            const frameSrc = document.getElementById('documentFrame').src;
            const link = document.createElement('a');
            link.href = frameSrc;
            link.download = frameSrc.split('/').pop();
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        // Function to handle license upload
        function handleLicenseUpload(licenseNumber, input) {
            const file = input.files[0];
            if (file) {
                const statusElement = document.getElementById(`upload-status-${licenseNumber}`);
                statusElement.innerHTML = `<i class="fas fa-check-circle"></i> ${file.name}`;
                
                // In a real application, you would upload the file to the server here
                console.log(`Uploading file for license ${licenseNumber}:`, file.name);
            }
        }

        // Function to handle file upload for new license
        function handleNewLicenseUpload(input) {
            const file = input.files[0];
            if (file) {
                const uploadedFileSpan = input.closest('td').querySelector('.uploaded-file');
                uploadedFileSpan.innerHTML = `<i class="fas fa-check-circle"></i> ${file.name}`;
            }
        }

        // Function to open renew modal
       function openRenewModal(licenseNumber,expiryDateold) {
   
    // Set license number fields
    document.getElementById('renewLicenseNumber').value = licenseNumber;
    document.getElementById('displayLicenseNumber').textContent = licenseNumber;

    // Find the expiry date from the table
    const table = document.getElementById('fssaiTable');
    const rows = table.getElementsByTagName('tr');
    let expiryDate = '';

    for (let i = 1; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        if (cells[2].textContent.trim() === licenseNumber.trim()) {
            expiryDate = cells[3].textContent.trim();
            break;
        }
    }

    document.getElementById('currentExpiryDate').textContent = expiryDateold;
    document.getElementById('newExpiryDate').value = '';
    document.getElementById('renewalFileName').innerHTML = '<i class="fas fa-file-alt"></i> No file selected';

    // Use Bootstrap modal method to show modal
    const renewModal = new bootstrap.Modal(document.getElementById('renewModal'));
    renewModal.show();
}


        // Function to open history modal
       function openHistoryModal(licenseNumber) {
           
           
           
           
            let url = '{{route("UnitLincesHistory")}}';
        $.ajax({
            type: "GET",
            url: url,
            data:{id:licenseNumber},
            success: function(response) {
                if(response.status == true){
                    $('#ingredients-block').empty();
                    $('#ingredients-block').html(response);
                    $('#productexampleExtraLargeModal').modal('show');
                }
                else{
                          $('#ingredients-block').empty();
                    $('#ingredients-block').html(response);
                    $('#productexampleExtraLargeModal').modal('show');
                    //alert('error','There is some problem to get ingredient!Please contact to your server administrator');
                }
            },
            error: function(data) {
                      $('#ingredients-block').empty();
                    $('#ingredients-block').html(response);
                    $('#productexampleExtraLargeModal').modal('show');
               //alert('error','There is some problem to get ingredient!Please contact to your server administrator');
            }
        });
        
       
}


        // Helper function to get badge class based on action type
        function getBadgeClass(action) {
            switch(action) {
                case 'Created':
                    return 'badge-success';
                case 'Renewal':
                    return 'badge-primary';
                case 'Document Upload':
                    return 'badge-warning';
                default:
                    return 'badge-primary';
            }
        }

        // Function to add new editable row to the table
        function addNewLicense() {
    const tableBody = document.querySelector('#fssaiTable tbody');
    const newRow = document.createElement('tr');
    newRow.className = 'editable-row';

    const rowCount = tableBody.rows.length;
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    newRow.innerHTML = `
        <td>${rowCount + 1}</td>
        <td>
            <input type="text" class="form-control form-control-sm" placeholder="Unit Name" name="unitName" readonly value="<?= Auth::user()->company_name ?>">
        </td>
        <td>
            <select class="form-control form-control-sm" name="document_type" form="newTrainingForm">
                <option value="">Select Category</option>
                <option value="License">License</option>
                <option value="HRA">HRA</option>
                <option value="TPA">TPA</option>
                <option value="Other">Other</option>
            </select>
        </td>
        <td>
            <input type="text" class="form-control form-control-sm" name="lincess_number" placeholder="License Number" form="newTrainingForm">
        </td>
        <td>
            <input type="date" class="form-control form-control-sm" name="due_date" form="newTrainingForm">
        </td>
        <td>
            <select class="form-control form-control-sm" name="cat_type" form="newTrainingForm">
                <option value="NA">NA</option>
                <option value="Central License">Central License</option>
                <option value="State License">State License</option>
                <option value="Basic Registration">Basic Registration</option>
            </select>
        </td>
        <td class="document-cell">
            <div class="file-upload">
                <i class="fas fa-cloud-upload-alt"></i> Upload
                <input class="form-control form-control-sm" type="file" name="image" form="newTrainingForm" >
            </div>
            <span class="uploaded-file"></span>
        </td>
        <td><span class="status status-active">Active</span></td>
        <td>
            <form id="newTrainingForm" action="{{route('lincesupload')}}" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="${csrfToken}">
                <button type="submit" class="btn btn-sm btn-save">
                    <i class="fas fa-save"></i> Save
                </button>
                <button type="button" class="btn btn-sm btn-cancel" onclick="cancelNewLicense(this)">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </form>
        </td>
    `;

    tableBody.insertBefore(newRow, tableBody.firstChild);
    updateSerialNumbers();
    newRow.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

        
        // Function to save new license
        function saveNewLicense(button) {
            const row = button.closest('tr');
            const cells = row.cells;
            
            // Get values from inputs
            const category = cells[1].querySelector('select').value;
            const licenseNumber = cells[2].querySelector('input').value;
            const expiryDate = cells[3].querySelector('input').value;
            const licenseType = cells[4].querySelector('select').value;
            const fileInput = cells[5].querySelector('input[type="file"]');
            const fileName = fileInput.files[0] ? fileInput.files[0].name : '';
            
            // Validate required fields
            if (!category || !licenseNumber || !expiryDate) {
                alert('Please fill in all required fields');
                return;
            }
            
            // Replace inputs with plain text
            cells[1].innerHTML = category;
            cells[2].innerHTML = licenseNumber;
            cells[3].innerHTML = expiryDate;
            cells[4].innerHTML = licenseType;
            
            // Update document cell
            if (fileName) {
                cells[5].innerHTML = `
                    <div class="document-preview" onclick="viewDocument('${fileName}')">
                        <i class="fas fa-file-pdf document-icon"></i>
                        <span class="document-name">${fileName}</span>
                    </div>
                `;
            } else {
                cells[5].innerHTML = `
                    <div class="file-upload">
                        <i class="fas fa-cloud-upload-alt"></i> Upload
                        <input type="file" onchange="handleLicenseUpload('${licenseNumber}', this)" accept=".pdf,.jpg,.jpeg,.png">
                    </div>
                    <span id="upload-status-${licenseNumber}" class="uploaded-file"></span>
                `;
            }
            
            // Update action buttons
            cells[7].innerHTML = `
                <div class="action-btns">
                    <button class="btn btn-sm btn-renew" onclick="openRenewModal('${licenseNumber}','${expiryDate}')">
                        <i class="fas fa-sync-alt"></i> Renew
                    </button>
                    <button class="btn btn-sm btn-history" onclick="openHistoryModal('${licenseNumber}','${expiryDate}')">
                        <i class="fas fa-history"></i> History
                    </button>
                </div>
            `;
            
            // Remove editable class
            row.classList.remove('editable-row');
            
            // Add to history log
            addHistoryEntry(licenseNumber, 'Created', 'New license record added');
            
            alert('License saved successfully!');
        }
        
        // Function to cancel adding new license
        function cancelNewLicense(button) {
            const row = button.closest('tr');
            row.remove();
            
            // Update serial numbers for all rows
            updateSerialNumbers();
        }
        
        // Function to update serial numbers in the table
        function updateSerialNumbers() {
            const rows = document.querySelectorAll('#fssaiTable tbody tr');
            rows.forEach((row, index) => {
                row.cells[0].textContent = index + 1;
            });
        }
        
        // Function to add history entry
        function addHistoryEntry(licenseNumber, action, details) {
            // In a real app, this would be saved to the server
            console.log(`History entry added for ${licenseNumber}: ${action} - ${details}`);
        }

        // Function to close any modal
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Event listeners for file inputs to show selected file names
        document.getElementById('renewalDocument').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                document.getElementById('renewalFileName').innerHTML = `<i class="fas fa-file-alt"></i> ${file.name}`;
            }
        });

        // Form submission handlers
        document.getElementById('renewForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const licenseNumber = document.getElementById('renewLicenseNumber').value;
            const newExpiryDate = document.getElementById('newExpiryDate').value;
            const file = document.getElementById('renewalDocument').files[0];
            
            // In a real application, you would send this data to the server
            console.log(`Renewing license ${licenseNumber} with new expiry date ${newExpiryDate}`);
            if (file) {
                console.log('With file:', file.name);
            }
            
            // Show success message
            alert('Renewal request submitted successfully!');
            closeModal('renewModal');
        });

        // Close modals when clicking outside
        window.onclick = function(event) {
            const modals = document.getElementsByClassName('modal');
            for (let modal of modals) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            }
        };
    </script>
    <script>
        function toggleStatus(licenseId, isChecked) {
    
   
    let newStatus = isChecked ? 'active' : 'inactive';

    // Optional: Show loading or disable toggle temporarily
    console.log(`Updating license ID ${licenseId} to ${newStatus}`);

let url = '{{route("updatelincesstatus")}}';

    $.ajax({
        url: url,  // 🔁 Update this route to your real one
        method: 'POST',
        data: {
            _token: $('meta[name="csrf-token"]').attr('content'), // CSRF token
            license_id: licenseId,
            status: newStatus
        },
        success: function(response) {
            console.log('Status updated:', response);
            // You can show a toast or update UI
        },
        error: function(xhr) {
            alert('Failed to update status.');
            console.error(xhr.responseText);
            // Optionally rollback toggle state
        }
    });
}
    </script>
<script>
        // --- START: IDENTIFY CHANGES (Custom Categories & Schedule Feature) ---
        // This section marks the beginning of the JavaScript changes for
        // custom categories and scheduling functionality.
        // --- END: IDENTIFY CHANGES ---

        const DATA_KEYS=['slNo','unitName','category','licenseNo','expiryDate','licenseType','licenseCopy','status','actions'];const ALL_OPTION_VALUE="";let currentUser={role:'Super Admin',corporateName:null,regionalName:null,unitName:null};let accessibleLicenseData=[];let allLicenseData=[{slNo:1,unitName:'Main Plant A',corporate:'Stark Industries',regional:'North',category:'License',licenseNo:'123456789012',expiryDate:'2026-01-01',licenseType:'Central',licenseCopy:'FSSAI_License_123456789012.pdf',status:'Active',isActive:true},{slNo:2,unitName:'South Warehouse Beta',corporate:'Stark Industries',regional:'South',category:'HRA',licenseNo:'SOUTHBETA999',expiryDate:'2026-11-30',licenseType:'NA',licenseCopy:null,status:'Active',isActive:true},{slNo:3,unitName:'North Retail Outlet C',corporate:'Stark Industries',regional:'North',category:'TPA',licenseNo:'NORTHC001234',expiryDate:'2025-08-15',licenseType:'NA',licenseCopy:null,status:'Active',isActive:false},{slNo:4,unitName:'Main Plant A',corporate:'Stark Industries',regional:'North',category:'HRA',licenseNo:'MPA-HRA-001',expiryDate:'2025-06-30',licenseType:'NA',licenseCopy:null,status:'Active',isActive:true},{slNo:5,unitName:'Main Plant A',corporate:'Stark Industries',regional:'North',category:'Others',otherCategoryName:'Pest Control Audit',licenseNo:'MPA-OTH-001',expiryDate:'2024-10-31',licenseType:'NA',licenseCopy:'PestControl.pdf',status:'Active',isActive:true},{slNo:6,unitName:'South Warehouse Beta',corporate:'Stark Industries',regional:'South',category:'Others',otherCategoryName:'Water Test Report',licenseNo:'SWB-OTH-002',expiryDate:'2023-07-15',licenseType:'NA',licenseCopy:null,status:'Expired',isActive:true},{slNo:7,unitName:'Gotham Central',corporate:'Wayne Enterprises',regional:'Central',category:'License',licenseNo:'WECGC888000',expiryDate:'2027-01-01',licenseType:'State',licenseCopy:'Wayne_License.pdf',status:'Active',isActive:true},{slNo:8,unitName:'Bludhaven Docks',corporate:'Wayne Enterprises',regional:'Coastal',category:'HRA',licenseNo:'WEBDHRA001',expiryDate:'2025-05-01',licenseType:'NA',licenseCopy:null,status:'Active',isActive:true},{slNo:9,unitName:'Stark Tower Cafeteria',corporate:'Stark Industries',regional:'East',category:'TPA',licenseNo:'STC-TPA-01',expiryDate:'2024-09-15',licenseType:'NA',licenseCopy:'STC_TPA.pdf',status:'Active',isActive:true}];let filteredLicenseData=[];let draftUpdates=[];

        // --- START: IDENTIFY CHANGES (New Global Variables) ---
        let scheduledUpdates = [];
        let customCategoriesData = [];
        const BASE_CATEGORIES = ['License', 'HRA', 'TPA', 'Others'];
        // --- END: IDENTIFY CHANGES ---

        let currentPage=1;let rowsPerPage=10;let activeFilters={selectedCorporate:null,selectedRegional:null,selectedUnit:null,licenseNoSearch:null,expiryDateFrom:null,expiryDateTo:null};let currentlyOpenFilterDropdown=null;var tooltipTriggerList,tooltipList,documentModal,renewModal,historyModal,scheduleModalInstance, mobileFilterModalInstance;

        const rowsPerPageSelectDesktopEl = document.getElementById('rowsPerPageSelectDesktop');
        const rowsPerPageSelectMobileEl = document.getElementById('rowsPerPageSelectMobile');

        function setCurrentUser(role,corporate=null,regional=null,unit=null){currentUser.role=role;currentUser.corporateName=corporate;currentUser.regionalName=regional;currentUser.unitName=unit;const sI=document.getElementById('dashboardScopeInfo');if(sI){if(role==='Super Admin')sI.textContent='All Data';else if(role==='Corporate')sI.textContent=`Corporate: ${corporate}`;else if(role==='Regional')sI.textContent=`Regional: ${regional} (${corporate})`;else if(role==='Unit')sI.textContent=`Unit: ${unit}`;}initializeUserScope();}
        function filterDataForCurrentUser(){if(!allLicenseData)return[];if(currentUser.role==='Super Admin')return[...allLicenseData];return allLicenseData.filter(i=>{if(currentUser.role==='Corporate')return i.corporate===currentUser.corporateName;if(currentUser.role==='Regional')return i.corporate===currentUser.corporateName&&i.regional===currentUser.regionalName;if(currentUser.role==='Unit')return i.corporate===currentUser.corporateName&&i.regional===currentUser.regionalName&&i.unitName===currentUser.unitName;return false;});}

        // --- START: IDENTIFY CHANGES (Modified initializeUserScope) ---
        function initializeUserScope(){
            accessibleLicenseData=filterDataForCurrentUser();
            resetAllFiltersInternal();

            populateCustomCategoryScopeSelector();
            displayCustomCategories();

            applyAllFilters();
            const m=calculateDashboardMetrics(accessibleLicenseData);
            updateDashboardCards(m);
            updateHierarchicalFilterOptionsBasedOnUserScope();
            updateGeneralFilterOptionsBasedOnUserScope();
            populateMobileFilterOptions();
            updateDraftCount();

            const aNB=document.getElementById('addNewButton');
            if(aNB){
                const iM=isMobileView();
                if(currentUser.role==='Unit'&&!iM){
                    aNB.style.display='inline-block';
                    aNB.disabled=false;
                } else {
                    aNB.style.display='none';
                }
            }
            if (rowsPerPageSelectDesktopEl) rowsPerPageSelectDesktopEl.value = rowsPerPage;
            if (rowsPerPageSelectMobileEl) rowsPerPageSelectMobileEl.value = rowsPerPage;
        }
        // --- END: IDENTIFY CHANGES ---

        function applyUserRoleSelection(){const sel=document.getElementById('roleSelector'),sV=sel.value,p=sV.split('_');setCurrentUser(p[0],p[1]||null,p[2]||null,p[3]||null);addHistoryEntry('SYSTEM','Role Change',`Simulated role to ${p[0]} ${p[1]?'('+p[1]+')':''}`,'User');}
        function getFileIconClass(fName){if(!fName)return'fa-file';const ext=fName.split('.').pop().toLowerCase();if(['pdf'].includes(ext))return'fa-file-pdf document-icon';if(['jpg','jpeg','png','gif','bmp'].includes(ext))return'fa-file-image document-icon';if(['doc','docx'].includes(ext))return'fa-file-word document-icon';if(['xls','xlsx'].includes(ext))return'fa-file-excel document-icon';return'fa-file document-icon';}
        function viewDocument(fName){const dP=`documents/${fName}`,frm=document.getElementById('documentFrame'),eMD=document.getElementById('docErrorMsg');frm.src='about:blank';frm.setAttribute('data-filename',fName);eMD.classList.add('d-none');frm.classList.remove('d-none');setTimeout(()=>{frm.src=dP;},50);frm.onload=()=>{eMD.classList.add('d-none');frm.classList.remove('d-none');};frm.onerror=()=>{eMD.textContent=`Error loading '${fName}'.`;eMD.classList.remove('d-none');frm.classList.add('d-none');};if(documentModal)documentModal.show();}
        function downloadDocument(){const frm=document.getElementById('documentFrame'),eMD=document.getElementById('docErrorMsg'),fS=frm.getAttribute('src');if(eMD.classList.contains('d-none')===false||!fS||fS==='about:blank'){alert("Preview failed.");return;}const fN=frm.getAttribute('data-filename')||fS.split('/').pop(),lnk=document.createElement('a');lnk.href=fS;lnk.download=fN;document.body.appendChild(lnk);lnk.click();document.body.removeChild(lnk);}
        function handleLicenseUpload(licNo,input){const f=input.files[0];if(!f)return;const dIdx=findDataIndexByLicenseNo(licNo);if(dIdx===-1)return;allLicenseData[dIdx].licenseCopy=f.name;initializeUserScope();addHistoryEntry(licNo,'Document Upload',`Uploaded: ${f.name}`,'User');}
        function handleNewLicenseUpload(input){const f=input.files[0],uFS=input.closest('td, .pdf-icon-mobile').querySelector('.uploaded-file');if(f){uFS.innerHTML=`<i class="fas ${getFileIconClass(f.name)}"></i> ${f.name}`;input.dataset.uploadedFileName=f.name;}else{uFS.innerHTML='';delete input.dataset.uploadedFileName;}}
        function toggleOtherNameInput(selEl,wId=null,iId=null){let oNW,oNI;if(wId&&iId){oNW=document.getElementById(wId);oNI=document.getElementById(iId);}else{const r=selEl.closest('tr');if(!r)return;oNW=r.querySelector('.other-category-name-input-wrapper');if(oNW)oNI=oNW.querySelector('input[name="otherCategoryName"]');}if(oNW&&oNI){oNW.classList.toggle('d-none',selEl.value!=='Others');if(selEl.value!=='Others')oNI.value='';}}
        function handleCategoryChange(catSel){const r=catSel.closest('tr'),lTSel=r.querySelector('select[name="licenseType"]');if(!lTSel)return;lTSel.disabled=catSel.value!=='License';if(catSel.value!=='License')lTSel.value='NA';else if(lTSel.value==='NA'){const fNNAO=Array.from(lTSel.options).find(o=>o.value!=='NA');if(fNNAO)lTSel.value=fNNAO.value;else lTSel.value='';}if(r.classList.contains('editable-row'))toggleOtherNameInput(catSel);}
        function openRenewModal(licNo){const dIdx=findDataIndexByLicenseNo(licNo);if(dIdx===-1){alert("Error: License not found.");return;}const oD=allLicenseData[dIdx];if(!oD.isActive){alert("License is deactivated. Cannot renew/update.");return;}const eD=draftUpdates.find(d=>d.licenseNo===licNo);document.getElementById('renewLicenseNumber').value=oD.licenseNo;document.getElementById('renewUnitName').textContent=oD.unitName;document.getElementById('renewCorporateName').textContent=oD.corporate||'N/A';document.getElementById('renewRegionalName').textContent=oD.regional||'N/A';document.getElementById('displayLicenseNumber').textContent=oD.licenseNo;document.getElementById('currentExpiryDate').textContent=oD.expiryDate||'N/A';document.getElementById('newExpiryDate').value=eD?eD.newExpiryDate:'';document.getElementById('renewCategory').textContent=oD.category||'N/A';const rOCNW=document.getElementById('renewOtherCategoryNameWrapper'),rOCNI=document.getElementById('renewOtherCategoryName');if(oD.category==='Others'){rOCNW.classList.remove('d-none');rOCNI.value=(eD&&typeof eD.otherCategoryName!=='undefined')?(eD.otherCategoryName||''):(oD.otherCategoryName||'');}else{rOCNW.classList.add('d-none');rOCNI.value='';}document.getElementById('renewalDocument').value=null;document.getElementById('renewalFileName').innerHTML=(eD&&eD.newDocumentName)?`<i class="fas ${getFileIconClass(eD.newDocumentName)}"></i> ${eD.newDocumentName}`:'<i class="fas fa-file-alt"></i> No new file';if(renewModal)renewModal.show();}

        function openScheduleModal(licenseNo) {
            const dataIndex = findDataIndexByLicenseNo(licenseNo);
            if (dataIndex === -1) {
                alert("Error: License not found.");
                return;
            }
            const originalData = allLicenseData[dataIndex];
             if (!originalData.isActive) {
                alert("License is deactivated. Cannot schedule update.");
                return;
            }

            const existingSchedule = scheduledUpdates.find(s => s.licenseNo === licenseNo);

            document.getElementById('scheduleLicenseNumber').value = originalData.licenseNo;
            document.getElementById('scheduleUnitName').textContent = originalData.unitName || 'N/A';
            document.getElementById('scheduleDisplayLicenseNumber').textContent = originalData.licenseNo || 'N/A';
            document.getElementById('scheduleCurrentExpiry').textContent = originalData.expiryDate || 'N/A';

            if (existingSchedule) {
                document.getElementById('scheduleDate').value = existingSchedule.scheduledDate || '';
                document.getElementById('scheduleTime').value = existingSchedule.scheduledTime || '';
                document.getElementById('scheduleComments').value = existingSchedule.scheduledComments || '';
            } else {
                document.getElementById('scheduleDate').value = '';
                document.getElementById('scheduleTime').value = '';
                document.getElementById('scheduleComments').value = '';
            }
            if(scheduleModalInstance) scheduleModalInstance.show();
        }

        function saveScheduledUpdate() {
            const licenseNo = document.getElementById('scheduleLicenseNumber').value;
            const scheduledDate = document.getElementById('scheduleDate').value;
            const scheduledTime = document.getElementById('scheduleTime').value;
            const scheduledComments = document.getElementById('scheduleComments').value.trim();

            if (!scheduledDate) {
                alert('Please select a schedule date.');
                document.getElementById('scheduleDate').classList.add('is-invalid');
                return;
            }
            document.getElementById('scheduleDate').classList.remove('is-invalid');

            const scheduleData = {
                licenseNo: licenseNo,
                scheduledDate: scheduledDate,
                scheduledTime: scheduledTime,
                scheduledComments: scheduledComments
            };

            const existingScheduleIndex = scheduledUpdates.findIndex(s => s.licenseNo === licenseNo);
            if (existingScheduleIndex > -1) {
                scheduledUpdates[existingScheduleIndex] = scheduleData;
            } else {
                scheduledUpdates.push(scheduleData);
            }

            initializeUserScope();
            addHistoryEntry(licenseNo, 'Update Scheduled', `Scheduled for ${scheduledDate}${scheduledTime ? ' at ' + scheduledTime : ''}. Notes: ${scheduledComments || 'None'}`, 'User');
            if(scheduleModalInstance) scheduleModalInstance.hide();
            alert(`Update for license ${licenseNo} scheduled successfully.`);
        }


        const licenseHistoryData={'123456789012':[{date:'2022-01-15',action:'Issued',details:'Initial License',user:'System'},{date:'2023-11-01',action:'Doc Upload',details:'FSSAI_License_123456789012.pdf',user:'User1'}],'SOUTHBETA999':[{date:'2024-11-30',action:'Issued',details:'Initial HRA',user:'System'}],'NORTHC001234':[{date:'2023-08-15',action:'Issued',details:'Initial TPA',user:'System'}],SYSTEM:[{date:new Date().toISOString().split('T')[0],action:'System',details:'Dashboard loaded',user:'System'}],'MPA-HRA-001':[{date:new Date().toISOString().split('T')[0],action:'Issued',details:'Initial HRA MPA',user:'System'}],'MPA-OTH-001':[{date:'2024-01-10',action:'Issued',details:'Pest Audit',user:'System'}],'SWB-OTH-002':[{date:'2022-07-01',action:'Issued',details:'Water Report',user:'System'}],'WECGC888000':[{date:'2025-01-01',action:'Issued',details:'Initial License GC',user:'System'}],'WEBDHRA001':[{date:'2023-05-01',action:'Issued',details:'Initial HRA BD',user:'System'}],'STC-TPA-01':[{date:'2022-09-15',action:'Issued',details:'Initial TPA STC',user:'System'}]};
        function addHistoryEntry(licNo,action,details,user='System'){if(!licNo||!action||!details)return;if(!licenseHistoryData[licNo])licenseHistoryData[licNo]=[];licenseHistoryData[licNo].unshift({date:new Date().toISOString().split('T')[0],action,details,user});}
        function openHistoryModal(licNo){const dIdx=findDataIndexByLicenseNo(licNo);if(dIdx===-1&&licNo!=='SYSTEM'){alert("Error: License not found.");return;}const d=licNo==='SYSTEM'?{unitName:'System Log',licenseNo:'SYSTEM',corporate:'N/A',regional:'N/A'}:allLicenseData[dIdx];document.getElementById('historyUnitName').textContent=d.unitName;document.getElementById('historyLicenseNumber').textContent=d.licenseNo;document.getElementById('historyCorporateName').textContent=d.corporate||'N/A';document.getElementById('historyRegionalName').textContent=d.regional||'N/A';const h=licenseHistoryData[licNo]||[],hTB=document.getElementById('historyTableBody');hTB.innerHTML=h.length===0?'<tr><td colspan="4" class="text-center text-muted">No history.</td></tr>':h.map(e=>`<tr><td>${e.date}</td><td>${e.action}</td><td>${e.details}</td><td>${e.user}</td></tr>`).join('');if(historyModal)historyModal.show();}
        function findDataIndexByLicenseNo(licNo){return licNo?allLicenseData.findIndex(i=>i.licenseNo===licNo):-1;}
        function getStatusBadge(sTxt,isAct=true){if(isAct===false)return`<span class="status status-deactivated">Deactivated</span>`;sTxt=sTxt||'Unknown';let s=sTxt.toLowerCase(),bCls=s==='active'?'status-active':(s==='expired'?'status-expired':'status-pending');return`<span class="status ${bCls}">${sTxt.charAt(0).toUpperCase()+sTxt.slice(1)}</span>`;}
        function updateStatusBasedOnDate(dStr,curStat='Active'){if(!dStr||dStr==='N/A'||curStat==='Pending'||!['License','HRA','TPA','Others'].includes(curStat)){if(dStr&&dStr!=='N/A'){try{const eD=new Date(dStr),t=new Date();t.setHours(0,0,0,0);if(!isNaN(eD.getTime())&&eD<t)return'Expired';}catch(e){}}return curStat;}try{const eD=new Date(dStr),t=new Date();t.setHours(0,0,0,0);return isNaN(eD.getTime())?'Unknown':(eD<t?'Expired':'Active');}catch(e){return'Unknown';}}
        function initializeStatuses(){allLicenseData.forEach(i=>{i.corporate=i.corporate||null;i.regional=i.regional||null;i.isActive=typeof i.isActive==='undefined'?true:i.isActive;if(i.category&&!['License','HRA','TPA','Others'].includes(i.category))i.licenseType='NA';if(i.category==='Others'&&typeof i.otherCategoryName==='undefined')i.otherCategoryName=null;i.status=updateStatusBasedOnDate(i.expiryDate,i.status);});}
        function generateLicenseCopyHTML(fName,licNo){if(fName)return`<div class="document-preview" onclick="viewDocument('${fName}')" title="View ${fName}"><i class="fas ${getFileIconClass(fName)}"></i><span class="document-name">${fName}</span></div>`;const dIdx=findDataIndexByLicenseNo(licNo);if(dIdx===-1||isMobileView()){return`<label class="file-upload"><i class="fas fa-cloud-upload-alt me-1"></i> Upload<input type="file" onchange="handleNewLicenseUpload(this)" accept=".pdf,.jpg,.jpeg,.png" name="licenseCopyFile"></label><span class="uploaded-file"></span>`;}const i=allLicenseData[dIdx];return(i.category&&['License','HRA','TPA','Others'].includes(i.category))?`<label class="file-upload"><i class="fas fa-cloud-upload-alt me-1"></i> Upload<input type="file" id="license-${licNo}" onchange="handleLicenseUpload('${licNo}',this)" accept=".pdf,.jpg,.jpeg,.png"></label><span id="upload-status-${licNo}" class="uploaded-file"></span>`:'<!-- NA -->';}

        function generateActionsHTML(item) {
            if (isMobileView()) {
                return '<!-- Actions hidden on mobile -->';
            }

            const licNo = item.licenseNo;
            let toggleHTML = '';
            let buttonsHTML = '';

            if (!item || typeof item.status === 'undefined' || typeof item.isActive === 'undefined') {
                return `<div class="action-buttons-wrapper"><div class="action-btns"></div></div>`;
            }

            const hasDraft = draftUpdates.some(d => d.licenseNo === licNo);
            const isScheduled = scheduledUpdates.some(s => s.licenseNo === licNo);
            const uniqueSwitchId = `toggle-${(licNo || `new-${Math.random().toString(36).substring(2, 7)}`).replace(/[^a-zA-Z0-9]/g, "")}`;

            toggleHTML = `<div class="form-check form-switch" title="${item.isActive ? 'Deactivate' : 'Activate'} License">
                            <input class="form-check-input" type="checkbox" role="switch" id="${uniqueSwitchId}" ${item.isActive ? 'checked' : ''} onchange="toggleActivation('${licNo}', this)" ${!licNo ? 'disabled' : ''}>
                            <label class="form-check-label visually-hidden" for="${uniqueSwitchId}">${item.isActive ? 'Active' : 'Inactive'}</label>
                        </div>`;

            let specificActions = [];
            if (item.isActive) {
                if (hasDraft) {
                    specificActions.push(
                        `<button class="btn-action-icon btn-submit-draft" onclick="submitSingleDraft('${licNo}', this)" title="Submit Saved Draft">
                            <i class="fas fa-check"></i>
                        </button>`
                    );
                } else if (item.status === 'Pending') {
                    specificActions.push(
                        `<button class="btn-action-icon btn-update-status" onclick="alert('Update Status for ${licNo} - Not Implemented.')" title="Update License Status">
                            <i class="fas fa-edit"></i>
                        </button>`
                    );
                } else if (['License', 'HRA', 'TPA', 'Others'].includes(item.category)) {
                    if (!isScheduled || (isScheduled && !hasDraft)) {
                        specificActions.push(
                            `<button class="btn-action-icon btn-renew" onclick="openRenewModal('${licNo}')" title="Renew or Update License Details">
                                <i class="fas fa-sync-alt"></i>
                            </button>`
                        );
                    }
                }
                if (['License', 'HRA', 'TPA', 'Others'].includes(item.category)) {
                    specificActions.push(
                        `<button class="btn-action-icon btn-schedule ${isScheduled ? 'active-schedule' : ''}" onclick="openScheduleModal('${licNo}')" title="${isScheduled ? 'Manage Schedule' : 'Schedule Renew/Update'}">
                            <i class="fas fa-calendar-alt"></i>
                        </button>`
                    );
                }
            }


            if (licNo) {
                specificActions.push(
                    `<button class="btn-action-icon btn-history" onclick="openHistoryModal('${licNo}')" title="View License History">
                        <i class="fas fa-history"></i>
                    </button>`
                );
                 specificActions.push(
                    `<button class="btn-action-icon btn-delete" onclick="deleteLicense('${licNo}')" title="Delete License">
                        <i class="fas fa-trash-alt"></i>
                    </button>`
                );
            }

            buttonsHTML = `<div class="action-btns">${specificActions.join('')}</div>`;
            return `<div class="action-buttons-wrapper">${toggleHTML}${buttonsHTML}</div>`;
        }

        function deleteLicense(licenseNo) {
            if (!licenseNo) {
                alert("Error: License number is missing.");
                return;
            }
            if (!confirm(`Are you sure you want to permanently delete license ${licenseNo}? This action cannot be undone.`)) {
                return;
            }

            const dataIndex = findDataIndexByLicenseNo(licenseNo);
            if (dataIndex === -1) {
                alert("Error: License not found in the data.");
                return;
            }

            const deletedItem = allLicenseData.splice(dataIndex, 1)[0];

            const draftIndex = draftUpdates.findIndex(d => d.licenseNo === licenseNo);
            if (draftIndex > -1) {
                draftUpdates.splice(draftIndex, 1);
                updateDraftCount();
            }
            const scheduleIndex = scheduledUpdates.findIndex(s => s.licenseNo === licenseNo);
            if (scheduleIndex > -1) {
                scheduledUpdates.splice(scheduleIndex, 1);
            }


            addHistoryEntry(licenseNo, 'License Deleted',
                `License ${licenseNo} (Unit: ${deletedItem.unitName}, Category: ${deletedItem.category}) was deleted.`,
                currentUser.role);

            initializeUserScope();
            alert(`License ${licenseNo} has been deleted successfully.`);
        }


        function toggleActivation(licNo,cb){const dIdx=findDataIndexByLicenseNo(licNo);if(dIdx===-1){alert("Error: License not found.");cb.checked=!cb.checked;return;}const i=allLicenseData[dIdx];i.isActive=cb.checked;addHistoryEntry(i.licenseNo,'Activation Change',`License ${i.isActive?'activated':'deactivated'}.`,'User');initializeUserScope();alert(`License ${licNo} ${i.isActive?'activated':'deactivated'}.`);}
        function populateHierarchicalOptions(dTUse,selEl,key,pF=null){const cV=selEl.value;selEl.innerHTML=`<option value="${ALL_OPTION_VALUE}" selected>-- All --</option>`;let fD=dTUse;if(pF){if(pF.corporate&&pF.corporate!==ALL_OPTION_VALUE)fD=fD.filter(i=>i.corporate===pF.corporate);if(pF.regional&&pF.regional!==ALL_OPTION_VALUE)fD=fD.filter(i=>i.regional===pF.regional);}const uV=[...new Set(fD.map(i=>i[key]).filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true}));uV.forEach(v=>selEl.add(new Option(v,v)));selEl.value=Array.from(selEl.options).some(o=>o.value===cV)?cV:(activeFilters[`selected${key.charAt(0).toUpperCase()+key.slice(1).replace('Name','')}`]||ALL_OPTION_VALUE);selEl.disabled=selEl.options.length<=1&&!selEl.value;}
        function updateHierarchicalFilterOptionsBasedOnUserScope(){const s={c:document.getElementById('unit-filter-corporate-select'),r:document.getElementById('unit-filter-regional-select'),u:document.getElementById('unit-filter-unit-select'),mC:document.getElementById('mobile-unit-filter-corporate-select'),mR:document.getElementById('mobile-unit-filter-regional-select'),mU:document.getElementById('mobile-unit-filter-unit-select')};if(Object.values(s).some(sel=>!sel))return;const cFC=activeFilters.selectedCorporate||s.c.value,cFR=activeFilters.selectedRegional||s.r.value;populateHierarchicalOptions(accessibleLicenseData,s.c,'corporate');populateHierarchicalOptions(accessibleLicenseData,s.r,'regional',{corporate:cFC});populateHierarchicalOptions(accessibleLicenseData,s.u,'unitName',{corporate:cFC,regional:cFR});populateHierarchicalOptions(accessibleLicenseData,s.mC,'corporate');populateHierarchicalOptions(accessibleLicenseData,s.mR,'regional',{corporate:cFC});populateHierarchicalOptions(accessibleLicenseData,s.mU,'unitName',{corporate:cFC,regional:cFR});const setDis=(sel,val,dis)=>{if(sel){sel.value=val;sel.disabled=dis;}};if(currentUser.role==='Corporate'){setDis(s.c,currentUser.corporateName,true);setDis(s.mC,currentUser.corporateName,true);populateHierarchicalOptions(accessibleLicenseData,s.r,'regional',{corporate:currentUser.corporateName});populateHierarchicalOptions(accessibleLicenseData,s.u,'unitName',{corporate:currentUser.corporateName,regional:activeFilters.selectedRegional||s.r.value});populateHierarchicalOptions(accessibleLicenseData,s.mR,'regional',{corporate:currentUser.corporateName});populateHierarchicalOptions(accessibleLicenseData,s.mU,'unitName',{corporate:currentUser.corporateName,regional:activeFilters.selectedRegional||s.mR.value});}else if(currentUser.role==='Regional'){setDis(s.c,currentUser.corporateName,true);setDis(s.r,currentUser.regionalName,true);setDis(s.mC,currentUser.corporateName,true);setDis(s.mR,currentUser.regionalName,true);populateHierarchicalOptions(accessibleLicenseData,s.u,'unitName',{corporate:currentUser.corporateName,regional:currentUser.regionalName});populateHierarchicalOptions(accessibleLicenseData,s.mU,'unitName',{corporate:currentUser.corporateName,regional:currentUser.regionalName});}else if(currentUser.role==='Unit'){[s.c,s.mC].forEach(sel=>setDis(sel,currentUser.corporateName,true));[s.r,s.mR].forEach(sel=>setDis(sel,currentUser.regionalName,true));[s.u,s.mU].forEach(sel=>setDis(sel,currentUser.unitName,true));}Object.values(s).forEach(sel=>{if(sel&&!sel.disabled)sel.disabled=sel.options.length<=1&&!sel.value;});if(s.c.disabled)activeFilters.selectedCorporate=s.c.value!==ALL_OPTION_VALUE?s.c.value:null;if(s.r.disabled)activeFilters.selectedRegional=s.r.value!==ALL_OPTION_VALUE?s.r.value:null;if(s.u.disabled)activeFilters.selectedUnit=s.u.value!==ALL_OPTION_VALUE?s.u.value:null;}

        // --- START: IDENTIFY CHANGES (Modified getUniqueColumnValues) ---
        function getUniqueColumnValues(k){
            const vS=new Set();
            if (k === 'category') {
                BASE_CATEGORIES.forEach(cat => vS.add(cat));
                const customCats = getScopedCustomCategories(); // Use scoped categories
                customCats.forEach(cat => vS.add(cat.name));
            } else {
                accessibleLicenseData.forEach(i=>{
                    if(k==='status')vS.add(i.isActive===false?'Deactivated':(i.status||'(Empty)'));
                    else vS.add(i[k]||'(Empty)');
                });
            }
            return [...vS].filter(v=>v||v==='(Empty)').sort((a,b)=>String(a).localeCompare(String(b)));
        }
        // --- END: IDENTIFY CHANGES ---

        function updateGeneralFilterOptionsBasedOnUserScope(){['category','licenseType','status'].forEach(k=>{const dE=document.querySelector(`.th-filter-dropdown[data-column-key="${k}"]`);if(dE)populateFilterOptions(dE,k);});}
        function populateFilterOptions(dE,k){if(['unitName','licenseNo','expiryDate'].includes(k))return;const oL=dE.querySelector('.options-list'),sI=dE.querySelector('.filter-search input');if(!oL)return;const uV=getUniqueColumnValues(k),cCF=Array.isArray(activeFilters[k])?activeFilters[k]:[];oL.innerHTML=uV.map(v=>{const sV=String(v).replace(/[^a-zA-Z0-9-_]/g,''),cbId=`filter-${k}-${sV||'empty'}-${Math.random().toString(36).substring(2,7)}`,iC=cCF.includes(v);return`<li><input type="checkbox" id="${cbId}" value="${v}" ${iC?'checked':''}><label for="${cbId}">${v}</label></li>`;}).join('');if(sI){sI.value='';filterDropdownOptions(sI);}}
        function filterDropdownOptions(sI){if(!sI)return;const fT=sI.value.toLowerCase(),oL=sI.closest('.th-filter-dropdown, .modal-body').querySelector('.options-list, .options-container');if(!oL)return;oL.querySelectorAll('li, .form-check').forEach(i=>{const l=i.querySelector('label');if(l)i.style.display=l.textContent.toLowerCase().includes(fT)?'':'none';});}
        function closeAllFilterDropdowns(eE=null){document.querySelectorAll('.th-filter-dropdown').forEach(d=>{if(d!==eE)d.style.display='none';});if(currentlyOpenFilterDropdown&&currentlyOpenFilterDropdown!==eE)currentlyOpenFilterDropdown=null;}
        function resetAllFiltersInternal(){activeFilters.licenseNoSearch=null;activeFilters.expiryDateFrom=null;activeFilters.expiryDateTo=null;['licenseNoSearchInput','expiryDateFromInput','expiryDateToInput','mobile-licenseNoSearchInput','mobile-expiryDateFromInput','mobile-expiryDateToInput'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});['category','licenseType','status'].forEach(k=>{delete activeFilters[k];const d=document.querySelector(`.th-filter-dropdown[data-column-key="${k}"]`);if(d){d.querySelectorAll('.options-list input[type="checkbox"]').forEach(cb=>cb.checked=false);const sI=d.querySelector('.filter-search input');if(sI){sI.value='';filterDropdownOptions(sI);}}const mK=k==='licenseType'?'licensetype':k,mOC=document.getElementById(`mobile-${mK}-options`);if(mOC)mOC.querySelectorAll('input[type="checkbox"]').forEach(cb=>cb.checked=false);const mSI=document.getElementById(`mobile-${mK}-search`);if(mSI)mSI.value='';});const s={c:'unit-filter-corporate-select',r:'unit-filter-regional-select',u:'unit-filter-unit-select',mC:'mobile-unit-filter-corporate-select',mR:'mobile-unit-filter-regional-select',mU:'mobile-unit-filter-unit-select'};const rS=(id,val)=>{const el=document.getElementById(id);if(el)el.value=val;};if(currentUser.role==='Super Admin'){activeFilters.selectedCorporate=null;activeFilters.selectedRegional=null;activeFilters.selectedUnit=null;Object.values(s).forEach(id=>rS(id,ALL_OPTION_VALUE));}else if(currentUser.role==='Corporate'){activeFilters.selectedCorporate=currentUser.corporateName;activeFilters.selectedRegional=null;activeFilters.selectedUnit=null;[s.c,s.mC].forEach(id=>rS(id,currentUser.corporateName));[s.r,s.u,s.mR,s.mU].forEach(id=>rS(id,ALL_OPTION_VALUE));}else if(currentUser.role==='Regional'){activeFilters.selectedCorporate=currentUser.corporateName;activeFilters.selectedRegional=currentUser.regionalName;activeFilters.selectedUnit=null;[s.c,s.mC].forEach(id=>rS(id,currentUser.corporateName));[s.r,s.mR].forEach(id=>rS(id,currentUser.regionalName));[s.u,s.mU].forEach(id=>rS(id,ALL_OPTION_VALUE));}else if(currentUser.role==='Unit'){activeFilters.selectedCorporate=currentUser.corporateName;activeFilters.selectedRegional=currentUser.regionalName;activeFilters.selectedUnit=currentUser.unitName;[s.c,s.mC].forEach(id=>rS(id,currentUser.corporateName));[s.r,s.mR].forEach(id=>rS(id,currentUser.regionalName));[s.u,s.mU].forEach(id=>rS(id,currentUser.unitName));}const sInp=document.getElementById('searchInput');if(sInp)sInp.value='';document.querySelectorAll('.th-filter-icon.active').forEach(i=>i.classList.remove('active'));closeAllFilterDropdowns();}
        function resetAllFilters(){resetAllFiltersInternal();initializeUserScope();addHistoryEntry('SYSTEM','Table Refresh','Filters cleared.','User');}
        const DUE_SOON_DAYS=90;function calculateDashboardMetrics(dTUse){const cats=['License','HRA','TPA','Others'],mets={};const t=new Date();t.setHours(0,0,0,0);const dSD=new Date(t);dSD.setDate(t.getDate()+DUE_SOON_DAYS);cats.forEach(cat=>{const cD=dTUse.filter(i=>i.category===cat&&i.isActive===true);let aC=0,eC=0,dSC=0,eDD=null;cD.forEach(i=>{if(i.status==='Active'){aC++;if(i.expiryDate&&i.expiryDate!=='N/A'){try{const exp=new Date(i.expiryDate);if(!isNaN(exp.getTime())){exp.setHours(0,0,0,0);if(!eDD||exp<eDD)eDD=exp;if(exp>=t&&exp<=dSD)dSC++;}}catch(e){}}}else if(i.status==='Expired')eC++;});mets[cat]={total:cD.length,active:aC,expired:eC,dueSoon:dSC,earliestDueDate:eDD};});return mets;}
        function updateDashboardCards(mets){const cM={'License':{p:'card-license',c:'dashboard-card-green'},'HRA':{p:'card-hra',c:'dashboard-card-orange'},'TPA':{p:'card-tpa',c:'dashboard-card-blue'},'Others':{p:'card-others',c:'dashboard-card-gray'}};Object.keys(cM).forEach(cat=>{const m=mets[cat],cfg=cM[cat],el=id=>document.getElementById(`${cfg.p}-${id}`);const sE=el('status'),dE=el('due'),pE=el('progress'),iE=el('info'),cE=document.getElementById(cfg.p);if(!sE||!dE||!pE||!iE||!cE)return;sE.className='status-badge';pE.className='progress-fill';cE.className=`dashboard-card`;if(!m||m.total===0){sE.textContent='N/A';sE.classList.add('status-pending');dE.textContent='Next Due: N/A';pE.style.width='0%';iE.textContent='No Active Data';cE.className=`dashboard-card dashboard-card-gray`;return;}let oTxt='COMPLIANT',oCls='status-compliant',pClrCls='progress-fill-green',cBdrCls=cfg.c;if(m.expired>0){oTxt='EXPIRED';oCls='status-expired';pClrCls='progress-fill-red';cBdrCls='dashboard-card-red';}else if(m.dueSoon>0){oTxt='DUE SOON';oCls='status-due-soon';pClrCls='progress-fill-orange';cBdrCls='dashboard-card-orange';}sE.textContent=oTxt;sE.classList.add(oCls);dE.textContent=m.earliestDueDate?`Next Due: ${m.earliestDueDate.toISOString().split('T')[0]}`:(m.active===0&&m.total>0?'Next Due: N/A (None Active)':'Next Due: N/A');pE.style.width=`${m.total>0?(m.active/m.total)*100:0}%`;pE.classList.add(pClrCls);iE.textContent=`Active: ${m.active} / Total: ${m.total}`;cE.className=`dashboard-card ${cBdrCls}`;});}
        function saveDraftUpdate(){const licNo=document.getElementById('renewLicenseNumber').value,dIdx=findDataIndexByLicenseNo(licNo);if(dIdx>-1&&!allLicenseData[dIdx].isActive){alert("Cannot save draft for deactivated license.");if(renewModal)renewModal.hide();return;}const nED=document.getElementById('newExpiryDate').value;if(!nED){alert('Select new expiry date.');return;}const f=document.getElementById('renewalDocument').files[0];let nDN=f?f.name:(draftUpdates.find(d=>d.licenseNo===licNo)?.newDocumentName||null);let oCNU=null;const oI=allLicenseData[dIdx];if(oI&&oI.category==='Others'){const rOI=document.getElementById('renewOtherCategoryName');oCNU=rOI.value.trim();if(!oCNU){alert('Provide detail for "Others".');rOI.classList.add('is-invalid');return;}rOI.classList.remove('is-invalid');}const dD={licenseNo:licNo,newExpiryDate:nED,newDocumentName:nDN};if(oI&&oI.category==='Others')dD.otherCategoryName=oCNU;const drIdx=draftUpdates.findIndex(d=>d.licenseNo===licNo);if(drIdx>-1)draftUpdates[drIdx]=dD;else draftUpdates.push(dD);initializeUserScope();updateDraftCount();if(renewModal)renewModal.hide();alert(`Draft saved for ${licNo}.`);}
        function updateDraftCount(){const c=draftUpdates.length;document.getElementById('draftCount').textContent=c;document.getElementById('submitDraftsButton').disabled=(c===0);}

        // --- START: IDENTIFY CHANGES (Modified reapplyDraftStyles & reapplyScheduledStyles) ---
        function reapplyDraftStyles(){
            const tB=document.getElementById('fssaiTableBody');
            tB.querySelectorAll('tr.has-draft').forEach(r => r.classList.remove('has-draft'));
            draftUpdates.forEach(d=>{
                const r=tB.querySelector(`tr[data-license-no="${d.licenseNo}"]`);
                if(r){
                    const iIdx=findDataIndexByLicenseNo(d.licenseNo);
                    if(iIdx>-1&&allLicenseData[iIdx].isActive){ r.classList.add('has-draft'); }
                }
            });
            if (!isMobileView()) {
                 tB.querySelectorAll('tr[data-license-no]').forEach(row => {
                    const licNo = row.dataset.licenseNo;
                    const itemIndex = findDataIndexByLicenseNo(licNo);
                    if (itemIndex > -1) {
                        const item = allLicenseData[itemIndex];
                        const actionCellIndex = DATA_KEYS.indexOf('actions');
                        if (row.cells[actionCellIndex]) { row.cells[actionCellIndex].innerHTML = generateActionsHTML(item); }
                    }
                });
            }
        }
        function reapplyScheduledStyles() {
            const tB = document.getElementById('fssaiTableBody');
            tB.querySelectorAll('tr.is-scheduled').forEach(r => r.classList.remove('is-scheduled'));
            scheduledUpdates.forEach(s => {
                const r = tB.querySelector(`tr[data-license-no="${s.licenseNo}"]`);
                if (r) {
                    const iIdx = findDataIndexByLicenseNo(s.licenseNo);
                    if (iIdx > -1 && allLicenseData[iIdx].isActive) { r.classList.add('is-scheduled'); }
                }
            });
            if (!isMobileView()) {
                 tB.querySelectorAll('tr[data-license-no]').forEach(row => {
                    const licNo = row.dataset.licenseNo;
                    const itemIndex = findDataIndexByLicenseNo(licNo);
                    if (itemIndex > -1) {
                        const item = allLicenseData[itemIndex];
                        const actionCellIndex = DATA_KEYS.indexOf('actions');
                         if (row.cells[actionCellIndex]) { row.cells[actionCellIndex].innerHTML = generateActionsHTML(item); }
                    }
                });
            }
        }
        // --- END: IDENTIFY CHANGES ---

        function isMobileView(){return window.innerWidth<=768;}
        function submitSingleDraft(licNo,btnEl){const drIdx=draftUpdates.findIndex(d=>d.licenseNo===licNo);if(drIdx===-1){alert(`Error: Draft not found for ${licNo}.`);if(btnEl?.closest('tr'))btnEl.closest('tr').classList.remove('has-draft');return;}const dr=draftUpdates[drIdx],dIdx=findDataIndexByLicenseNo(licNo);if(dIdx===-1){alert(`Error: Original data not for ${licNo}.`);draftUpdates.splice(drIdx,1);updateDraftCount();if(btnEl?.closest('tr'))btnEl.closest('tr').classList.remove('has-draft');return;}const i=allLicenseData[dIdx];if(!i.isActive){alert(`License ${licNo} deactivated.`);return;}const oE=i.expiryDate,oD=i.licenseCopy,oOCN=i.otherCategoryName;i.expiryDate=dr.newExpiryDate;i.licenseCopy=dr.newDocumentName;if(i.category==='Others'&&typeof dr.otherCategoryName!=='undefined')i.otherCategoryName=dr.otherCategoryName;i.status=updateStatusBasedOnDate(i.expiryDate,i.status);let dets=`Applied: Exp ${oE||'N/A'}->${i.expiryDate}`;if(dr.newDocumentName&&dr.newDocumentName!==oD)dets+=`, Doc: ${dr.newDocumentName}`;else if(!dr.newDocumentName&&oD)dets+=`, Doc Removed`;if(i.category==='Others'&&dr.otherCategoryName!==oOCN)dets+=`, OthDetail: ${oOCN||'N/A'}->${i.otherCategoryName}`;addHistoryEntry(i.licenseNo,'Draft Submitted',dets,'User');draftUpdates.splice(drIdx,1);updateDraftCount();initializeUserScope();alert(`Draft for ${licNo} submitted.`);}
        function applyAllFilters(){const gST=document.getElementById('searchInput').value.toLowerCase().trim();let dR=[...accessibleLicenseData];const{selectedCorporate:sC,selectedRegional:sR,selectedUnit:sU,licenseNoSearch:lNS,expiryDateFrom:eDF,expiryDateTo:eDT}=activeFilters;if(sC&&sC!==ALL_OPTION_VALUE)dR=dR.filter(i=>i.corporate===sC);if(sR&&sR!==ALL_OPTION_VALUE)dR=dR.filter(i=>i.regional===sR);if(sU&&sU!==ALL_OPTION_VALUE)dR=dR.filter(i=>i.unitName===sU);Object.keys(activeFilters).forEach(k=>{const v=activeFilters[k];if(!['selectedCorporate','selectedRegional','selectedUnit','expiryDateFrom','expiryDateTo','licenseNoSearch'].includes(k)&&Array.isArray(v)&&v.length>0){dR=dR.filter(i=>v.includes(k==='status'?(i.isActive===false?'Deactivated':(i.status||'(Empty)')):(i[k]||'(Empty)')));}});if(lNS)dR=dR.filter(i=>i.licenseNo&&i.licenseNo.toLowerCase().includes(lNS.toLowerCase()));if(eDF||eDT){const f=eDF?new Date(eDF):null,t=eDT?new Date(eDT):null;if(f)f.setHours(0,0,0,0);if(t)t.setHours(23,59,59,999);dR=dR.filter(i=>{if(!i.expiryDate||i.expiryDate==='N/A')return false;try{const iD=new Date(i.expiryDate);iD.setHours(0,0,0,0);return(f?iD>=f:true)&&(t?iD<=t:true);}catch(e){return false;}}); }filteredLicenseData=gST?dR.filter(i=>Object.values(i).some(v=>(v&&v.toString().toLowerCase().includes(gST))||(i.category==='Others'&&i.otherCategoryName&&i.otherCategoryName.toLowerCase().includes(gST)))):dR;document.querySelectorAll('.th-filter-icon').forEach(icon=>{const k=icon.dataset.columnKey;let iA=false;if(k==='unitName')iA=!!(sC||sR||sU);else if(k==='licenseNo')iA=!!lNS;else if(k==='expiryDate')iA=!!(eDF||eDT);else iA=Array.isArray(activeFilters[k])&&activeFilters[k].length>0;icon.classList.toggle('active',iA);});renderTablePage(1); }

        function handleRowsPerPageChange(event) {
            rowsPerPage = parseInt(event.target.value, 10);
            if (event.target.id === 'rowsPerPageSelectDesktop' && rowsPerPageSelectMobileEl) {
                rowsPerPageSelectMobileEl.value = rowsPerPage;
            } else if (event.target.id === 'rowsPerPageSelectMobile' && rowsPerPageSelectDesktopEl) {
                rowsPerPageSelectDesktopEl.value = rowsPerPage;
            }
            renderTablePage(1);
        }

        function setupEventListeners(){
            document.querySelectorAll('.th-filter-icon').forEach(i=>{i.addEventListener('click',e=>{e.stopPropagation();const k=i.dataset.columnKey,d=i.closest('th').querySelector('.th-filter-dropdown');if(!d)return;if(d===currentlyOpenFilterDropdown)closeAllFilterDropdowns();else{closeAllFilterDropdowns(d);if(k==='licenseNo'){const inp=d.querySelector('#licenseNoSearchInput');if(inp){inp.value=activeFilters.licenseNoSearch||'';inp.focus();}}else if(k==='expiryDate'){const f=d.querySelector('#expiryDateFromInput'),t=d.querySelector('#expiryDateToInput');if(f)f.value=activeFilters.expiryDateFrom||'';if(t)t.value=activeFilters.expiryDateTo||'';}else if(!['unitName'].includes(k)){populateFilterOptions(d,k);const s=d.querySelector('.filter-search input');if(s)s.focus();}d.style.display='block';currentlyOpenFilterDropdown=d;}});});document.querySelectorAll('.th-filter-dropdown[data-column-key="category"] .btn-apply,.th-filter-dropdown[data-column-key="licenseType"] .btn-apply,.th-filter-dropdown[data-column-key="status"] .btn-apply').forEach(b=>b.addEventListener('click',()=>{const d=b.closest('.th-filter-dropdown'),k=d.dataset.columnKey,sV=Array.from(d.querySelectorAll('.options-list input:checked')).map(cb=>cb.value);if(sV.length>0)activeFilters[k]=sV;else delete activeFilters[k];closeAllFilterDropdowns();applyAllFilters();}));document.querySelectorAll('.th-filter-dropdown[data-column-key="category"] .btn-clear,.th-filter-dropdown[data-column-key="licenseType"] .btn-clear,.th-filter-dropdown[data-column-key="status"] .btn-clear').forEach(b=>b.addEventListener('click',()=>{const d=b.closest('.th-filter-dropdown'),k=d.dataset.columnKey;d.querySelectorAll('.options-list input').forEach(cb=>cb.checked=false);const sI=d.querySelector('.filter-search input');if(sI){sI.value='';filterDropdownOptions(sI);}delete activeFilters[k];applyAllFilters();}));document.querySelectorAll('.th-filter-dropdown[data-column-key="category"] .filter-search input,.th-filter-dropdown[data-column-key="licenseType"] .filter-search input,.th-filter-dropdown[data-column-key="status"] .filter-search input').forEach(i=>i.addEventListener('input',()=>filterDropdownOptions(i)));const cS=document.getElementById('unit-filter-corporate-select'),rS=document.getElementById('unit-filter-regional-select'),uS=document.getElementById('unit-filter-unit-select'),uFA=document.querySelector('.unit-filter-apply'),uFC=document.querySelector('.unit-filter-clear');if(cS)cS.addEventListener('change',()=>{if(!cS.disabled){activeFilters.selectedCorporate=cS.value!==ALL_OPTION_VALUE?cS.value:null;activeFilters.selectedRegional=null;activeFilters.selectedUnit=null;if(rS)rS.value=ALL_OPTION_VALUE;if(uS)uS.value=ALL_OPTION_VALUE;updateHierarchicalFilterOptionsBasedOnUserScope();}});if(rS)rS.addEventListener('change',()=>{if(!rS.disabled){activeFilters.selectedRegional=rS.value!==ALL_OPTION_VALUE?rS.value:null;activeFilters.selectedUnit=null;if(uS)uS.value=ALL_OPTION_VALUE;updateHierarchicalFilterOptionsBasedOnUserScope();}});if(uFA&&cS&&rS&&uS)uFA.addEventListener('click',()=>{if(!cS.disabled)activeFilters.selectedCorporate=cS.value!==ALL_OPTION_VALUE?cS.value:null;if(!rS.disabled)activeFilters.selectedRegional=rS.value!==ALL_OPTION_VALUE?rS.value:null;if(!uS.disabled)activeFilters.selectedUnit=uS.value!==ALL_OPTION_VALUE?uS.value:null;closeAllFilterDropdowns();applyAllFilters();});if(uFC&&cS&&rS&&uS)uFC.addEventListener('click',()=>{if(!cS.disabled){cS.value=ALL_OPTION_VALUE;activeFilters.selectedCorporate=null;}if(!rS.disabled){rS.value=ALL_OPTION_VALUE;activeFilters.selectedRegional=null;}if(!uS.disabled){uS.value=ALL_OPTION_VALUE;activeFilters.selectedUnit=null;}updateHierarchicalFilterOptionsBasedOnUserScope();applyAllFilters();});const lNA=document.querySelector('.licenseNo-filter-apply'),lNC=document.querySelector('.licenseNo-filter-clear'),lNS=document.getElementById('licenseNoSearchInput');if(lNA&&lNS){lNA.addEventListener('click',()=>{activeFilters.licenseNoSearch=lNS.value.trim()||null;closeAllFilterDropdowns();applyAllFilters();});lNS.addEventListener('keypress',e=>{if(e.key==='Enter'){e.preventDefault();lNA.click();}});}if(lNC&&lNS)lNC.addEventListener('click',()=>{lNS.value='';activeFilters.licenseNoSearch=null;applyAllFilters();});const eDA=document.querySelector('.expiryDate-filter-apply'),eDC=document.querySelector('.expiryDate-filter-clear'),eDF=document.getElementById('expiryDateFromInput'),eDT=document.getElementById('expiryDateToInput');if(eDA&&eDF&&eDT)eDA.addEventListener('click',()=>{activeFilters.expiryDateFrom=eDF.value||null;activeFilters.expiryDateTo=eDT.value||null;closeAllFilterDropdowns();applyAllFilters();});if(eDC&&eDF&&eDT)eDC.addEventListener('click',()=>{eDF.value='';eDT.value='';activeFilters.expiryDateFrom=null;activeFilters.expiryDateTo=null;applyAllFilters();});document.addEventListener('click',e=>{if(currentlyOpenFilterDropdown&&!currentlyOpenFilterDropdown.contains(e.target)&&!e.target.closest('.th-filter-icon')&&!e.target.closest('.th-filter-dropdown .filter-actions button'))closeAllFilterDropdowns();});document.querySelectorAll('.th-filter-dropdown').forEach(d=>d.addEventListener('click',e=>e.stopPropagation()));
            const sI=document.getElementById('searchInput');
            if(sI){
                sI.addEventListener('keypress',e=>{if(e.key==='Enter')applyAllFilters();});
                sI.addEventListener('input',()=>applyAllFilters());
            }

            if (rowsPerPageSelectDesktopEl) {
                rowsPerPageSelectDesktopEl.addEventListener('change', handleRowsPerPageChange);
            }
            if (rowsPerPageSelectMobileEl) {
                rowsPerPageSelectMobileEl.addEventListener('change', handleRowsPerPageChange);
            }

            document.getElementById('submitDraftsButton').addEventListener('click',()=>{if(draftUpdates.length===0){alert("No drafts.");return;}if(!confirm(`Submit ${draftUpdates.length} draft(s)?`))return;let app=0,skp=0;const tS=[...draftUpdates];tS.forEach(d=>{const idx=findDataIndexByLicenseNo(d.licenseNo);if(idx>-1){const i=allLicenseData[idx];if(!i.isActive){skp++;return;}const oE=i.expiryDate,oD=i.licenseCopy,oOCN=i.otherCategoryName;i.expiryDate=d.newExpiryDate;i.licenseCopy=d.newDocumentName;if(i.category==='Others'&&typeof d.otherCategoryName!=='undefined')i.otherCategoryName=d.otherCategoryName;i.status=updateStatusBasedOnDate(i.expiryDate,i.status);let dets=`Applied: Exp ${oE||'N/A'}->${i.expiryDate}`;if(d.newDocumentName&&d.newDocumentName!==oD)dets+=`, Doc: ${d.newDocumentName}`;else if(!d.newDocumentName&&oD)dets+=`, Doc Removed`;if(i.category==='Others'&&d.otherCategoryName!==oOCN)dets+=`, OthDetail: ${oOCN||'N/A'}->${i.otherCategoryName}`;addHistoryEntry(i.licenseNo,'Draft Submitted',dets,'User');const oIdx=draftUpdates.findIndex(dr=>dr.licenseNo===d.licenseNo);if(oIdx>-1)draftUpdates.splice(oIdx,1);app++;}else{const oIdx=draftUpdates.findIndex(dr=>dr.licenseNo===d.licenseNo);if(oIdx>-1)draftUpdates.splice(oIdx,1);}});updateDraftCount();initializeUserScope();let msg=`${app} draft(s) submitted.`;if(skp>0)msg+=` ${skp} for deactivated skipped.`;alert(msg);});
            document.getElementById('refreshTableButton').addEventListener('click',()=>resetAllFilters());
            const mCS=document.getElementById('mobile-unit-filter-corporate-select'),mRS=document.getElementById('mobile-unit-filter-regional-select');if(mCS)mCS.addEventListener('change',()=>{if(!mCS.disabled){const sC=mCS.value!==ALL_OPTION_VALUE?mCS.value:null;populateHierarchicalOptions(accessibleLicenseData,mRS,'regional',{corporate:sC});populateHierarchicalOptions(accessibleLicenseData,document.getElementById('mobile-unit-filter-unit-select'),'unitName',{corporate:sC,regional:mRS.value!==ALL_OPTION_VALUE?mRS.value:null});}});if(mRS)mRS.addEventListener('change',()=>{if(!mRS.disabled){const sR=mRS.value!==ALL_OPTION_VALUE?mRS.value:null;const cMC=mCS.value!==ALL_OPTION_VALUE?mCS.value:null;populateHierarchicalOptions(accessibleLicenseData,document.getElementById('mobile-unit-filter-unit-select'),'unitName',{corporate:cMC,regional:sR});}});['category','licensetype','status'].forEach(k=>{const sInp=document.getElementById(`mobile-${k}-search`);if(sInp)sInp.addEventListener('input',()=>filterMobileDropdownOptions(sInp,k));});
        }
        function openMobileFilterModal(){populateMobileFilterOptions();if(mobileFilterModalInstance)mobileFilterModalInstance.show();}
        function populateMobileFilterOptions(){const mCS=document.getElementById('mobile-unit-filter-corporate-select'),mRS=document.getElementById('mobile-unit-filter-regional-select'),mUS=document.getElementById('mobile-unit-filter-unit-select');const cFC=activeFilters.selectedCorporate,cFR=activeFilters.selectedRegional,cFU=activeFilters.selectedUnit;populateHierarchicalOptions(accessibleLicenseData,mCS,'corporate');populateHierarchicalOptions(accessibleLicenseData,mRS,'regional',{corporate:cFC});populateHierarchicalOptions(accessibleLicenseData,mUS,'unitName',{corporate:cFC,regional:cFR});if(cFC)mCS.value=cFC;if(cFC)populateHierarchicalOptions(accessibleLicenseData,mRS,'regional',{corporate:cFC});if(cFR)mRS.value=cFR;if(cFR)populateHierarchicalOptions(accessibleLicenseData,mUS,'unitName',{corporate:cFC,regional:cFR});if(cFU)mUS.value=cFU;const sMSD=(s,v,d)=>{if(s){s.value=v;s.disabled=d;}};if(currentUser.role==='Corporate'){sMSD(mCS,currentUser.corporateName,true);populateHierarchicalOptions(accessibleLicenseData,mRS,'regional',{corporate:currentUser.corporateName});populateHierarchicalOptions(accessibleLicenseData,mUS,'unitName',{corporate:currentUser.corporateName,regional:mRS.value!==ALL_OPTION_VALUE?mRS.value:activeFilters.selectedRegional});if(activeFilters.selectedRegional)mRS.value=activeFilters.selectedRegional;if(activeFilters.selectedUnit)mUS.value=activeFilters.selectedUnit;mRS.disabled=mRS.options.length<=1&&!mRS.value;mUS.disabled=mUS.options.length<=1&&!mUS.value;}else if(currentUser.role==='Regional'){sMSD(mCS,currentUser.corporateName,true);sMSD(mRS,currentUser.regionalName,true);populateHierarchicalOptions(accessibleLicenseData,mUS,'unitName',{corporate:currentUser.corporateName,regional:currentUser.regionalName});if(activeFilters.selectedUnit)mUS.value=activeFilters.selectedUnit;mUS.disabled=mUS.options.length<=1&&!mUS.value;}else if(currentUser.role==='Unit'){sMSD(mCS,currentUser.corporateName,true);sMSD(mRS,currentUser.regionalName,true);sMSD(mUS,currentUser.unitName,true);}else{[mCS,mRS,mUS].forEach(s=>{if(s)s.disabled=s.options.length<=1&&!s.value;});}['category','licensetype','status'].forEach(kI=>{const dK=kI==='licensetype'?'licenseType':kI;const oC=document.getElementById(`mobile-${kI}-options`),sI=document.getElementById(`mobile-${kI}-search`);if(!oC)return;const uV=getUniqueColumnValues(dK),cCF=Array.isArray(activeFilters[dK])?activeFilters[dK]:[];oC.innerHTML=uV.map(v=>{const sV=String(v).replace(/[^a-zA-Z0-9-_]/g,''),cbId=`mobile-filter-${kI}-${sV||'empty'}-${Math.random().toString(36).substring(2,7)}`,iC=cCF.includes(v);return`<div class="form-check"><input class="form-check-input" type="checkbox" value="${v}" id="${cbId}" ${iC?'checked':''}><label class="form-check-label" for="${cbId}">${v}</label></div>`;}).join('');if(sI){sI.value='';filterMobileDropdownOptions(sI,kI);}});const mLNI=document.getElementById('mobile-licenseNoSearchInput');if(mLNI)mLNI.value=activeFilters.licenseNoSearch||'';const mEF=document.getElementById('mobile-expiryDateFromInput');if(mEF)mEF.value=activeFilters.expiryDateFrom||'';const mET=document.getElementById('mobile-expiryDateToInput');if(mET)mET.value=activeFilters.expiryDateTo||'';}
        function filterMobileDropdownOptions(sI,k){const fT=sI.value.toLowerCase(),oC=document.getElementById(`mobile-${k}-options`);if(!oC)return;oC.querySelectorAll('.form-check').forEach(i=>{const l=i.querySelector('label');if(l)i.style.display=l.textContent.toLowerCase().includes(fT)?'':'none';});}
        function applyMobileFilters(){const mC=document.getElementById('mobile-unit-filter-corporate-select'),mR=document.getElementById('mobile-unit-filter-regional-select'),mU=document.getElementById('mobile-unit-filter-unit-select');if(!mC.disabled)activeFilters.selectedCorporate=mC.value!==ALL_OPTION_VALUE?mC.value:null;if(!mR.disabled)activeFilters.selectedRegional=mR.value!==ALL_OPTION_VALUE?mR.value:null;if(!mU.disabled)activeFilters.selectedUnit=mU.value!==ALL_OPTION_VALUE?mU.value:null;['category','licensetype','status'].forEach(k=>{const dK=k==='licensetype'?'licenseType':k;const c=document.getElementById(`mobile-${k}-options`);if(c){const s=Array.from(c.querySelectorAll('input[type="checkbox"]:checked')).map(cb=>cb.value);if(s.length>0)activeFilters[dK]=s;else delete activeFilters[dK];}});activeFilters.licenseNoSearch=document.getElementById('mobile-licenseNoSearchInput').value.trim()||null;activeFilters.expiryDateFrom=document.getElementById('mobile-expiryDateFromInput').value||null;activeFilters.expiryDateTo=document.getElementById('mobile-expiryDateToInput').value||null;applyAllFilters();if(mobileFilterModalInstance)mobileFilterModalInstance.hide();}
        function clearMobileFilters(){resetAllFiltersInternal();populateMobileFilterOptions();}

        // --- START: IDENTIFY CHANGES (Modified renderTablePage for scheduled info) ---
        function renderTablePage(page){
            currentPage=page;
            const tB=document.getElementById('fssaiTableBody');
            tB.innerHTML='';
            let dataToRender=filteredLicenseData;
            const isMobile=isMobileView();

            if(isMobile){
                let mobileDisplayData=[...dataToRender];
                mobileDisplayData.sort((a,b)=>(a.isActive===b.isActive)?0:a.isActive?-1:1);
                dataToRender=mobileDisplayData;
            }

            let totalItems=dataToRender.length,totalPages=Math.ceil(totalItems/rowsPerPage)||1;
            page=Math.max(1,Math.min(page,totalPages));
            currentPage=page;
            let start=(page-1)*rowsPerPage,end=start+rowsPerPage;
            let pageData=dataToRender.slice(start,end);

            if(pageData.length===0&&totalItems>0&&currentPage>1){changePage(currentPage-1);return;}
            if(pageData.length===0&&totalItems===0){tB.innerHTML=isMobile?`<tr><td><div class="mobile-license-card text-center text-muted p-3">No data available.</div></td></tr>`:`<tr><td colspan="${DATA_KEYS.length}" class="text-center text-muted">No data available.</td></tr>`;updatePaginationControls(0,0,0);return;}

            pageData.forEach((item,index)=>{
                const actualSlNo=start+index+1,row=tB.insertRow();
                row.setAttribute('data-license-no',item.licenseNo||`temp-${index}`);
                if(item.isActive===false)row.classList.add('row-deactivated','mobile-card-border-deactivated');
                else if(item.status==='Active')row.classList.add('mobile-card-border-active');
                else if(item.status==='Expired')row.classList.add('mobile-card-border-expired');
                else if(item.status==='Pending')row.classList.add('mobile-card-border-pending');

                if(draftUpdates.some(d=>d.licenseNo===item.licenseNo)&&item.isActive)row.classList.add('has-draft');

                const scheduleForItem = scheduledUpdates.find(s => s.licenseNo === item.licenseNo);
                if(scheduleForItem && item.isActive) row.classList.add('is-scheduled');


                if(isMobile){
                    const cell=row.insertCell();
                    cell.colSpan=DATA_KEYS.length;
                    let catDisp=item.category==='Others'&&item.otherCategoryName?`Others: ${item.otherCategoryName}`:(item.category||'N/A');
                    let dispExpDate=item.expiryDate||'N/A';
                    if(item.expiryDate&&/^\d{4}-\d{2}-\d{2}$/.test(item.expiryDate)){const p=item.expiryDate.split('-');dispExpDate=`${p[1]}/${p[2]}/${p[0]}`; }

                    let scheduledInfoMobileHTML = '';
                    if (scheduleForItem && item.isActive) {
                        scheduledInfoMobileHTML = `<p class="scheduled-info-mobile" title="${scheduleForItem.scheduledComments || 'No comments'}"><i class="fas fa-calendar-check"></i> Scheduled: ${scheduleForItem.scheduledDate}${scheduleForItem.scheduledTime ? ' @ ' + scheduleForItem.scheduledTime : ''}</p>`;
                    }

                    cell.innerHTML=`
                        <div class="mobile-license-card">
                            <div class="card-header-mobile"><span class="unit-name-mobile">${item.unitName||'N/A'}</span><span class="status-mobile">${getStatusBadge(item.status,item.isActive)}</span></div>
                            <div class="card-subheader-mobile">${item.corporate||'N/A'} &gt; ${item.regional||'N/A'}</div>
                            <div class="card-body-mobile">
                                <div class="left-details">
                                    <p><strong>Category:</strong> ${catDisp}</p>
                                    <p><strong>License Type:</strong> ${item.licenseType||'N/A'}</p>
                                </div>
                                <div class="right-details">
                                    <p><strong>License No:</strong> ${item.licenseNo||'N/A'}</p>
                                    <p><strong>Expiry Date:</strong> ${dispExpDate}</p>
                                    ${scheduledInfoMobileHTML}
                                </div>
                            </div>
                            <div class="card-footer-mobile">
                                <div class="pdf-icon-mobile">${generateLicenseCopyHTML(item.licenseCopy,item.licenseNo)}</div>
                                <div class="actions-mobile">${generateActionsHTML(item)}</div>
                            </div>
                        </div>`;
                } else {
                    row.insertCell().textContent=actualSlNo;
                    const uHC=row.insertCell();
                    uHC.innerHTML=`<div>${item.unitName||''}</div><small class="text-muted">${item.corporate||'N/A'} > ${item.regional||'N/A'}</small>`;
                    uHC.style.whiteSpace='normal';
                    const cC=row.insertCell();
                    cC.textContent=item.category==='Others'&&item.otherCategoryName?`Others: ${item.otherCategoryName}`:(item.category||'');
                    row.insertCell().textContent=item.licenseNo||'';

                    const expiryDateCell = row.insertCell();
                    let expiryDateHTML = item.expiryDate||'N/A';
                    if (scheduleForItem && item.isActive) {
                        expiryDateHTML += `<div class="scheduled-info-badge" title="${scheduleForItem.scheduledComments || 'No comments'}">
                                              <i class="fas fa-calendar-check me-1"></i>Scheduled: ${scheduleForItem.scheduledDate}${scheduleForItem.scheduledTime ? ' @ ' + scheduleForItem.scheduledTime : ''}
                                           </div>`;
                    }
                    expiryDateCell.innerHTML = expiryDateHTML;

                    row.insertCell().textContent=item.licenseType||'N/A';
                    row.insertCell().innerHTML=generateLicenseCopyHTML(item.licenseCopy,item.licenseNo);
                    row.insertCell().innerHTML=getStatusBadge(item.status,item.isActive);
                    row.insertCell().innerHTML=generateActionsHTML(item);
                }
            });
            updatePaginationControls(page,totalPages,totalItems);
            if (!isMobile) { // Re-init tooltips for desktop only, as mobile doesn't show action buttons with tooltips
                tooltipList.forEach(tooltip => tooltip.dispose());
                tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"], .action-buttons-wrapper [title], .scheduled-info-badge[title]'));
                tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl);
                });
            }
        }
        // --- END: IDENTIFY CHANGES ---

        function updatePaginationControls(curP,totP,totI){const pU=document.getElementById('paginationUl');pU.innerHTML='';const sS=document.getElementById('showingStart'),sE=document.getElementById('showingEnd'),tE=document.getElementById('totalEntries');if(totI===0){sS.textContent=0;sE.textContent=0;tE.textContent=0;pU.innerHTML='<li class="page-item disabled"><span class="page-link">No data</span></li>';return;}const sEntry=(curP-1)*rowsPerPage+1,eEntry=Math.min(sEntry+rowsPerPage-1,totI);sS.textContent=sEntry;sE.textContent=eEntry;tE.textContent=totI;let liP=document.createElement('li');liP.className=`page-item ${curP===1?'disabled':''}`;liP.innerHTML=`<a class="page-link" href="#" ${curP>1?`onclick="event.preventDefault();changePage(${curP-1})"`:''}>Previous</a>`;pU.appendChild(liP);const mP=5;let sP=Math.max(1,curP-Math.floor(mP/2)),eP=Math.min(totP,sP+mP-1);sP=Math.max(1,eP-mP+1);if(sP>1){pU.appendChild(createPageItem(1));if(sP>2)pU.appendChild(createEllipsisItem());}for(let i=sP;i<=eP;i++)pU.appendChild(createPageItem(i,curP===i));if(eP<totP){if(eP<totP-1)pU.appendChild(createEllipsisItem());pU.appendChild(createPageItem(totP));}let liN=document.createElement('li');liN.className=`page-item ${curP===totP?'disabled':''}`;liN.innerHTML=`<a class="page-link" href="#" ${curP<totP?`onclick="event.preventDefault();changePage(${curP+1})"`:''}>Next</a>`;pU.appendChild(liN);}
        function createPageItem(pN,isAct=false){let li=document.createElement('li');li.className=`page-item ${isAct?'active':''}`;li.innerHTML=`<a class="page-link" href="#" onclick="event.preventDefault();changePage(${pN})">${pN}</a>`;return li;}
        function createEllipsisItem(){let li=document.createElement('li');li.className='page-item disabled';li.innerHTML=`<span class="page-link">...</span>`;return li;}
        function changePage(pg){let dataToProcess = filteredLicenseData; if(isMobileView()){ let mobileSortedData = [...filteredLicenseData]; mobileSortedData.sort((a, b) => (a.isActive === b.isActive)? 0 : a.isActive? -1 : 1); dataToProcess = mobileSortedData; } const tP = Math.ceil(dataToProcess.length / rowsPerPage) || 1; if(pg < 1 || pg > tP) return; renderTablePage(pg); }

        // --- START: IDENTIFY CHANGES (Modified updateAvailableCategoriesForNewRow) ---
        function updateAvailableCategoriesForNewRow(uNI){
            const nR = uNI.closest('tr');
            if (!nR || !nR.classList.contains('editable-row')) return;

            const cS = nR.querySelector('select[name="category"]');
            const cU = uNI.value.trim();
            const oCVal = cS.value;

            let allAvailableSystemCategories = [...BASE_CATEGORIES];
            const scopedCustomCats = getScopedCustomCategories();
            scopedCustomCats.forEach(cc => {
                if (!allAvailableSystemCategories.includes(cc.name)) {
                    allAvailableSystemCategories.push(cc.name);
                }
            });
            allAvailableSystemCategories.sort();


            let categoriesForNewEntry = [...allAvailableSystemCategories];

            cS.innerHTML = '';

            if (cU && currentUser.role === 'Unit') {
                let pCo = currentUser.corporateName;
                let pRe = currentUser.regionalName;

                const existingUnitCategories = allLicenseData.filter(item =>
                    item.unitName && item.unitName.toLowerCase() === cU.toLowerCase() &&
                    item.isActive === true && item.category !== 'Others' &&
                    item.corporate === pCo && item.regional === pRe
                ).map(item => item.category);

                categoriesForNewEntry = allAvailableSystemCategories.filter(cat => cat === 'Others' || !existingUnitCategories.includes(cat));
            }


            let plO = document.createElement('option');
            plO.value = "";
            plO.textContent = "-- Select Category (Required) --";
            plO.disabled = true;
            plO.selected = true;
            cS.appendChild(plO);

            categoriesForNewEntry.forEach(cat => {
                const o = document.createElement('option');
                o.value = cat;
                o.textContent = cat;
                cS.appendChild(o);
            });

            if (Array.from(cS.options).some(o => o.value === oCVal && o.value !== "")) {
                cS.value = oCVal;
            } else {
                cS.selectedIndex = 0;
            }
            handleCategoryChange(cS);
        }
        // --- END: IDENTIFY CHANGES ---

        function addNewLicense(){
            const tB = document.getElementById('fssaiTableBody');
            if (tB.querySelector('.editable-row')) {
                alert('Please save or cancel the current new license entry before adding another.');
                return;
            }
            const nR = tB.insertRow(0);
            nR.classList.add('editable-row');
            let unitNameValue = (currentUser.role === 'Unit') ? currentUser.unitName : '';
            let unitNameDisabled = (currentUser.role === 'Unit') ? 'disabled' : '';
            let uNIHTML = `<input type="text" class="form-control form-control-sm" value="${unitNameValue}" name="unitName" ${unitNameDisabled} placeholder="Unit Name (Required)" oninput="updateAvailableCategoriesForNewRow(this)">`;
            const cSHTML = `<div>
                                <select class="form-select form-select-sm" name="category" onchange="handleCategoryChange(this)"></select>
                                <div class="other-category-name-input-wrapper d-none mt-1">
                                    <input type="text" class="form-control form-control-sm" name="otherCategoryName" placeholder="Specify Other Name (Required)">
                                </div>
                            </div>`;
            const lTO = ['NA', 'Registration', 'State', 'Central'];
            let lTSHTML = '<select class="form-select form-select-sm" name="licenseType" disabled>';
            lTO.forEach(o => lTSHTML += `<option value="${o}" ${o === 'NA' ? 'selected' : ''}>${o}</option>`);
            lTSHTML += '</select>';
            nR.insertCell().textContent = '*';
            nR.insertCell().innerHTML = uNIHTML;
            nR.insertCell().innerHTML = cSHTML;
            nR.insertCell().innerHTML = '<input type="text" class="form-control form-control-sm" placeholder="License No (Required)" name="licenseNo">';
            nR.insertCell().innerHTML = '<input type="date" class="form-control form-control-sm" name="expiryDate" title="Expiry Date (Required)">';
            nR.insertCell().innerHTML = lTSHTML;
            nR.insertCell().innerHTML = `<div class="file-upload"><i class="fas fa-cloud-upload-alt me-1"></i>Upload<input type="file" onchange="handleNewLicenseUpload(this)" accept=".pdf,.jpg,.jpeg,.png" name="licenseCopyFile"></div><span class="uploaded-file"></span>`;
            nR.insertCell().innerHTML = getStatusBadge('Pending', true);
            nR.insertCell().innerHTML = `<div class="action-buttons-wrapper">
                                            <div class="action-btns">
                                                <button class="btn btn-sm btn-success btn-save" onclick="saveNewLicense(this)"><i class="fas fa-save me-1"></i>Save</button>
                                                <button class="btn btn-sm btn-danger btn-cancel" onclick="cancelNewLicense(this)"><i class="fas fa-times me-1"></i>Cancel</button>
                                            </div>
                                        </div>`;
            const nUNI = nR.querySelector('input[name="unitName"]');
            if (nUNI) updateAvailableCategoriesForNewRow(nUNI);
            nR.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }


        function saveNewLicense(btn){const r=btn.closest('tr'),inps=r.querySelectorAll('input[name],select[name]');let nD={slNo:0,corporate:null,regional:null,unitName:null,isActive:true,otherCategoryName:null},isV=true,licNo='',expD='',aTO=false;inps.forEach(i=>{const v=i.value,n=i.getAttribute('name');i.classList.remove('is-invalid');if(i.tagName==='SELECT'&&!v&&n==='category'){i.classList.add('is-invalid');isV=false;}else if(i.type==='file'){nD.licenseCopy=i.dataset.uploadedFileName||null;delete i.dataset.uploadedFileName;}else if(n==='otherCategoryName'){if(r.querySelector('select[name="category"]').value==='Others'){if(!v.trim()){i.classList.add('is-invalid');isV=false;aTO=true;}nD.otherCategoryName=v.trim();}else nD.otherCategoryName=null;}else if(i.type!=='file'&&!v.trim()&&['licenseNo','expiryDate','unitName'].includes(n) && !i.disabled){i.classList.add('is-invalid');isV=false;}else if(i.type!=='file')nD[n]=v.trim();if(n==='licenseNo')licNo=v.trim();if(n==='expiryDate')expD=v;if(n==='unitName')nD.unitName=v.trim();});if(currentUser.role==='Unit'){nD.corporate=currentUser.corporateName;nD.regional=currentUser.regionalName;nD.unitName=currentUser.unitName;}if(nD.category==='License'&&(!nD.licenseType||nD.licenseType==='NA')){const lTSel=r.querySelector('select[name="licenseType"]');if(lTSel&&!lTSel.disabled){lTSel.classList.add('is-invalid');isV=false;}}else if(nD.category!=='License')nD.licenseType='NA';if(nD.category==='Others'&&!nD.otherCategoryName){const oNI=r.querySelector('input[name="otherCategoryName"]');if(oNI)oNI.classList.add('is-invalid');isV=false;aTO=true;}if(!isV){let m='Please fill all required fields: ',rF=[];if(r.querySelector('select[name="category"].is-invalid'))rF.push('Category');if(r.querySelector('input[name="licenseNo"].is-invalid'))rF.push('License No');if(r.querySelector('input[name="expiryDate"].is-invalid'))rF.push('Expiry Date');if(r.querySelector('select[name="licenseType"].is-invalid'))rF.push('License Type');if(aTO)rF.push('Other Category Name');alert(m+rF.join(', ')+'.');return;}if(!licNo){alert('License Number cannot be empty.');r.querySelector('input[name="licenseNo"]').classList.add('is-invalid');return;}if(findDataIndexByLicenseNo(licNo)!==-1){alert(`License with number ${licNo} already exists.`);r.querySelector('input[name="licenseNo"]').classList.add('is-invalid');return;}if(!nD.corporate||!nD.regional||!nD.unitName){alert('Unit hierarchy (Corporate, Regional, Unit Name) is missing. This might be a configuration issue.');return;}nD.status=updateStatusBasedOnDate(expD,'Pending');nD.slNo=Math.max(0,...allLicenseData.map(d=>d.slNo))+1;allLicenseData.unshift(nD);initializeUserScope();let hD=`Unit:${nD.unitName}(C:${nD.corporate},R:${nD.regional}),Cat:${nD.category}`;if(nD.category==='Others'&&nD.otherCategoryName)hD+=`(${nD.otherCategoryName})`;hD+=`,Type:${nD.licenseType},Exp:${expD}`;addHistoryEntry(licNo,'License Created',hD,'User');if(nD.licenseCopy)addHistoryEntry(licNo,'Doc Upload',`Initial document: ${nD.licenseCopy}`,'User');alert('New license added successfully.');}
        function cancelNewLicense(btn){btn.closest('tr').remove();}
        function downloadCSV(csv,fName){const cF=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"}),dL=document.createElement("a");dL.download=fName;dL.href=window.URL.createObjectURL(cF);dL.style.display="none";document.body.appendChild(dL);dL.click();document.body.removeChild(dL);}
        function exportTableToCSV(fName){const csv=[],h=['SL No','Corporate','Regional','Unit Name','Category','Other Category Detail','License No','Expiry Date','License Type','License Copy File','Status','Is Active'];csv.push(h.join(","));const d=filteredLicenseData;if(d.length===0){alert("No data to export.");return;}d.forEach((i,idx)=>{const rD=[];rD.push(`"${idx+1}"`);rD.push(`"${i.corporate?.replace(/"/g,'""')||''}"`);rD.push(`"${i.regional?.replace(/"/g,'""')||''}"`);rD.push(`"${i.unitName?.replace(/"/g,'""')||''}"`);rD.push(`"${i.category?.replace(/"/g,'""')||''}"`);rD.push(`"${(i.category==='Others'&&i.otherCategoryName)?i.otherCategoryName.replace(/"/g,'""'):''}"`);rD.push(`"${i.licenseNo?.replace(/"/g,'""')||''}"`);rD.push(`"${i.expiryDate||''}"`);rD.push(`"${i.licenseType?.replace(/"/g,'""')||''}"`);rD.push(`"${i.licenseCopy?i.licenseCopy.replace(/"/g,'""'):'No'}"`);const dS=i.isActive===false?'Deactivated':(i.status||'');rD.push(`"${dS.replace(/"/g,'""')}"`);rD.push(`"${i.isActive?'Yes':'No'}"`);csv.push(rD.join(","));});downloadCSV(csv.join("\n"),fName);addHistoryEntry('SYSTEM','Export',`Exported ${d.length} records.`,'User');}

        // --- START: IDENTIFY CHANGES (New Custom Category Functions) ---
        function populateCustomCategoryScopeSelector() {
            const wrapper = document.getElementById('customCategoryScopeWrapper');
            const nameInput = document.getElementById('newCustomCategoryName');
            const addButton = document.querySelector('#categoryManagementSection button[onclick="addNewCustomCategory()"]');

            if (!wrapper || !nameInput || !addButton) return;
            wrapper.innerHTML = '';

            if (currentUser.role === 'Super Admin') {
                let optionsHTML = `<label for="customCategoryScope" class="form-label">Scope</label>
                                <select id="customCategoryScope" class="form-select form-select-sm">
                                    <option value="Super Admin" selected>Global (All Users)</option>`;
                const corporates = [...new Set(allLicenseData.map(item => item.corporate).filter(Boolean))].sort();
                corporates.forEach(corp => {
                    optionsHTML += `<option value="Corporate_${corp}">${corp}</option>`;
                });
                optionsHTML += `</select>`;
                wrapper.innerHTML = optionsHTML;
                nameInput.disabled = false;
                addButton.disabled = false;
            } else if (currentUser.role === 'Corporate') {
                wrapper.innerHTML = `<input type="hidden" id="customCategoryScope" value="Corporate_${currentUser.corporateName}">
                                    <p class="form-control-plaintext ps-0 small text-muted mb-0 pb-2">Scope: ${currentUser.corporateName} (Corporate)</p>`;
                nameInput.disabled = false;
                addButton.disabled = false;
            } else if (currentUser.role === 'Regional') {
                wrapper.innerHTML = `<input type="hidden" id="customCategoryScope" value="Regional_${currentUser.corporateName}_${currentUser.regionalName}">
                                    <p class="form-control-plaintext ps-0 small text-muted mb-0 pb-2">Scope: ${currentUser.regionalName} (${currentUser.corporateName})</p>`;
                nameInput.disabled = false;
                addButton.disabled = false;
            } else {
                wrapper.innerHTML = '<p class="small text-muted mb-0 pb-2">Category creation not available for Unit role.</p>';
                nameInput.disabled = true;
                addButton.disabled = true;
            }
        }

        function getScopedCustomCategories() {
            let visibleCategories = [];
            visibleCategories.push(...customCategoriesData.filter(cat => cat.scope === 'Super Admin'));

            if (currentUser.role === 'Corporate' || currentUser.role === 'Regional' || currentUser.role === 'Unit') {
                visibleCategories.push(...customCategoriesData.filter(cat => cat.scope === `Corporate_${currentUser.corporateName}`));
            }
            if (currentUser.role === 'Regional' || currentUser.role === 'Unit') {
                 visibleCategories.push(...customCategoriesData.filter(cat => cat.scope === `Regional_${currentUser.corporateName}_${currentUser.regionalName}`));
            }
            // if (currentUser.role === 'Unit') {
            //     // Potentially unit-specific categories, if implemented:
            //     // visibleCategories.push(...customCategoriesData.filter(cat => cat.scope === `Unit_${currentUser.corporateName}_${currentUser.regionalName}_${currentUser.unitName}`));
            // }
            return [...new Map(visibleCategories.map(item => [item.name, item])).values()];
        }

        function displayCustomCategories() {
            const listElement = document.getElementById('customCategoryList');
            const scopeInfoEl = document.getElementById('customCategoryListScope');
            if (!listElement || !scopeInfoEl) return;

            let currentScopeDisplay = "Your Scope";
            if(currentUser.role === 'Super Admin') currentScopeDisplay = "All Defined (Admin View)";
            else if(currentUser.role === 'Corporate') currentScopeDisplay = `Corporate: ${currentUser.corporateName}`;
            else if(currentUser.role === 'Regional') currentScopeDisplay = `Regional: ${currentUser.regionalName}`;
            else if(currentUser.role === 'Unit') currentScopeDisplay = `Unit: ${currentUser.unitName} (View Only)`;
            scopeInfoEl.textContent = currentScopeDisplay;

            let categoriesToDisplay = [];
            if(currentUser.role === 'Super Admin'){
                categoriesToDisplay = [...customCategoriesData];
            } else {
                categoriesToDisplay = getScopedCustomCategories();
            }

            listElement.innerHTML = '';
            if (categoriesToDisplay.length === 0) {
                listElement.innerHTML = '<li class="list-group-item text-muted">No custom categories defined for this scope.</li>';
                return;
            }
            categoriesToDisplay.sort((a,b) => a.name.localeCompare(b.name)).forEach(cat => {
                const li = document.createElement('li');
                li.className = 'list-group-item d-flex justify-content-between align-items-center';

                let scopeText = cat.scope;
                if (scopeText.startsWith('Corporate_')) scopeText = scopeText.replace('Corporate_', 'Corp: ');
                else if (scopeText.startsWith('Regional_')) scopeText = scopeText.replace(`Regional_${cat.scope.split('_')[1]}_`, 'Reg: ');


                let scopeBadge = `<span class="badge bg-secondary rounded-pill">${scopeText}</span>`;
                if (cat.scope === 'Super Admin') scopeBadge = `<span class="badge bg-primary rounded-pill">Global</span>`;
                else if (cat.scope.startsWith('Corporate_')) scopeBadge = `<span class="badge bg-info text-dark rounded-pill">${cat.scope.replace('Corporate_','')}</span>`;
                else if (cat.scope.startsWith('Regional_')) scopeBadge = `<span class="badge bg-success rounded-pill">${cat.scope.split('_').slice(2).join(' ')} (${cat.scope.split('_')[1]})</span>`;


                let canDelete = false;
                if (currentUser.role === 'Super Admin') canDelete = true;
                else if (currentUser.role === 'Corporate' && cat.scope === `Corporate_${currentUser.corporateName}`) canDelete = true;
                else if (currentUser.role === 'Regional' && cat.scope === `Regional_${currentUser.corporateName}_${currentUser.regionalName}`) canDelete = true;

                if(canDelete){
                    li.innerHTML = `${cat.name} ${scopeBadge} <button class="btn btn-sm btn-outline-danger py-0 px-1" onclick="deleteCustomCategory('${cat.name}', '${cat.scope}')" title="Delete ${cat.name}"><i class="fas fa-times"></i></button>`;
                } else {
                     li.innerHTML = `${cat.name} ${scopeBadge}`;
                }
                listElement.appendChild(li);
            });
        }

        function addNewCustomCategory() {
            // const nameInput = document.getElementById('newCustomCategoryName');
            // const categoryName = nameInput.value.trim();
            // if (!categoryName) {
            //     alert("Category name cannot be empty.");
            //     nameInput.classList.add('is-invalid');
            //     return;
            // }
            // nameInput.classList.remove('is-invalid');

            // let scope = "Super Admin";
            // if (currentUser.role === 'Corporate') {
            //     scope = `Corporate_${currentUser.corporateName}`;
            // } else if (currentUser.role === 'Regional') {
            //     scope = `Regional_${currentUser.corporateName}_${currentUser.regionalName}`;
            // } else if (currentUser.role === 'Super Admin') {
            //     const scopeSelect = document.getElementById('customCategoryScope');
            //     if (scopeSelect) scope = scopeSelect.value;
            // }

            // const isBaseCategory = BASE_CATEGORIES.map(b => b.toLowerCase()).includes(categoryName.toLowerCase());
            // const isDuplicateInScope = customCategoriesData.some(cat => cat.name.toLowerCase() === categoryName.toLowerCase() && cat.scope === scope);
            // const isGlobalDuplicate = customCategoriesData.some(cat => cat.name.toLowerCase() === categoryName.toLowerCase() && cat.scope === "Super Admin");

            // if (isBaseCategory) {
            //     alert(`Category "${categoryName}" is a standard base category and cannot be added.`); return;
            // }
            // if (isDuplicateInScope) {
            //      alert(`Category "${categoryName}" already exists within the scope: ${scope}.`); return;
            // }
            // if (scope !== "Super Admin" && isGlobalDuplicate) { // Prevent non-SuperAdmins from adding a category that's already global
            //      alert(`Category "${categoryName}" already exists as a global category.`); return;
            // }


            // customCategoriesData.push({ name: categoryName, scope: scope });
            // nameInput.value = '';
            // addHistoryEntry('SYSTEM', 'Custom Category Added', `Category: ${categoryName}, Scope: ${scope}`, currentUser.role);
            // alert(`Custom category "${categoryName}" added for scope: ${scope}.`);
            // displayCustomCategories();
            // initializeUserScope();
            
            const nameInput = document.getElementById('newCustomCategoryName');
        const categoryName = nameInput.value.trim();

        if (!categoryName) {
            alert("Category name cannot be empty.");
            nameInput.classList.add('is-invalid');
            return;
        }

        document.getElementById('customCategoryForm').submit();
        }

        function deleteCustomCategory(categoryName, categoryScope) {
            // Check if category is in use
            const isInUse = allLicenseData.some(item => item.category === categoryName &&
                ( // This scope check for deletion is simplified; a real app would need robust checks
                  categoryScope === "Super Admin" ||
                  (categoryScope.startsWith("Corporate_") && item.corporate === categoryScope.split("_")[1]) ||
                  (categoryScope.startsWith("Regional_") && item.corporate === categoryScope.split("_")[1] && item.regional === categoryScope.split("_")[2])
                )
            );

            if (isInUse) {
                alert(`Cannot delete category "${categoryName}" as it is currently in use by one or more licenses.`);
                return;
            }

            if (!confirm(`Are you sure you want to delete the custom category "${categoryName}" for scope "${categoryScope}"?`)) return;

            customCategoriesData = customCategoriesData.filter(cat => !(cat.name === categoryName && cat.scope === categoryScope));
            addHistoryEntry('SYSTEM', 'Custom Category Deleted', `Category: ${categoryName}, Scope: ${categoryScope}`, currentUser.role);
            alert(`Custom category "${categoryName}" deleted.`);
            displayCustomCategories();
            initializeUserScope();
        }
        // --- END: IDENTIFY CHANGES ---

        document.addEventListener('DOMContentLoaded',()=>{
            tooltipTriggerList=[].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipList=tooltipTriggerList.map(el=>new bootstrap.Tooltip(el));

            documentModal=new bootstrap.Modal(document.getElementById('documentModal'));
            renewModal=new bootstrap.Modal(document.getElementById('renewModal'));
            historyModal=new bootstrap.Modal(document.getElementById('historyModal'));
            scheduleModalInstance = new bootstrap.Modal(document.getElementById('scheduleModal'));
            mobileFilterModalInstance=new bootstrap.Modal(document.getElementById('mobileFilterModal'));

            initializeStatuses();
            setCurrentUser('Super Admin'); // This will call initializeUserScope

            // rowsPerPage = parseInt(rowsPerPageSelectDesktopEl.value, 10); // Moved to initializeUserScope
            // if (rowsPerPageSelectMobileEl) {
            //     rowsPerPageSelectMobileEl.value = rowsPerPage;
            // }

            setupEventListeners();
            addHistoryEntry('SYSTEM','System Init',`Dashboard Initialized for ${currentUser.role} ${currentUser.corporateName||''}`,'System');
            // handleResize(); // Called by initializeUserScope -> applyAllFilters -> renderTablePage
        });

        function handleResize(){
            const isM = isMobileView();
            const aNB = document.getElementById('addNewButton');
            if(aNB){
                if(currentUser.role==='Unit' && !isM) {
                    aNB.style.display='inline-block';
                } else {
                    aNB.style.display='none';
                }
            }

            const currentRowsPerPageValue = document.getElementById('rowsPerPageSelectDesktop')?.value || document.getElementById('rowsPerPageSelectMobile')?.value || rowsPerPage;
            rowsPerPage = parseInt(currentRowsPerPageValue, 10);
            if (document.getElementById('rowsPerPageSelectDesktop')) document.getElementById('rowsPerPageSelectDesktop').value = rowsPerPage;
            if (document.getElementById('rowsPerPageSelectMobile')) document.getElementById('rowsPerPageSelectMobile').value = rowsPerPage;

            renderTablePage(currentPage);

            tooltipList.forEach(tooltip => tooltip.dispose());
            tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"], .action-buttons-wrapper [title], .scheduled-info-badge[title]'));
            tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        }
        window.addEventListener('resize',handleResize);
    </script>

   