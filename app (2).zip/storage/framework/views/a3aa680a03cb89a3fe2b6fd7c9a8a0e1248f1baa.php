                <div class="modal fade" id="toolselection" tabindex="-1" aria-hidden="true" enctype="multipart/form-data">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                      <h5 class="modal-title">Add ToolSelection</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                         <form></form>
                        <form method="post" action="<?php echo e(route('facility_tool_store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                    <div class="row">
		
                        <div class="mb-6 col-md-6">
                            <label class="form-label">Tools Name:</label>
                            <input type="text" class="form-control"  name="name" placeholder="" required>
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>
                        </div>
						
						    <div class="mb-6 col-md-6">
                            <label class="form-label">Purpose:</label>
                            <input type="text" class="form-control"  name="purpose" placeholder="" required>
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>
                        </div>
						
							    <div class="mb-6 col-md-6">
                            <label class="form-label">Target Surface:</label>
                            <input type="text" class="form-control"  name="target_surface" placeholder="" required>
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>
                        </div>
						
						       <div class="mb-6 col-md-6">
                            <label class="form-label">Image:</label>
                          <input type="file" class="form-control" placeholder="" name="company_logo">
                           
                        </div>
						
					
			
               
                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary">Add New ToolSelection</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>

<?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/popups/fhm/toolselection.blade.php ENDPATH**/ ?>