<style type="text/css">
    .error {
    color: red;
    margin: 10px 0px;
}
</style>
<?php $__env->startSection('content'); ?>

     <?php echo $__env->make('admin.users.popups.reginoal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.users.popups.unit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                      <div class="modal fade" id="addunitdetails" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add  Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                         <form></form>
                        <form method="post" action="<?php echo e(route('add_users')); ?>">
                            <?php echo csrf_field(); ?>
                    <div class="row">

<input type="hidden" name="is_role" value="2">

                        <div class="mb-3 col-md-6">
                            <label class="form-label">Login ID:</label>
                            <input type="text" class="form-control"  name="login_id" placeholder="">
                            <?php if($errors->has('login_id')): ?>
    <div class="error"><?php echo e($errors->first('login_id')); ?></div>
<?php endif; ?>
                        </div>

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Company Name:</label>
                            <input type="text" class="form-control"  name="company_name" placeholder="">
                            <?php if($errors->has('company_name')): ?>
    <div class="error"><?php echo e($errors->first('company_name')); ?></div>
<?php endif; ?>
                        </div>


                               <div class="mb-3 col-md-6">
                            <label class="form-label">Company Address
:</label>
                            <input type="text" class="form-control"  name="Company_address" placeholder="">
                            <?php if($errors->has('Company_address')): ?>
    <div class="error"><?php echo e($errors->first('Company_address')); ?></div>
<?php endif; ?>
                        </div>

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Contact Person Name:</label>
                            <input type="text" class="form-control"  name="Contact_Person_Name" placeholder="">
                            <?php if($errors->has('login_id')): ?>
    <div class="error"><?php echo e($errors->first('login_id')); ?></div>
<?php endif; ?>
                        </div>

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Designation:</label>
                            <input type="text" class="form-control"  name="designation" placeholder="">
                            <?php if($errors->has('designation')): ?>
    <div class="error"><?php echo e($errors->first('designation')); ?></div>
<?php endif; ?>
                        </div>

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Full Name </label>
                            <input type="text" name="name" class="form-control" placeholder="">
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>

                        </div>

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Email </label>
                            <input type="email" name="email" class="form-control" placeholder="">
                            <?php if($errors->has('email')): ?>
    <div class="error"><?php echo e($errors->first('email')); ?></div>
<?php endif; ?>
                        </div>

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Mobile Number </label>
                            <input type="text" name="mobile_number" class="form-control" placeholder="">
                            <?php if($errors->has('mobile_number')): ?>
    <div class="error"><?php echo e($errors->first('mobile_number')); ?></div>
<?php endif; ?>
                        </div>

                              <div class="mb-12 col-md-12">
                            <label class="form-label">Enter Password </label>
                            <input type="text" name="password" class="form-control" placeholder="">
                            <?php if($errors->has('password')): ?>
    <div class="error"><?php echo e($errors->first('password')); ?></div>
<?php endif; ?>
                        </div>
               
                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary">Add  Details</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 
                      <div class="modal fade" id="addcompanydetails" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add  Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                         <form></form>
                        <form method="post" action="<?php echo e(route('add_users')); ?>">
                            <?php echo csrf_field(); ?>
                    <div class="row">



                        <div class="mb-3 col-md-6">
                            <label class="form-label">Unit ID:</label>
                            <input type="text" class="form-control"  name="login_id" placeholder="">
                            <?php if($errors->has('login_id')): ?>
    <div class="error"><?php echo e($errors->first('login_id')); ?></div>
<?php endif; ?>
                        </div>

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Unit Name:</label>
                            <input type="text" class="form-control"  name="company_name" placeholder="">
                            <?php if($errors->has('company_name')): ?>
    <div class="error"><?php echo e($errors->first('company_name')); ?></div>
<?php endif; ?>
                        </div>


                               <div class="mb-3 col-md-6">
                            <label class="form-label">Unit Address
:</label>
                            <input type="text" class="form-control"  name="Company_address" placeholder="">
                            <?php if($errors->has('Company_address')): ?>
    <div class="error"><?php echo e($errors->first('Company_address')); ?></div>
<?php endif; ?>
                        </div>

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Contact Person Name:</label>
                            <input type="text" class="form-control"  name="Contact_Person_Name" placeholder="">
                            <?php if($errors->has('login_id')): ?>
    <div class="error"><?php echo e($errors->first('login_id')); ?></div>
<?php endif; ?>
                        </div>

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Designation:</label>
                            <input type="text" class="form-control"  name="designation" placeholder="">
                            <?php if($errors->has('designation')): ?>
    <div class="error"><?php echo e($errors->first('designation')); ?></div>
<?php endif; ?>
                        </div>

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Full Name </label>
                            <input type="text" name="name" class="form-control" placeholder="">
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>

                        </div>

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Email </label>
                            <input type="email" name="email" class="form-control" placeholder="">
                            <?php if($errors->has('email')): ?>
    <div class="error"><?php echo e($errors->first('email')); ?></div>
<?php endif; ?>
                        </div>

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Mobile Number </label>
                            <input type="text" name="mobile_number" class="form-control" placeholder="">
                            <?php if($errors->has('mobile_number')): ?>
    <div class="error"><?php echo e($errors->first('mobile_number')); ?></div>
<?php endif; ?>
                        </div>

                              <div class="mb-12 col-md-12">
                            <label class="form-label">Enter Password </label>
                            <input type="text" name="password" class="form-control" placeholder="">
                            <?php if($errors->has('password')): ?>
    <div class="error"><?php echo e($errors->first('password')); ?></div>
<?php endif; ?>
                        </div>
               
                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary">Add  Details</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
                  <div class="row">
                         <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <ul class="nav nav-pills nav-pills-success mb-3" role="tablist" style="
    display: block !important;">
                                        <li class="nav-item" role="presentation" style="
    display: block !important;">
                                            <a class="nav active" style="
    display: block !important;" data-bs-toggle="pill" href="#company-details" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center" style="width: 87%;
    display: block !important;">
                                                     
         <?php echo $__env->make('admin.includes.flashMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         
                                                </div>
                                            </a>
                                        </li>
                                        
                                 
                              
                                
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="company-details" role="tabpanel">
											
											<a href="<?php echo e(url()->previous()); ?>

" class="back"><i class="font-20 bx bxs-arrow-left"></i>
Back</a>
                            
                                            <table class="table table-bordered table-striped mt-5">
                                                <thead>
                                                  <tr>
                                                    <th width="30">SI No.</th>
                                                    <th>Unit ID</th>
                               <th>Contact Person Name</th>
													   <th>Designation</th>
													   <th> Email</th>
													     <th>Mobile  Number</th>
													 
													     <th>Unit Name</th>
													  <th>Unit Address</th>
                                                   
													
                                                   <th>User Type</th>
													  
                                                    <th width="80">Action</th>
                                                  </tr>
                                                </thead>
                                                <tbody>

<?php $i=1; ?>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <tr>
                                                    <td><?php echo e($i); ?></td>
													    <td><?php echo e($userss->login_id ?? ''); ?></td>
													     <td><?php echo e($userss->name ?? ''); ?></td>
                                                    <td><?php echo e($userss->designation ?? ''); ?></td>
													  
                                                    <td><?php echo e($userss->email ?? ''); ?></td>
													  <td><?php echo e($userss->mobile_number ?? ''); ?></td>
													  
													  
													     <td><?php echo e($userss->company_name ?? ''); ?></td>
													
                                                    <td><?php echo e($userss->Company_address ?? ''); ?></td>
                                                   
                                    <td>Unit</td>
       
													 
                                                 
                                                    
                                    
                                                    <td align="center">
                                                   
                                                     <a data-bs-toggle="modal" data-bs-target="#editcompanydetails<?php echo e($userss->id); ?>"> <i class="font-20 bx bxs-edit"></i></a>
                                                       <a href="<?php echo e(route('storeusers_delete',$userss->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="font-20 bx bxs-trash"></i></a>

                                                      </td>


                      <div class="modal fade" id="editcompanydetails<?php echo e($userss->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit  Unit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                         <form></form>
                        <form method="post" action="<?php echo e(route('edit_users')); ?>">
                            <?php echo csrf_field(); ?>
                    <div class="row">

                        <input type="hidden" name="id" value="<?php echo e($userss->id); ?>">
						
						        <div class="mb-3 col-md-6">
                            <label class="form-label">Unit ID:</label>
                            <input type="text" class="form-control"  name="login_id" placeholder="" value="<?php echo e($userss->login_id); ?>">
                            <?php if($errors->has('login_id')): ?>
    <div class="error"><?php echo e($errors->first('login_id')); ?></div>
<?php endif; ?>
                        </div>
						
						

         <div class="mb-3 col-md-6">
                            <label class="form-label">Select Corporate Name:</label>
				 
				 <input type="hidden" name="is_role" value="3">
									 
									 <select name="created_by" id="mySelect21" onchange="myFunction(this)" class="form-control" >
										 <option value="">Please Select Corporate </option>
										   <?php $unit_list = DB::table('users')->where('is_role', "2")->get(); ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 <option value="<?php echo e($unit_lists->id); ?>" <?php if($unit_lists->id == $userss->created_by ): ?> selected <?php endif; ?>><?php echo e($unit_lists->company_name); ?></option>
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									 </select>

                        </div>
						
						
						         <div class="mb-3 col-md-6">
                            <label class="form-label">Select Regional Name:</label>
				 
				 <input type="hidden" name="is_role" value="3">
									 
									 <select name="created_by1" id="mySelect22" class="form-control" >
										 <option value="">Please Select Corporate </option>
					 <?php $unit_list = DB::table('users')->where('is_role', "1")->where('created_by', $userss->created_by)->get(); ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 <option value="<?php echo e($unit_lists->id); ?>" <?php if($unit_lists->id == $userss->created_by1 ): ?> selected <?php endif; ?>><?php echo e($unit_lists->company_name); ?></option>
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									 </select>

                        </div>

            
                

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Unit Name:</label>
                            <input type="text" class="form-control"  name="company_name" placeholder="" value="<?php echo e($userss->company_name); ?>">
                            <?php if($errors->has('company_name')): ?>
    <div class="error"><?php echo e($errors->first('company_name')); ?></div>
<?php endif; ?>
                        </div>


                               <div class="mb-3 col-md-6">
                            <label class="form-label">Unit Address
:</label>
                            <input type="text" class="form-control"  name="Company_address" placeholder="" value="<?php echo e($userss->Company_address); ?>">
                            <?php if($errors->has('Company_address')): ?>
    <div class="error"><?php echo e($errors->first('Company_address')); ?></div>
<?php endif; ?>
                        </div>

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Contact Person Name:</label>
                            <input type="text" class="form-control"  name="name" placeholder="" value="<?php echo e($userss->name); ?>">
                            <?php if($errors->has('login_id')): ?>
    <div class="error"><?php echo e($errors->first('login_id')); ?></div>
<?php endif; ?>
                        </div>

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Designation:</label>
                            <input type="text" class="form-control"  name="designation" placeholder="" value="<?php echo e($userss->designation); ?>">
                            <?php if($errors->has('designation')): ?>
    <div class="error"><?php echo e($errors->first('designation')); ?></div>
<?php endif; ?>
                        </div>

                  

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Email </label>
                            <input type="email" name="email" class="form-control" placeholder="" value="<?php echo e($userss->email); ?>">
                            <?php if($errors->has('email')): ?>
    <div class="error"><?php echo e($errors->first('email')); ?></div>
<?php endif; ?>
                        </div>

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Mobile Number </label>
                            <input type="text" name="mobile_number" class="form-control" placeholder="" value="<?php echo e($userss->mobile_number); ?>">
                            <?php if($errors->has('mobile_number')): ?>
    <div class="error"><?php echo e($errors->first('mobile_number')); ?></div>
<?php endif; ?>
                        </div>

                       
               
                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary">Edit  Details</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
                                                  </tr>
<?php $i++; ?>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                                  
                                                </tbody>
                                              </table>
                                        </div>
                              
                                                
                                                    </div> 
                                                   </div>
                                                
                                                
                                                
                                            </div>
                                            

                                            
                                            
                                       </div>
                          
                         
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
       
                        
                    </div>

        
<?php $__env->stopSection(); ?>



 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

<?php if($errors->any()): ?>
<script>
    $(document).ready(function() {
    $('#addcompanydetails').modal('show');
});
     </script>
<?php endif; ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>

<script type="text/javascript">

function myFunction(sel) {
  var id = sel.value;

	        $.ajax({
           type:'GET',
           url:"<?php echo e(route('regional_list')); ?>",
           data:{id:id},
				dataType: "json",
           success:function(datalist){
          var data =  datalist.data;
					 $('#mySelect22').empty();
					           var selOpts = "";
            for (i=0;i<data.length;i++)
            {
                var id = data[i]['id'];
                var val = data[i]['company_name'];
                selOpts += "<option value='"+id+"'>"+val+"</option>";
            }
            $('#mySelect22').append(selOpts);
                    //alert(data.success);
                    //location.reload();
             
           }
        });
	
}
	
</script>

   
<?php echo $__env->make('layouts.app', ['pagetitle'=>'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/efsms.in/httpdocs/admin/resources/views/admin/users/units.blade.php ENDPATH**/ ?>