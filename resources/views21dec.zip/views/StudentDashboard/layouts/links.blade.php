<link rel="preload" href="{{asset('student_dashboard/assets/css/bootstrap.min.css')}}" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <link rel="stylesheet" type="text/css" href="{{asset('student_dashboard/assets/css/bootstrap.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('student_dashboard/assets/css/slick.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('student_dashboard/assets/css/slick-theme.css')}}">
<link rel="stylesheet" media="all" href="{{asset('student_dashboard/assets/css/style.css?fsdf')}}">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
