   @include('Admin.AddNewCategory.layouts.top')
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="space-add">
                        <h4 class="page-title">
                            <i class="mdi mdi-apple-keyboard-command title_icon"></i>
                            Categories
                        </h4>
                        <a href="{{url('/admin/add-new-category/category-add')}}" class="btn btn-outline-primary btn-rounded alignToTitle">
                            <i class="mdi mdi-plus"></i>Add new category
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container mt-4">
        <div class="row row-cols-1 row-cols-md-3 g-4">
            @if($categories)
            @foreach ($categories as $category)
            <div class="col">
                <div class="card h-100">
                    <?php $thumbnail = str_replace("public","storage",$category->thumbnail); ?>
                    <img src="{{asset($thumbnail)}}" class="card-img-top" alt="....">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas <?php echo $category->icon; ?>" style="font-size: 20px; color: #007bff;left:30px;margin-right:15px"></i>{{$category->category_title}}</h5>
                        <p class="card-text text-italic" style="margin-right: 30px">{{count($category->subcategories)}} Sub Categories</p>
                    </div>
                    <ul class="list-group list-group-flush">
                        @if($category->subcategories)
                        @foreach ($category->subcategories as $subcategory)
                        <li class="list-group-item"><i class="fas <?php echo $subcategory->sub_category_icon; ?>" style="font-size: 20px; color: #007bff;left:30px;margin-right:15px"></i>{{$subcategory->sub_category_title}}
                            <div class="edit-delete-buttons">
                                 <a href="{{url('admin/add-new-category/edit-sub-category',$subcategory->sub_category_id)}}"> <i class="fa-solid fa-pen-to-square"></i></a>
                                 <a href="{{url('admin/add-new-category/delete-sub-category',$subcategory->sub_category_id)}}"><i class="fa-solid fa-trash"></i></a>
                            </div>
                        </li>
                        @endforeach
                        @endif
                    </ul>
                    <div class="card-body d-flex justify-content-between">
                        <a href="{{url('admin/add-new-category/edit-main-category',$category->id)}}"><button class="btn btn-sm btn-primary btn-edit">Edit</button></a>
                            <a href="{{url('admin/add-new-category/delete-main-category',$category->id)}}"> <button class="btn btn-sm btn-danger btn-delete">Delete</button></a>
                    </div>
                </div>
            </div>
            @endforeach
            @endif
        </div>

    </div>
@include('Admin.AddNewCourse.layouts.bottom')
