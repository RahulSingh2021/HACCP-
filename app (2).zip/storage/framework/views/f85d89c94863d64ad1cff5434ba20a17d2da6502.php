        <footer class="page-footer">
            <p class="mb-0">Copyright © 2022. All right reserved.</p>
        </footer>

<?php /**PATH /var/www/vhosts/efsms.in/httpdocs/admin/resources/views/layouts/footer.blade.php ENDPATH**/ ?>