@extends('layouts.app2', ['pagetitle'=>'Dashboard'])
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- EXTERNAL LIBRARIES FOR PDF/EXCEL -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fuse.js@6.6.2/dist/fuse.min.js"></script>
    <meta name="csrf-token" content="{{ csrf_token() }}">

      <style>
      
      .page-wrapper {
    height: 100%;
    margin-top: 40px !important;
    margin-bottom: 30px;
    margin-left: 0px;
}

.page-content button.btn {
    background-color: auto !important;
    border: none;
}

.page-footer {
    background: #ffffff;
    left: 0px;
    right: 0;
    bottom: 0;
     position: relative !important; 
    text-align: center;
    padding: 7px;
    font-size: 14px;
    border-top: 1px solid #e4e4e4;
    z-index: 3;
}


button.btn {
     background: none !important; 
    border: none;
}

.btn:focus {
    outline: 0 !important; 
    box-shadow: 0 !important; 
}

        :root {
            --primary-color: #3a7bd5; --secondary-color: #e74c3c; --success-color: #28a745; --warning-color: #ffc107; --danger-color: #dc3545; --info-color: #17a2b8;
            --light-gray: #f8f9fa; --medium-gray: #ced4da; --dark-gray: #343a40; --text-muted: #6c757d; --border-color: #e0e0e0;
            --border-radius: 6px; --box-shadow: 0 4px 12px rgba(0,0,0,0.08); --transition: all 0.3s ease-in-out;
            --details-primary-light: #e0e7ff;
            --error-color: #e74c3c;
            /* Editor Pro Desktop Theme */
            --editor-bg: #525252;
            --editor-ruler-bg: #3a3a3a;
            --editor-ruler-marks: #888;
            --editor-checkerboard-light: #707070;
            --editor-checkerboard-dark: #5e5e5e;
            /* Editor Mobile Theme */
            --mobile-editor-bg: #1a1a1a;
            --mobile-toolbar-bg: #2b2b2b;
            --mobile-primary-text: #ffffff;
            --mobile-secondary-text: #a0a0a0;
            --mobile-finish-btn-bg: #007aff;
            --mobile-confirm-color: #34c759;
            --mobile-cancel-color: #ff3b30;
            /* Details Component Variables */
            --details-primary-color: #4361ee;
            --details-danger-color: #ef233c;
            --details-danger-light: #ffe0e3;
            --details-gray-100: #f8f9fa;
            --details-gray-200: #e9ecef;
            --details-gray-300: #dee2e6;
            --details-gray-500: #adb5bd;
            --details-gray-600: #6c757d;
            --details-gray-800: #343a40;
            --details-border-radius: 0.375rem;
            --details-box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --details-transition: all 0.2s ease-in-out;
        }
        /* --- REWORK: Layout for Scrollable Table --- */
        html, body {
            height: 100%;
            overflow: hidden; /* Prevent the whole page from scrolling */
        }
        .page-wrapper {
            height: 100%;
            padding: 1rem;
        }
        .page-content {
            height: 100%;
        }
        .card {
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .card-body {
            flex-grow: 1; /* Allow body to take up all available space */
            overflow-y: auto; /* Make the card body scrollable */
        }
        .table-report thead th { 
            position: sticky; /* Stick to the top of the scrolling container (.card-body) */
            top: 0;
            z-index: 10;
            background-color: #f8f9fa; 
        }
        /* --- END REWORK --- */

        body { font-family: 'Roboto', -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif; background-color: #f5f7fa; }
        .card { border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border: none; }
        
        .card-header { 
            background-color: #fff; 
            border-bottom: 1px solid var(--border-color);
        }
        .table-report thead th { 
            font-weight: 600; 
            color: var(--dark-gray); 
            border-bottom: 2px solid var(--border-color); 
            padding: 12px 16px; 
        }

        .table-report { font-size: 14px; border-collapse: separate; border-spacing: 0; min-width: 1400px; }
        .table-report tbody tr:hover { background-color: rgba(58,123,213,0.05); }
        .table-report td { padding: 12px 16px; vertical-align: middle; border-top: 1px solid var(--border-color); }
        .btn-icon { background: transparent; border: none; color: var(--text-muted); opacity: .6; transition: opacity .2s ease, color .2s ease; }
        .btn-icon:hover { opacity: 1; }
        .concern-details { display: flex; align-items: flex-start; }
        .concern-details .concern-title-wrapper { flex-grow: 1; }
        .concern-details .concern-title { font-weight: 500; color: var(--dark-gray); }
        .concern-title strong { color: var(--primary-color); font-weight: 700; }
        .concern-details .concern-id { font-size: 12px; font-weight: 600; color: var(--text-muted); margin-bottom: 8px; display: block; background-color: var(--light-gray); padding: 2px 6px; border-radius: 4px; display: inline-block; }
        .concern-details .concern-meta { display: flex; flex-wrap: wrap; gap: 8px 16px; font-size: 13px; color: var(--text-muted); }
        .concern-details .concern-meta span { display: flex; align-items: center; gap: 4px; }
        .concern-responsibility { font-size: 13px; color: var(--text-muted); margin-top: 8px; padding-top: 8px; border-top: 1px dashed var(--border-color); display: flex; align-items: center; gap: 6px; }
        .concern-responsibility strong { color: var(--dark-gray); }
        .risk-score-badge { padding: .2em .5em; border-radius: 4px; font-weight: 600; background-color: #e9ecef; color: #495057; }
        .image-cell { display: flex; gap: 12px; align-items: center; }
        .report-image-thumb { width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 1px solid #e9ecef; cursor: pointer; transition: transform .2s ease; }
        .report-image-thumb:hover { transform: scale(1.05); }
        .image-label { position: absolute; bottom: 6px; left: 6px; background-color: rgba(0,0,0,.7); color: #fff; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 600; }
        .after-photo-placeholder { width: 80px; height: 80px; border-radius: 8px; border: 2px dashed #adb5bd; background-color: #f8f9fa; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #adb5bd; }
        .status-badge { padding: .35em .65em; border-radius: 50px; font-size: 12px; font-weight: 600; }
        .status-open { background-color: rgba(220,53,69,.1); color: var(--danger-color); }
        .status-resolved { background-color: rgba(40,167,69,.1); color: var(--success-color); }
        .status-in-progress { background-color: rgba(23,162,184,.1); color: var(--info-color); }
        .status-scheduled { background-color: rgba(255,193,7,.1); color: #856404; }
        .status-verified { background-color: #0d6efd; color: white; }
        .status-not-applicable { background-color: #6c757d; color: white; }
        .status-follow-up-created { background-color: #e8dff5; color: #6a0dad; } /* New status style */
        .badge-breakdown { background-color: var(--details-danger-light); color: var(--danger-color); border: 1px solid var(--danger-color); }
        .action-btn-group, .action-btn-group-vertical { display: flex; flex-wrap: wrap; gap: 6px; }
        .action-btn { width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; }
        .progress-tracker { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
        .step { position: relative; flex: 1; text-align: center; }
        .step:not(:first-child)::before { content: ''; position: absolute; top: 12px; right: 50%; width: 100%; height: 2px; background-color: var(--border-color); z-index: 1; }
        .step-icon { position: relative; z-index: 2; width: 24px; height: 24px; border-radius: 50%; background-color: #fff; border: 2px solid var(--border-color); display: inline-flex; align-items: center; justify-content: center; font-size: 12px; margin-bottom: 8px; }
        .step-label { font-size: 12px; color: var(--text-muted); }
        .step-label strong { display: block; font-weight: 500; color: var(--dark-gray); }
        .step-label .step-time { font-size: 11px; }
        .step.is-completed .step-icon { background-color: var(--success-color); border-color: var(--success-color); color: #fff; }
        .step.is-completed::before { background-color: var(--success-color); }
        .step.is-completed .step-label { color: var(--dark-gray); }
        .step.is-scheduled .step-icon { background-color: var(--warning-color); border-color: var(--warning-color); color: #fff; }
        .step-label .scheduled-note { font-size: 11px; display: block; margin-top: 2px; color: #856404; font-weight: 600; }
        .time-since-reported { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
        .filter-list { list-style: none; padding-left: 0; max-height: 200px; overflow-y: auto; border: 1px solid #eee; border-radius: .375rem; padding: .5rem; font-size: 0.9rem; }
        .filter-list .form-check-label { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .dropdown-menu.p-3 { min-width: 280px; }
        .image-modal-body img, .image-modal-body video { max-width: 100%; max-height: 80vh; display: block; margin: auto; }
        .table-report thead th .fa-filter { font-size: 0.8em; }
        .table-report thead th .btn-icon { opacity: 0.4; } .table-report thead th:hover .btn-icon { opacity: 1; }
        .table-report thead th > .d-flex { gap: 8px; }
        @keyframes row-flash { 0%, 100% { background-color: inherit; } 50% { background-color: #fff3cd; } }
        .flash-reminder { animation: row-flash 1s ease-in-out; }
        .table-report td:first-child, .table-report th:first-child { text-align: center; }
        #bulkAcknowledgeBtn { font-weight: 500; }
        #offline-status-container { font-size: 0.9rem; }
        #connection-status-indicator.status-online { background-color: var(--success-color); }
        #connection-status-indicator.status-offline { background-color: var(--danger-color); }
        .table-report tbody tr.is-draft { background-color: #fffbe6; opacity: 0.9; }
        .table-report tbody tr.is-draft:hover { background-color: #fff9d9; opacity: 1; }
        .table-report tbody tr.is-breakdown { background-color: var(--details-danger-light) !important; }
        .status-draft { background-color: rgba(255,193,7,.1); color: #856404; }
        .media-upload-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.6); border-radius: 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; color: white; z-index: 5; transition: opacity 0.3s ease; opacity: 1; }
        .media-upload-overlay .spinner-border { width: 1.5rem; height: 1.5rem; }
        .upload-progress-text { font-size: 0.8rem; font-weight: 600; margin-top: 5px; }
        .media-upload-overlay.hidden { opacity: 0; pointer-events: none; }
        .media-upload-overlay.upload-error .spinner-border, .media-upload-overlay.upload-error .upload-progress-text { display: none; }
        .upload-error-icon { font-size: 1.5rem; color: var(--warning-color); display: none; }
        .media-upload-overlay.upload-error .upload-error-icon { display: block; }
        .upload-retry-btn { background: var(--primary-color); color: white; border: none; border-radius: 4px; padding: 2px 8px; font-size: 0.75rem; margin-top: 5px; cursor: pointer; display: none; }
        .media-upload-overlay.upload-error .upload-retry-btn { display: block; }
        .video-thumbnail-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.3); color: rgba(255, 255, 255, 0.85); display: flex; align-items: center; justify-content: center; font-size: 2rem; border-radius: 8px; pointer-events: none; transition: opacity 0.2s ease; z-index: 2; }
        .image-cell .position-relative:hover .video-thumbnail-overlay { opacity: 0; }
        .action-btn-group-mobile { display: none; }
        .btn-star { font-size: 1.1rem; color: var(--text-muted); opacity: 0.5; vertical-align: top; padding: 0 8px 0 0; line-height: 1; }
        .btn-star:hover { opacity: 1; }
        tr[data-starred="true"] .btn-star, .btn-star.is-starred { color: var(--warning-color); opacity: 1; }
        #followUpFilterBtn.active, #breakdownFilterBtn.active { background-color: var(--primary-color); color: #fff; border-color: var(--primary-color); }
        .is-editing { outline: 2px solid var(--primary-color); background-color: #f8f9fa; border-radius: 4px; padding: 4px; }
        
        #bulkUploadDropzone { 
            position: relative; 
            border: 2px dashed var(--medium-gray); 
            border-radius: var(--border-radius); 
            padding: 2rem; 
            text-align: center; 
            background-color: var(--light-gray);
            transition: all var(--transition); 
        }
        #bulkUploadDropzone.is-dragover { 
            background-color: var(--details-primary-light); 
            border-color: var(--primary-color);
            transform: scale(1.02);
        }
        #bulkUploadDropzone .dropzone-content {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            pointer-events: none;
        }
        #bulkUploadDropzone .dropzone-icon {
            font-size: 3.5rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        #bulkUploadDropzone h6 {
            font-weight: 600;
            color: var(--dark-gray);
        }
        #bulkUploadDropzone p {
            color: var(--text-muted);
            margin-bottom: 1.5rem;
        }
        #bulkUploadDropzone label { 
            position: absolute; top: 0; left: 0; width: 100%; height: 100%; 
            cursor: pointer; 
        }
        #bulkImageInput { 
            width: 0.1px; height: 0.1px; opacity: 0; overflow: hidden; position: absolute; z-index: -1; 
        }
        
        #bulkUploadPreviewArea { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 1rem; margin-top: 1.5rem; max-height: 40vh; overflow-y: auto; }
        .bulk-preview-card { position: relative; border: 1px solid var(--border-color); border-radius: var(--border-radius); overflow: hidden; }
        .bulk-preview-card img { width: 100%; height: 100px; object-fit: cover; }
        .bulk-preview-card .location-overlay { position: absolute; bottom: 0; left: 0; width: 100%; background: rgba(0,0,0,0.7); color: white; font-size: 0.75rem; padding: 4px 6px; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .bulk-preview-card .remove-bulk-image-btn { position: absolute; top: 4px; right: 4px; width: 20px; height: 20px; background: rgba(255, 255, 255, 0.8); border: 1px solid rgba(0,0,0,0.1); border-radius: 50%; color: var(--danger-color); font-weight: bold; line-height: 18px; text-align: center; cursor: pointer; }
        #bulkLocationList { max-height: 200px; overflow-y: auto; }
        #historyModalBody { background-color: #f4f7fa; padding: 20px; }
        .history-modal .report-container { width: 100%; max-width: 1200px; margin: 0 auto; background-color: #ffffff; border: 1px solid #e0e6ed; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); overflow: hidden; }
        .history-modal .report-timestamps { background-color: #f8f9fa; padding: 12px 20px; border-bottom: 1px solid #e0e6ed; display: flex; justify-content: space-between; font-size: 13px; color: #52616b; }
        .history-modal .report-header { display: flex; justify-content: space-between; align-items: flex-start; padding: 20px; gap: 20px; }
        .history-modal .evidence-section { display: flex; gap: 15px; }
        .history-modal .evidence-image-wrapper { width: 120px; height: 90px; border-radius: 6px; position: relative; cursor: pointer; overflow: hidden; border: 1px solid #e0e6ed; }
        .history-modal .evidence-image-wrapper img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s ease; }
        .history-modal .evidence-image-wrapper:hover img { transform: scale(1.1); }
        .history-modal .evidence-tag { position: absolute; bottom: 6px; left: 6px; background-color: rgba(0, 0, 0, 0.7); color: white; padding: 3px 6px; font-size: 11px; font-weight: 500; border-radius: 4px; }
        .history-modal .report-details { flex-grow: 1; padding: 0 15px; }
        .history-modal .report-details h2 { margin: 0 0 8px 0; font-size: 18px; font-weight: 600; color: #2c3e50; }
        .history-modal .report-details .meta-info { font-size: 14px; color: #52616b; margin-bottom: 8px; }
        .history-modal .risk { display: inline-block; background-color: #f1f3f5; padding: 4px 8px; border-radius: 4px; font-weight: 500; }
        .history-modal .header-right-panel { display: flex; align-items: flex-start; gap: 30px; }
        .history-modal .area-status { text-align: right; min-width: 180px; }
        .history-modal .area-status .area { font-size: 14px; line-height: 1.5; color: #52616b; }
        .history-modal .status { margin-top: 10px; }
        .history-modal .status-badge { display: inline-flex; align-items: center; color: white; padding: 5px 12px; border-radius: 15px; font-size: 12px; font-weight: 600; text-transform: uppercase; }
        .history-modal .status-badge.status-open { background-color: #e74c3c; }
        .history-modal .status-badge.status-closed { background-color: #2ecc71; }
        .history-modal .status-badge::before { content: ''; width: 8px; height: 8px; background-color: white; border-radius: 50%; margin-right: 6px; }
        .history-modal .time-ago { font-size: 12px; color: #8492a6; margin-top: 6px; display: block; }
        .history-modal .download-button { padding: 8px 16px; background-color: #3498db; color: white; text-decoration: none; border-radius: 5px; font-size: 14px; font-weight: 500; transition: background-color 0.2s, opacity 0.2s; white-space: nowrap; border: none; cursor: pointer; }
        .history-modal .download-button:hover { background-color: #2980b9; }
        .history-modal .download-button:disabled { background-color: #a9cce3; cursor: not-allowed; }
        .history-modal .report-table-wrapper { padding: 10px; }
        .history-modal .report-table { width: 100%; border-collapse: collapse; }
        .history-modal .report-table th, .history-modal .report-table td { padding: 16px; text-align: left; border-bottom: 1px solid #e0e6ed; vertical-align: top; }
        .history-modal .report-table tr:last-child td { border-bottom: none; }
        .history-modal .report-table th { background-color: #f8f9fa; color: #495057; font-size: 13px; font-weight: 600; text-transform: uppercase; }
        .history-modal .status-tag { display: inline-block; padding: 5px 12px; border-radius: 15px; font-weight: 500; font-size: 13px; }
        .history-modal .status-non-compliance { background-color: #fdf2e3; color: #da7c0c; border: 1px solid #fbe5c5; }
        .history-modal .status-in-progress { background-color: #e3f2fd; color: #1e88e5; border: 1px solid #bbdefb; }
        .history-modal .status-breakdown-update { background-color: #fff3e0; color: #e65100; border: 1px solid #ffe0b2; }
        .history-modal .status-not-applicable { background-color: #f1f3f5; color: #52616b; border: 1px solid #ced4da; }
        .history-modal .status-compliance-verified { background-color: var(--success-color); color: white; border: 1px solid #198754;}
        .history-modal .status-non-compliance-found { background-color: var(--danger-color); color: white; border: 1px solid #dc3545;}
        .history-modal .table-image { width: 80px; height: 60px; border-radius: 4px; object-fit: cover; cursor: pointer; transition: transform 0.3s ease; border: 1px solid #e0e6ed; }
        .history-modal .table-image:hover { transform: scale(1.05); }
        .history-modal .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.8); display: flex; justify-content: center; align-items: center; z-index: 1056; opacity: 0; visibility: hidden; transition: opacity 0.3s, visibility 0.3s; }
        .history-modal .modal-overlay.visible { opacity: 1; visibility: visible; }
        .history-modal .modal-content { position: relative; max-width: 90vw; max-height: 90vh; }
        .history-modal .modal-content img { display: block; max-width: 100%; max-height: 100%; border-radius: 8px; }
        .history-modal .modal-close { position: absolute; top: -30px; right: -20px; color: white; font-size: 30px; font-weight: bold; cursor: pointer; }
        .mobile-evidence-header { display: none; }
        .signature-pad { border: 1px solid var(--medium-gray); border-radius: var(--border-radius); background-color: #fff; cursor: crosshair; }

        /* --- Complaint Form Styles --- */
        #complaintFormModal .modal-body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.65;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            padding: 1.5rem;
            -webkit-tap-highlight-color: transparent;
        }
        #complaintFormModal .main-container { max-width: 800px; margin: 0 auto; }
        #complaintFormModal .details-container { background-color: white; padding: 1.5rem; border-radius: var(--border-radius); box-shadow: var(--box-shadow); position: relative; }
        #complaintFormModal .form-group { margin-bottom: 28px; position: relative; }
        #complaintFormModal .form-group:last-child { margin-bottom: 0; }
        #complaintFormModal label { display: block; margin-bottom: 8px; font-weight: 500; color: var(--primary-color); font-size: 0.95em; }
        #complaintFormModal .error-message { color: var(--error-color); font-size: 0.85em; margin-top: 6px; display: none; }
        #complaintFormModal .complaint-input-wrapper { display: flex; align-items: flex-start; gap: 1rem; border: 1px solid var(--details-gray-300); border-radius: var(--details-border-radius); padding: 0.75rem 1rem; transition: all 0.2s ease-in-out; }
        #complaintFormModal .complaint-input-wrapper:focus-within { border-color: var(--details-primary-color); box-shadow: 0 0 0 0.2rem rgba(67, 97, 238, 0.25); }
        #complaintFormModal .complaint-box { flex-grow: 1; display: flex; flex-direction: column; line-height: 1.8; min-height: 24px; }
        #complaintFormModal .complaint-box p { margin: 0; display: flex; flex-wrap: wrap; align-items: baseline; gap: 0.5rem; }
        #complaintFormModal #direct-upload-options-container { transition: opacity 0.3s ease, transform 0.3s ease, width 0.3s ease; flex-shrink: 0; }
        #complaintFormModal .complaint-input-wrapper.has-media #direct-upload-options-container { opacity: 0; width: 0; overflow: hidden; pointer-events: none; }
        #complaintFormModal .direct-upload-options { display: flex; gap: 10px; align-items: center; }
        #complaintFormModal .upload-option-direct { background: none; border: none; cursor: pointer; padding: 4px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--details-gray-600); transition: background-color 0.2s ease; }
        #complaintFormModal .upload-option-direct:hover { background-color: var(--details-gray-200); }
        #complaintFormModal .upload-option-direct svg { width: 22px; height: 22px; fill: currentColor; }
        #complaintFormModal .image-collage-preview { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--details-gray-200); align-items: flex-start; }
        #complaintFormModal .add-more-options-wrapper { grid-column: 1 / -1; display: flex; justify-content: center; gap: 15px; padding-top: 10px; border-top: 1px solid var(--light-gray); margin-top: 10px; }
        #complaintFormModal .preview-item { position: relative; width: 100%; height: 100px; border: 1px solid var(--medium-gray); border-radius: var(--border-radius); overflow: hidden; background-color: #f8f9fa; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; justify-content: center; align-items: center; cursor: pointer; }
        #complaintFormModal .preview-item img, .preview-item video { max-width: 100%; max-height: 100%; width: auto; height: auto; object-fit: contain; display: block; }
        #complaintFormModal .preview-item-controls { position: absolute; top: 0; right: 0; padding: 4px; display: flex; gap: 4px; z-index: 2; background: linear-gradient(to bottom left, rgba(0,0,0,0.2), transparent 80%); border-top-right-radius: var(--border-radius); }
        #complaintFormModal .remove-preview-btn, #complaintFormModal .edit-preview-btn, #complaintFormModal .enlarge-preview-btn { background-color: rgba(255, 255, 255, 0.8); color: var(--primary-color); border: 1px solid rgba(0,0,0,0.1); border-radius: 50%; width: 22px; height: 22px; font-size: 12px; font-weight: bold; line-height: 22px; text-align: center; cursor: pointer; padding: 0; transition: all 0.2s ease; box-shadow: 0 1px 2px rgba(0,0,0,0.1); }
        #complaintFormModal .remove-preview-btn:hover { background-color: var(--secondary-color); color: white; }
        #complaintFormModal .edit-preview-btn { font-size: 10px; }
        #complaintFormModal .enlarge-preview-btn { font-size: 14px; }
        #complaintFormModal .edit-preview-btn:hover, #complaintFormModal .enlarge-preview-btn:hover { background-color: var(--accent-color); color: white; }
        #complaintFormModal .pdf-placeholder { width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; font-size: 0.8em; padding: 8px; text-align: center; box-sizing: border-box; word-break: break-word; color: var(--fixed-text-color); }
        #complaintFormModal .pdf-placeholder svg { width: 30px; height: 30px; margin-bottom: 5px; fill: currentColor; }
        #complaintFormModal .video-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.2); display: flex; align-items: center; justify-content: center; pointer-events: none; }
        #complaintFormModal .video-overlay svg { width: 40px; height: 40px; fill: rgba(255,255,255,0.8); }
        #complaintFormModal .preview-item:hover .video-overlay { opacity: 0; }
        #image-preview-modal { display: none; position: fixed; z-index: 1060; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.85); justify-content: center; align-items: center; animation: fadeIn 0.3s; }
        #image-preview-modal .modal-content { position: relative; display: flex; justify-content: center; align-items: center; max-width: 90vw; max-height: 90vh; }
        #image-preview-modal img, #image-preview-modal video { max-width: 100%; max-height: 100%; border-radius: var(--border-radius); box-shadow: 0 10px 30px rgba(0,0,0,0.4); }
        #image-preview-modal .close-preview { position: absolute; top: 10px; right: 10px; z-index: 10; color: #fff; font-size: 35px; font-weight: bold; cursor: pointer; background-color: rgba(0, 0, 0, 0.6); border-radius: 50%; width: 35px; height: 35px; line-height: 35px; text-align: center; transition: var(--transition); text-shadow: 0 1px 2px rgba(0,0,0,0.5); }
        #image-preview-modal .close-preview:hover { transform: scale(1.1); color: var(--secondary-color); }
        .confirmation-dialog, .upload-choice-modal, .image-editor-modal, .collage-maker-container, .video-recorder-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6); z-index: 1056; justify-content: center; align-items: center; padding: 20px; box-sizing: border-box; }
        .confirmation-content, .upload-choice-content, .image-editor-content, .collage-maker-content, .video-recorder-content { background-color: white; border-radius: var(--border-radius); box-shadow: 0 8px 25px rgba(0,0,0,0.15); display: flex; flex-direction: column; overflow: hidden; }
        #upload-choice-modal { display: none !important; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes scaleUp { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        @keyframes slideUp { from { transform: translateY(100%); } to { translateY(0); } }
        .video-recorder-content { max-width: 640px; width: 100%; padding: 20px; }
        #video-preview { width: 100%; max-height: 480px; background: #000; border-radius: var(--border-radius); margin-bottom: 15px; }
        .video-controls { display: flex; justify-content: center; gap: 10px; align-items: center; }
        .video-controls button { padding: 10px 20px; border-radius: var(--border-radius); cursor: pointer; font-weight: 500; border: 1px solid var(--medium-gray); }
        #stop-record-btn { background-color: var(--secondary-color); color: white; border-color: var(--secondary-color); }
        .recording-indicator { font-size: 0.9em; color: var(--secondary-color); display: none; }
        .recording-indicator::before { content: '●'; margin-right: 5px; animation: pulse 1.5s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
        /* --- Styles for other modals from complaint form --- */
        .collage-maker-content { width: 100%; max-width: 800px; max-height: 90vh; }
        .collage-maker-header { padding: 15px 20px; background-color: var(--primary-color); color: white; display: flex; justify-content: space-between; align-items: center; }
        .image-editor-content { max-width: 90vw; width: 100%; min-height: 500px; max-height: 90vh; background-color: #333; }
        .image-editor-header { padding: 12px 20px; background-color: #333; border-bottom: 1px solid #444; color: white; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; }
        /* Additional specific styles from the complaint form are numerous and are included below for brevity */
        .details-container .form-group-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; flex-wrap: wrap; gap: 10px;}
        .details-container .form-label { display: block; font-weight: 600; margin-bottom: 0; font-size: 1rem; color: var(--details-gray-800); }
        .details-container .form-label .required-star { color: var(--details-danger-color); }
        #complaint-sentence-template { opacity: 0; transition: opacity 0.4s ease; display: none; }
        .complaint-input-wrapper.is-typing #complaint-sentence-template { opacity: 1; display: inline; }
        .details-container .inline-input { border: none; background-color: transparent; font-family: inherit; font-size: inherit; padding: 0; min-width: 150px; color: var(--details-gray-800); display: inline-block; width: auto; }
        .details-container .inline-input:focus { outline: none; }
        .details-container .inline-input[contenteditable]:empty::before { content: attr(data-placeholder); color: var(--details-gray-500); pointer-events: none; }
        .details-container .highlight { background-color: var(--details-primary-light); border-radius: 0.25rem; font-weight: 500; padding: 0 0.125rem; transition: background-color var(--details-transition); cursor: pointer; }
        .details-container .misspelled { border-bottom: 2px dotted var(--details-danger-color); cursor: pointer; text-decoration: none; background-color: var(--details-danger-light); border-radius: 0.25rem; padding: 0 0.125rem; transition: all var(--details-transition); }
        .details-container .optional-details-section { margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--details-gray-200); }
        .details-container .optional-details-section h4 { margin-top: 0; margin-bottom: 0; font-size: 1rem; font-weight: 600; color: var(--details-gray-800); }
        .details-container .optional-selectors-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
        .details-container .optional-selector-item > label { display: block; font-size: 0.9rem; font-weight: 500; color: var(--details-gray-700); margin-bottom: 0.25rem; }
        .details-container .multi-select-wrapper { position: relative; display: inline-flex; vertical-align: baseline; align-items: baseline; gap: 0.25rem; }
        .details-container .complaint-box .multi-select-wrapper { width: auto; }
        .details-container .optional-selector-item .multi-select-wrapper { width: 100%; }
        .details-container .pills-container { display: flex; flex-wrap: wrap; gap: 0.5rem; align-items: center; width: 100%; min-height: 38px; padding: 0.375rem 0.5rem; cursor: pointer; border: 1px solid var(--details-gray-300); border-radius: var(--details-border-radius); background-color: white; box-sizing: border-box; }
        .details-container .pills-container.inline { display: inline-flex; align-items: center; gap: 0.35rem; padding: 2px 4px; border-radius: 4px; border-bottom: 1px solid transparent; transition: background-color 0.2s; min-height: initial; width: auto; vertical-align: middle; background-color: var(--details-gray-100); border: 1px solid var(--details-gray-300); }
        .details-container .pills-container.inline:hover { background-color: var(--details-gray-200); border-color: var(--details-gray-400); }
        .details-container .pills-placeholder-text { color: var(--details-primary-color); font-weight: 500; }
        .pills-placeholder-add-icon, .pill-add-button { display: inline-flex; align-items: center; justify-content: center; width: 1.25em; height: 1.25em; background-color: var(--details-primary-color); color: white; border-radius: 50%; flex-shrink: 0; border: none; cursor: pointer; font-size: 1em; line-height: 1; }
        .pill-add-button { margin-left: 0.35rem; }
        .pills-placeholder-add-icon svg, .pill-add-button svg { width: 0.9em; height: 0.9em; fill: currentColor; }
        .details-container .pills-placeholder { display: flex; align-items: center; gap: 0.35rem; color: var(--details-gray-600); }
        .details-container .pills-placeholder > svg { flex-shrink: 0; }
        .details-container .pill { background-color: var(--details-primary-light); border-radius: 99px; padding: 0.2rem 0.6rem; font-size: 0.9em; display: flex; align-items: center; gap: 0.3rem; color: var(--details-primary-color); font-weight: 500; white-space: nowrap; }
        .details-container .pill .deselect-pill { cursor: pointer; font-weight: bold; font-size: 1.1em; line-height: 1; opacity: 0.6; }
        .details-container .pill .deselect-pill:hover { opacity: 1; }
        .details-container .pills-container.inline .pill { background-color: transparent; padding: 0; border-radius: 0; border-bottom: 1px dotted var(--details-primary-color); }
        .details-container .multi-select-dropdown { display: none; position: absolute; background-color: white; border: 1px solid var(--details-gray-300); border-radius: var(--details-border-radius); box-shadow: var(--details-box-shadow); z-index: 1055; min-width: 250px; max-height: 300px; display: none; flex-direction: column; margin-top: 0.25rem; }
        .details-container .multi-select-dropdown.active { display: flex; }
        .details-container .multi-select-search { padding: 0.5rem; border: none; border-bottom: 1px solid var(--details-gray-200); outline: none; }
        .details-container .multi-select-list-container { overflow-y: auto; flex-grow: 1; }
        .details-container .multi-select-item { display: flex; align-items: center; padding: 0.5rem 0.75rem; cursor: pointer; transition: background-color 0.2s ease; }
        .details-container .multi-select-item.selected { background-color: var(--details-primary-light); font-weight: 500; }
        .details-container .multi-select-item:hover { background-color: var(--details-gray-200); }
        .details-container .multi-select-item label { margin-left: 0.5rem; cursor: pointer; flex-grow: 1; }
        .details-container .multi-select-item input[type="checkbox"] { appearance: none; -webkit-appearance: none; position: relative; width: 18px; height: 18px; border-radius: 4px; border: 2px solid var(--details-gray-400); cursor: pointer; flex-shrink: 0; transition: all 0.2s ease; }
        .details-container .multi-select-item input[type="checkbox"]:checked { background-color: var(--details-primary-color); border-color: var(--details-primary-color); }
        .details-container .multi-select-item input[type="checkbox"]::after { content: ''; position: absolute; top: 1px; left: 5px; width: 5px; height: 10px; border: solid white; border-width: 0 2px 2px 0; transform: rotate(45deg); opacity: 0; transition: opacity 0.2s ease; }
        .details-container .multi-select-item input[type="checkbox"]:checked::after { opacity: 1; }
        .details-container .multi-select-item.add-new-trigger { color: var(--details-primary-color); font-weight: 500; }
        .details-container .multi-select-item.add-new-trigger svg { width: 16px; height: 16px; stroke: currentColor; stroke-width: 2; }
        .details-container .multi-select-add-new { display: flex; padding: 0.5rem; border-top: 1px solid var(--details-gray-200); }
        .details-container .multi-select-add-input { flex-grow: 1; border: 1px solid var(--details-gray-300); border-right: none; border-radius: var(--details-border-radius) 0 0 var(--details-border-radius); padding: 0.3rem; outline: none; }
        .details-container .multi-select-add-btn { background-color: var(--details-primary-color); color: white; border: none; border-radius: 0 var(--details-border-radius) var(--details-border-radius) 0; padding: 0 0.5rem; cursor: pointer; display: flex; align-items: center; justify-content: center; }
        #complaintFormModal .submit-button { display: block; width: 100%; padding: 0.875rem; background-color: var(--details-primary-color); color: white; border: none; border-radius: var(--details-border-radius); cursor: pointer; font-weight: 600; font-size: 1.1rem; margin-top: 1.5rem; transition: background-color var(--details-transition); }
        #complaintFormModal .submit-button:hover { background-color: #3f37c9; }
        #complaintFormModal #modelStatus { font-size: 0.8rem; color: var(--details-gray-600); margin-top: 0.75rem; }
        
        .alert-ticker { display: none; padding: 8px; color: white; font-size: 0.9rem; font-weight: 500; overflow: hidden; white-space: nowrap; }
        .alert-ticker.observation { background-color: var(--primary-color); }
        .alert-ticker.breakdown { background-color: var(--danger-color); }
        .alert-ticker.verification { background-color: var(--warning-color); color: #212529; }
        .ticker-wrap { display: flex; align-items: center; }
        .ticker-content { display: inline-block; padding-left: 100%; animation: marquee 20s linear infinite; }
        .ticker-content i { margin-right: 10px; }
        .ticker-close { background: none; border: none; color: white; font-size: 1.5rem; font-weight: bold; line-height: 1; opacity: 0.8; cursor: pointer; margin-left: auto; padding: 0 15px; }
        .ticker-close:hover { opacity: 1; }
        .verification .ticker-close { color: #212529; }
        @keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-100%); } }
        /* --- END REWORK --- */

        #toast-container { position: fixed; top: 20px; right: 20px; z-index: 1060; display: flex; flex-direction: column; gap: 10px; }
        .toast-notification { padding: 15px 20px; border-radius: var(--border-radius); color: white; background-color: var(--success-color); box-shadow: var(--box-shadow); opacity: 0; animation: toast-fade-in 0.5s forwards, toast-fade-out 0.5s 4.5s forwards; font-weight: 500; }
        @keyframes toast-fade-in { from { opacity: 0; transform: translateX(100%); } to { opacity: 1; transform: translateX(0); } }
        @keyframes toast-fade-out { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(100%); } }
        
        .breakdown-history-table {
            font-size: 0.85rem;
        }
        .breakdown-history-table thead {
            position: sticky;
            top: 0;
            z-index: 2;
        }

        .mobile-card-view {
            display: none;
        }
        
        /* --- MOBILE CARD STYLES --- */
        .complaint-card-mobile {
            --card-bg: #ffffff;
            --primary-text: #333333;
            --secondary-text: #6c757d;
            --border-color: #e9ecef;
            --orange: #f0ad4e;
            --green: #28a745;
            --grey: #ced4da;
            --blue: #007bff;
            --danger: #dc3545;
            --light-grey-bg: #f8f9fa;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --border-radius: 12px;
            font-family: 'Poppins', sans-serif;
            background-color: var(--card-bg);
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            max-width: 450px;
            width: 100%;
            padding: 1.5rem;
            box-sizing: border-box;
            margin: 0 auto;
            border: 2px solid transparent;
        }

        .card-border-1 {
            border-image: linear-gradient(to top right, #3a7bd5, #00d2ff) 1;
        }
        .card-border-2 {
            border: 2px dashed var(--danger-color);
        }
        .card-border-3 {
            border-image: linear-gradient(to top right, #ff416c, #ff4b2b) 1;
        }
        .card-border-4 {
            border: 2px solid var(--success-color);
            border-radius: 20px;
        }
        
        .complaint-card-mobile .section-title {
            font-weight: 600;
            color: var(--primary-text);
            margin-bottom: 1rem;
            font-size: 1.1rem;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.5rem;
        }

        .complaint-card-mobile .escalation-matrix {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 1.5rem;
        }
        
        .complaint-card-mobile .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }

        .complaint-card-mobile .details-grid .detail-item.full-width {
            grid-column: 1 / -1;
        }
        
        .complaint-card-mobile .detail-item .label {
            color: var(--secondary-text);
            display: block;
            margin-bottom: 0.25rem;
            font-weight: 400;
        }

        .complaint-card-mobile .detail-item .value {
            color: var(--primary-text);
            font-weight: 600;
        }

        .complaint-card-mobile .detail-item .time-since-reported {
            font-size: 0.8rem;
            font-weight: 400;
            display: block;
            margin-top: 2px;
        }
        
        .complaint-card-mobile .comment-section {
            margin-bottom: 1.5rem;
        }
        
        .complaint-card-mobile .comment-section .label {
            color: var(--secondary-text);
            font-weight: 400;
            font-size: 0.9rem;
            margin-bottom: 0.3rem;
        }
        
        .complaint-card-mobile .comment-section .value {
            color: var(--primary-text);
            font-weight: 500;
            font-size: 0.95rem;
            line-height: 1.5;
        }

        .complaint-card-mobile .collapsible-details {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.5s ease-in-out, opacity 0.3s ease-in-out;
            opacity: 0;
            visibility: hidden;
        }

        .complaint-card-mobile.is-expanded .collapsible-details {
            max-height: 1500px;
            opacity: 1;
            visibility: visible;
        }

        .card-expander .expand-toggle-btn {
            border-radius: 50px;
            padding: 5px 15px;
            font-weight: 500;
            width: 150px;
        }

        .card-expander .expand-toggle-btn .fa-chevron-up {
            transform: rotate(180deg);
        }

        .card-expander .expand-toggle-btn i {
            transition: transform 0.3s ease;
        }

        /* --- Responsive Styles --- */
        @media (min-width: 992.02px) {
            .mobile-card-view { display: none !important; }
        }

        @media (max-width: 992px) {
            .desktop-view { display: none !important; }
            .mobile-card-view { display: block !important; }

            .card-header h5 { display: none; }
            .table-report { min-width: 100%; border-spacing: 0; border-collapse: collapse; }
            .table-report thead { display: none; }
            
            .table-report tbody tr {
                display: block;
                border: none;
                background-color: transparent;
                padding: 0;
                margin-bottom: 1.5rem;
                box-shadow: none;
            }
             .table-report td {
                 display: block;
                 border: none;
                 padding: 0;
             }
           
            /* Responsive History Modal */
            .history-modal .report-header { flex-direction: column; align-items: stretch; gap: 1rem; }
            .history-modal .evidence-section { justify-content: center; }
            .history-modal .header-right-panel { flex-direction: row; justify-content: space-between; align-items: center; margin-top: 1rem; }
            .history-modal .area-status { text-align: left; }
            .history-modal .report-table thead { display: none; }
            .history-modal .report-table tbody tr { display: block; margin-bottom: 1rem; padding: 1rem; border: 1px solid var(--border-color); border-radius: var(--border-radius); }
            .history-modal .report-table td { display: flex; justify-content: space-between; text-align: right; padding: .5rem 0; border: none; }
            .history-modal .report-table tr td:last-child { border-bottom: none; }
            .history-modal .report-table td > * { max-width: 60%; }
            .history-modal .report-table td::before { content: attr(data-label); font-weight: bold; text-align: left; margin-right: 1rem; }
            /* Complaint Form Responsive */
            #complaintFormModal .modal-body { padding: 0.75rem; }
            #complaintFormModal .image-collage-preview { grid-template-columns: repeat(3, 1fr); }
            .optional-details-toggle-wrapper > h4 { cursor: pointer; display: flex; justify-content: space-between; align-items: center; }
            .optional-toggle-icon { transition: transform 0.2s ease-in-out; }
            .optional-details-toggle-wrapper:not(.is-expanded) .optional-selectors-grid { display: none; }
            .optional-details-toggle-wrapper.is-expanded .optional-selectors-grid { margin-top: 1rem; }
            .optional-details-toggle-wrapper.is-expanded .optional-toggle-icon { transform: rotate(180deg); }
            body.modal-open::after { content: ''; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); z-index: 1051; }
            .details-container .multi-select-dropdown { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 90vw; max-width: 400px; box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15); }
        
            #bulkUploadModal .modal-dialog {
                max-width: 100%;
                margin: 0;
            }
            #bulkUploadModal .modal-content {
                height: 100vh;
                border-radius: 0;
                border: none;
            }
             #bulkUploadModal .modal-body {
                overflow-y: auto;
            }
        }
        
        button#bulkAcknowledgeBtn {
    border: 0px;
}   
button#newReportBtn {
    border: 0px;
}
button#exportExcelBtn {
    border: 0px;
}

button.btn-sm.btn-info.text-white {
    border: 0px;
}
    </style>

@section('content')

    <div id="toast-container"></div>

    <div class="page-wrapper">
        <div class="page-content">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <h5 class="mb-0">Report Management</h5>
                        <div class="d-flex gap-2 align-items-center flex-wrap">
                            <div id="offline-status-container" class="d-flex align-items-center gap-2 me-2">
                               <span id="connection-status-indicator" class="badge rounded-pill"></span>
                               <span id="connection-status-text" class="d-none d-sm-inline small fw-bold"></span>
                            </div>
                            <button class="btn-sm btn-outline-primary d-lg-none" id="mobileFilterBtn" data-bs-toggle="modal" data-bs-target="#filterModal">
                                <i class="fas fa-filter me-1"></i> Filter
                            </button>
                            <button class="btn-sm btn-outline-secondary" id="followUpFilterBtn" style="background: auto !important;">
                                <i class="fas fa-star me-1 me-sm-2"></i>
                                <span class="d-none d-sm-inline">Follow Up</span>
                            </button>
                            <button class="btn-sm btn-outline-danger" id="breakdownFilterBtn">
                                <i class="fas fa-exclamation-triangle me-1 me-sm-2"></i>
                                <span class="d-none d-sm-inline">Breakdown</span>
                            </button>
                            <button class="btn-sm btn-outline-secondary" id="refreshBtn">
                                <i class="fas fa-sync-alt me-1 me-sm-2"></i>
                                <span class="d-none d-sm-inline">Refresh</span>
                            </button>
                            <button class="btn-sm btn-warning" id="bulkAcknowledgeBtn" style="display: none;">
                                <i class="fas fa-check-double me-1 me-sm-2"></i>
                                <span class="d-none d-sm-inline">Acknowledge (<span id="selectedCount">0</span>)</span>
                            </button>
                            <button class="btn-sm btn-info text-white" data-bs-toggle="modal" data-bs-target="#bulkUploadModal">
                                <i class="fas fa-images me-1 me-sm-2"></i>
                                <span class="d-none d-sm-inline">Bulk Upload</span>
                            </button>
                            <button class="btn-sm btn-primary" id="newReportBtn" >
                                <a style="color: #fff;" class="d-none d-sm-inline" href="https://efsm.safefoodmitra.com/admin/public/index.php/inspection/bulkupload"><i class="fas fa-plus me-1 me-sm-2"></i>New Report</a>
                                <span ></span>
                            </button>
                            
                                <button class="btn-sm btn-primary" id="newReportBtn1" >
                                <span > <i class="fas fa-plus me-1 me-sm-2"></i>New Report</span>
                            </button>
                            
                            
                            <button class="btn-sm btn-success" id="exportExcelBtn">
                                <i class="fas fa-file-excel me-1 me-sm-2"></i>
                                <span class="d-none d-sm-inline">Export to Excel</span>
                            </button>
                        </div>
                    </div>
                    <!-- Alert Ticker Container -->
                    <div id="alert-container" class="mt-2">
                        <div id="observation-ticker" class="alert-ticker observation">
                            <div class="ticker-wrap"><div class="ticker-content"></div><button class="ticker-close">&times;</button></div>
                        </div>
                        <div id="breakdown-ticker" class="alert-ticker breakdown">
                             <div class="ticker-wrap"><div class="ticker-content"></div><button class="ticker-close">&times;</button></div>
                        </div>
                        <div id="verification-ticker" class="alert-ticker verification">
                             <div class="ticker-wrap"><div class="ticker-content"></div><button class="ticker-close">&times;</button></div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-report" id="incidentReportTable">
                             <thead>
                                <tr>
                                    <th width="40"><input class="form-check-input" type="checkbox" id="selectAllCheckbox" title="Select all"></th>
                                    <th width="180">Evidence</th>
                                    <th width="450">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span>Report Details</span>
                                            <div class="dropdown d-none d-lg-block">
                                                <button class="btn btn-sm btn-icon" type="button" id="detailsFilterBtn" data-bs-toggle="dropdown" data-bs-strategy="fixed" aria-expanded="false" data-bs-auto-close="outside" title="Filter Details">
                                                    <i class="fas fa-filter"></i>
                                                </button>
                                                <div class="dropdown-menu p-3" aria-labelledby="detailsFilterBtn" style="min-width: 300px;">
                                                    <div class="mb-2">
                                                        <label class="form-label small fw-bold">SOP Name</label>
                                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search SOPs..." id="sopSearchInput">
                                                        <div id="sopFilterList" class="filter-list"></div>
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label small fw-bold">Risk</label>
                                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search Risks..." id="riskSearchInput">
                                                        <div id="riskFilterList" class="filter-list"></div>
                                                    </div>
                                                    <div>
                                                        <label class="form-label small fw-bold">Responsibility</label>
                                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="responsibilitySearchInput">
                                                        <div id="responsibilityFilterList" class="filter-list"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <th width="250">Closure Comments</th>
                                    <th width="220">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span>Area</span>
                                            <div class="dropdown d-none d-lg-block">
                                                <button class="btn btn-sm btn-icon" type="button" id="areaFilterBtn" data-bs-toggle="dropdown" data-bs-strategy="fixed" aria-expanded="false" data-bs-auto-close="outside" title="Filter Area">
                                                    <i class="fas fa-filter"></i>
                                                </button>
                                                <div class="dropdown-menu p-3" aria-labelledby="areaFilterBtn" style="min-width: 300px;">
                                                    <div class="mb-2">
                                                        <label class="form-label small fw-bold">Regional</label>
                                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="regionSearchInput">
                                                        <div id="regionFilterList" class="filter-list"></div>
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label small fw-bold">Unit</label>
                                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="unitSearchInput">
                                                        <div id="unitFilterList" class="filter-list"></div>
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label small fw-bold">Department</label>
                                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="departmentSearchInput">
                                                        <div id="departmentFilterList" class="filter-list"></div>
                                                    </div>
                                                    <div>
                                                        <label class="form-label small fw-bold">Location</label>
                                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="locationSearchInput">
                                                        <div id="locationFilterList" class="filter-list"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <th width="180">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span>Status</span>
                                             <div class="dropdown d-none d-lg-block">
                                                <button class="btn btn-sm btn-icon" type="button" id="statusFilterBtn" data-bs-toggle="dropdown" data-bs-strategy="fixed" aria-expanded="false" data-bs-auto-close="outside" title="Filter Status">
                                                    <i class="fas fa-filter"></i>
                                                </button>
                                                <div class="dropdown-menu p-3" aria-labelledby="statusFilterBtn">
                                                    <input type="search" class="form-control form-control-sm mb-2" placeholder="Search..." id="statusSearchInput">
                                                    <div id="statusFilterList" class="filter-list" style="max-height: 150px;"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <th width="450">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span>Tracking Status</span>
                                            <div class="dropdown d-none d-lg-block">
                                                <button class="btn btn-sm btn-icon" type="button" id="trackingFilterBtn" data-bs-toggle="dropdown" data-bs-strategy="fixed" aria-expanded="false" data-bs-auto-close="outside" title="Filter Tracking Status">
                                                    <i class="fas fa-filter"></i>
                                                </button>
                                                <div class="dropdown-menu p-3" aria-labelledby="trackingFilterBtn" style="min-width: 320px;">
                                                    <div class="mb-3">
                                                        <label class="form-label small fw-bold">By Reporting Date</label>
                                                        <div class="input-group input-group-sm mb-1">
                                                            <span class="input-group-text">From</span>
                                                            <input type="date" class="form-control" id="reportingDateFrom">
                                                        </div>
                                                        <div class="input-group input-group-sm">
                                                            <span class="input-group-text">To</span>
                                                            <input type="date" class="form-control" id="reportingDateTo">
                                                        </div>
                                                    </div>
                                                     <div class="mb-3">
                                                        <label class="form-label small fw-bold">By Closure Date</label>
                                                        <div class="input-group input-group-sm mb-1">
                                                            <span class="input-group-text">From</span>
                                                            <input type="date" class="form-control" id="closureDateFrom">
                                                        </div>
                                                        <div class="input-group input-group-sm">
                                                            <span class="input-group-text">To</span>
                                                            <input type="date" class="form-control" id="closureDateTo">
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <label class="form-label small fw-bold">By Timeline Stage</label>
                                                        <div id="timelineStageFilterList">
                                                             <div class="form-check"><input class="form-check-input" type="checkbox" value="owner" id="pendingOwnerAck"><label class="form-check-label" for="pendingOwnerAck">Pending Owner Ack</label></div>
                                                             <div class="form-check"><input class="form-check-input" type="checkbox" value="assignment" id="pendingAssignment"><label class="form-check-label" for="pendingAssignment">Pending Assignment</label></div>
                                                             <div class="form-check"><input class="form-check-input" type="checkbox" value="staff" id="pendingStaffAck"><label class="form-check-label" for="pendingStaffAck">Pending Staff Ack</label></div>
                                                             <div class="form-check"><input class="form-check-input" type="checkbox" value="completion" id="pendingCompletion"><label class="form-check-label" for="pendingCompletion">Pending Completion</label></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </th>
                                    <th width="200">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Rows will be dynamically injected by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div id="paginationInfo" class="text-muted small"></div>
                    <div class="d-flex align-items-center">
                        <select class="form-select form-select-sm me-3" id="itemsPerPageSelect" style="width: auto;"><option value="3" selected>3 per page</option><option value="5">5 per page</option><option value="10">10 per page</option><option value="25">25 per page</option></select>
                        <nav aria-label="Page navigation"><ul class="pagination pagination-sm mb-0" id="paginationControls"></ul></nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- HTML TEMPLATE FOR TABLE ROW -->
    <template id="report-row-template">
        <tr data-incident-id="" data-reported-time="" data-sop="" data-risk="" data-region="" data-unit="" data-department="" data-location="" data-status="" data-registered-by="">
            <!-- DESKTOP VIEW CELLS -->
            <td class="desktop-view" data-label="Select">
                <!-- Checkbox will be added by JS if needed -->
            </td>
            <td class="desktop-view" data-label="Evidence">
                <div class="image-cell">
                    <!-- Image thumbnails will be injected here -->
                </div>
            </td>
            <td class="desktop-view concern-details" data-label="Report Details">
                <button class="btn btn-icon btn-star" title="Mark for follow-up"><i class="far fa-star"></i></button>
                <div class="concern-title-wrapper">
                    <div class="concern-id"></div>
                    <div class="concern-title"></div>
                    <div class="concern-meta"></div>
                    <div class="concern-responsibility"></div>
                </div>
            </td>
            <td class="desktop-view" data-label="Closure Comments"><span class="closure-comments-cell">---</span></td>
            <td class="desktop-view" data-label="Area"><span></span></td>
            <td class="desktop-view" data-label="Status"><div><span class="status-badge"></span><div class="time-since-reported"></div></div></td>
            <td class="desktop-view" data-label="Tracking Status"><div class="progress-tracker"></div></td>
            <td class="desktop-view" data-label="Actions">
                <div class="action-btn-group">
                    <button class="action-btn btn-compliance" title="Mark as Compliance"><i class="fas fa-check-circle text-success"></i></button>
                    <button class="action-btn btn-not-compliance" title="Mark as Not Compliance / Re-open"><i class="fas fa-times-circle text-danger"></i></button>
                    <button class="action-btn btn-not-applicable" title="Mark as Not Applicable"><i class="fas fa-ban text-secondary"></i></button>
                    <button class="action-btn btn-breakdown" title="Mark as Breakdown"><i class="fas fa-exclamation-triangle text-danger"></i></button>
                    <button class="action-btn btn-breakdown-update" title="Update Breakdown Status"><i class="fas fa-tasks text-primary"></i></button>
                    <button class="action-btn btn-edit" title="Edit"><i class="fas fa-pencil-alt"></i></button>
                    <button class="action-btn btn-view" title="View"><i class="fas fa-eye"></i></button>
                    <button class="action-btn btn btn-sm btn-info text-white btn-assign" title="Acknowledge & Assign"><i class="fas fa-user-plus"></i></button>
                    <button class="action-btn btn btn-sm btn-success text-white btn-complete-task" title="Complete Task"><i class="fas fa-check-double"></i></button>
                    <button class="action-btn btn btn-sm btn-outline-secondary btn-progress" title="Progress Update"><i class="fas fa-comment-dots"></i></button>
                    <button class="action-btn btn btn-sm btn-outline-danger btn-delete" title="Delete"><i class="fas fa-trash-alt"></i></button>
                </div>
            </td>

            <!-- MOBILE VIEW CONTAINER -->
            <td class="mobile-card-view">
                <div class="complaint-card-mobile">
                    <!-- Always Visible Content -->
                    <div class="image-cell" style="padding-bottom: 1.5rem; flex-wrap: wrap; justify-content: center;">
                        <!-- Mobile images will be injected here -->
                    </div>
                    <div class="action-btn-group d-flex justify-content-center flex-wrap gap-2 mb-3 border-bottom pb-3">
                         <button class="action-btn btn-star" title="Mark for follow-up"><i class="far fa-star"></i></button>
                        <button class="action-btn btn-compliance" title="Mark as Compliance"><i class="fas fa-check-circle text-success"></i></button>
                        <button class="action-btn btn-not-compliance" title="Mark as Not Compliance / Re-open"><i class="fas fa-times-circle text-danger"></i></button>
                        <button class="action-btn btn-not-applicable" title="Mark as Not Applicable"><i class="fas fa-ban text-secondary"></i></button>
                        <button class="action-btn btn-breakdown" title="Mark as Breakdown"><i class="fas fa-exclamation-triangle text-danger"></i></button>
                        <button class="action-btn btn-breakdown-update" title="Update Breakdown Status"><i class="fas fa-tasks text-primary"></i></button>
                        <button class="action-btn btn-edit" title="Edit"><i class="fas fa-pencil-alt"></i></button>
                        <button class="action-btn btn-view" title="View"><i class="fas fa-eye"></i></button>
                        <button class="action-btn btn btn-sm btn-info text-white btn-assign" title="Acknowledge & Assign"><i class="fas fa-user-plus"></i></button>
                        <button class="action-btn btn btn-sm btn-success text-white btn-complete-task" title="Complete Task"><i class="fas fa-check-double"></i></button>
                        <button class="action-btn btn btn-sm btn-outline-secondary btn-progress" title="Progress Update"><i class="fas fa-comment-dots"></i></button>
                        <button class="action-btn btn btn-sm btn-outline-danger btn-delete" title="Delete"><i class="fas fa-trash-alt"></i></button>
                    </div>
                     <div class="comment-section">
                        <div class="label">Concern Comments:</div>
                        <div class="value" data-mobile="concern-comments"></div>
                    </div>
                    <div class="comment-section">
                        <div class="label">Closure Comments:</div>
                        <div class="value" data-mobile="closure-comments"></div>
                    </div>

                    <!-- Collapsible Section -->
                    <div class="collapsible-details">
                        <h2 class="section-title mt-4">Escalation Matrix</h2>
                        <div class="escalation-matrix progress-tracker">
                            <!-- Mobile escalation matrix will be dynamically populated here -->
                        </div>
                        <div class="details-grid">
                            <div class="detail-item">
                                <span class="label">Complain Number:</span>
                                <span class="value" data-mobile="complain-number"></span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Created By:</span>
                                <span class="value" data-mobile="created-by"></span>
                            </div>
                            <div class="detail-item full-width">
                                <span class="label">Area:</span>
                                <span class="value" data-mobile="area"></span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Created Date:</span>
                                <span class="value" data-mobile="created-date"></span>
                            </div>
                             <div class="detail-item">
                                <span class="label">Closer Date:</span>
                                <span class="value" data-mobile="closer-date"></span>
                            </div>
                             <div class="detail-item">
                                <span class="label">Responsibility:</span>
                                <span class="value" data-mobile="responsibility"></span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Risk:</span>
                                <span class="value" data-mobile="risk"></span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Status:</span>
                                <span class="value" data-mobile="status"></span>
                                <span class="time-since-reported"></span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Closed By:</span>
                                <span class="value" data-mobile="closed-by"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Expander Button -->
                    <div class="card-expander text-center mt-2 border-top pt-3">
                        <button class="btn btn-sm btn-outline-primary expand-toggle-btn">
                            <span>Show Details</span>
                            <i class="fas fa-chevron-down ms-2"></i>
                        </button>
                    </div>
                </div>
            </td>
        </tr>
    </template>
    
    <!-- MOBILE FILTER MODAL -->
    <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="filterModalLabel">Filter Reports</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="accordion" id="filterAccordion">
                        <!-- Report Details Filter -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingDetails">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseDetails" aria-expanded="false" aria-controls="collapseDetails">
                                    Report Details
                                </button>
                            </h2>
                            <div id="collapseDetails" class="accordion-collapse collapse" aria-labelledby="headingDetails" data-bs-parent="#filterAccordion">
                                <div class="accordion-body">
                                    <div class="mb-2">
                                        <label class="form-label small fw-bold">SOP Name</label>
                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search SOPs..." id="sopSearchInput_mobile">
                                        <div id="sopFilterList_mobile" class="filter-list"></div>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label small fw-bold">Risk</label>
                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search Risks..." id="riskSearchInput_mobile">
                                        <div id="riskFilterList_mobile" class="filter-list"></div>
                                    </div>
                                    <div>
                                        <label class="form-label small fw-bold">Responsibility</label>
                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="responsibilitySearchInput_mobile">
                                        <div id="responsibilityFilterList_mobile" class="filter-list"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Area Filter -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingArea">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseArea" aria-expanded="false" aria-controls="collapseArea">
                                    Area
                                </button>
                            </h2>
                            <div id="collapseArea" class="accordion-collapse collapse" aria-labelledby="headingArea" data-bs-parent="#filterAccordion">
                                <div class="accordion-body">
                                     <div class="mb-2">
                                        <label class="form-label small fw-bold">Regional</label>
                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="regionSearchInput_mobile">
                                        <div id="regionFilterList_mobile" class="filter-list"></div>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label small fw-bold">Unit</label>
                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="unitSearchInput_mobile">
                                        <div id="unitFilterList_mobile" class="filter-list"></div>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label small fw-bold">Department</label>
                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="departmentSearchInput_mobile">
                                        <div id="departmentFilterList_mobile" class="filter-list"></div>
                                    </div>
                                    <div>
                                        <label class="form-label small fw-bold">Location</label>
                                        <input type="search" class="form-control form-control-sm mb-1" placeholder="Search..." id="locationSearchInput_mobile">
                                        <div id="locationFilterList_mobile" class="filter-list"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Status Filter -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingStatus">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseStatus" aria-expanded="false" aria-controls="collapseStatus">
                                    Status
                                </button>
                            </h2>
                            <div id="collapseStatus" class="accordion-collapse collapse" aria-labelledby="headingStatus" data-bs-parent="#filterAccordion">
                                <div class="accordion-body">
                                    <input type="search" class="form-control form-control-sm mb-2" placeholder="Search..." id="statusSearchInput_mobile">
                                    <div id="statusFilterList_mobile" class="filter-list" style="max-height: 150px;"></div>
                                </div>
                            </div>
                        </div>
                        <!-- Tracking Filter -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTracking">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTracking" aria-expanded="false" aria-controls="collapseTracking">
                                    Tracking Status
                                </button>
                            </h2>
                            <div id="collapseTracking" class="accordion-collapse collapse" aria-labelledby="headingTracking" data-bs-parent="#filterAccordion">
                                <div class="accordion-body">
                                     <div class="mb-3">
                                        <label class="form-label small fw-bold">By Reporting Date</label>
                                        <div class="input-group input-group-sm mb-1">
                                            <span class="input-group-text">From</span>
                                            <input type="date" class="form-control" id="reportingDateFrom_mobile">
                                        </div>
                                        <div class="input-group input-group-sm">
                                            <span class="input-group-text">To</span>
                                            <input type="date" class="form-control" id="reportingDateTo_mobile">
                                        </div>
                                    </div>
                                     <div class="mb-3">
                                        <label class="form-label small fw-bold">By Closure Date</label>
                                        <div class="input-group input-group-sm mb-1">
                                            <span class="input-group-text">From</span>
                                            <input type="date" class="form-control" id="closureDateFrom_mobile">
                                        </div>
                                        <div class="input-group input-group-sm">
                                            <span class="input-group-text">To</span>
                                            <input type="date" class="form-control" id="closureDateTo_mobile">
                                        </div>
                                    </div>
                                    <div>
                                        <label class="form-label small fw-bold">By Timeline Stage</label>
                                        <div id="timelineStageFilterList_mobile">
                                             <div class="form-check"><input class="form-check-input" type="checkbox" value="owner" id="pendingOwnerAck_mobile"><label class="form-check-label" for="pendingOwnerAck_mobile">Pending Owner Ack</label></div>
                                             <div class="form-check"><input class="form-check-input" type="checkbox" value="assignment" id="pendingAssignment_mobile"><label class="form-check-label" for="pendingAssignment_mobile">Pending Assignment</label></div>
                                             <div class="form-check"><input class="form-check-input" type="checkbox" value="staff" id="pendingStaffAck_mobile"><label class="form-check-label" for="pendingStaffAck_mobile">Pending Staff Ack</label></div>
                                             <div class="form-check"><input class="form-check-input" type="checkbox" value="completion" id="pendingCompletion_mobile"><label class="form-check-label" for="pendingCompletion_mobile">Pending Completion</label></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" id="clearFiltersModalBtn">Clear Filters</button>
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Apply</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="assignModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Acknowledge Report</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div id="assignChoiceContainer"><p>How would you like to proceed?</p><div class="d-grid gap-2"><button type="button" class="btn btn-primary btn-lg" id="showAssignDetailsBtn"><i class="fas fa-user-friends me-2"></i> Assign to Staff</button><button type="button" class="btn btn-success btn-lg" id="attendMyselfBtn"><i class="fas fa-user-check me-2"></i> Attend Myself</button><button type="button" class="btn btn-warning btn-lg text-dark" id="scheduleTaskBtn"><i class="far fa-calendar-alt me-2"></i> Schedule Task</button></div></div><div id="assignDetailsContainer" style="display: none;"><input type="hidden" id="assignIncidentId"><div class="mb-3"><label class="form-label">Assign To:</label><input type="text" class="form-control" id="staffSearchInput" placeholder="Search for staff..."><ul id="staffSelectionList" class="filter-list mt-2" style="max-height: 150px;"></ul></div><div class="mb-3"><label for="assignmentNotes" class="form-label">Notes:</label><textarea class="form-control" id="assignmentNotes" rows="3"></textarea></div></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary d-none" id="confirmAssignmentBtn">Confirm Assignment</button></div></div></div></div>
    <div class="modal fade" id="staffAckModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Acknowledge Task</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" id="staffAckIncidentId"><p>Attend to this task now or schedule it?</p></div><div class="modal-footer d-flex justify-content-between"><button type="button" class="btn btn-primary" id="attendNowBtn"><i class="fas fa-bolt me-2"></i>Attend Now</button><button type="button" class="btn btn-secondary" id="attendLaterBtn"><i class="far fa-calendar-alt me-2"></i>Schedule</button></div></div></div></div>
    <div class="modal fade" id="attendLaterModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Schedule Task</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" id="attendLaterIncidentId"><p>Provide a tentative date and time.</p><div class="mb-3"><label for="tentativeDate" class="form-label">Date</label><input type="date" class="form-control" id="tentativeDate"></div><div class="mb-3"><label for="tentativeTime" class="form-label">Time</label><input type="time" class="form-control" id="tentativeTime"></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="confirmScheduleBtn">Schedule</button></div></div></div></div>
    <div class="modal fade" id="closureModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Observation Closure Form</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" id="closureIncidentId"><div class="mb-3"><label for="correctiveAction" class="form-label">Corrective Action Taken:</label><textarea class="form-control" id="correctiveAction" rows="4"></textarea></div><div class="mb-3"><label for="afterPhoto" class="form-label">Upload "After" Photo:</label><input class="form-control" type="file" id="afterPhoto" accept="image/*"></div><div id="afterPhotoPreviewContainer" class="text-center d-none mt-3"><img id="afterPhotoPreview" src="" alt="After Photo Preview" style="max-height: 200px; border-radius: 8px;"></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-success" id="confirmClosureBtn">Submit Closure</button></div></div></div></div>
    <div class="modal fade" id="scheduleModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Schedule Task</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" id="scheduleIncidentId"><p>Select a date and add comments for the scheduled task.</p><div class="mb-3"><label for="scheduleDate" class="form-label">Date</label><input type="date" class="form-control" id="scheduleDate"></div><div class="mb-3"><label for="scheduleComments" class="form-label">Comments</label><textarea class="form-control" id="scheduleComments" rows="3"></textarea></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="confirmMainScheduleBtn">Confirm Schedule</button></div></div></div></div>
    <div class="modal fade" id="imageModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Image Preview</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body image-modal-body text-center"></div></div></div></div>
    <div class="modal fade" id="bulkUploadModal" tabindex="-1" aria-labelledby="bulkUploadModalLabel" aria-hidden="true"><div class="modal-dialog modal-xl"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="bulkUploadModalLabel">Bulk Image Upload</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="row g-3"><div class="col-12"><label for="bulkLocationSearch" class="form-label"><strong>Step 1:</strong> Select a Location for this batch</label><div class="dropdown"><input type="text" class="form-control" id="bulkLocationSearch" placeholder="Search and select a location..." data-bs-toggle="dropdown" autocomplete="off"><input type="hidden" id="bulkLocationSelectValue"><ul class="dropdown-menu w-100" id="bulkLocationList" aria-labelledby="bulkLocationSearch"></ul></div></div>
    <div class="col-12">
        <label class="form-label"><strong>Step 2:</strong> Add Images</label>
        <div id="bulkUploadDropzone">
            <input type="file" id="bulkImageInput" multiple accept="image/*">
            <label for="bulkImageInput"></label> 
            <div class="dropzone-content">
                <i class="fas fa-cloud-arrow-up dropzone-icon"></i>
                <h6>Drag & drop files here</h6>
                <p class="small">Maximum file size: 10MB</p>
                <button type="button" class="btn btn-primary" onclick="document.getElementById('bulkImageInput').click();">
                    <i class="fas fa-folder-open me-2"></i>Or Browse Files
                </button>
            </div>
        </div>
    </div>
</div><hr class="my-4"><div id="bulkUploadPreviewArea"></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="processBulkUploadBtn" disabled><span class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true"></span> Process Upload (<span id="bulkImageCount">0</span>)</button></div></div></div></div>
        
    <!-- Breakdown Modals -->
    <div class="modal fade" id="breakdownModal" tabindex="-1" aria-labelledby="breakdownModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="breakdownModalLabel">Breakdown Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="breakdownForm">
                        <input type="hidden" id="breakdownIncidentId">
                        <div class="mb-3">
                            <label for="breakdownEquipmentSearch" class="form-label">Equipment</label>
                            <div class="dropdown">
                                <input type="text" class="form-control" id="breakdownEquipmentSearch" placeholder="Search and select equipment..." data-bs-toggle="dropdown" autocomplete="off" required>
                                <input type="hidden" id="breakdownEquipment">
                                <ul class="dropdown-menu w-100" id="breakdownEquipmentList" aria-labelledby="breakdownEquipmentSearch">
                                    <!-- Search results will be populated here by JS -->
                                </ul>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="breakdownRootCause" class="form-label">Root Cause for Breakdown</label>
                            <textarea class="form-control" id="breakdownRootCause" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="breakdownClosureDate" class="form-label">Tentative Closure Date</label>
                            <input type="date" class="form-control" id="breakdownClosureDate" required>
                        </div>
                        <div class="mb-3">
                            <label for="breakdownStepTaken" class="form-label">Current Step Taken</label>
                            <textarea class="form-control" id="breakdownStepTaken" rows="2" required></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmBreakdownBtn">Save Details</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="breakdownUpdateModal" tabindex="-1" aria-labelledby="breakdownUpdateModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl modal-fullscreen-lg-down">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="breakdownUpdateModalLabel">Breakdown Status Update</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                     <div id="breakdownUpdateFormContainer">
                        <h6 class="mb-3">Post New Update</h6>
                        <form id="breakdownUpdateForm">
                            <input type="hidden" id="breakdownUpdateIncidentId">
                             <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="breakdownUpdateDate" class="form-label">Update Date</label>
                                    <input type="date" class="form-control" id="breakdownUpdateDate" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="breakdownUpdateCost" class="form-label">Cost Incurred</label>
                                    <div class="input-group">
                                        <span class="input-group-text">₹</span>
                                        <input type="number" class="form-control" id="breakdownUpdateCost" min="0" step="0.01" placeholder="0.00">
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="breakdownUpdateComments" class="form-label">Corrective Action / Comments</label>
                                <textarea class="form-control" id="breakdownUpdateComments" rows="3" required></textarea>
                            </div>
                        </form>
                    </div>

                    <div class="mt-4">
                        <h6 class="mb-3">Breakdown History</h6>
                        <div class="table-responsive" style="max-height: 40vh; overflow-y: auto;">
                            <!-- REWORK: Table styling updated for consistency -->
                            <table class="table table-bordered table-striped table-sm breakdown-history-table">
                                <thead class="table-light">
                                    <tr>
                                        <th>Reported Date</th>
                                        <th>Reported By</th>
                                        <th>Breakdown Reason</th>
                                        <th>Tentative Date</th>
                                        <th>Corrective Action</th>
                                        <th>Closure Date</th>
                                        <th>Rectified By</th>
                                        <th>Verified By</th>
                                        <th>Verification Date</th>
                                        <th>Incurred Expenses</th>
                                    </tr>
                                </thead>
                                <tbody id="breakdownHistoryContainer">
                                    <!-- History will be injected here by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="confirmBreakdownUpdateBtn">Post Update</button>
                    <button type="button" class="btn btn-warning" id="confirmBreakdownResolveBtn">Resolve Breakdown</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Verification Modal -->
    <div class="modal fade" id="breakdownVerificationModal" tabindex="-1" aria-labelledby="breakdownVerificationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl modal-fullscreen-lg-down">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="breakdownVerificationModalLabel">Verify Breakdown Closure</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="breakdownVerificationIncidentId">
                    <div class="mb-3">
                       <label for="verificationComments" class="form-label">Verification Comments</label>
                       <textarea class="form-control" id="verificationComments" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                       <label for="verificationSignaturePad" class="form-label d-block">Verification Signature</label>
                       <canvas id="verificationSignaturePad" class="signature-pad" width="400" height="150"></canvas>
                        <button type="button" class="btn btn-sm btn-outline-secondary mt-2 d-block" id="clearVerificationSignatureBtn">Clear Signature</button>
                    </div>
                    <div class="mt-4">
                        <h6 class="mb-3">Breakdown History for Review</h6>
                         <div class="table-responsive" style="max-height: 30vh; overflow-y: auto;">
                             <!-- REWORK: Table styling updated for consistency -->
                            <table class="table table-bordered table-striped table-sm breakdown-history-table">
                                <thead class="table-light">
                                    <tr>
                                        <th>Reported Date</th>
                                        <th>Reported By</th>
                                        <th>Breakdown Reason</th>
                                        <th>Corrective Action</th>
                                        <th>Rectified By</th>
                                        <th>Incurred Expenses</th>
                                    </tr>
                                </thead>
                                <tbody id="verificationHistoryContainer">
                                    <!-- Simplified History will be injected here by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="rejectBreakdownBtn">Reject</button>
                    <button type="button" class="btn btn-success" id="finalSubmitVerificationBtn">Final Submit</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Non-Compliance, NA, History Modals -->
    <div class="modal fade" id="nonComplianceModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Re-open as Non-Compliance</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><p>This will create a <strong>new open observation</strong> based on the previous one. Please provide the reason and new evidence.</p><form id="nonComplianceForm"><input type="hidden" id="nonComplianceOriginalId"><div class="mb-3"><label for="nonComplianceComments" class="form-label">Reason for Non-Compliance:</label><textarea class="form-control" id="nonComplianceComments" rows="4" required></textarea></div><div class="mb-3"><label for="nonCompliancePhoto" class="form-label">Upload New "Before" Photo:</label><input class="form-control" type="file" id="nonCompliancePhoto" accept="image/*" required></div><div id="nonCompliancePhotoPreviewContainer" class="text-center d-none mt-3"><img id="nonCompliancePhotoPreview" src="" alt="Non-Compliance Photo Preview" style="max-height: 200px; border-radius: 8px;"></div></form></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-danger" id="confirmNonComplianceBtn">Create New Observation</button></div></div></div></div>
    <div class="modal fade" id="naModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Mark as Not Applicable</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><p>Provide a reason for marking this as not applicable. This will be added to the follow-up history.</p><form id="naForm"><input type="hidden" id="naIncidentId"><div class="mb-3"><label for="naComments" class="form-label">Reason:</label><textarea class="form-control" id="naComments" rows="4" required></textarea></div><div class="mb-3"><label for="naEvidence" class="form-label">Upload Evidence (Optional):</label><input class="form-control" type="file" id="naEvidence" accept="image/*,video/*"></div></form></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="confirmNaBtn">Submit</button></div></div></div></div>
    <div class="modal fade" id="historyModal" tabindex="-1" aria-labelledby="historyModalLabel" aria-hidden="true"><div class="modal-dialog modal-fullscreen"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="historyModalLabel">Follow Up History</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body history-modal" id="historyModalBody"><div id="report-root" class="report-container"><div class="report-timestamps"><div><strong>Start Date:</strong> <span data-js="start-date"></span></div><div><strong>End Date:</strong> <span data-js="end-date"></span></div></div><div class="report-header"><div class="evidence-section" data-js="evidence-section"></div><div class="report-details"><h2 data-js="title"></h2><div class="meta-info" data-js="meta-info"></div><div class="meta-info" data-js="risk"></div><div class="meta-info" data-js="responsibility"></div></div><div class="header-right-panel"><div class="area-status"><div class="area" data-js="area"></div><div class="status" data-js="status-header"></div></div><div><button class="download-button" data-js="download-button">Download PDF</button></div></div></div><div class="report-table-wrapper"><table class="report-table"><thead><tr><th>Date & Time</th><th>Status</th><th>Comments</th><th>Image/Video</th></tr></thead><tbody data-js="history-table-body"></tbody></table></div></div><div id="report-update-section" class="report-update-section mt-4 p-3 bg-light border rounded" style="max-width: 1200px; margin: 1.5rem auto 0 auto;"><h5 class="mb-3">Post a Progress Update or Comment</h5><div class="mb-3"><label for="historyComment" class="form-label">Comment</label><textarea class="form-control" id="historyComment" rows="3" placeholder="Provide details about the delay or progress..."></textarea></div><div class="mb-3"><label for="historyEvidence" class="form-label">Attach Evidence (Optional)</label><input class="form-control" type="file" id="historyEvidence" accept="image/*,video/*"></div><div class="text-end"><button class="btn btn-primary" id="postHistoryUpdateBtn">Post Update</button></div></div><div id="image-modal" class="modal-overlay" role="dialog" aria-modal="true"><div class="modal-content"><span class="modal-close" data-js="modal-close" aria-label="Close image view">&times;</span><img src="" alt="Enlarged report image" data-js="modal-image"></div></div></div></div></div></div>

    <!-- Complaint Form Modal -->
    <div class="modal fade" id="complaintFormModal" tabindex="-1" aria-labelledby="complaintFormModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="complaintFormModalLabel">Create / Edit Report</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="main-container">
                        <div class="details-container">
                            <div class="form-group">
                                <div class="form-group-header">
                                    <label class="form-label" for="complaint-box">Complaint Details <span class="required-star">*</span></label>
                                </div>
                                <input type="file" id="camera-file-input" accept="image/jpeg,image/png" capture="environment" style="display: none;">
                                <input type="file" id="gallery-file-input" accept="image/*,video/*,application/pdf" multiple style="display: none;">
                                <div class="error-message" id="image-error" aria-live="polite"></div>
                                <div class="complaint-input-wrapper" id="complaintInputWrapper">
                                    <div class="complaint-box" id="complaintBox">
                                         <p>
                                            <span contenteditable="true" class="inline-input" id="concernInput" data-placeholder="Type or add media..."></span>
                                            <span id="complaint-sentence-template">
                                                <span>, indicating a deviation from the</span>
                                                <span class="multi-select-wrapper" id="sopSelector"></span>
                                                <span style="display: none;">
                                                    <span>at</span>
                                                    <span class="multi-select-wrapper" id="departmentSelector"></span>
                                                </span>
                                                <span>at</span>
                                                <span class="multi-select-wrapper" id="locationSelector"></span>
                                                <span>. This issue requires rectification by</span>
                                                <span class="multi-select-wrapper" id="responsibilitySelector"></span>
                                                <span>.</span>
                                            </span>
                                        </p>
                                        <div id="image-collage-preview-area" class="image-collage-preview" style="display: none;"></div>
                                        <button type="button" id="create-collage-btn" style="display: none; margin-top: 10px; width: 100%; padding: 10px; background-color: var(--accent-color); color: white; border: none; border-radius: var(--border-radius); cursor: pointer;">Create Collage from Images</button>
                                    </div>

                                    <div id="direct-upload-options-container">
                                        <div id="direct-upload-options" class="direct-upload-options">
                                            <button type="button" id="direct-camera-btn" class="upload-option-direct" aria-label="Take a photo">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M4,4H7L9,2H15L17,4H20A2,2 0 0,1 22,6V18A2,2 0 0,1 20,20H4A2,2 0 0,1 2,18V6A2,2 0 0,1 4,4M12,7A5,5 0 0,0 7,12A5,5 0 0,0 12,17A5,5 0 0,0 17,12A5,5 0 0,0 12,7M12,9A3,3 0 0,1 15,12A3,3 0 0,1 12,15A3,3 0 0,1 9,12A3,3 0 0,1 12,9Z" /></svg>
                                            </button>
                                            <button type="button" id="direct-camcorder-btn" class="upload-option-direct" aria-label="Record a video">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17,10.5V7A1,1 0 0,0 16,6H4A1,1 0 0,0 3,7V17A1,1 0 0,0 4,18H16A1,1 0 0,0 17,17V13.5L21,17.5V6.5L17,10.5Z" /></svg>
                                            </button>
                                            <button type="button" id="direct-gallery-btn" class="upload-option-direct" aria-label="Upload from photos and videos">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21.58,16.09L17.17,11.67C16.42,10.92,15.21,10.92,14.46,11.67L11.91,14.22L9.21,11.5C8.82,11.13,8.19,11.13,7.8,11.5L2.42,16.94C1.63,17.72,2.2,19,3.14,19H20.86C21.8,19,22.37,17.72,21.58,16.09M22,5V15.5C22,16.05,21.55,16.5,21,16.5H3C2.45,16.5,2,16.05,2,15.5V5C2,3.9,2.9,3,4,3H20C21.1,3,22,3.9,22,5Z" /></svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div id="modelStatus"></div>
                            </div>
                    
                            <div class="optional-details-section optional-details-toggle-wrapper">
                                <h4>
                                    <span>Optional: Specify Items/People Involved</span>
                                    <svg class="optional-toggle-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                                </h4>
                                <div class="optional-selectors-grid">
                                    <div class="optional-selector-item">
                                        <label for="peopleSelector">Person(s)</label>
                                        <span class="multi-select-wrapper" id="peopleSelector"></span>
                                    </div>
                                    <div class="optional-selector-item">
                                        <label for="equipmentSelector">Equipment</label>
                                        <span class="multi-select-wrapper" id="equipmentSelector"></span>
                                    </div>
                                    <div class="optional-selector-item">
                                        <label for="foodSelector">Food Item(s)</label>
                                        <span class="multi-select-wrapper" id="foodSelector"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <button id="submitBtn" class="submit-button">Submit Complaint</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END Complaint Form Modal -->

    <!-- Modals from Complaint Form -->
    <div id="image-preview-modal"><div class="modal-content"><span class="close-preview" id="close-image-preview-modal">&times;</span></div></div>
    <div id="upload-choice-modal" class="upload-choice-modal"></div>
    <div id="video-recorder-modal" class="video-recorder-modal"><div class="video-recorder-content"><video id="video-preview" autoplay muted playsinline></video><div class="video-controls"><span class="recording-indicator" id="recording-indicator">Recording...</span><button id="start-record-btn">Start</button><button id="stop-record-btn" style="display: none;">Stop</button><button id="save-video-btn" style="display: none;">Save</button><button id="cancel-video-btn">Cancel</button></div></div></div>
    <div id="collage-maker-container" class="collage-maker-container"></div>
    <div id="image-editor-modal" class="image-editor-modal"></div>
    
    
    
    
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg"> <!-- Centered + Large -->
    <div class="modal-content">
      
      <!-- Modal Header -->
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Observation Closure Form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      
      <!-- Modal Body -->
      <div class="modal-body">
        @include('admin.inspection.Observation_Closure_Form')
      </div>
 
      
    </div>
  </div>
</div>

	
@endsection


@section('footerscript')
	   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    
        // --- CONSOLIDATED AND REWORKED SCRIPT ---
        
        let bulkUploadFiles = [];
        let reportDatabase = {};
        let mobileCardStyleCounter = 0;

        // Mock data for equipment, normally fetched from a server.
        const dummyEquipmentData = {
            "Maintenance-Main Kitchen": ["EQ-MK-001 (Oven)", "EQ-MK-002 (Dishwasher)", "EQ-MK-003 (Exhaust Hood)"],
            "Engineering-Hall 3": ["EQ-H3-101 (Fire Panel)", "EQ-H3-102 (HVAC Unit)"],
            "Food Production-Back Area": ["EQ-FP-055 (Freezer)", "EQ-FP-056 (Blast Chiller)"],
            "Default": ["EQ-GEN-001", "EQ-GEN-002"]
        };
        
        // Initial static data that will be processed into the table on load.
        const initialReportData = [
            
                    @foreach($inspection_list as $inspection)
            {
                incidentId: "{{$inspection->id}}", reportedTime: "2024-05-19T10:30:00Z", completedTime: "2024-05-20T14:45:00Z", sop: "SOP: {{$inspection->sops ?? ''}}", risk: "Major", region: "{{$inspection->regional ?? 'NA'}}", unit: "{{$inspection->unit ?? 'NA'}}",
                department: "{{$inspection->sublocation ?? ''}}", location: "{{$inspection->location ?? ''}}", status: "{{$inspection->select_action ?? ''}}",starred: "{{$inspection->starred ?? ''}}", registeredBy: "{{Helper::user_info($inspection->unit_id)->name ?? ''}}.", assignedTo: "{{Helper::user_info($inspection->updated_by)->name ?? ''}}",
                title: "{{$inspection->title ?? ''}}",
               responsibility: "{{$inspection->responsibility}}",
                closureComments: "{{$inspection->closure_comments ?? ''}}",
                images: { before: "{{ !empty($inspection->image) ? asset('inspection/' . $inspection->image) : '' }}", after: "" },
                progress: [
                    { stage: 'Registered', user: 'Shreekant P.', time: '19-May 10:30' },
                    { stage: 'Owner Ack.', user: 'Rahul V.', time: '19-May 14:30' },
                    { stage: 'Assigned', user: 'to Ajay S. (E021)', time: '19-May 14:32' },
                    { stage: 'Staff Ack.', user: 'by Ajay S. (E021)', time: '19-May 15:05' },
                    { stage: 'Completed', user: 'by Ajay S. (E021)', time: '20-May 14:45' }
                ]
            },
            
            @endforeach
        ];

        /**
         * Generates unique IDs for reports based on the current date.
         */
        const IdGenerator = (() => {
            let dailyCounters = {};
            const pad = (num, size) => ('000' + num).slice(-size);
            const getTodayKey = () => {
                const d = new Date();
                return `${pad(d.getDate(), 2)}${pad(d.getMonth() + 1, 2)}${d.getFullYear()}`;
            };

            return {
                generate: () => {
                    const key = getTodayKey();
                    if (!dailyCounters[key]) { dailyCounters[key] = 0; }
                    dailyCounters[key]++;
                    return `${key}-${pad(dailyCounters[key], 3)}`;
                }
            };
        })();

        // Manages alert tickers and toast notifications.
        const AlertManager = {
            init() {
                this.obsTicker = document.getElementById('observation-ticker');
                this.breakdownTicker = document.getElementById('breakdown-ticker');
                this.verificationTicker = document.getElementById('verification-ticker');
                this.toastContainer = document.getElementById('toast-container');
                
                document.querySelectorAll('.ticker-close').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        e.target.closest('.alert-ticker').style.display = 'none';
                    });
                });
            },
            _showTicker(tickerEl, message) {
                const contentEl = tickerEl.querySelector('.ticker-content');
                contentEl.innerHTML = message;
                tickerEl.style.display = 'block';
            },
            showObservation(message) {
                this._showTicker(this.obsTicker, `<i class="fas fa-info-circle"></i> ${message}`);
            },
            showBreakdown(message) {
                this._showTicker(this.breakdownTicker, `<i class="fas fa-exclamation-triangle"></i> ${message}`);
            },
            showVerification(message) {
                this._showTicker(this.verificationTicker, `<i class="fas fa-user-check"></i> ${message}`);
            },
            showToast(message, type = 'success') {
                const toast = document.createElement('div');
                toast.className = `toast-notification ${type}`;
                toast.innerHTML = message;
                this.toastContainer.appendChild(toast);
                setTimeout(() => { toast.remove(); }, 5000);
            }
        };
    
        // Centralized object to manage all Bootstrap modals.
        const ActionModals = {
            assign: new bootstrap.Modal(document.getElementById("assignModal")),
            staffAck: new bootstrap.Modal(document.getElementById("staffAckModal")),
            attendLater: new bootstrap.Modal(document.getElementById("attendLaterModal")),
            closure: new bootstrap.Modal(document.getElementById("closureModal")),
            schedule: new bootstrap.Modal(document.getElementById("scheduleModal")),
            image: new bootstrap.Modal(document.getElementById("imageModal")),
            bulkUpload: new bootstrap.Modal(document.getElementById("bulkUploadModal")),
            history: new bootstrap.Modal(document.getElementById("historyModal")),
            nonCompliance: new bootstrap.Modal(document.getElementById("nonComplianceModal")),
            na: new bootstrap.Modal(document.getElementById("naModal")),
            complaintForm: new bootstrap.Modal(document.getElementById("complaintFormModal")),
            breakdown: new bootstrap.Modal(document.getElementById("breakdownModal")),
            breakdownUpdate: new bootstrap.Modal(document.getElementById("breakdownUpdateModal")),
            breakdownVerification: new bootstrap.Modal(document.getElementById("breakdownVerificationModal")),
            filter: new bootstrap.Modal(document.getElementById("filterModal"))
        };
        window.ActionModals = ActionModals;

        // Utility to compress images before processing.
        function compressImage(file, options = { maxWidth: 1024, quality: 0.8 }) {
            return new Promise((resolve, reject) => {
                if (!file.type.startsWith('image/')) { return resolve(file); }
                const reader = new FileReader();
                reader.onload = (event) => {
                    const img = new Image();
                    img.onload = () => {
                        const canvas = document.createElement('canvas');
                        let { width, height } = img;
                        if (width > options.maxWidth) { height *= options.maxWidth / width; width = options.maxWidth; }
                        canvas.width = width; canvas.height = height;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0, width, height);
                        canvas.toBlob((blob) => {
                            if (!blob) { return reject(new Error('Canvas to Blob conversion failed.')); }
                            resolve(new File([blob], file.name, { type: 'image/jpeg', lastModified: Date.now() }));
                        }, 'image/jpeg', options.quality);
                    };
                    img.onerror = (error) => reject(error);
                    img.src = event.target.result;
                };
                reader.onerror = (error) => reject(error);
                reader.readAsDataURL(file);
            });
        }
    
        // Manages offline status and syncs drafts using IndexedDB.
        const OfflineManager = {
            db: null, isSyncing: false,
            init() {
                const request = indexedDB.open('EFSMS_DB', 1);
                request.onupgradeneeded = e => { 
                    if (!e.target.result.objectStoreNames.contains('offlineDrafts')) {
                        e.target.result.createObjectStore('offlineDrafts', { keyPath: 'id' }); 
                    }
                };
                request.onsuccess = e => {
                    this.db = e.target.result;
                    window.addEventListener('online', this.updateOnlineStatus.bind(this));
                    window.addEventListener('offline', this.updateOnlineStatus.bind(this));
                    this.updateOnlineStatus();
                };
                request.onerror = e => console.error('DB Error:', e.target.error);
            },
            updateOnlineStatus() {
                const online = navigator.onLine;
                const indicator = document.getElementById('connection-status-indicator');
                const text = document.getElementById('connection-status-text');
                indicator.className = `badge rounded-pill ${online ? 'status-online' : 'status-offline'}`;
                text.textContent = online ? 'Online' : 'Offline';
                if(online) {
                    text.classList.remove('text-danger');
                    text.classList.add('text-success');
                } else {
                    text.classList.add('text-danger');
                    text.classList.remove('text-success');
                }

                if (online) { 
                    UploadManager.retryAllFailed(); 
                    this.syncDrafts();
                } else { 
                    this.loadAndDisplayDrafts(); 
                }
            },
            saveDraft(data) {
                return new Promise((resolve, reject) => {
                    const tx = this.db.transaction('offlineDrafts', 'readwrite');
                    tx.oncomplete = () => { resolve(data); };
                    tx.onerror = e => reject(e.target.error);
                    tx.objectStore('offlineDrafts').put(data);
                });
            },
            getDrafts: () => new Promise(resolve => OfflineManager.db.transaction('offlineDrafts').objectStore('offlineDrafts').getAll().onsuccess = e => resolve(e.target.result)),
            deleteDraft: id => new Promise(resolve => OfflineManager.db.transaction('offlineDrafts', 'readwrite').objectStore('offlineDrafts').delete(id).onsuccess = () => resolve()),
            async loadAndDisplayDrafts() {
                const drafts = await this.getDrafts();
                drafts.forEach(draft => {
                    if (!document.querySelector(`tr[data-draft-id="${draft.id}"]`)) {
                        ReportProcessor.createAndDisplayDraftRow(draft);
                    }
                });
            },
            async syncDrafts() {
                if (this.isSyncing) return;
                const drafts = await this.getDrafts();
                if (drafts.length === 0) return;

                this.isSyncing = true;
                
                for (let i = 0; i < drafts.length; i++) {
                    const draft = drafts[i];
                    document.querySelector(`tr[data-draft-id="${draft.id}"]`)?.remove();
                    await this.deleteDraft(draft.id);
                    await new Promise(r => setTimeout(r, 300));
                }

                this.isSyncing = false;
            }
        };
    
        // Simulates media uploads.
        const UploadManager = {
            retryAllFailed() {},
            _performUpload(file, mediaId) {
                const mediaContainer = document.getElementById(mediaId);
                if (!mediaContainer) return;
                const progressText = mediaContainer.querySelector('.upload-progress-text');
                let percent = 0;
                const interval = setInterval(() => {
                    percent += 10;
                    if(progressText) progressText.textContent = `${percent}%`;
                    if (percent >= 100) {
                        clearInterval(interval);
                        if(progressText) progressText.textContent = '✓';
                        setTimeout(() => {
                            mediaContainer.querySelector('.media-upload-overlay')?.classList.add('hidden');
                            mediaContainer.dataset.mediaStatus = 'complete';
                        }, 500);
                    }
                }, 150);
            }
        };
    
        // Handles creating and populating report rows in the table.
        const ReportProcessor = {
            processSingleBulkUpload(file, locationString) {
                const [region, unit, department, location] = locationString.split(' / ').map(s => s.trim());
                const data = {
                    title: "Bulk Upload: General Observation",
                    sop: "SOP: General Observation",
                    risk: "Minor",
                    region: region || 'N/A',
                    unit: unit || 'N/A',
                    department: department || 'N/A',
                    location: location || 'N/A',
                    status: 'Open',
                    registeredBy: 'Bulk Upload',
                    responsibility: 'Unassigned',
                    images: { before: URL.createObjectURL(file) },
                    progress: [ { stage: 'Registered', user: 'Bulk Upload', time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) } ]
                };
                this.createAndDisplayRow(data);
            },
            createAndDisplayRow(data, isFromSync = false) {
                const template = document.getElementById('report-row-template');
                const newRow = template.content.cloneNode(true).querySelector('tr');
                
                const now = new Date();
                const incidentId = data.incidentId || `INC${now.getTime()}`;
                const complaintId = data.complaintId || IdGenerator.generate();
                
                Object.assign(newRow.dataset, {
                    incidentId: incidentId,
                    complaintId: complaintId,
                    reportedTime: data.reportedTime || now.toISOString(),
                    completedTime: data.completedTime || '',
                    sop: data.sop,
                    risk: data.risk,
                    region: data.region,
                    unit: data.unit,
                    department: data.department,
                    location: data.location,
                    status: data.status,
                    starred: data.starred == 1 ? "true" : "false",
                    registeredBy: data.registeredBy,
                    assignedTo: data.assignedTo || ''
                });

                newRow.querySelector('.concern-id').textContent = complaintId;
                newRow.querySelector('.concern-title').innerHTML = data.title;
                
                let metaHTML = `
                    <span data-type="sop"><i class="fas fa-book me-1"></i> ${data.sop}</span>
                    <span data-type="dev"><i class="fas fa-exclamation-triangle me-1"></i> Dev: ${data.risk}</span>
                    <span class="risk-score-badge" data-type="risk-score"></span>`;

                if (data.originalIncidentId) {
                    metaHTML += `<span class="badge bg-secondary">Re-opened from 
                        <a href="#" class="text-white fw-bold" data-original-id="${data.originalIncidentId}">#${data.originalIncidentId}</a>
                    </span>`;
                }
                newRow.querySelector('.concern-meta').innerHTML = metaHTML;

                newRow.querySelector('.concern-responsibility').innerHTML = `<strong>Responsibility:</strong>&nbsp;<span>${data.responsibility || 'Unassigned'}</span>`;
                newRow.querySelector('.closure-comments-cell').textContent = data.closureComments || '---';
                const areaText = `${data.region} / ${data.unit} / ${data.department} / ${data.location}`;
                newRow.querySelector('td[data-label="Area"] span').textContent = areaText;
                
                const desktopImageCell = newRow.querySelector('.desktop-view .image-cell');
                desktopImageCell.innerHTML = '';
                if (data.images?.before) desktopImageCell.innerHTML += `<div class="position-relative" data-media-status="complete"><img src="${data.images.before}" class="report-image-thumb" crossorigin="anonymous"><span class="image-label">Before</span></div>`;
                if (data.images?.after) desktopImageCell.innerHTML += `<div class="position-relative" data-media-status="complete"><img src="${data.images.after}" class="report-image-thumb" crossorigin="anonymous"><span class="image-label">After</span></div>`;
                if (data.videos?.before) desktopImageCell.innerHTML += `<div class="position-relative" data-media-status="complete"><div class="video-thumbnail-overlay"><i class="fas fa-play-circle"></i></div><video class="report-image-thumb" src="${data.videos.before}" muted loop></video><span class="image-label">Before</span></div>`;
                
                
                const progressTracker = newRow.querySelector('.desktop-view .progress-tracker');
                const stages = ['Registered', 'Owner Ack.', 'Assigned', 'Staff Ack.', 'Completed'];
                const icons = ['fa-flag', 'fa-user-check', 'fa-user-plus', 'fa-clipboard-check', 'fa-check'];
                const progressHTML = stages.map((stage, index) => {
                    const stepData = (data.progress || []).find(p => p.stage === stage);
                    const isCompleted = !!stepData;
                    return `
                        <div class="step ${isCompleted ? 'is-completed' : ''}">
                            <div class="step-icon"><i class="fas ${icons[index]}"></i></div>
                            <div class="step-label">
                                <strong>${stage}</strong>
                                <span>${stepData ? `by ${stepData.user}` : 'Pending'}</span>
                                ${stepData?.time ? `<span class="step-time">${stepData.time}</span>` : ''}
                            </div>
                        </div>`;
                }).join('');
                progressTracker.innerHTML = progressHTML;


                // --- MOBILE VIEW POPULATION ---
                const mobileCard = newRow.querySelector('.complaint-card-mobile');
                const mobileImageCell = mobileCard.querySelector('.image-cell');
                mobileImageCell.innerHTML = desktopImageCell.innerHTML;

                mobileCardStyleCounter++;
                mobileCard.classList.add('card-border-' + ((mobileCardStyleCounter % 4) + 1));


                const mobileEscalationMatrix = mobileCard.querySelector('.escalation-matrix');
                mobileEscalationMatrix.innerHTML = progressHTML;
                
                mobileCard.querySelector('[data-mobile="complain-number"]').textContent = complaintId;
                mobileCard.querySelector('[data-mobile="created-by"]').textContent = data.registeredBy || 'N/A';
                mobileCard.querySelector('[data-mobile="area"]').textContent = areaText;
                mobileCard.querySelector('[data-mobile="created-date"]').textContent = new Date(data.reportedTime).toLocaleString();
                mobileCard.querySelector('[data-mobile="closer-date"]').textContent = data.completedTime ? new Date(data.completedTime).toLocaleString() : '';
                mobileCard.querySelector('[data-mobile="responsibility"]').textContent = data.responsibility || 'Unassigned';
                mobileCard.querySelector('[data-mobile="risk"]').textContent = data.risk || 'N/A';
                mobileCard.querySelector('[data-mobile="status"]').textContent = data.status;
                mobileCard.querySelector('[data-mobile="status"]').style.color = data.status === 'Open' ? 'var(--danger-color)' : 'var(--green)';
                mobileCard.querySelector('[data-mobile="closed-by"]').textContent = data.status === 'Resolved' ? (data.assignedTo || 'N/A') : '';
                mobileCard.querySelector('[data-mobile="concern-comments"]').textContent = data.title;
                const closureText = data.closureComments && data.closureComments !== '---' ? data.closureComments : '';
                mobileCard.querySelector('[data-mobile="closure-comments"]').textContent = closureText;

                document.querySelector("#incidentReportTable tbody").prepend(newRow);
                
                IncidentTableManager.allTableRows.unshift(newRow);
                IncidentTableManager.calculateAndSetRiskScore(newRow);
                ReportHistoryManager.initializeReportData(newRow);
                IncidentTableManager.updateRowUI(newRow); 
                
                if (!data.incidentId) {
                     AlertManager.showObservation(`New Observation Reported: "${data.title}" at ${data.location}`);
                }

                return newRow;
            },
            createAndDisplayDraftRow(draft) {
                 const newRow = document.createElement('tr');
                 newRow.classList.add('is-draft');
                 newRow.dataset.draftId = draft.id;
                 newRow.innerHTML = `
                    <td data-label="Select"></td>
                    <td data-label="Evidence">
                        <div class="mobile-evidence-header"><span class="status-badge status-draft"><i class="fas fa-save me-1"></i> Draft</span></div>
                        <div class="image-cell">${(draft.files || []).map(f => `<div class="position-relative"><img src="${URL.createObjectURL(f)}" class="report-image-thumb"></div>`).join('')}</div>
                        <div class="action-btn-group-mobile"><button class="action-btn btn btn-sm btn-outline-danger btn-delete-draft" title="Delete Draft"><i class="fas fa-trash-alt"></i></button></div>
                    </td>
                    <td data-label="Report Details"><div class="concern-title">${draft.concern}</div></td>
                    <td data-label="Closure Comments">---</td><td data-label="Area">${draft.location}</td>
                    <td data-label="Status"><div><span class="status-badge status-draft"><i class="fas fa-save me-1"></i> Draft</span></div></td>
                    <td data-label="Tracking Status"><span>Pending upload</span></td>
                    <td data-label="Actions"><div class="action-btn-group"><button class="action-btn btn btn-sm btn-outline-danger btn-delete-draft" title="Delete Draft"><i class="fas fa-trash-alt"></i></button></div></td>
                 `;
                 document.querySelector("#incidentReportTable tbody").prepend(newRow);
                 IncidentTableManager.allTableRows.unshift(newRow);
                 IncidentTableManager.displayPage(IncidentTableManager.currentPage);

                 newRow.querySelector('.btn-delete-draft').addEventListener('click', async () => {
                    if (confirm('Delete this draft?')) { 
                        await OfflineManager.deleteDraft(draft.id); 
                        newRow.remove(); 
                        IncidentTableManager.allTableRows = IncidentTableManager.allTableRows.filter(r => r !== newRow);
                        IncidentTableManager.applyAllFilters();
                    }
                 });
            }
        };

        const GlobalFilterManager = {
            showFollowUpsOnly: false,
            showBreakdownsOnly: false,

            init() {
                document.getElementById('followUpFilterBtn').addEventListener('click', () => {
                    this.showFollowUpsOnly = !this.showFollowUpsOnly;
                    document.getElementById('followUpFilterBtn').classList.toggle('active', this.showFollowUpsOnly);
                    IncidentTableManager.displayPage(1);
                });
                document.getElementById('breakdownFilterBtn').addEventListener('click', () => {
                    this.showBreakdownsOnly = !this.showBreakdownsOnly;
                    document.getElementById('breakdownFilterBtn').classList.toggle('active', this.showBreakdownsOnly);
                    IncidentTableManager.displayPage(1);
                });
            },

            clear() {
                this.showFollowUpsOnly = false;
                this.showBreakdownsOnly = false;
                document.getElementById('followUpFilterBtn').classList.remove('active');
                document.getElementById('breakdownFilterBtn').classList.remove('active');
            }
        };

        const FilterManager = {
            activeFilters: { sop: [], risk: [], responsibility: [] },

            init() {
                this.populateFilters();
                this.addEventListeners();
            },

            populateFilters() {
                const uniqueSOPs = new Set();
                const uniqueRisks = new Set();
                const uniqueResponsibilities = new Set();

                IncidentTableManager.allTableRows.forEach(row => {
                    if (row.dataset.sop) uniqueSOPs.add(row.dataset.sop);
                    if (row.dataset.risk) uniqueRisks.add(row.dataset.risk);
                    const resp = row.querySelector('.concern-responsibility span');
                    if (resp && resp.textContent) uniqueResponsibilities.add(resp.textContent);
                });

                this.renderFilterOptions('sop', Array.from(uniqueSOPs).sort());
                this.renderFilterOptions('risk', Array.from(uniqueRisks).sort());
                this.renderFilterOptions('responsibility', Array.from(uniqueResponsibilities).sort());
            },

            renderFilterOptions(type, options) {
                const container = document.getElementById(`${type}FilterList`);
                const mobileContainer = document.getElementById(`${type}FilterList_mobile`);
                const html = options.map((option, index) => `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="${option}" id="${type}Filter-${index}">
                        <label class="form-check-label" for="${type}Filter-${index}" title="${option}">${option}</label>
                    </div>
                `).join('');
                container.innerHTML = html;
                if(mobileContainer) mobileContainer.innerHTML = html.replaceAll(`id="${type}Filter-`, `id="${type}Filter_mobile-`);
            },

            addEventListeners() {
                ['sop', 'risk', 'responsibility'].forEach(type => {
                    const setupListeners = (suffix = '') => {
                        const listContainer = document.getElementById(`${type}FilterList${suffix}`);
                        const searchInput = document.getElementById(`${type}SearchInput${suffix}`);

                        listContainer.addEventListener('change', e => {
                            if (e.target.type === 'checkbox') {
                                this.updateActiveFilters(type, e.target.value, e.target.checked);
                                this.updateMainFilterIcon();
                                this.syncCheckboxes(type, e.target.value, e.target.checked);
                                IncidentTableManager.displayPage(1);
                            }
                        });

                        searchInput.addEventListener('keyup', () => {
                            const searchTerm = searchInput.value.toLowerCase();
                            const items = listContainer.querySelectorAll('.form-check');
                            items.forEach(item => {
                                const label = item.querySelector('label');
                                item.style.display = label.textContent.toLowerCase().includes(searchTerm) ? '' : 'none';
                            });
                        });
                    };
                    setupListeners('');
                    setupListeners('_mobile');
                });
            },
            
            syncCheckboxes(type, value, isChecked) {
                document.querySelectorAll(`#${type}FilterList input[value="${value}"], #${type}FilterList_mobile input[value="${value}"]`).forEach(cb => {
                    cb.checked = isChecked;
                });
            },

            updateActiveFilters(type, value, isChecked) {
                const filterSet = new Set(this.activeFilters[type]);
                if (isChecked) {
                    filterSet.add(value);
                } else {
                    filterSet.delete(value);
                }
                this.activeFilters[type] = Array.from(filterSet);
            },
            
            updateMainFilterIcon() {
                const filterBtn = document.getElementById('detailsFilterBtn');
                if (!filterBtn) return;
                const hasActiveFilters = Object.values(this.activeFilters).some(arr => arr.length > 0);
                if (hasActiveFilters) {
                    filterBtn.classList.add('text-primary');
                } else {
                    filterBtn.classList.remove('text-primary');
                }
            },
            
            clear() {
                Object.keys(this.activeFilters).forEach(type => this.activeFilters[type] = []);
                document.querySelectorAll('#detailsFilterBtn + .dropdown-menu .form-check-input, #filterModal .form-check-input').forEach(chk => chk.checked = false);
                this.updateMainFilterIcon();
            }
        };

        const AreaFilterManager = {
            activeFilters: { region: [], unit: [], department: [], location: [] },

            init() {
                this.populateFilters();
                this.addEventListeners();
            },

            populateFilters() {
                const unique = {
                    region: new Set(),
                    unit: new Set(),
                    department: new Set(),
                    location: new Set()
                };

                IncidentTableManager.allTableRows.forEach(row => {
                    if (row.dataset.region) unique.region.add(row.dataset.region);
                    if (row.dataset.unit) unique.unit.add(row.dataset.unit);
                    if (row.dataset.department) unique.department.add(row.dataset.department);
                    if (row.dataset.location) unique.location.add(row.dataset.location);
                });

                Object.keys(unique).forEach(type => {
                    this.renderFilterOptions(type, Array.from(unique[type]).sort());
                });
            },

            renderFilterOptions(type, options) {
                 const container = document.getElementById(`${type}FilterList`);
                const mobileContainer = document.getElementById(`${type}FilterList_mobile`);
                const html = options.map((option, index) => `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="${option}" id="${type}Filter-${index}">
                        <label class="form-check-label" for="${type}Filter-${index}" title="${option}">${option}</label>
                    </div>
                `).join('');
                container.innerHTML = html;
                if(mobileContainer) mobileContainer.innerHTML = html.replaceAll(`id="${type}Filter-`, `id="${type}Filter_mobile-`);
            },

            addEventListeners() {
                Object.keys(this.activeFilters).forEach(type => {
                     const setupListeners = (suffix = '') => {
                        const listContainer = document.getElementById(`${type}FilterList${suffix}`);
                        const searchInput = document.getElementById(`${type}SearchInput${suffix}`);

                        listContainer.addEventListener('change', e => {
                            if (e.target.type === 'checkbox') {
                                this.updateActiveFilters(type, e.target.value, e.target.checked);
                                this.updateMainFilterIcon();
                                this.syncCheckboxes(type, e.target.value, e.target.checked);
                                IncidentTableManager.displayPage(1);
                            }
                        });

                        searchInput.addEventListener('keyup', () => {
                            const searchTerm = searchInput.value.toLowerCase();
                            const items = listContainer.querySelectorAll('.form-check');
                            items.forEach(item => {
                                const label = item.querySelector('label');
                                item.style.display = label.textContent.toLowerCase().includes(searchTerm) ? '' : 'none';
                            });
                        });
                    };
                    setupListeners('');
                    setupListeners('_mobile');
                });
            },
            
            syncCheckboxes(type, value, isChecked) {
                document.querySelectorAll(`#${type}FilterList input[value="${value}"], #${type}FilterList_mobile input[value="${value}"]`).forEach(cb => {
                    cb.checked = isChecked;
                });
            },

            updateActiveFilters(type, value, isChecked) {
                const filterSet = new Set(this.activeFilters[type]);
                if (isChecked) {
                    filterSet.add(value);
                } else {
                    filterSet.delete(value);
                }
                this.activeFilters[type] = Array.from(filterSet);
            },

            updateMainFilterIcon() {
                const filterBtn = document.getElementById('areaFilterBtn');
                if (!filterBtn) return;
                const hasActiveFilters = Object.values(this.activeFilters).some(arr => arr.length > 0);
                if (hasActiveFilters) {
                    filterBtn.classList.add('text-primary');
                } else {
                    filterBtn.classList.remove('text-primary');
                }
            },

            clear() {
                Object.keys(this.activeFilters).forEach(type => this.activeFilters[type] = []);
                document.querySelectorAll('#areaFilterBtn + .dropdown-menu .form-check-input, #filterModal .form-check-input').forEach(chk => chk.checked = false);
                this.updateMainFilterIcon();
            }
        };

        const StatusFilterManager = {
            activeFilters: { status: [] },

            init() {
                this.populateFilters();
                this.addEventListeners();
            },

            populateFilters() {
                const statuses = ['Open', 'Resolved', 'In Progress', 'Verified', 'Not Applicable', 'Follow-up Created'];
                this.renderFilterOptions('status', statuses);
            },

            renderFilterOptions(type, options) {
                 const container = document.getElementById(`${type}FilterList`);
                const mobileContainer = document.getElementById(`${type}FilterList_mobile`);
                const html = options.map((option, index) => `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="${option}" id="${type}Filter-${index}">
                        <label class="form-check-label" for="${type}Filter-${index}">${option}</label>
                    </div>
                `).join('');
                 container.innerHTML = html;
                if(mobileContainer) mobileContainer.innerHTML = html.replaceAll(`id="${type}Filter-`, `id="${type}Filter_mobile-`);
            },
            
            addEventListeners() {
                 const setupListeners = (suffix = '') => {
                    const listContainer = document.getElementById(`statusFilterList${suffix}`);
                    const searchInput = document.getElementById(`statusSearchInput${suffix}`);

                    listContainer.addEventListener('change', e => {
                        if (e.target.type === 'checkbox') {
                            this.updateActiveFilters('status', e.target.value, e.target.checked);
                            this.updateMainFilterIcon();
                            this.syncCheckboxes('status', e.target.value, e.target.checked);
                            IncidentTableManager.displayPage(1);
                        }
                    });

                    searchInput.addEventListener('keyup', () => {
                        const searchTerm = searchInput.value.toLowerCase();
                        const items = listContainer.querySelectorAll('.form-check');
                        items.forEach(item => {
                            const label = item.querySelector('label');
                            item.style.display = label.textContent.toLowerCase().includes(searchTerm) ? '' : 'none';
                        });
                    });
                };
                setupListeners('');
                setupListeners('_mobile');
            },

            syncCheckboxes(type, value, isChecked) {
                document.querySelectorAll(`#${type}FilterList input[value="${value}"], #${type}FilterList_mobile input[value="${value}"]`).forEach(cb => {
                    cb.checked = isChecked;
                });
            },

            updateActiveFilters(type, value, isChecked) {
                const filterSet = new Set(this.activeFilters[type]);
                if (isChecked) filterSet.add(value);
                else filterSet.delete(value);
                this.activeFilters[type] = Array.from(filterSet);
            },

            updateMainFilterIcon() {
                const filterBtn = document.getElementById('statusFilterBtn');
                if (!filterBtn) return;
                const hasActiveFilters = this.activeFilters.status.length > 0;
                if (hasActiveFilters) filterBtn.classList.add('text-primary');
                else filterBtn.classList.remove('text-primary');
            },
            
            clear() {
                this.activeFilters.status = [];
                document.querySelectorAll('#statusFilterList .form-check-input, #statusFilterList_mobile .form-check-input').forEach(chk => chk.checked = false);
                this.updateMainFilterIcon();
            }
        };

        const TrackingStatusFilterManager = {
            activeFilters: {
                reportingFrom: '', reportingTo: '',
                closureFrom: '', closureTo: '',
                timelineStages: []
            },

            init() {
                this.addEventListeners();
            },

            addEventListeners() {
                const setupListeners = (suffix = '') => {
                    const container = suffix 
                        ? document.getElementById('collapseTracking') 
                        : document.getElementById('trackingFilterBtn').nextElementSibling;
                    
                    container.addEventListener('change', e => {
                        this.updateActiveFilters();
                        this.updateMainFilterIcon();
                        this.syncInputs();
                        IncidentTableManager.displayPage(1);
                    });
                };
                setupListeners('');
                setupListeners('_mobile');
            },
            
            updateActiveFilters() {
                this.activeFilters.reportingFrom = document.getElementById('reportingDateFrom').value;
                this.activeFilters.reportingTo = document.getElementById('reportingDateTo').value;
                this.activeFilters.closureFrom = document.getElementById('closureDateFrom').value;
                this.activeFilters.closureTo = document.getElementById('closureDateTo').value;
                this.activeFilters.timelineStages = Array.from(document.querySelectorAll('#timelineStageFilterList input:checked')).map(cb => cb.value);
            },
            
            syncInputs() {
                const desktopIds = ['reportingDateFrom', 'reportingDateTo', 'closureDateFrom', 'closureDateTo'];
                desktopIds.forEach(id => {
                    document.getElementById(id + '_mobile').value = document.getElementById(id).value;
                });
                
                const stageIds = ['pendingOwnerAck', 'pendingAssignment', 'pendingStaffAck', 'pendingCompletion'];
                stageIds.forEach(id => {
                    document.getElementById(id + '_mobile').checked = document.getElementById(id).checked;
                });
            },
            
            updateMainFilterIcon() {
                const filterBtn = document.getElementById('trackingFilterBtn');
                const hasActiveFilters = this.activeFilters.reportingFrom || this.activeFilters.reportingTo ||
                                         this.activeFilters.closureFrom || this.activeFilters.closureTo ||
                                         this.activeFilters.timelineStages.length > 0;
                if (hasActiveFilters) {
                    filterBtn.classList.add('text-primary');
                } else {
                    filterBtn.classList.remove('text-primary');
                }
            },
            
            clear() {
                ['reportingDateFrom', 'reportingDateTo', 'closureDateFrom', 'closureDateTo'].forEach(id => {
                    document.getElementById(id).value = '';
                    document.getElementById(id + '_mobile').value = '';
                });
                ['pendingOwnerAck', 'pendingAssignment', 'pendingStaffAck', 'pendingCompletion'].forEach(id => {
                     document.getElementById(id).checked = false;
                     document.getElementById(id + '_mobile').checked = false;
                });

                this.updateActiveFilters();
                this.updateMainFilterIcon();
            }
        };
    
        // Main object for managing the incidents table.
        const IncidentTableManager = {
            allTableRows: [], activeRows: [], currentPage: 1, itemsPerPage: 3, 
            staffData: [ { id: "E021", name: "Ajay S." }, { id: "E045", name: "Mohan K." }, { id: "T001", name: "Engineering Team" } ],
            KEYWORD_WEIGHTS: { food: 10, pipe: 8, wiring: 12, alarm: 15, leak: 8 },
            SEVERITY_MARKINGS: { Critical: 10, Major: 5, Minor: 2 },
            
            init() {
                initialReportData.forEach(data => ReportProcessor.createAndDisplayRow(data));
                
                this.activeRows = [...this.allTableRows];

                this.setupPagination();
                this.attachEventListeners();
                this.initBulkActions();
                this.startReminderNotifications();
                this.initAssignModal();
                this.initBreakdownModals();
                this.setupBulkUpload(); 
                this.updateTimers();
                setInterval(this.updateTimers.bind(this), 60000);

                document.getElementById('confirmNaBtn').addEventListener('click', () => this.handleNaConfirmation());
                document.getElementById('confirmNonComplianceBtn').addEventListener('click', () => this.handleNonComplianceConfirmation());
                document.getElementById('nonCompliancePhoto').addEventListener('change', (e) => {
                    const [file] = e.target.files;
                    if (file) {
                        const preview = document.getElementById('nonCompliancePhotoPreview');
                        const container = document.getElementById('nonCompliancePhotoPreviewContainer');
                        preview.src = URL.createObjectURL(file);
                        container.classList.remove('d-none');
                    }
                });
                
                GlobalFilterManager.init();
                FilterManager.init();
                AreaFilterManager.init();
                StatusFilterManager.init();
                TrackingStatusFilterManager.init();

                this.displayPage(1);
            },

            clearAllFilters() {
                GlobalFilterManager.clear();
                FilterManager.clear();
                AreaFilterManager.clear();
                StatusFilterManager.clear();
                TrackingStatusFilterManager.clear();
                this.displayPage(1);
            },

            setupBulkUpload() {
                const modalEl = document.getElementById('bulkUploadModal');
                const dropzone = document.getElementById('bulkUploadDropzone');
                const fileInput = document.getElementById('bulkImageInput');
                const previewArea = document.getElementById('bulkUploadPreviewArea');
                const locationSearch = document.getElementById('bulkLocationSearch');
                const locationValue = document.getElementById('bulkLocationSelectValue');
                const locationList = document.getElementById('bulkLocationList');
                const processBtn = document.getElementById('processBulkUploadBtn');
                const processBtnSpinner = processBtn.querySelector('.spinner-border');
                const imageCountSpan = document.getElementById('bulkImageCount');
                
                const allLocations = [
                    
              @foreach($locations as $location)
    @php 
        $department_name = DB::table('departments')->where('id', $location->department_id)->value('name');
        $unit = DB::table('users')->where('id', $location->created_by)->first();
        
        $regional = DB::table('users')->where('id', $unit->created_by1)->first();
        $corporate = DB::table('users')->where('id', $unit->created_by)->first();
        
    @endphp
    "{{ $corporate->name ?? '' }} / {{ $regional->name ?? '' }} / {{ $unit->name ?? '' }} / {{ $department_name }} / {{ $location->name ?? '' }}",
@endforeach
                ];

                const checkProcessButtonState = () => {
                    const hasLocation = locationValue.value.trim() !== '';
                    const hasFiles = bulkUploadFiles.length > 0;
                    processBtn.disabled = !(hasLocation && hasFiles);
                };

                const updateBulkUploadUI = () => {
                    previewArea.innerHTML = '';
                    bulkUploadFiles.forEach((file, index) => {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            const card = document.createElement('div');
                            card.className = 'bulk-preview-card';
                            card.innerHTML = `
                                <img src="${e.target.result}" alt="${file.name}">
                                <div class="remove-bulk-image-btn" data-index="${index}" title="Remove image">&times;</div>
                            `;
                            previewArea.appendChild(card);
                        }
                        reader.readAsDataURL(file);
                    });
                    imageCountSpan.textContent = bulkUploadFiles.length;
                    checkProcessButtonState();
                };

                const renderLocationList = (filter = '') => {
                    locationList.innerHTML = '';
                    const filtered = allLocations.filter(loc => loc.toLowerCase().includes(filter.toLowerCase()));
                    if (filtered.length === 0) {
                        locationList.innerHTML = `<li><span class="dropdown-item-text text-muted">No locations found</span></li>`;
                    } else {
                        filtered.forEach(loc => {
                            const li = document.createElement('li');
                            const a = document.createElement('a');
                            a.className = 'dropdown-item';
                            a.href = '#';
                            a.textContent = loc;
                            a.addEventListener('click', (e) => {
                                e.preventDefault();
                                locationSearch.value = loc;
                                locationValue.value = loc;
                                checkProcessButtonState();
                                const dropdown = bootstrap.Dropdown.getInstance(locationSearch) || new bootstrap.Dropdown(locationSearch);
                                dropdown.hide();
                            });
                            li.appendChild(a);
                            locationList.appendChild(li);
                        });
                    }
                };

                locationSearch.addEventListener('keyup', () => renderLocationList(locationSearch.value));
                locationSearch.addEventListener('focus', () => renderLocationList(locationSearch.value));
                
                const handleFiles = (files) => {
                    const newFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
                    bulkUploadFiles.push(...newFiles);
                    updateBulkUploadUI();
                };

                fileInput.addEventListener('change', () => handleFiles(fileInput.files));
                
                dropzone.addEventListener('dragover', (e) => { e.preventDefault(); dropzone.classList.add('is-dragover'); });
                dropzone.addEventListener('dragleave', () => dropzone.classList.remove('is-dragover'));
                dropzone.addEventListener('drop', (e) => { e.preventDefault(); dropzone.classList.remove('is-dragover'); handleFiles(e.dataTransfer.files); });
                
                previewArea.addEventListener('click', (e) => {
                    if (e.target.classList.contains('remove-bulk-image-btn')) {
                        const index = parseInt(e.target.dataset.index, 10);
                        bulkUploadFiles.splice(index, 1);
                        updateBulkUploadUI();
                    }
                });


$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    }
});
                processBtn.addEventListener('click', async () => {
    processBtn.disabled = true;
    processBtnSpinner.classList.remove('d-none');

    const location = locationValue.value;
    const compressionPromises = bulkUploadFiles.map(file => compressImage(file));
    const compressedFiles = await Promise.all(compressionPromises);

    if (navigator.onLine) {
        const formData = new FormData();
        formData.append('location', location);
        compressedFiles.forEach((file, index) => {
            formData.append(`files[${index}]`, file);
        });

        $.ajax({
            url: '{{ route("bulkuploaddata") }}',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                console.log('Complaint saved:', response);
                alert(`${compressedFiles.length} images have been successfully added.`);

                concernInput.innerHTML = "";
                complaintInputWrapper.classList.remove('is-typing');
                document.querySelector('#complaint-sentence-template').style.display = 'none';

                selectedSops.length = 0;
                selectedLocations.length = 0;
                selectedResponsibilities.length = 0;
                selectedPeople.length = 0;
                selectedEquipment.length = 0;
                selectedFood.length = 0;

                allLocations = [...initialLocations];
                allResponsibilities = [...initialResponsibilities];

                document.dispatchEvent(new CustomEvent('form-reset'));

                window.location.href = "https://efsm.safefoodmitra.com/admin/public/index.php/inspection/newlist";
            },
            error: function (xhr) {
                alert("Failed to submit complaint. Please try again.");
                console.error(xhr.responseText);
            },
            complete: function () {
                processBtn.disabled = false;
                processBtnSpinner.classList.add('d-none');
            }
        });
    } else {
        for (const file of compressedFiles) {
            const draft = {
                id: `draft-${Date.now()}-${Math.random()}`,
                concern: "Bulk Upload (Draft)",
                location: location,
                files: [file]
            };
            await OfflineManager.saveDraft(draft);
            ReportProcessor.createAndDisplayDraftRow(draft);
        }
        alert(`You are offline. ${compressedFiles.length} images saved as drafts.`);
        processBtn.disabled = false;
        processBtnSpinner.classList.add('d-none');
    }

    this.displayPage(this.currentPage);
    ActionModals.bulkUpload.hide();
});

                modalEl.addEventListener('hidden.bs.modal', () => {
                    bulkUploadFiles = [];
                    locationSearch.value = '';
                    locationValue.value = '';
                    fileInput.value = '';
                    updateBulkUploadUI();
                });
            },

            getFormattedTime: () => new Date().toLocaleTimeString('en-US', { hour: "2-digit", minute: "2-digit", hour12: false }),
            calculateAndSetRiskScore(row) {
                const title = (row.querySelector(".concern-title")?.textContent || "").toLowerCase();
                const risk = row.dataset.risk;
                const keywordScore = Object.keys(this.KEYWORD_WEIGHTS).reduce((score, key) => title.includes(key) ? score + this.KEYWORD_WEIGHTS[key] : score, 0);
                const totalScore = keywordScore + (this.SEVERITY_MARKINGS[risk] || 0);
                const level = totalScore > 15 ? "High" : totalScore > 8 ? "Medium" : "Low";
                const badge = row.querySelector(".risk-score-badge");
                if (badge) badge.innerHTML = `<i class="fas fa-calculator me-1"></i>Risk: ${totalScore} (${level})`;
            },
            formatDuration(ms) {
                if (ms < 0) return "0m"; let t = Math.floor(ms / 60000); const d = Math.floor(t / 1440); t %= 1440; const h = Math.floor(t / 60); t %= 60; return [d && `${d}d`, h && `${h}h`, t >= 0 && `${t}m`].filter(Boolean).join(' ') || "0m";
            },
            updateTimers() {
                document.querySelectorAll("tr[data-reported-time]").forEach(row => {
                    row.querySelectorAll(".time-since-reported").forEach(timerEl => {
                        const start = new Date(row.dataset.reportedTime);
                        const end = row.dataset.completedTime ? new Date(row.dataset.completedTime) : new Date();
                        timerEl.textContent = `${this.formatDuration(end - start)} ${row.dataset.completedTime ? 'total' : 'ago'}`;
                    });
                });
            },
            setupPagination() {
                document.getElementById("itemsPerPageSelect").addEventListener("change", e => { this.itemsPerPage = parseInt(e.target.value, 10); this.displayPage(1); });
                document.getElementById("paginationControls").addEventListener("click", e => {
                    e.preventDefault(); const link = e.target.closest("a");
                    if (!link || link.parentElement.classList.contains("disabled") || link.parentElement.classList.contains("active")) return;
                    const page = link.dataset.page, totalPages = Math.ceil(this.activeRows.length / this.itemsPerPage);
                    if (page === "prev") { if (this.currentPage > 1) this.displayPage(this.currentPage - 1); }
                    else if (page === "next") { if (this.currentPage < totalPages) this.displayPage(this.currentPage + 1); }
                    else this.displayPage(parseInt(page, 10));
                });
            },
            displayPage(page) {
                this.currentPage = page || 1;
                this.applyAllFilters();
                
                this.allTableRows.forEach(row => row.style.display = 'none');
                
                const start = (this.currentPage - 1) * this.itemsPerPage;
                const end = start + this.itemsPerPage;

                this.activeRows.slice(start, end).forEach(row => {
                    row.style.display = 'table-row';
                });

                this.renderPaginationControls(); this.updatePaginationInfo();
            },
            renderPaginationControls() {
                const controls = document.getElementById("paginationControls"), totalPages = Math.ceil(this.activeRows.length / this.itemsPerPage);
                controls.innerHTML = ""; if (totalPages <= 1) return;
                const createItem = (p, t, d = false, a = false) => `<li class="page-item ${d ? 'disabled' : ''} ${a ? 'active' : ''}"><a class="page-link" href="#" data-page="${p}">${t}</a></li>`;
                controls.innerHTML += createItem("prev", "«", this.currentPage === 1);
                for (let i = 1; i <= totalPages; i++) controls.innerHTML += createItem(i, i, false, i === this.currentPage);
                controls.innerHTML += createItem("next", "»", this.currentPage === totalPages);
            },
            updatePaginationInfo() {
                const info = document.getElementById("paginationInfo"), total = this.activeRows.length, start = total > 0 ? (this.currentPage - 1) * this.itemsPerPage + 1 : 0, end = Math.min(start + this.itemsPerPage - 1, total);
                info.textContent = `Showing ${start} to ${end} of ${total} entries`;
            },
            applyAllFilters() {
                this.activeRows = this.allTableRows.filter(row => {
                    if (row.classList.contains('is-draft')) return false;

                    const sopMatch = FilterManager.activeFilters.sop.length === 0 || FilterManager.activeFilters.sop.includes(row.dataset.sop);
                    const riskMatch = FilterManager.activeFilters.risk.length === 0 || FilterManager.activeFilters.risk.includes(row.dataset.risk);
                    const respEl = row.querySelector('.concern-responsibility span');
                    const responsibilityMatch = FilterManager.activeFilters.responsibility.length === 0 || (respEl && FilterManager.activeFilters.responsibility.includes(respEl.textContent));

                    const regionMatch = AreaFilterManager.activeFilters.region.length === 0 || AreaFilterManager.activeFilters.region.includes(row.dataset.region);
                    const unitMatch = AreaFilterManager.activeFilters.unit.length === 0 || AreaFilterManager.activeFilters.unit.includes(row.dataset.unit);
                    const departmentMatch = AreaFilterManager.activeFilters.department.length === 0 || AreaFilterManager.activeFilters.department.includes(row.dataset.department);
                    const locationMatch = AreaFilterManager.activeFilters.location.length === 0 || AreaFilterManager.activeFilters.location.includes(row.dataset.location);

                    const statusMatch = StatusFilterManager.activeFilters.status.length === 0 || StatusFilterManager.activeFilters.status.includes(row.dataset.status);
                    
                    const { reportingFrom, reportingTo, closureFrom, closureTo, timelineStages } = TrackingStatusFilterManager.activeFilters;
                    let trackingMatch = true;
                    
                    if (reportingFrom || reportingTo) {
                        const reportedTime = new Date(row.dataset.reportedTime).setHours(0,0,0,0);
                        const from = reportingFrom ? new Date(reportingFrom).getTime() : -Infinity;
                        const to = reportingTo ? new Date(reportingTo).getTime() : Infinity;
                        if (reportedTime < from || reportedTime > to) trackingMatch = false;
                    }

                    if (trackingMatch && (closureFrom || closureTo)) {
                        if (!row.dataset.completedTime) {
                            trackingMatch = false;
                        } else {
                            const completedTime = new Date(row.dataset.completedTime).setHours(0,0,0,0);
                            const from = closureFrom ? new Date(closureFrom).getTime() : -Infinity;
                            const to = closureTo ? new Date(closureTo).getTime() : Infinity;
                            if (completedTime < from || completedTime > to) trackingMatch = false;
                        }
                    }
                    
                    if (trackingMatch && timelineStages.length > 0) {
                        const steps = row.querySelectorAll('.progress-tracker .step');
                        const stageChecks = {
                            owner: steps[1] && !steps[1].classList.contains('is-completed'),
                            assignment: steps[2] && !steps[2].classList.contains('is-completed'),
                            staff: steps[3] && !steps[3].classList.contains('is-completed'),
                            completion: steps[4] && !steps[4].classList.contains('is-completed')
                        };
                        const timelineStageMatch = timelineStages.some(stage => stageChecks[stage]);
                        if (!timelineStageMatch) trackingMatch = false;
                    }

                    const followUpMatch = !GlobalFilterManager.showFollowUpsOnly || row.dataset.starred === 'true';
                    const breakdownMatch = !GlobalFilterManager.showBreakdownsOnly || row.dataset.isBreakdown === 'true';

                    return sopMatch && riskMatch && responsibilityMatch && regionMatch && unitMatch && departmentMatch && locationMatch && statusMatch && trackingMatch && followUpMatch && breakdownMatch;
                });
            },
            initBulkActions() {}, updateBulkActionUI() {}, initAssignModal() {}, addCheckboxToRowIfNeeded(row) {},
            getSelectedRows: () => Array.from(document.querySelectorAll('.row-checkbox:checked')).map(cb => cb.closest('tr')),
            startReminderNotifications() {},
            
            updateRowUI(row) {
                const status = row.dataset.status;
                const isStarred = row.dataset.starred === 'true';
                const isBreakdown = row.dataset.isBreakdown === 'true';
                const breakdownStatus = row.dataset.breakdownStatus;
                
                const isFinalState = ['Resolved', 'Verified', 'Not Applicable', 'Follow-up Created'].includes(status);

                const statusMap = {
                    'Open': { class: 'status-open', icon: 'fa-exclamation-circle' },
                    'In Progress': { class: 'status-in-progress', icon: 'fa-tasks' },
                    'Resolved': { class: 'status-resolved', icon: 'fa-check-circle' },
                    'Verified': { class: 'status-verified', icon: 'fa-user-check' },
                    'Not Applicable': { class: 'status-not-applicable', icon: 'fa-ban' },
                    'Follow-up Created': { class: 'status-follow-up-created', icon: 'fa-copy' }
                };
                const statusInfo = statusMap[status] || { class: 'status-open', icon: 'fa-exclamation-circle' };
                row.querySelectorAll('.status-badge').forEach(badge => {
                    badge.className = `status-badge ${statusInfo.class}`;
                    badge.innerHTML = `<i class="fas ${statusInfo.icon} me-1"></i> ${status}`;
                });
                
                const visibility = {
                    '.btn-compliance': isFinalState && isStarred,
                    '.btn-not-compliance': true,
                    '.btn-not-applicable': isFinalState && isStarred,
                    '.btn-assign': !isFinalState,
                    '.btn-complete-task': !isFinalState,
                    '.btn-progress': !isFinalState,
                    '.btn-edit': !isFinalState,
                    '.btn-delete': !isFinalState,
                    '.btn-view': isFinalState,
                    '.btn-breakdown': !isFinalState && !isBreakdown,
                    '.btn-breakdown-update': isBreakdown
                };
                
                for (const selector in visibility) {
                    row.querySelectorAll(selector).forEach(btn => {
                        btn.style.display = visibility[selector] ? 'inline-flex' : 'none';
                    });
                }
                
                row.querySelectorAll('.btn-not-compliance').forEach(btn => {
                    btn.title = isFinalState ? 'Re-open as new observation' : 'Log Non-Compliance';
                });

                if (isBreakdown) {
                    row.querySelectorAll('.btn-breakdown-update').forEach(btn => {
                        const equipmentName = row.dataset.breakdownEquipment || "Breakdown";
                        if (breakdownStatus === 'pending-verification') {
                            btn.className = 'action-btn btn btn-sm btn-warning btn-breakdown-update';
                            btn.innerHTML = `<i class="fas fa-user-check"></i>`;
                            btn.title = `Verify ${equipmentName} Closure`;
                        } else if (breakdownStatus === 'resolved') {
                            btn.className = 'action-btn btn btn-sm btn-outline-success btn-breakdown-update';
                            btn.innerHTML = `<i class="fas fa-history"></i>`;
                            btn.title = `View ${equipmentName} History Card`;
                        } else { 
                             btn.className = 'action-btn btn-breakdown-update';
                             btn.innerHTML = '<i class="fas fa-tasks text-primary"></i>';
                             btn.title = "Update Breakdown Status";
                        }
                    });
                }
            },

            initBreakdownModals() {
                const breakdownModalEl = document.getElementById('breakdownModal');
                
                let equipmentSearchHandler;

                breakdownModalEl.addEventListener('show.bs.modal', e => {
                    const incidentId = e.relatedTarget.closest('tr').dataset.incidentId;
                    const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                    document.getElementById('breakdownIncidentId').value = incidentId;
                    
                    const equipmentSearchInput = document.getElementById('breakdownEquipmentSearch');
                    const equipmentHiddenInput = document.getElementById('breakdownEquipment');
                    const equipmentListContainer = document.getElementById('breakdownEquipmentList');
                    
                    equipmentSearchInput.value = ''; equipmentHiddenInput.value = ''; equipmentListContainer.innerHTML = '';

                    const department = row.dataset.department;
                    const location = row.dataset.location;
                    const key = `${department}-${location}`;
                    const equipmentOptions = dummyEquipmentData[key] || dummyEquipmentData['Default'];
                    
                    const fuse = new Fuse(equipmentOptions, { threshold: 0.4 });

                    const renderList = (items) => {
                        equipmentListContainer.innerHTML = '';
                        if (items.length === 0) {
                            equipmentListContainer.innerHTML = '<li><span class="dropdown-item-text text-muted">No equipment found</span></li>';
                            return;
                        }
                        items.forEach(item => {
                            const li = document.createElement('li');
                            const a = document.createElement('a');
                            a.className = 'dropdown-item'; a.href = '#'; a.style.cursor = 'pointer'; a.textContent = item;
                            a.addEventListener('click', (evt) => {
                                evt.preventDefault();
                                equipmentSearchInput.value = item; equipmentHiddenInput.value = item;
                                const dropdown = bootstrap.Dropdown.getInstance(equipmentSearchInput);
                                if (dropdown) dropdown.hide();
                            });
                            li.appendChild(a); equipmentListContainer.appendChild(li);
                        });
                    };
                    if (equipmentSearchHandler) { equipmentSearchInput.removeEventListener('keyup', equipmentSearchHandler); }
                    equipmentSearchHandler = () => {
                        const searchTerm = equipmentSearchInput.value;
                        if (!searchTerm) { renderList(equipmentOptions); } 
                        else { renderList(fuse.search(searchTerm).map(result => result.item)); }
                    };
                    equipmentSearchInput.addEventListener('keyup', equipmentSearchHandler);
                    renderList(equipmentOptions);
                    
                    if(row.dataset.isBreakdown === 'true') {
                        equipmentSearchInput.value = row.dataset.breakdownEquipment || '';
                        equipmentHiddenInput.value = row.dataset.breakdownEquipment || '';
                        document.getElementById('breakdownRootCause').value = row.dataset.breakdownRootCause || '';
                        document.getElementById('breakdownClosureDate').value = row.dataset.breakdownClosureDate || '';
                        document.getElementById('breakdownStepTaken').value = row.dataset.breakdownStepTaken || '';
                    } else {
                       document.getElementById('breakdownForm').reset();
                       equipmentSearchInput.value = ''; equipmentHiddenInput.value = '';
                    }
                });

                document.getElementById('confirmBreakdownBtn').addEventListener('click', () => {
                    const incidentId = document.getElementById('breakdownIncidentId').value;
                    const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                    if (!row) return;

                    Object.assign(row.dataset, {
                        isBreakdown: 'true',
                        breakdownStatus: 'active',
                        breakdownStartTime: new Date().toISOString(),
                        breakdownTotalCost: '0',
                        breakdownEquipment: document.getElementById('breakdownEquipment').value,
                        breakdownRootCause: document.getElementById('breakdownRootCause').value,
                        breakdownClosureDate: document.getElementById('breakdownClosureDate').value,
                        breakdownStepTaken: document.getElementById('breakdownStepTaken').value
                    });

                    const firstHistoryEntry = {
                        date: row.dataset.breakdownStartTime, reportedBy: row.dataset.registeredBy, breakdownReason: row.dataset.breakdownRootCause,
                        tentativeDate: row.dataset.breakdownClosureDate, correctiveAction: row.dataset.breakdownStepTaken, incurredExpenses: '0.00'
                    };
                    ReportHistoryManager.addBreakdownHistoryEntry(incidentId, firstHistoryEntry);
                    
                    row.classList.add('is-breakdown');
                    const statusCell = row.querySelector('td[data-label="Status"] > div');
                    if (statusCell && !statusCell.querySelector('.badge-breakdown')) { statusCell.insertAdjacentHTML('beforeend', '<span class="badge badge-breakdown mt-1">Breakdown</span>'); }
                    
                    this.updateRowUI(row);
                    
                    ActionModals.breakdown.hide();
                    AlertManager.showBreakdown(`BREAKDOWN REPORTED: ${row.dataset.breakdownEquipment} in ${row.dataset.location}.`);
                });


                const breakdownUpdateModalEl = document.getElementById('breakdownUpdateModal');
                breakdownUpdateModalEl.addEventListener('show.bs.modal', e => {
                    const incidentId = e.relatedTarget.closest('tr').dataset.incidentId;
                    const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                    document.getElementById('breakdownUpdateIncidentId').value = incidentId;
                    
                    const equipmentName = row.dataset.breakdownEquipment || "Equipment";
                    document.getElementById('breakdownUpdateModalLabel').textContent = `(${equipmentName}) Breakdown Status Update`;

                    const updateFormContainer = document.getElementById('breakdownUpdateFormContainer');
                    const postUpdateButton = document.getElementById('confirmBreakdownUpdateBtn');
                    const resolveButton = document.getElementById('confirmBreakdownResolveBtn');
                    const isReadOnly = row.dataset.breakdownStatus === 'resolved' || row.dataset.status === 'Resolved';
                    
                    updateFormContainer.style.display = 'block';
                    updateFormContainer.querySelectorAll('input, textarea').forEach(el => el.disabled = isReadOnly);
                    postUpdateButton.style.display = isReadOnly ? 'none' : 'inline-block';
                    resolveButton.style.display = isReadOnly ? 'none' : 'inline-block';
                    
                    if (!isReadOnly) {
                        document.getElementById('breakdownUpdateForm').reset();
                        document.getElementById('breakdownUpdateDate').value = new Date().toISOString().split('T')[0];
                    }
                    this.populateBreakdownHistory(incidentId, document.getElementById('breakdownHistoryContainer'));
                });
                
                document.getElementById('confirmBreakdownUpdateBtn').addEventListener('click', () => {
                    const incidentId = document.getElementById('breakdownUpdateIncidentId').value;
                    const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                    if(!row) return;

                    const comments = document.getElementById('breakdownUpdateComments').value;
                    const cost = parseFloat(document.getElementById('breakdownUpdateCost').value) || 0;
                    const updateDate = document.getElementById('breakdownUpdateDate').value;

                    if (!comments.trim()) { alert('Corrective Action/Comments are required for an update.'); return; }
                    
                    const updateHistoryEntry = {
                        date: new Date(updateDate).toISOString(), reportedBy: row.dataset.registeredBy, correctiveAction: comments,
                        incurredExpenses: cost.toFixed(2), rectifiedBy: row.dataset.assignedTo || 'System'
                    };
                    ReportHistoryManager.addBreakdownHistoryEntry(incidentId, updateHistoryEntry);

                    let currentCost = parseFloat(row.dataset.breakdownTotalCost) || 0;
                    row.dataset.breakdownTotalCost = currentCost + cost;

                    this.populateBreakdownHistory(incidentId, document.getElementById('breakdownHistoryContainer'));
                    document.getElementById('breakdownUpdateForm').reset();
                    document.getElementById('breakdownUpdateDate').value = new Date().toISOString().split('T')[0];
                });

                document.getElementById('confirmBreakdownResolveBtn').addEventListener('click', () => {
                    const incidentId = document.getElementById('breakdownUpdateIncidentId').value;
                    const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                    if (!row) return;
                    
                    row.dataset.breakdownStatus = 'pending-verification';
                    this.updateRowUI(row);

                    ActionModals.breakdownUpdate.hide();
                    AlertManager.showVerification(`PENDING VERIFICATION: ${row.dataset.breakdownEquipment} in ${row.dataset.location} is ready for closure verification.`);
                });
                
                const verificationModalEl = document.getElementById('breakdownVerificationModal');
                const vCanvas = document.getElementById('verificationSignaturePad');
                const vCtx = vCanvas.getContext('2d');
                let vDrawing = false, vHasSigned = false;

                function getPointerPos(canvasDom, pointerEvent) {
                    const rect = canvasDom.getBoundingClientRect();
                    return { x: pointerEvent.clientX - rect.left, y: pointerEvent.clientY - rect.top };
                }
                vCanvas.addEventListener('mousedown', (e) => { vDrawing = true; const pos = getPointerPos(vCanvas, e); vCtx.beginPath(); vCtx.moveTo(pos.x, pos.y); });
                vCanvas.addEventListener('mouseup', () => { vDrawing = false; });
                vCanvas.addEventListener('mousemove', (e) => { if (vDrawing) { vHasSigned = true; const pos = getPointerPos(vCanvas, e); vCtx.lineTo(pos.x, pos.y); vCtx.stroke(); }});
                document.getElementById('clearVerificationSignatureBtn').addEventListener('click', () => { vCtx.clearRect(0, 0, vCanvas.width, vCanvas.height); vHasSigned = false; });
                
                verificationModalEl.addEventListener('show.bs.modal', e => {
                    const incidentId = e.relatedTarget.closest('tr').dataset.incidentId;
                    document.getElementById('breakdownVerificationIncidentId').value = incidentId;
                    document.getElementById('verificationComments').value = '';
                    vCtx.clearRect(0, 0, vCanvas.width, vCanvas.height); vHasSigned = false;
                    this.populateBreakdownHistory(incidentId, document.getElementById('verificationHistoryContainer'), true);
                });

                document.getElementById('finalSubmitVerificationBtn').addEventListener('click', () => {
                    const incidentId = document.getElementById('breakdownVerificationIncidentId').value;
                    const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                    if (!row) return;

                    const comments = document.getElementById('verificationComments').value;
                    if (!comments.trim()) { alert('Verification comments are required.'); return; }
                    if (!vHasSigned) { alert('A signature is required for verification.'); return; }
                    
                    const resolutionTime = new Date();
                    const finalHistoryEntry = {
                        date: resolutionTime.toISOString(), correctiveAction: "Breakdown closure verified.",
                        closureDate: resolutionTime.toISOString(), rectifiedBy: row.dataset.assignedTo || 'System', verifiedBy: 'Manager (Verified)',
                        verificationDate: resolutionTime.toISOString(), verificationComments: comments, signature: vCanvas.toDataURL()
                    };
                    ReportHistoryManager.addBreakdownHistoryEntry(incidentId, finalHistoryEntry);

                    row.dataset.breakdownStatus = 'resolved';
                    this.updateRowStatus(row, 'Resolved');
                    
                    const tracker = row.querySelector('.progress-tracker');
                    if (tracker) { tracker.querySelectorAll('.step').forEach(step => step.classList.add('is-completed')); }
                    
                    row.classList.remove('is-breakdown');
                    if(row.querySelector('.badge-breakdown')) row.querySelector('.badge-breakdown').remove();
                    this.updateTimers();

                    ActionModals.breakdownVerification.hide();
                    AlertManager.showToast(`Breakdown for ${row.dataset.breakdownEquipment} has been verified and closed.`, 'success');
                });
                
                document.getElementById('rejectBreakdownBtn').addEventListener('click', () => {
                    const incidentId = document.getElementById('breakdownVerificationIncidentId').value;
                    const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                    if (!row) return;
                    
                    const comments = document.getElementById('verificationComments').value;
                    if (!comments.trim()) { alert('Rejection comments are required.'); return; }
                    
                    const rejectionTime = new Date();
                    const rejectionHistoryEntry = {
                        date: rejectionTime.toISOString(), correctiveAction: "Breakdown closure REJECTED.",
                        verifiedBy: 'Manager (Rejected)', verificationComments: comments
                    };
                    ReportHistoryManager.addBreakdownHistoryEntry(incidentId, rejectionHistoryEntry);

                    row.dataset.breakdownStatus = 'active';
                    this.updateRowUI(row);
                    ActionModals.breakdownVerification.hide();
                });
            },

            populateBreakdownHistory(incidentId, container, isSimple = false) {
                const history = (reportDatabase[incidentId]?.breakdownHistory || []).sort((a, b) => new Date(a.date) - new Date(b.date));

                if (history.length === 0) {
                    container.innerHTML = `<tr><td colspan="${isSimple ? 6 : 10}" class="text-center">No history yet.</td></tr>`;
                    return;
                }
                
                container.innerHTML = history.map(entry => {
                    const entryDate = new Date(entry.date);
                    const formattedReportedDate = `${entryDate.toLocaleDateString()} ${entryDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
                    let correctiveActionText = entry.correctiveAction || '---';
                    if (entry.verificationComments) {
                         correctiveActionText += `<div class="mt-2 pt-1 border-top" style="color: ${entry.correctiveAction.includes('REJECTED') ? 'var(--danger-color)' : 'var(--success-color)'};"><strong>Verification:</strong> ${entry.verificationComments}</div>`;
                    }

                    if (isSimple) {
                        return `
                        <tr>
                            <td>${formattedReportedDate}</td>
                            <td>${entry.reportedBy || '---'}</td>
                            <td>${entry.breakdownReason || '---'}</td>
                            <td>${correctiveActionText}</td>
                            <td>${entry.rectifiedBy || '---'}</td>
                            <td>₹${parseFloat(entry.incurredExpenses || 0).toFixed(2)}</td>
                        </tr>`;
                    } else {
                        const formattedTentativeDate = entry.tentativeDate ? new Date(entry.tentativeDate).toLocaleDateString() : '---';
                        const formattedClosureDate = entry.closureDate ? new Date(entry.closureDate).toLocaleDateString() : '---';
                        const formattedVerificationDate = entry.verificationDate ? new Date(entry.verificationDate).toLocaleDateString() : '---';
                        
                        let verifiedByContent = entry.verifiedBy || '---';
                        if (entry.signature) {
                            verifiedByContent += `<br><img src="${entry.signature}" alt="Signature" style="height: 30px; background-color: white; border: 1px solid #ddd; margin-top: 5px;">`;
                        }

                        return `
                        <tr>
                            <td>${formattedReportedDate}</td>
                            <td>${entry.reportedBy || '---'}</td>
                            <td>${entry.breakdownReason || '---'}</td>
                            <td>${formattedTentativeDate}</td>
                            <td>${correctiveActionText}</td>
                            <td>${formattedClosureDate}</td>
                            <td>${entry.rectifiedBy || '---'}</td>
                            <td>${verifiedByContent}</td>
                            <td>${formattedVerificationDate}</td>
                            <td>₹${parseFloat(entry.incurredExpenses || 0).toFixed(2)}</td>
                        </tr>`;
                    }
                }).join('');
            },

            showHistoryFor(incidentId) {
                const historyModal = ActionModals.history._element;
                historyModal.dataset.incidentId = incidentId;
                ReportComponent.init(incidentId);
                ActionModals.history.show();
            },

            attachEventListeners() {
                document.getElementById('refreshBtn').addEventListener('click', () => this.clearAllFilters());
                document.getElementById('clearFiltersModalBtn').addEventListener('click', () => this.clearAllFilters());

                
                document.getElementById('confirmClosureBtn').addEventListener('click', () => {
                    const incidentId = document.getElementById('closureIncidentId').value;
                    const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                    if(row) {
                         this.updateRowStatus(row, 'Resolved');
                         AlertManager.showToast(`Observation "${row.querySelector('.concern-title').textContent}" has been addressed.`, 'success');
                    }
                    ActionModals.closure.hide();
                });
                
                const table = document.getElementById('incidentReportTable');
                table.addEventListener('click', e => {
                    const originalLink = e.target.closest('a[data-original-id]');
                    if (originalLink) {
                        e.preventDefault();
                        const originalId = originalLink.dataset.originalId;
                        this.showHistoryFor(originalId);
                        return;
                    }
                    
                    const btn = e.target.closest('button, img, video');
                    if (!btn) return;
                    
                    if (btn.classList.contains('expand-toggle-btn')) {
                        const currentMobileCard = btn.closest('.complaint-card-mobile');
                        
                        // Collapse others before expanding the current one
                        document.querySelectorAll('.complaint-card-mobile.is-expanded').forEach(card => {
                            if (card !== currentMobileCard) {
                                card.classList.remove('is-expanded');
                                const otherBtn = card.querySelector('.expand-toggle-btn');
                                if(otherBtn) {
                                    otherBtn.querySelector('span').textContent = 'Show Details';
                                    const icon = otherBtn.querySelector('i');
                                    icon.classList.remove('fa-chevron-up');
                                    icon.classList.add('fa-chevron-down');
                                }
                            }
                        });

                        currentMobileCard.classList.toggle('is-expanded');

                        const textSpan = btn.querySelector('span');
                        const icon = btn.querySelector('i');
                        if (currentMobileCard.classList.contains('is-expanded')) {
                            textSpan.textContent = 'Hide Details';
                            icon.classList.replace('fa-chevron-down', 'fa-chevron-up');
                        } else {
                            textSpan.textContent = 'Show Details';
                            icon.classList.replace('fa-chevron-up', 'fa-chevron-down');
                        }
                        return;
                    }
                    
                    const row = btn.closest('tr');
                    if (!row) return;
                    
          if (btn.classList.contains('btn-star')) {
    const isCurrentlyStarred = row.dataset.starred === 'true';
    const newStarState = !isCurrentlyStarred;
    const inspectionId = row.dataset.incidentId; // मान लेते हैं कि row में id attribute है, जैसे <tr data-id="123">

    // UI Update
    row.dataset.starred = newStarState.toString();
    row.querySelectorAll('.btn-star').forEach(b => b.classList.toggle('is-starred', newStarState));
    row.querySelectorAll('.btn-star i').forEach(i => {
        i.classList.toggle('fas', newStarState);
        i.classList.toggle('far', !newStarState);
    });

    // UI Refresh
    this.updateRowUI(row);

    // === AJAX CALL ===
    $.ajax({
        url: '{{ route("followinspection") }}', // Laravel route
        method: 'POST',
        data: {
            inspection_id: inspectionId,
            starred: newStarState ? 1 : 0,
            _token: '{{ csrf_token() }}'
        },
        success: function (response) {
            console.log('FollowInspection updated:', response);
        },
        error: function (xhr) {
            console.error('Error updating FollowInspection:', xhr.responseText);
            alert('Something went wrong while updating follow inspection.');
        }
    });
}
                    else if(btn.classList.contains('btn-compliance')) {
                        const incidentId = row.dataset.incidentId;
                        ReportHistoryManager.addHistoryEntry(incidentId, { date: new Date().toISOString(), status: 'Compliance Verified', comments: 'The resolution has been verified as compliant.' });
                        this.updateRowStatus(row, 'Verified');
                        AlertManager.showToast('Report marked as compliant.', 'success');
                    }
                    else if(btn.classList.contains('btn-not-compliance')) {
                        document.getElementById('nonComplianceOriginalId').value = row.dataset.incidentId;
                        ActionModals.nonCompliance.show();
                    }
                    else if(btn.classList.contains('btn-not-applicable')) {
                        document.getElementById('naIncidentId').value = row.dataset.incidentId;
                        ActionModals.na.show();
                    }
                    else if(btn.classList.contains('btn-breakdown')) { ActionModals.breakdown.show(btn); }
                    else if(btn.classList.contains('btn-breakdown-update')) {
                        const status = row.dataset.breakdownStatus;
                        if (status === 'pending-verification') { ActionModals.breakdownVerification.show(btn); } 
                        else { ActionModals.breakdownUpdate.show(btn); }
                    }
                    else if(btn.classList.contains('btn-edit')) { ComplaintFormManager.populateForEdit(row); ActionModals.complaintForm.show(); }
                    else if (btn.classList.contains('btn-assign')) { ActionModals.assign.show(btn); }
                    else if (btn.classList.contains('btn-acknowledge-staff')) { ActionModals.staffAck.show(btn); }
                   // else if (btn.classList.contains('btn-complete-task')) { document.getElementById('closureIncidentId').value = row.dataset.incidentId; ActionModals.closure.show(btn); }
                   
                   else if (btn.classList.contains('btn-complete-task')) {
    document.getElementById('closureIncidentId').value = row.dataset.incidentId;
    
    // agar aapko ActionModals.closure.show(btn) ki zarurat nahi hai to ye hata dein:
    // ActionModals.closure.show(btn);

    // Bootstrap modal show karne ke liye:
    let myModal = new bootstrap.Modal(document.getElementById('exampleModal'));
    myModal.show();
}

                    else if (btn.classList.contains('btn-history') || btn.classList.contains('btn-progress') || btn.classList.contains('btn-view')) { ActionModals.history.show(btn); }
                    else if (btn.classList.contains('btn-delete') && confirm('Delete this report?')) { row.remove(); this.allTableRows = this.allTableRows.filter(r => r !== row); this.displayPage(this.currentPage); }
                    else if (btn.classList.contains('report-image-thumb')) {
                         const modalBody = document.querySelector("#imageModal .modal-body");
                         const mediaSrc = btn.tagName === 'IMG' ? btn.src : btn.querySelector('source')?.src || btn.src;
                         modalBody.innerHTML = btn.tagName === 'VIDEO' 
                            ? `<video src="${mediaSrc}" controls autoplay style="max-width:100%; max-height: 80vh;"></video>`
                            : `<img src="${mediaSrc}" class="img-fluid" />`;
                         ActionModals.image.show();
                    }
                });
                document.getElementById('newReportBtn').addEventListener('click', () => { ComplaintFormManager.prepareForNew(); });
            },

            handleNaConfirmation() {
                const incidentId = document.getElementById('naIncidentId').value;
                const comments = document.getElementById('naComments').value;
                const row = document.querySelector(`tr[data-incident-id="${incidentId}"]`);
                if (row && comments) {
                    ReportHistoryManager.addHistoryEntry(incidentId, { date: new Date().toISOString(), status: 'Not Applicable', comments: comments });
                    this.updateRowStatus(row, 'Not Applicable');
                    AlertManager.showToast('Report marked as Not Applicable.', 'info');
                    ActionModals.na.hide();
                    document.getElementById('naForm').reset();
                } else {
                    alert('Please provide a reason.');
                }
            },
            
            handleNonComplianceConfirmation() {
                const originalId = document.getElementById('nonComplianceOriginalId').value;
                const comments = document.getElementById('nonComplianceComments').value;
                const fileInput = document.getElementById('nonCompliancePhoto');
                const row = document.querySelector(`tr[data-incident-id="${originalId}"]`);
                if (!row || !comments.trim()) { alert('Please provide a reason.'); return; }

                const isClosed = ['Resolved', 'Verified'].includes(row.dataset.status);

                if(isClosed) { 
                    if(!fileInput.files.length) { alert('Please provide new evidence to re-open a task.'); return; }
                    
                    ReportHistoryManager.addHistoryEntry(originalId, { date: new Date().toISOString(), status: 'Non-Compliance Found', comments: `A new follow-up report was created. Reason: ${comments}` });
                    this.updateRowStatus(row, 'Follow-up Created');
                    
                    const originalCommentCell = row.querySelector('.closure-comments-cell');
                    if(originalCommentCell) {
                        originalCommentCell.innerHTML = `<div class="text-danger fw-bold border-bottom pb-1 mb-1">Re-opened: ${comments}</div>` + originalCommentCell.innerHTML;
                    }

                     const newReportData = {
                        title: `(Re-opened) ${row.querySelector('.concern-title').innerText}`,
                        sop: row.dataset.sop,
                        location: row.dataset.location,
                        department: row.dataset.department,
                        unit: row.dataset.unit,
                        region: row.dataset.region,
                        risk: row.dataset.risk,
                        status: 'Open',
                        registeredBy: 'System',
                        images: { before: URL.createObjectURL(fileInput.files[0]) },
                        originalIncidentId: originalId
                    };
                    const newRow = ReportProcessor.createAndDisplayRow(newReportData);
                    this.displayPage(this.currentPage);
                    AlertManager.showToast('New non-compliance report created.', 'warning');

                } else {
                     ReportHistoryManager.addHistoryEntry(originalId, { 
                        date: new Date().toISOString(), 
                        status: 'Non-Compliance Logged', 
                        comments: `Non-compliance noted. Reason: ${comments}` 
                    });
                    AlertManager.showToast('Non-compliance has been logged.', 'info');
                }

                ActionModals.nonCompliance.hide();
                document.getElementById('nonComplianceForm').reset();
            },

            updateRowStatus(row, newStatus) {
                row.dataset.status = newStatus;
                if (['Resolved', 'Verified', 'Not Applicable', 'Follow-up Created'].includes(newStatus)) {
                    row.dataset.completedTime = new Date().toISOString();
                }
                this.updateRowUI(row);
                this.updateTimers();
            }
        };
    
        const ReportHistoryManager = {
            initializeReportData(row) {
                const id = row.dataset.incidentId;
                if (!reportDatabase[id]) {
                    const areaParts = row.querySelector('td[data-label="Area"] span').innerText.split(' / ');
                    reportDatabase[id] = {
                        id: id, title: row.querySelector('.concern-title').innerText, sop: row.dataset.sop, startDate: row.dataset.reportedTime, endDate: row.dataset.completedTime || null, deviation: row.dataset.risk,
                        risk: { level: Math.floor(Math.random() * 20), category: row.dataset.risk }, responsibility: row.querySelector('.concern-responsibility span').innerText, 
                        area: row.querySelector('td[data-label="Area"] span').innerText, status: row.dataset.status,
                        imageBefore: row.querySelector('.report-image-thumb')?.src, imageAfter: row.querySelectorAll('.report-image-thumb')[1]?.src, 
                        history: [], breakdownHistory: []
                    };
                }
            },
            addHistoryEntry(incidentId, entry) { if(reportDatabase[incidentId]) { reportDatabase[incidentId].history.unshift(entry); } },
            addBreakdownHistoryEntry(incidentId, entry) { if(reportDatabase[incidentId]) { reportDatabase[incidentId].breakdownHistory.push(entry); } }
        };

        const ReportComponent = {
             init: async function(id) {
                 const data = reportDatabase[id] || { history: [] };
                 const row = document.querySelector(`tr[data-incident-id="${id}"]`);
                 this.render(data);
                 this.setupEventListeners();
                 const updateSection = document.getElementById('report-update-section');
                 if (row && (row.dataset.status === 'Resolved' || row.dataset.status === 'Verified' || row.dataset.status === 'Not Applicable')) { 
                     updateSection.style.display = 'none'; 
                 } else { 
                     updateSection.style.display = 'block'; 
                 }
             },
            formatDate: (dateString) => { if (!dateString) return "Pending"; const options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }; return new Date(dateString).toLocaleDateString('en-US', options); },
            render: function(data) { 
                const modalBody = document.getElementById('historyModalBody');
                modalBody.querySelector('[data-js="start-date"]').textContent = this.formatDate(data.startDate);
                modalBody.querySelector('[data-js="end-date"]').textContent = this.formatDate(data.endDate);
                const evidenceSection = modalBody.querySelector('[data-js="evidence-section"]');
                evidenceSection.innerHTML = `<div class="evidence-image-wrapper" data-img-src="${data.imageBefore}"><img src="${data.imageBefore}" alt="Before image"><div class="evidence-tag">Before</div></div>${data.imageAfter ? `<div class="evidence-image-wrapper" data-img-src="${data.imageAfter}"><img src="${data.imageAfter}" alt="After image"><div class="evidence-tag">After</div></div>` : ''}`;
                modalBody.querySelector('[data-js="title"]').textContent = data.title;
                modalBody.querySelector('[data-js="meta-info"]').innerHTML = `<span>SOP: ${data.sop}</span> &nbsp;&nbsp; <span>&#9888; Dev: ${data.deviation}</span>`;
                modalBody.querySelector('[data-js="risk"]').innerHTML = `<span class="risk">Risk: ${data.risk.level} (${data.risk.category})</span>`;
                modalBody.querySelector('[data-js="responsibility"]').innerHTML = `<span>Responsibility: ${data.responsibility}</span>`;
                modalBody.querySelector('[data-js="area"]').innerHTML = data.area.replace(/\//g, '/<br>');
                const tableBody = modalBody.querySelector('[data-js="history-table-body"]');
                tableBody.innerHTML = (data.history || []).map(item => `
                    <tr>
                        <td data-label="Date & Time">${this.formatDate(item.date)}</td>
                        <td data-label="Status"><span class="status-tag status-${(item.status || '').toLowerCase().replace(/\s+/g, '-')}">${item.status}</span></td>
                        <td data-label="Comments">${item.comments}</td>
                        <td data-label="Evidence">${item.image ? `<img src="${item.image}" alt="History image" class="table-image" data-img-src="${item.image}">` : 'N/A'}</td>
                    </tr>`).join('');
            },
             setupEventListeners: function() {
                const modalBody = document.getElementById('historyModalBody');
                modalBody.addEventListener('click', (e) => { const imageWrapper = e.target.closest('[data-img-src]'); if (imageWrapper) { modalBody.querySelector('[data-js="modal-image"]').src = imageWrapper.dataset.imgSrc; modalBody.querySelector('#image-modal').classList.add('visible'); } });
                modalBody.querySelector('[data-js="modal-close"]').addEventListener('click', () => modalBody.querySelector('#image-modal').classList.remove('visible'));
                 document.getElementById('postHistoryUpdateBtn').addEventListener('click', () => {
                     const incidentId = ActionModals.history._element.dataset.incidentId;
                     const comment = document.getElementById('historyComment').value.trim();
                     const evidenceFile = document.getElementById('historyEvidence').files[0];
                     if (!comment && !evidenceFile) { alert('Please add a comment or attach evidence.'); return; }
                     ReportHistoryManager.addHistoryEntry(incidentId, { date: new Date().toISOString(), status: 'Progress Update', comments: comment || 'Evidence provided.', image: evidenceFile ? URL.createObjectURL(evidenceFile) : null });
                     this.init(incidentId);
                     document.getElementById('historyComment').value = ''; document.getElementById('historyEvidence').value = '';
                 });
            }
        };
        
        document.getElementById('historyModal').addEventListener('show.bs.modal', (e) => { const incidentId = e.relatedTarget.closest('tr').dataset.incidentId; ActionModals.history._element.dataset.incidentId = incidentId; ReportComponent.init(incidentId); });
        
        document.getElementById('exportExcelBtn').addEventListener('click', async () => {
            const btn = document.getElementById('exportExcelBtn');
            btn.disabled = true;
            btn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>Preparing data...`;

            function imageElementToBase64(imgElement) {
                if (!imgElement || !imgElement.src) return null;
                try {
                    const canvas = document.createElement('canvas');
                    canvas.width = imgElement.naturalWidth || imgElement.width;
                    canvas.height = imgElement.naturalHeight || imgElement.height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(imgElement, 0, 0, canvas.width, canvas.height);
                    return canvas.toDataURL('image/jpeg');
                } catch (e) {
                    console.error("Canvas toDataURL error:", e);
                    return null;
                }
            }

            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('Report');
            
            worksheet.columns = [
                { header: 'Sl No', key: 'sl_no', width: 8 },
                { header: 'Complaint ID', key: 'complaint_id', width: 20 },
                { header: 'Report Id', key: 'id', width: 20 },
                { header: 'Reported Date', key: 'reported_date', width: 25 },
                { header: 'Area', key: 'area', width: 45 },
                { header: 'Reported By', key: 'reported_by', width: 20 },
                { header: 'Report details', key: 'details', width: 50 },
                { header: 'Before Image', key: 'before_image', width: 15 },
                { header: 'Responsibility', key: 'responsibility', width: 30 },
                { header: 'After Image', key: 'after_image', width: 15 },
                { header: 'Closure Comments', key: 'closure_comments', width: 50 },
                { header: 'SOPs', key: 'sops', width: 30 },
                { header: 'Risk', key: 'risk', width: 15 },
                { header: 'Total Hrs', key: 'total_hrs', width: 12 },
                { header: 'Assigned To', key: 'assigned_to', width: 30 },
                { header: 'Tracking Status', key: 'tracking_status', width: 30 },
                { header: 'Follow-up History', key: 'follow_up_history', width: 60, style: { alignment: { wrapText: true } } },
                { header: 'Breakdown History', key: 'breakdown_history', width: 60, style: { alignment: { wrapText: true } } }
            ];
            worksheet.getRow(1).font = { bold: true };

            const rowsToProcess = IncidentTableManager.activeRows;
            
            for (const [index, row] of rowsToProcess.entries()) {
                const na = (val) => val || 'NA';
                const closureComments = row.querySelector('.closure-comments-cell')?.innerText;
                const totalHrs = (row.dataset.completedTime && row.dataset.reportedTime) ? ((new Date(row.dataset.completedTime) - new Date(row.dataset.reportedTime)) / 3600000).toFixed(2) : 'NA';
                const trackingText = Array.from(row.querySelectorAll('.progress-tracker .step-label')).map(label => label.innerText.replace(/\n/g, ' ')).join('\n');
                const incidentId = row.dataset.incidentId;
                const reportData = reportDatabase[incidentId];

                const followUpHistory = (reportData.history || [])
                    .map(h => `[${new Date(h.date).toLocaleString()}] - ${h.status}: ${h.comments}`)
                    .join('\n');

                const breakdownHistory = (reportData.breakdownHistory || [])
                    .map(h => {
                        let parts = [`[${new Date(h.date).toLocaleString()}]`];
                        if (h.breakdownReason) parts.push(`Reason: ${h.breakdownReason}`);
                        if (h.correctiveAction) parts.push(`Action: ${h.correctiveAction}`);
                        if (h.incurredExpenses) parts.push(`Cost: ₹${h.incurredExpenses}`);
                        if (h.verifiedBy) parts.push(`Verified by ${h.verifiedBy}: ${h.verificationComments}`);
                        return parts.join(' - ');
                    }).join('\n');
                
                const rowData = {
                    sl_no: index + 1,
                    complaint_id: row.dataset.complaintId,
                    id: incidentId,
                    reported_date: new Date(row.dataset.reportedTime).toLocaleString('en-GB'),
                    area: row.querySelector('td[data-label="Area"] span')?.innerText,
                    reported_by: na(row.dataset.registeredBy),
                    details: row.querySelector('.concern-title')?.innerText,
                    responsibility: row.querySelector('.concern-responsibility span')?.innerText,
                    closure_comments: (closureComments && closureComments.trim() !== '---') ? closureComments : 'NA',
                    sops: na(row.dataset.sop),
                    risk: na(row.dataset.risk),
                    total_hrs: totalHrs,
                    assigned_to: na(row.dataset.assignedTo),
                    tracking_status: trackingText,
                    follow_up_history: followUpHistory || 'No follow-up history.',
                    breakdown_history: row.dataset.isBreakdown ? (breakdownHistory || 'No breakdown history.') : 'NA'
                };
                
                const addedRow = worksheet.addRow(rowData);
                addedRow.height = 65;
                addedRow.alignment = { vertical: 'middle' };

                const beforeImgEl = row.querySelector('.image-cell img.report-image-thumb');
                const afterImgEl = row.querySelectorAll('.image-cell img.report-image-thumb')[1];
                
                const beforeImgBase64 = imageElementToBase64(beforeImgEl);
                if (beforeImgBase64) {
                    const imageId = workbook.addImage({ base64: beforeImgBase64, extension: 'jpeg' });
                    worksheet.addImage(imageId, {
                        tl: { col: 7.05, row: index + 1.05 },
                        ext: { width: 80, height: 80 }
                    });
                }
                
                const afterImgBase64 = imageElementToBase64(afterImgEl);
                 if (afterImgBase64) {
                    const imageId = workbook.addImage({ base64: afterImgBase64, extension: 'jpeg' });
                    worksheet.addImage(imageId, {
                        tl: { col: 9.05, row: index + 1.05 },
                        ext: { width: 80, height: 80 }
                    });
                }
                
                btn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>Processing ${index + 1}/${rowsToProcess.length}...`;
            }

            btn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>Generating file...`;
                        const buffer = await workbook.xlsx.writeBuffer();
            const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = `Report_${new Date().toISOString().slice(0,10)}.xlsx`;
            link.click();
            URL.revokeObjectURL(link.href);

            btn.disabled = false;
            btn.innerHTML = `<i class="fas fa-file-excel me-1 me-sm-2"></i><span class="d-none d-sm-inline">Export to Excel</span>`;
        });


        const ComplaintFormManager = {
            prepareForNew() { const form = document.getElementById('complaintFormModal'); form.dataset.mode = 'new'; form.dataset.incidentId = ''; document.dispatchEvent(new CustomEvent('form-reset')); },
            populateForEdit(tableRow) {
                const form = document.getElementById('complaintFormModal'); form.dataset.mode = 'edit'; form.dataset.incidentId = tableRow.dataset.incidentId; document.dispatchEvent(new CustomEvent('form-reset'));
                const concernText = tableRow.querySelector('.concern-title')?.innerText || ''; const sop = tableRow.dataset.sop; const location = tableRow.dataset.location; const responsibility = tableRow.querySelector('.concern-responsibility span')?.innerText;
                const concernInput = document.getElementById('concernInput'); concernInput.textContent = concernText; concernInput.dispatchEvent(new Event('input', { bubbles: true }));
                if(sop) ComplaintFormManager.setMultiSelect('sopSelector', [sop]); if(location) ComplaintFormManager.setMultiSelect('locationSelector', [location]); if(responsibility) ComplaintFormManager.setMultiSelect('responsibilitySelector', [responsibility]);
            },
            setMultiSelect(componentId, values) { const component = document.getElementById(componentId); if (component && component._update) { const internalStateArray = component.querySelector('.pills-container')._associatedState; if(internalStateArray) { internalStateArray.length = 0; internalStateArray.push(...values); component._update(); } } }
        };

        // --- INITIALIZATION ---
        AlertManager.init();
        OfflineManager.init();
        IncidentTableManager.init();
        
        (() => { /* Placeholder for Complaint Form JS */ })();

    });
    


    </script>

<script>
        $(document).on('click', '#newReportBtn1', function (e) {
    e.preventDefault();

    let myModal = new bootstrap.Modal(document.getElementById('exampleModal'));
    myModal.show();
});
</script>
        
 
@endsection




