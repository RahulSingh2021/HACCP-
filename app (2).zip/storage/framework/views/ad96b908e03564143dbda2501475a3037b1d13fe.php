
<div class="row">
                         <div class="col">
                            <div class="card">
                                <div class="card-body">                              
                                    <ul class="nav nav-pills nav-pills-success mb-3" role="tablist">
                       
                                                         <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 1): ?> active <?php else: ?>  <?php endif; ?>" data-bs-toggle="pill" href="#Measurement-Unit" role="tab" aria-selected="true">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Measurement Unit</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 2): ?> active <?php else: ?>  <?php endif; ?>" data-bs-toggle="pill" href="#Add-Serving-Area-Name" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Serving Area Name</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 3): ?> active <?php else: ?>  <?php endif; ?>" data-bs-toggle="pill" href="#Data-Refrence-Name" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Data Refrence Name</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 4): ?> active <?php else: ?>  <?php endif; ?>" data-bs-toggle="pill" href="#Product-Symbol" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Product Symbol</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 5): ?> active <?php else: ?>  <?php endif; ?>" data-bs-toggle="pill" href="#Allergen-Datails" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Allergen Datails</div>
                                                </div>
                                            </a>
                                        </li>
                       
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 6): ?> active <?php endif; ?>" data-bs-toggle="pill"  href="#Ingredients" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Ingredients</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 7): ?> active <?php endif; ?>" data-bs-toggle="pill" href="#Add-Recipe" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Recipe</div>
                                                </div>
                                            </a>
                                        </li>
                        
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane fade <?php if($_GET['tab_name'] == 1): ?> active show <?php else: ?>  <?php endif; ?>" id="Measurement-Unit" role="tabpanel">
                                            <div class="row row-cols-auto g-3">
                                                <div class="col-2 d-flex align-self-end justify-content-start">
													
													      <button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#addmeasurementunit">+ Add New</button>
													
													</div>
                                            </div>     
                     <?php echo $__env->make('admin.popups.nutrilator.measurementunitlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                       </div>

                                       <div class="tab-pane fade <?php if($_GET['tab_name'] == 2): ?> active show <?php else: ?>  <?php endif; ?>" id="Add-Serving-Area-Name" role="tabpanel">
                                        <div class="row row-cols-auto g-3">
                                            <div class="col-2 d-flex align-self-end justify-content-start"><button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#addservingarea">+ Add New</button></div>
                                        </div>     
                                 <?php echo $__env->make('admin.popups.nutrilator.servingarealist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                       </div>
                                       <div class="tab-pane fade <?php if($_GET['tab_name'] == 3): ?> active show <?php else: ?>  <?php endif; ?>" id="Data-Refrence-Name" role="tabpanel">
                                        <div class="row row-cols-auto g-3">
                                            <div class="col-2 d-flex align-self-end justify-content-start"><button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#DataRefrenceName">+ Add New</button></div>
                                        </div>     
                      <?php echo $__env->make('admin.popups.nutrilator.datarefrencelist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
										   
										   
                                       </div>
                                       <div class="tab-pane fade <?php if($_GET['tab_name']  == 4): ?> active show <?php else: ?>  <?php endif; ?>" id="Product-Symbol" role="tabpanel">
                                    <div class="row row-cols-auto g-3">
                                        <div class="col-2 d-flex align-self-end justify-content-start"><button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#DataRefrenceName1">+ Add New</button></div>
                                    </div>     
                                   <?php echo $__env->make('admin.popups.nutrilator.productsybbulelist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                       </div>
                                       <div class="tab-pane fade <?php if($_GET['tab_name'] == 5): ?> active show <?php else: ?>  <?php endif; ?>" id="Allergen-Datails" role="tabpanel">
                                <div class="row row-cols-auto g-3">
                                    <div class="col-2 d-flex align-self-end justify-content-start"><button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#DataRefrenceName2">+ Add New</button></div>
                                </div>     
                            <?php echo $__env->make('admin.popups.nutrilator.allergenlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                        </div>
                                      
										 <?php echo $__env->make('admin.nutrilator.Ingredients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
             
                                       <?php echo $__env->make('admin.nutrilator.Recipe.recipe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>



<?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/nutrilator/admin_menu.blade.php ENDPATH**/ ?>