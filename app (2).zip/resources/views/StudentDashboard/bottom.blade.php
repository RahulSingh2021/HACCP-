</div>
</div>
{{-- script --}}
@include('StudentDashboard.layouts.script')
</body>
</html>
