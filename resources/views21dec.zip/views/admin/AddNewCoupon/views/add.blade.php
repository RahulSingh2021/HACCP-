@include('Admin.AddNewCoupon.layouts.top')
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<div class="container mt-4">
    <div class="row">
        <div class="col-xl-12">
            <div class="card mb-4 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="mdi mdi-apple-keyboard-command title_icon"></i>
                        Add Coupons
                    </h4>
                    <a href="{{ url('/admin/add-new-coupon/') }}" class="btn btn-outline-primary btn-rounded">
                        <i class="mdi mdi-plus"></i> Back to Coupons
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="mb-4">Add New Coupon</h4>

                    <form class="needs-validation" action="{{url('admin/add-new-coupon/add-coupon')}}" method="post">
                        @csrf
                        <div class="form-group">
                            <label for="code">Coupon Code <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="code" name="coupon_code" required>
                                <div class="input-group-append">
                                    <button type="button" class="btn btn-primary" onclick="generateRandomCouponCode()">Generate Random</button>
                                </div>
                            </div>
                            <div class="invalid-feedback">Please enter a coupon code.</div>
                        </div>

                        <div class="form-group">
                            <label for="discount_percentage">Discount Percentage</label>
                            <div class="input-group">
                                <input type="number" name="discount_percentage" id="discount_percentage" class="form-control" value="0" min="1" max="100">
                                <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="expiry_date">Expiry Date <span class="text-danger">*</span></label>
                            <input type="date" name="expiry_date" class="form-control" id="expiry_date" required>
                            <div class="invalid-feedback">Please select an expiry date.</div>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function generateRandomCouponCode() {
    const length = Math.floor(Math.random() * 2) + 7; 
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        result += characters[randomIndex];
    }
    document.getElementById('code').value = result;
}

</script>

@include('Admin.AddNewCoupon.layouts.bottom')
