                      <div class="modal fade" id="addregionaldetails" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add  Regional</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                         <form></form>
                        <form method="post" action="<?php echo e(route('add_users')); ?>">
                            <?php echo csrf_field(); ?>
                    <div class="row">
          <div class="mb-3 col-md-6">
                            <label class="form-label">Regional ID:</label>
                            <input type="text" class="form-control"  name="login_id" placeholder="">
                            <?php if($errors->has('login_id')): ?>
    <div class="error"><?php echo e($errors->first('login_id')); ?></div>
<?php endif; ?>
                        </div>
	         <div class="mb-3 col-md-6">
                            <label class="form-label">Select Corporate Name:</label>
				 
				 <input type="hidden" name="is_role" value="1">
				 
				 
									 
									 <select name="created_by" class="form-control">
										 <option value="">Please Select Corporate </option>
										 
										   <?php $unit_list = DB::table('users')->where('is_role', "2")->get(); ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 <option value="<?php echo e($unit_lists->id); ?>"><?php echo e($unit_lists->company_name); ?></option>
										 
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									 
									 </select>

                        </div>

              

                               <div class="mb-3 col-md-6">
                            <label class="form-label">Regional Name:</label>
                            <input type="text" class="form-control"  name="company_name" placeholder="">
                            <?php if($errors->has('company_name')): ?>
    <div class="error"><?php echo e($errors->first('company_name')); ?></div>
<?php endif; ?>
                        </div>


                               <div class="mb-3 col-md-6">
                            <label class="form-label"> Address
:</label>
                            <input type="text" class="form-control"  name="Company_address" placeholder="">
                            <?php if($errors->has('Company_address')): ?>
    <div class="error"><?php echo e($errors->first('Company_address')); ?></div>
<?php endif; ?>
                        </div>

                   
 <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Contact Person Name </label>
                            <input type="text" name="name" class="form-control" placeholder="">
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>

                        </div>
                               <div class="mb-3 col-md-6">
                            <label class="form-label">Designation:</label>
                            <input type="text" class="form-control"  name="designation" placeholder="">
                            <?php if($errors->has('designation')): ?>
    <div class="error"><?php echo e($errors->first('designation')); ?></div>
<?php endif; ?>
                        </div>

                             
						
						      <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Mobile Number </label>
                            <input type="text" name="mobile_number" class="form-control" placeholder="">
                            <?php if($errors->has('mobile_number')): ?>
    <div class="error"><?php echo e($errors->first('mobile_number')); ?></div>
<?php endif; ?>
                        </div>

                              <div class="mb-3 col-md-6">
                            <label class="form-label">Enter Email </label>
                            <input type="email" name="email" class="form-control" placeholder="">
                            <?php if($errors->has('email')): ?>
    <div class="error"><?php echo e($errors->first('email')); ?></div>
<?php endif; ?>
                        </div>

                        

                              <div class="mb-12 col-md-12">
                            <label class="form-label">Enter Password </label>
                            <input type="text" name="password" class="form-control" placeholder="">
                            <?php if($errors->has('password')): ?>
    <div class="error"><?php echo e($errors->first('password')); ?></div>
<?php endif; ?>
                        </div>
               
                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary">Add  Details</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div><?php /**PATH /var/www/vhosts/efsms.in/httpdocs/admin/resources/views/admin/users/popups/reginoal.blade.php ENDPATH**/ ?>