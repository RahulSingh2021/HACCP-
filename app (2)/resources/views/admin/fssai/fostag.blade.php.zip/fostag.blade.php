@extends('layouts.app', ['pagetitle'=>'Dashboard'])

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
            <style>
              /* CSS Variables for theming */
        :root {
            --primary-color: #3498db;
            --secondary-color: #2980b9;
            --success-color: #2ecc71;     /* Final Submit / Valid Cert / Compliant Card */
            --warning-color: #f39c12;     /* Update / Due / Low Days Left (31-60 days) */
            --danger-color: #e74c3c;      /* Expired / Very Low Days Left (<=30 days) / Delete / Non-Compliant Card */
            --info-color: #17a2b8;       /* Save as Draft / Refresh Button */
            --light-gray: #ecf0f1;
            --dark-gray: #7f8c8d;
            --text-color: #2c3e50;
            --card-non-compliant-bg: #fee2e2; /* Light red for non-compliant tag */
            --card-non-compliant-text: #dc3545; /* Red text for non-compliant tag */
            --card-compliant-bg: #d1e7dd; /* Light green for compliant tag */
            --card-compliant-text: #0f5132; /* Dark green for compliant tag */
            --card-progress-bar-bg: #e9ecef; /* Progress bar background */
            --card-progress-bar-fill-orange: #f0ad4e; /* Orange progress bar fill */
            --card-progress-bar-fill-green: var(--success-color); /* Green progress bar fill */
        }

        /* Basic Reset and Font */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        html { scroll-behavior: smooth; } /* Enable smooth scrolling globally */
        body { background-color: #f5f7fa; color: var(--text-color); line-height: 1.6; }

        /* Sticky Top Navigation */
        .top-nav { background-color: white; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); padding: 0 20px; position: sticky; top: 0; z-index: 100; }
        .nav-container { display: flex; justify-content: space-between; align-items: center; max-width: 1800px; margin: 0 auto; }
        .logo { padding: 15px 0; }
        .logo h2 { color: var(--primary-color); font-size: 1.4rem; }

        /* Main Content Area */
        .main-content { max-width: 1800px; margin: 20px auto; padding: 20px; }
        .header { margin-bottom: 30px; border-bottom: 1px solid var(--light-gray); padding-bottom: 15px; min-height: 2rem; }
        .header h1 { color: var(--text-color); font-size: 1.8rem; }

        /* Container for Compliance Cards */
        .compliance-cards-container {
            display: flex;
            flex-wrap: wrap; /* Allow cards to wrap on smaller screens */
            gap: 30px; /* Space between cards */
            margin-bottom: 30px; /* Space below the container */
            justify-content: flex-start; /* Align cards to the start */
            align-items: flex-start; /* Align items to the top */
        }

        /* === Styles for the Training Card (Used by BOTH cards now) === */
        .training-card {
            background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border-left: 5px solid #ccc; padding: 20px; width: 100%; transition: border-left-color 0.3s ease;
            display: flex; flex-direction: column; gap: 15px; flex: 1 1 400px; min-width: 350px;
        }

        /* --- Status Theming --- */
        .training-card.status-due-soon { border-left-color: #f59e0b; /* Orange */ }
        .training-card.status-due-soon .status-badge { background-color: #fffbeb; color: #d97706; border: 1px solid #fcd34d; }
        .training-card.status-due-soon .progress-bar { background-color: #f59e0b; }
        .training-card.status-due-soon .btn-primary { background-color: #f59e0b; border-color: #f59e0b; color: #ffffff; }
        .training-card.status-due-soon .btn-primary:hover { background-color: #d97706; border-color: #d97706; }
        .training-card.status-due-soon .btn-secondary { background-color: #ffffff; border-color: #d1d5db; color: #374151; }
        .training-card.status-due-soon .btn-secondary:hover { background-color: #f3f4f6; }
        .training-card.status-due-soon .expired-info { display: none; } /* Hide expired */
        .training-card.status-due-soon .near-expiry-info { display: inline-flex; }
        .training-card.status-due-soon .expiring-soon-info { display: inline-flex; }
        .training-card.status-due-soon .unit-needs-attention-info { display: inline-flex; } /* Show attention for unit */


        .training-card.status-non-compliant { border-left-color: #ef4444; /* Red */ }
        .training-card.status-non-compliant .status-badge { background-color: #fee2e2; color: #dc2626; border: 1px solid #fca5a5; }
        .training-card.status-non-compliant .progress-bar { background-color: var(--danger-color); } /* Use danger color for progress in non-compliant */
        .training-card.status-non-compliant .btn-primary { background-color: #ef4444; border-color: #ef4444; color: #ffffff; }
        .training-card.status-non-compliant .btn-primary:hover { background-color: #dc2626; border-color: #dc2626; }
        .training-card.status-non-compliant .btn-secondary { background-color: #ffffff; border: 1px solid #d1d5db; color: #374151; }
        .training-card.status-non-compliant .btn-secondary:hover { background-color: #f3f4f6; }
        .training-card.status-non-compliant .expired-info { display: inline-flex; } /* Show expired */
        .training-card.status-non-compliant .near-expiry-info { display: inline-flex; }
        .training-card.status-non-compliant .expiring-soon-info { display: inline-flex; }
        .training-card.status-non-compliant .unit-needs-attention-info { display: inline-flex; } /* Show attention for unit */

        .training-card.status-compliant { border-left-color: #10b981; /* Green */ }
        .training-card.status-compliant .status-badge { background-color: #d1fae5; color: #047857; border: 1px solid #a7f3d0; }
        .training-card.status-compliant .progress-bar { background-color: #10b981; }
        .training-card.status-compliant .btn-primary { background-color: #10b981; border-color: #10b981; color: #ffffff; }
        .training-card.status-compliant .btn-primary:hover { background-color: #059669; border-color: #059669; }
        .training-card.status-compliant .btn-secondary { background-color: #ffffff; border-color: #d1d5db; color: #374151; }
        .training-card.status-compliant .btn-secondary:hover { background-color: #f3f4f6; }
        .training-card.status-compliant .expired-info,
        .training-card.status-compliant .near-expiry-info,
        .training-card.status-compliant .expiring-soon-info,
        .training-card.status-compliant .unit-needs-attention-info { display: none; } /* Hide all extra info for compliant */

        /* --- Card Sections --- */
        .training-card .card-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 10px; }
        .training-card .card-title { font-size: 1.3rem; font-weight: 600; color: #1f2937; margin: 0; display: flex; align-items: center; gap: 8px; }
        .training-card .icon-book, .training-card .icon-building { color: #6b7280; font-size: 1.1em; } /* Added icon-building */
        .training-card .status-badge { font-size: 0.75rem; font-weight: 600; padding: 4px 10px; border-radius: 12px; white-space: nowrap; margin-top: 2px; }
        .training-card .progress-section { display: flex; align-items: center; gap: 10px; }
        .training-card .progress-bar-container { flex-grow: 1; background-color: #e5e7eb; border-radius: 5px; height: 8px; overflow: hidden; }
        .training-card .progress-bar { height: 100%; border-radius: 5px; transition: width 0.5s ease-in-out; }
        .training-card .progress-text { font-size: 0.875rem; color: #4b5563; white-space: nowrap; font-weight: 500; }
        .training-card .card-details { display: flex; justify-content: space-between; flex-wrap: wrap; gap: 15px; font-size: 0.875rem; color: #4b5563; padding-top: 5px; }
        .training-card .detail-item { display: flex; align-items: center; gap: 6px; }
        .training-card .detail-item strong { color: #1f2937; font-weight: 600; }
        .training-card .detail-item i { color: #6b7280; font-size: 1.1em; }

        /* --- Clickable Card Count Styling --- */
        #fostac-valid-count-link,
        #fostac-expiring-count-link {
            cursor: pointer; text-decoration: none; color: inherit;
            border-bottom: 1px dashed var(--primary-color);
            transition: color 0.2s ease, border-bottom-color 0.2s ease;
            padding: 0 2px; margin: 0 -2px;
        }
        #fostac-valid-count-link:hover,
        #fostac-expiring-count-link:hover { color: var(--primary-color); border-bottom-color: transparent; }
        #fostac-valid-count-link strong,
        #fostac-expiring-count-link span {} /* Inherits from link */

        .training-card .card-extra-info { font-size: 0.875rem; margin-top: -5px; display: flex; flex-direction: column; gap: 5px; }
        .training-card .card-extra-info i { margin-right: 4px; }
        /* Visibility handled by JS based on card status classes */
        .training-card .expired-info,
        .training-card .near-expiry-info,
        .training-card .expiring-soon-info,
        .training-card .unit-needs-attention-info { display: none; align-items: center;} /* Hide by default */

        /* Specific styling for info spans */
        .expired-info { color: var(--danger-color); font-weight: 600; }
        .expired-info i { color: var(--danger-color); }

        .near-expiry-info { color: var(--danger-color); font-weight: 600; }
        .near-expiry-info i { color: var(--danger-color); }

        .expiring-soon-info { color: var(--warning-color); font-weight: 500; }
        .expiring-soon-info i { color: var(--warning-color); }

        /* Styling for the Unit Card's 'Needs Attention' info */
        .unit-needs-attention-info {
            color: var(--warning-color); /* Or danger-color if preferred */
            font-weight: 500;
            /* display handled by card status class */
            align-items: center;
        }
        .unit-needs-attention-info i {
            color: var(--warning-color); /* Match icon color */
        }

        .training-card .card-actions { display: flex; gap: 10px; margin-top: 10px; flex-wrap: wrap; }
        .training-card .btn {
            padding: 8px 16px; border: 1px solid transparent; border-radius: 6px; font-size: 0.875rem; font-weight: 500;
            cursor: pointer; transition: all 0.2s ease; display: inline-flex; align-items: center; justify-content: center;
            gap: 6px; line-height: 1.5;
        }
         .training-card .btn:hover { opacity: 0.85; transform: translateY(-1px); }
        .training-card .btn i { font-size: 0.95em; width: 1.1em; text-align: center; }
        /* Button colors are now primarily handled by card status classes */
        /* Default/Base styles (can be overridden by status classes) */
        .training-card .btn-primary { background-color: var(--primary-color); border-color: var(--primary-color); color: #ffffff; }
        .training-card .btn-primary:hover { background-color: var(--secondary-color); border-color: var(--secondary-color); }
        .training-card .btn-secondary { background-color: #ffffff; border-color: #d1d5db; color: #374151; }
        .training-card .btn-secondary:hover { background-color: #f3f4f6; border-color: #adb5bd; }
        /* === END: CSS Styles for the Training Card === */

        /* Table Styling */
        .employee-records-section { scroll-margin-top: 80px; } /* Add top margin for scrolling target */
        .table-container { overflow-x: auto; margin-bottom: 0px; }
        .reports-table { width: 100%; border-collapse: collapse; min-width: 1750px; }
        .reports-table th, .reports-table td { padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--light-gray); font-size: 13px; vertical-align: middle; }
        .reports-table th { background-color: #f8f9fa; font-weight: 600; white-space: nowrap; position: sticky; top: 0; z-index: 10; color: var(--text-color); cursor: default; position: relative; }
        .reports-table tbody tr:hover { background-color: #f1f4f6; }
        .reports-table th:first-child, .reports-table td.sl-no { text-align: center; width: 50px; min-width: 50px; padding: 10px 5px; }
        .reports-table td[data-field="daysLeft"] { text-align: center; font-weight: 500; }
        .days-left-low { color: var(--warning-color); } /* 60-31 days */
        .days-left-very-low { color: var(--danger-color); } /* 30-0 days */
        select.employee-select { width: 100%; min-width: 150px; padding: 4px 8px; border-radius: 4px; border: 1px solid #ced4da; font-size: 12px; cursor: pointer; height: 28px; vertical-align: middle; appearance: auto; background-image: none; padding-right: 8px; }

        /* Status Pills */
        .status { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 500; display: inline-block; white-space: nowrap; text-align: center; line-height: 1.4; }
        .status.pending { background-color: #fff3cd; color: #856404; }
        .status.completed { background-color: #d4edda; color: #155724; }
        .status.expired { background-color: #f8d7da; color: #721c24; } /* Renamed from overdue */
        .status.draft { background-color: #d1ecf1; color: #0c5460; }

        /* Action Buttons (Table) */
        .action-buttons { display: flex; gap: 5px; flex-wrap: nowrap; }
        .action-btn { padding: 5px 10px; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; transition: all 0.2s; display: inline-flex; align-items: center; gap: 4px; white-space: nowrap; }
        .action-btn:hover:not([disabled]) { opacity: 0.8; transform: translateY(-1px); }
        .action-btn[disabled] { opacity: 0.6; cursor: not-allowed; }
        .main-action-btn.update { background-color: var(--warning-color); color: white; }
        .main-action-btn.save-draft { background-color: var(--info-color); color: white; }
        .main-action-btn.final-submit { background-color: var(--success-color); color: white; }
        .history-btn { background-color: #6c757d; color: white; }
        .cancel-btn { background-color: #6c757d; color: white; }
        .delete-btn { background-color: var(--danger-color); color: white; }
        .delete-btn:hover:not([disabled]) { background-color: #c82333; }
        .action-btn span { margin-left: 4px; }

        /* Table Controls (Add/Refresh/Export Buttons) */
        .table-controls { display: flex; gap: 10px; align-items: center; margin-bottom: 15px; flex-wrap: wrap; }
        .control-btn { background-color: var(--primary-color); color: white; padding: 8px 15px; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; transition: all 0.2s; display: inline-flex; align-items: center; gap: 5px; }
        .control-btn:hover { opacity: 0.85; transform: translateY(-1px); }
        .control-btn.add { background-color: var(--success-color); }
        .control-btn.add:hover { background-color: #218838; }
        .control-btn.refresh { background-color: var(--info-color); }
        .control-btn.refresh:hover { background-color: #138496; }
        .control-btn.export { background-color: #6c757d; } /* Style for export button */
        .control-btn.export:hover { background-color: #5a6268; }

        /* Form elements within table */
        select.training-level-select, input.training-date-input, input.dob-input, input.doj-input, select.validity-select { padding: 4px 8px; border-radius: 4px; border: 1px solid #ced4da; font-size: 12px; cursor: pointer; max-width: 120px; height: 28px; vertical-align: middle; }
        input.training-date-input, input.dob-input, input.doj-input { width: 110px; }
        select.training-level-select, select.validity-select { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 0.5rem center; background-size: 16px 12px; padding-right: 1.8rem; }
        select:disabled, input:disabled { background-color: #e9ecef; cursor: not-allowed; opacity: 0.7; }
        td[data-field="trainingType"][contenteditable="true"] { background-color: white; outline: 1px solid var(--primary-color); padding: 4px 6px; border-radius: 3px; }

        /* Certificate Upload */
        .certificate-upload { display: inline-flex; align-items: center; position: relative; gap: 8px; }
        .certificate-upload input[type="file"] { position: absolute; left: 0; top: 0; opacity: 0; width: 100%; height: 100%; cursor: pointer; }
        .certificate-upload input[type="file"]:disabled + .certificate-btn { cursor: not-allowed; opacity: 0.7; background-color: #e9ecef; }
        .certificate-upload input[type="file"]:disabled + .certificate-btn:hover { background-color: #e9ecef; }
        .certificate-btn { background-color: var(--light-gray); color: var(--text-color); padding: 5px 10px; border-radius: 4px; cursor: pointer; display: inline-flex; align-items: center; font-size: 12px; transition: background-color 0.3s, transform 0.2s; border: 1px solid #ced4da; height: 28px; }
        .certificate-btn:hover { background-color: #dee2e6; transform: translateY(-1px); }
        .certificate-btn i { margin-right: 5px; }
        .certificate-status { font-size: 12px; color: var(--dark-gray); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100px; }
        .certificate-status.uploaded { color: var(--success-color); font-weight: 500; }

        /* Modal Styling */
        .modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.6); z-index: 1000; display: flex; justify-content: center; align-items: center; opacity: 0; visibility: hidden; transition: opacity 0.3s ease-in-out, visibility 0s 0.3s linear; }
        .modal.show { opacity: 1; visibility: visible; transition: opacity 0.3s ease-in-out, visibility 0s 0s linear; }
        .modal-content { background-color: white; border-radius: 8px; width: 90%; max-width: 1200px; max-height: 85vh; display: flex; flex-direction: column; box-shadow: 0 5px 25px rgba(0, 0, 0, 0.2); transform: scale(0.95); transition: transform 0.3s ease-in-out; }
        .modal.show .modal-content { transform: scale(1); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; padding: 15px 25px; border-bottom: 1px solid var(--light-gray); flex-shrink: 0; }
        .modal-header h2 { color: var(--primary-color); font-size: 1.25rem; }
        .close-modal { background: none; border: none; font-size: 28px; font-weight: bold; cursor: pointer; color: var(--dark-gray); transition: color 0.2s; line-height: 1; }
        .close-modal:hover { color: var(--danger-color); }
        .modal-body { padding: 25px; overflow-y: auto; flex-grow: 1; }

        /* History Tables in Modal */
        .history-table, .parameter-history-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .history-table th, .history-table td, .parameter-history-table th, .parameter-history-table td { padding: 8px 10px; border: 1px solid #dee2e6; font-size: 12px; text-align: left; }
        .history-table th, .parameter-history-table th { background-color: #f8f9fa; font-weight: 600; }
        .parameter-history-table th, .parameter-history-table td { text-align: center; white-space: nowrap; }
        .parameter-history-table th { position: sticky; top: -1px; z-index: 10; background-color: #f8f9fa; }
        .parameter-history-table tbody tr:nth-child(even) { background-color: #f9f9f9; }
        .parameter-history-table tbody tr:hover { background-color: #f1f1f1; }
        .history-header { font-weight: 600; background-color: #e9ecef; }
        .scrollable-table { overflow-x: auto; width: 100%; }

        /* Edit Mode Highlight */
        .edit-mode { background-color: #fff9e6 !important; outline: 1px dashed var(--warning-color); outline-offset: -1px; }
        .edit-mode [contenteditable="true"] { background-color: white; outline: 1px solid var(--primary-color); padding: 4px 6px; border-radius: 3px; }
        tr.new-record-edit td[data-field="empId"] select.employee-select { outline: 2px solid var(--primary-color); background-color: #eef7ff; }

        /* Filter Icon & Dropdown */
        th .filter-icon { margin-left: 5px; cursor: pointer; color: var(--dark-gray); transition: color 0.2s; font-size: 0.8em; vertical-align: middle; }
        th .filter-icon:hover { color: var(--primary-color); }
        th[data-filter-active="true"] .filter-icon { color: var(--primary-color); } /* Highlight active filter icon */
        .filter-dropdown { position: absolute; top: calc(100% + 5px); left: 0; background-color: white; border: 1px solid #ccc; border-radius: 4px; padding: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.15); z-index: 101; min-width: 200px; display: none; font-size: 12px; }
        .filter-dropdown.show { display: block; }
        .filter-dropdown input[type="text"] { width: 100%; padding: 6px 8px; margin-bottom: 8px; border: 1px solid #ddd; border-radius: 3px; font-size: 12px; }
        .filter-dropdown .filter-options { max-height: 150px; overflow-y: auto; margin-bottom: 8px; border: 1px solid #eee; padding: 5px; }
        .filter-dropdown label { cursor: pointer; white-space: nowrap; display: flex; align-items: center; gap: 5px; border-radius: 3px; }
        .filter-dropdown .standard-filter-content label { padding: 5px 3px; }
        .filter-dropdown label:hover { background-color: #f5f5f5; }
        .filter-dropdown input[type="checkbox"] { cursor: pointer; margin: 0; }
        .filter-buttons { display: flex; justify-content: space-between; margin-top: 8px; padding-top: 8px; border-top: 1px solid #eee; }
        .filter-dropdown button { padding: 4px 10px; border: none; border-radius: 3px; cursor: pointer; font-size: 12px; transition: background-color 0.2s, transform 0.2s; }
        .filter-dropdown button:hover { transform: translateY(-1px); }
        .filter-apply-btn { background-color: var(--primary-color); color: white; }
        .filter-apply-btn:hover { background-color: var(--secondary-color); }
        .filter-clear-btn { background-color: var(--light-gray); color: var(--text-color); }
        .filter-clear-btn:hover { background-color: #e0e0e0; }

        /* Custom filter element styles */
        .filter-dropdown .custom-filter-content label { display: block; margin-bottom: 3px; font-size: 11px; font-weight: 500; color: var(--text-color); }
        .filter-dropdown .custom-filter-content select, .filter-dropdown .custom-filter-content input[type="date"] { width: 100%; padding: 5px 8px; border: 1px solid #ccc; border-radius: 3px; font-size: 12px; background-color: white; margin-bottom: 8px; appearance: auto; background-image: none; padding-right: 8px; }
        .filter-dropdown .custom-filter-content select:disabled { background-color: #e9ecef; cursor: not-allowed; opacity: 0.7; }

        /* === Pagination Styles === */
        .pagination-container { display: flex; justify-content: space-between; align-items: center; padding: 15px 5px; border-top: 1px solid var(--light-gray); margin-top: 10px; font-size: 12px; flex-wrap: wrap; gap: 10px; }
        .rows-per-page-selector label { margin-right: 5px; color: var(--dark-gray); }
        .rows-per-page-selector select { padding: 3px 6px; border-radius: 4px; border: 1px solid #ccc; font-size: 12px; }
        .pagination-controls { display: flex; align-items: center; flex-wrap: nowrap; gap: 5px; /* Added gap */ }
        /* Inherit action-btn styles for pagination buttons */
        .pagination-controls button:not(.page-number-btn) { background-color: var(--primary-color); color: white; }
        .pagination-controls button:disabled { background-color: var(--light-gray); color: var(--dark-gray); cursor: not-allowed; opacity: 0.6; }
        .page-number-btn {
            padding: 5px 10px;
            margin: 0; /* Removed margin */
            border: 1px solid var(--light-gray);
            background-color: white;
            color: var(--primary-color);
            cursor: pointer;
            border-radius: 4px;
            font-size: 12px;
            transition: all 0.2s;
            display: inline-flex; /* Ensure alignment */
            align-items: center;
            justify-content: center;
            min-width: 30px; /* Give some width */
            height: 28px; /* Match action-btn height roughly */
            line-height: 1; /* Adjust line height */
        }
        .page-number-btn:hover { background-color: var(--light-gray); transform: translateY(-1px); }
        .page-number-btn.active { background-color: var(--primary-color); color: white; border-color: var(--primary-color); font-weight: bold; transform: none; }
        #pageInfo { color: var(--dark-gray); margin-left: 15px;}
        #pageNumbers { display: inline-flex; gap: 5px; align-items: center; } /* Use flex for better alignment */
        #pageNumbers span { color: var(--dark-gray); } /* Style for ellipsis */

        /* Responsive Adjustments */
        @media (max-width: 1800px) { .main-content { max-width: 95%; } .reports-table { min-width: 1600px; } }
        @media (max-width: 1300px) { .reports-table { min-width: 1400px; } }
        @media (max-width: 900px) {
             .compliance-cards-container { flex-direction: column; align-items: stretch; }
             .training-card { max-width: none; flex-basis: auto; } /* Adjusted */
        }
        @media (max-width: 768px) {
            .nav-container { flex-direction: column; align-items: flex-start; padding: 10px 0; }
            .logo h2 { font-size: 1.2rem; }
            .header h1 { font-size: 1.5rem; }
            .reports-table th, .reports-table td { padding: 8px 10px; font-size: 12px;}
            .action-buttons { flex-wrap: wrap; }
            .modal-content { width: 95%; max-height: 90vh;}
            .modal-header h2 { font-size: 1.1rem; }
            .reports-table { min-width: 1300px; }
            .pagination-container { flex-direction: column; align-items: center; gap: 15px;} /* Center items */
            .rows-per-page-selector { order: 1; } /* Move rows selector first */
            .pagination-controls { order: 2; justify-content: center; width: 100%; } /* Center controls */
            #pageInfo { order: 3; margin-left: 0; text-align: center; width: 100%;} /* Center info text */
        }
        @media (max-width: 576px) {
            .reports-table th, .reports-table td { font-size: 11px; }
            .action-btn { padding: 4px 8px; font-size: 11px; }
            .control-btn { font-size: 13px; padding: 7px 12px; }
            select.training-level-select, input.training-date-input, select.validity-select, input.dob-input, input.doj-input { max-width: 90px; font-size: 11px; height: 26px;}
            input.training-date-input, input.dob-input, input.doj-input { width: 90px; }
            .certificate-btn { font-size: 11px; padding: 4px 8px; height: 26px;}
            .certificate-status { max-width: 80px; }
            .reports-table { min-width: 1100px; }
            .reports-table th:first-child, .reports-table td.sl-no { width: 40px; min-width: 40px; padding: 8px 4px;}
            .training-card { min-width: 0; } /* Adjusted */
        }
        @media (max-width: 400px) {
             .training-card .card-actions { flex-direction: column; align-items: stretch; } /* Adjusted */
             .training-card { padding: 15px; } /* Adjusted */
             .training-card .progress-text, .training-card .detail-item, .training-card .card-extra-info, .training-card .btn { font-size: 0.85em; } /* Adjusted */
             .training-card .card-title { font-size: 1.15em; } /* Adjusted */
             .pagination-controls { flex-wrap: wrap; justify-content: center; } /* Allow wrapping */
             #pageNumbers { flex-wrap: wrap; justify-content: center; } /* Allow wrapping */
        }
    </style>
    </style>
@section('content')
 






                          <div class="row">
                         <div class="col">
                            <div class="card">
                                <div class="card-body">
                                     <ul class="nav nav-pills nav-pills-success mb-3" role="tablist">
            <li class="nav-item mr-3" role="presentation" style="margin:5px;">
            <a class="nav-link" href="{{route('linces')}}">
            <div class="d-flex align-items-center">
            <div class="tab-title">FSSAI Dashboard</div>
            </div>
            </a>
            </li>
            
                        <li class="nav-item " role="presentation" style="margin:5px;">
            <a class="nav-link" href="{{route('fssailinces')}}" >
            <div class="d-flex align-items-center">
            <div class="tab-title"> FSSAI License</div>
            </div>
            </a>

            </li>
            
            
                            <li class="nav-item " role="presentation" style="margin:5px;">
            <a class="nav-link "  href="{{route('food')}}" >
            <div class="d-flex align-items-center">
            <div class="tab-title"> Food Tests</div>
            </div>
            </a>

            </li>
            
            <li class="nav-item " role="presentation" style="margin:5px;">
<a class="nav-link"  href="{{route('medical')}}" >
<div class="d-flex align-items-center">
<div class="tab-title">Medical</div>
</div>
</a>

</li>


            <li class="nav-item " role="presentation" style="margin:5px;">
<a class="nav-link active"  href="{{route('fostac')}}" >
<div class="d-flex align-items-center">
<div class="tab-title">fostac</div>
</div>
</a>

</li>
                       
                                        
                                    </ul>
                                    <div class="tab-content">
										
	
											 	 <div class="" id="company-details1" role="tabpanel">
							
		


    
 <!-- Top Navigation -->
  

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="header">
            <h1 id="mainHeaderText">Employee FoSTaC Training Records</h1> <!-- JS will set this -->
        </div>

        <!-- Container for the Compliance Cards -->
        <div class="compliance-cards-container">

             <!-- START: NEW FOSTAC Training Card (Updated) -->
             <div class="training-card status-due-soon" id="fostacTrainingCard">
                 <div class="card-header">
                     <h3 class="card-title">
                         <i class="fa-solid fa-book-open icon-book"></i> FOSTAC Training
                     </h3>
                     <span class="status-badge" id="fostac-training-status-badge">DUE SOON</span>
                 </div>

                 <div class="progress-section">
                     <div class="progress-bar-container">
                         <div class="progress-bar" id="fostac-training-progress-bar" style="width: 75%;"></div>
                     </div>
                     <span class="progress-text" id="fostac-training-progress-text">75% Completed</span>
                 </div>

                 <div class="card-details">
                     <div class="detail-item">
                         <i class="fa-regular fa-calendar-check icon-calendar"></i>
                         <span>Next Due: <strong id="fostac-training-next-due">N/A</strong></span>
                     </div>
                     <div class="detail-item">
                         <i class="fa-solid fa-users icon-users"></i>
                         <span>Valid Certificates: <a href="#" id="fostac-valid-count-link" title="Click to view valid (non-expiring) certificates"><strong id="fostac-training-valid-certs">0/0</strong></a> Employees</span>
                     </div>
                 </div>

                 <div class="card-extra-info">
                      <!-- Expired Info (Renamed from Overdue) -->
                      <span class="expired-info" id="fostac-training-expired">
                          <i class="fa-solid fa-circle-exclamation"></i> Expired: <span id="fostac-training-expired-count">0</span> certificates
                      </span>
                      <!-- Near Expiry info -->
                      <span class="near-expiry-info" id="fostac-training-near-expiry">
                        <i class="fa-solid fa-fire-flame-curved"></i> Near Expiry (&lt;30d): <span id="fostac-training-near-expiry-count">0</span> certificates
                      </span>
                      <!-- Expiring soon link (Threshold updated) -->
                     <span class="expiring-soon-info" id="fostac-training-expiring-soon">
                          <i class="fa-solid fa-triangle-exclamation"></i> Expiring Soon (&lt;60d):
                          <a href="#" id="fostac-expiring-count-link" title="Click to view expiring certificates"><span id="fostac-training-expiring-soon-count">0</span></a> certificates
                     </span>
                 </div>

                 <div class="card-actions">
                     <!-- Button text changed, action linked in JS -->
                     <button class="btn btn-secondary" id="fostac-view-all-btn">
                         <i class="fa-regular fa-eye"></i> View Certificates
                     </button>
                     <!-- REMOVED Schedule Button -->
                 </div>
             </div> <!-- End of fostacTrainingCard -->
             <!-- END: NEW FOSTAC Training Card -->

             <!-- START: NEW FoSTaC Unit Compliance Card (Updated Structure) -->
             <div class="training-card status-compliant" id="fostacUnitCard">
                 <div class="card-header">
                     <h3 class="card-title">
                         <i class="fa-solid fa-building-shield icon-building"></i> FoSTaC Unit Compliance
                     </h3>
                     <span class="status-badge" id="unit-card-status-badge">COMPLIANT</span>
                 </div>

                 <div class="progress-section">
                     <div class="progress-bar-container">
                         <div class="progress-bar" id="unit-card-progress-bar" style="width: 0%;"></div>
                     </div>
                     <span class="progress-text" id="unit-card-progress-text">0% Compliant (0/0)</span>
                 </div>

                 <div class="card-details">
                     <div class="detail-item">
                        <!-- Content of this span is now set dynamically in JS to "Non-Compliant : Unit 12" -->
                        <i class="fa-regular fa-calendar-check icon-calendar"></i>
                        <span id="unit-card-next-expiry-parent"> <!-- ID added to parent span for easier targeting -->
                            <strong id="unit-card-next-expiry">N/A</strong> <!-- This strong tag might get overwritten -->
                        </span>
                     </div>
                     <div class="detail-item">
                         <i class="fa-solid fa-check-circle icon-check"></i>
                         <span>Compliant Units: <strong id="unit-card-compliant-units">0/0</strong></span>
                     </div>
                 </div>

                 <div class="card-extra-info">
                     <!-- Example: Showing units needing attention -->
                      <span class="unit-needs-attention-info" id="unit-card-needs-attention" style="display: none;">
                         <i class="fa-solid fa-triangle-exclamation"></i> Needs Attention: <span id="unit-card-needs-attention-count">0</span> units
                      </span>
                 </div>

                 <div class="card-actions">
                     <button class="btn btn-secondary" id="unit-card-view-btn">
                         <i class="fa-regular fa-eye"></i> View Units/Areas
                     </button>
                     <!-- REMOVED Audit Schedule Button -->
                 </div>
             </div> <!-- End of fostacUnitCard -->
             <!-- END: NEW FoSTaC Unit Compliance Card -->

        </div> <!-- End compliance-cards-container -->

        <!-- FoSTaC Records Section -->
        <div class="employee-records-section"> <!-- Scroll Target -->
             <!-- Table Controls -->
            <div class="table-controls">
                <button id="addNewEmployeeBtn" class="control-btn add"> <i class="fas fa-plus"></i> Add New Record </button>
                <button id="refreshTableBtn" class="control-btn refresh"> <i class="fas fa-sync-alt"></i> Refresh Table </button>
                <button id="exportTableBtn" class="control-btn export"> <i class="fas fa-download"></i> Export Visible Data </button>
                <span id="activeCardFilterInfo" style="margin-left: auto; font-size: 0.9em; color: var(--dark-gray); font-style: italic;"></span> <!-- Moved to right -->
            </div>
            <!-- Table Container -->
            <div class="table-container">
                
                <form action="{{route('saveDocuments')}}" method="post" enctype="multipart/form-data">
                    @csrf
                <table class="reports-table" id="currentTrainingsTable">
                     <thead>
                        <tr>
                            <th>Sl No</th>
                            <th>Unit Name <i class="fas fa-filter filter-icon" data-column="1"></i></th>
                            <th>Emp ID <i class="fas fa-filter filter-icon" data-column="2"></i></th>
                            <th>Name <i class="fas fa-filter filter-icon" data-column="3"></i></th>
                            <th>Dept <i class="fas fa-filter filter-icon" data-column="4"></i></th>
                            <th>Design. <i class="fas fa-filter filter-icon" data-column="5"></i></th>
                            <th>Food Handler <i class="fas fa-filter filter-icon" data-column="6"></i></th>
                            <th>Staff Category <i class="fas fa-filter filter-icon" data-column="7"></i></th>
                            <th>DOB <i class="fas fa-filter filter-icon" data-column="8"></i></th>
                            <th>DOJ <i class="fas fa-filter filter-icon" data-column="9"></i></th>
                            <th>Training Level <i class="fas fa-filter filter-icon" data-column="10"></i></th>
                            <th>Training Type <i class="fas fa-filter filter-icon" data-column="11"></i></th>
                            <th>Training Date <i class="fas fa-filter filter-icon" data-column="12"></i></th>
                            <th>Cert. Validity <i class="fas fa-filter filter-icon" data-column="13"></i></th>
                            <th>Days Left</th> <!-- No Filter -->
                            <th>Certificate <i class="fas fa-filter filter-icon" data-column="15"></i></th>
                            <th>Status <i class="fas fa-filter filter-icon" data-column="16"></i></th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="current-trainings-body">
                        <tr><td colspan="18" style="text-align: center; padding: 20px; color: var(--dark-gray);">Loading training data...</td></tr>
                    </tbody>
                </table>
                </form>
                 <!-- Filter Dropdown Template -->
                 <div class="filter-dropdown" id="filterDropdownTemplate" style="display: none;">
                     <div class="standard-filter-content">
                        <input type="text" placeholder="Search options..." class="filter-search">
                        <div class="filter-options"></div>
                     </div>
                     <div class="custom-filter-content"></div>
                     <div class="filter-buttons">
                         <button class="filter-apply-btn">Apply</button>
                         <button class="filter-clear-btn">Clear</button>
                     </div>
                 </div>
            </div>

            <!-- Pagination Container -->
             <div class="pagination-container">
                <div class="rows-per-page-selector">
                    <label for="rowsPerPageSelect">Rows per page:</label>
                    <select id="rowsPerPageSelect">
                        <option value="10" selected>10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>
                 <div class="pagination-controls">
                     <button id="prevPageBtn" class="action-btn" disabled><i class="fas fa-chevron-left"></i></button> <!-- Icon Only -->
                     <div id="pageNumbers"></div> <!-- Page numbers here -->
                     <button id="nextPageBtn" class="action-btn" disabled><i class="fas fa-chevron-right"></i></button> <!-- Icon Only -->
                 </div>
                  <span id="pageInfo"></span> <!-- Page info like "Showing 1-10 of 50" -->
             </div>

        </div> <!-- End employee-records-section -->

    </div> <!-- End Main Content -->

    <!-- History Modal -->
    <div class="modal" id="historyModal">
        <!-- Modal content remains the same -->
        <div class="modal-content">
            <div class="modal-header">
                <h2>Training History for <span id="history-emp-name"></span> (ID: <span id="history-emp-id"></span>)</h2>
                <button class="close-modal" onclick="closeModal('historyModal')" aria-label="Close history modal">×</button>
            </div>
            <div class="modal-body" id="history-content">
                <div style="margin-bottom: 15px; font-size: 14px; padding-bottom: 10px; border-bottom: 1px solid #eee;">
                    <strong>Current Status:</strong> <span id="history-current-status" class="status">N/A</span>
                </div>
                <h3 style="margin-top: 20px; margin-bottom: 10px; font-size: 1rem;">Training Record History</h3>
                <div class="scrollable-table">
                     <table class="parameter-history-table">
                         <thead>
                             <tr>
                                 <th>Updated On</th>
                                 <th>Training Level</th>
                                 <th>Training Type</th>
                                 <th>Training Date</th>
                                 <th>Cert. Validity</th>
                                 <th>Cert.</th>
                                 <th>Overall Status</th>
                                 <th>Updated By</th>
                             </tr>
                         </thead>
                         <tbody id="training-history-details">
                             <tr><td colspan="8" style="text-align: center; padding: 20px; color: var(--dark-gray);">Training history unavailable.</td></tr>
                         </tbody>
                     </table>
                 </div>
                <h3 style="margin-top: 25px; margin-bottom: 10px; font-size: 1rem;">Change Log</h3>
                <div class="table-container">
                    <table class="history-table">
                        <thead> <tr> <th>Date</th> <th>Action</th> <th>Changed By</th> <th>Details</th> </tr> </thead>
                        <tbody id="change-history-details"> <tr><td colspan="4" style="text-align: center; padding: 20px; color: var(--dark-gray);">No changes recorded.</td></tr> </tbody>
                    </table>
                </div>
            </div>
        </div>
     </div>

                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                    <!--end row-->  
                    
                    

@endsection


@section('footerscript')
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
 
  
    
    <script>
        // --- Global Variables ---
        const employeeMasterList = {
            <?php foreach ($unit_users_list as $user): ?>
            '<?= $user->employe_id ?>': { name: '<?= $user->employer_fullname ?>', department: '<?= $user->department_name ?>', designation: '<?= $user->designation ?>', foodHandlerCategory: '<?= $user->cat_name ?>', staffCategory: '<?= $user->staff_category ?>', dob: '<?= $user->dob ?>', doj: '<?= $user->dog ?>' },
            <?php endforeach; ?>
            
        };

        let trainingData = { // Use 'let' as it will be modified
         <?php foreach ($documentsList as $user): ?>
            '<?= $user->employe_id ?>': { unitName: '<?= Auth::user()->company_name ?> ', name: '<?= $user->employer_fullname ?>', department: '<?= $user->department_name ?>', designation: '<?= $user->designation ?>', foodHandlerCategory: '<?= $user->cat_name ?>', staffCategory: '<?= $user->staff_category ?>', dob: '<?= $user->dob ?>', doj: '<?= $user->dog ?>', trainingLevel: '<?= $user->trainingLevel ?>', trainingType: '<?= $user->trainingType ?>', trainingDate: '<?= $user->trainingDate ?>', certificateValidity: '<?= $user->certificateValidity ?>', status: 'completed', certificate: 'https://efsm.safefoodmitra.com/admin/public/documents/<?= $user->image ?>', history: [] }, // Valid until 2026-01-09
 <?php endforeach; ?>
         };

        let originalRowData = {}; // Backup for edits
        const currentUser = 'Admin'; // Or dynamically get user
        const unitHierarchy = { "Corp A": { "Region North": ["Unit A", "Unit B", "Warehouse North"], "Region South": ["Unit C", "Factory South"] }, "Corp B": { "Region East": ["Unit D", "Office East"], "Region West": ["Unit E", "Logistics West"] }, "Corporate Services": { "HQ": ["Admin Unit", "IT Support"], "Shared Facilities": ["Central Lab"] } };

        let currentPage = 1;
        let rowsPerPage = 10; // Default value, will be set by selector
        let currentTableFilter = 'default'; // State for card filters: 'default', 'validOnly', 'expiringSoon'
        const expiringSoonThreshold = 60; // Days threshold for expiring soon (<= 60 days)
        const nearExpiryThreshold = 30; // Days threshold for near expiry (<= 30 days)

        const FOSTAC_LEVELS = ['Awareness', 'Basic', 'Advanced', 'Supervisor', 'Trainer', 'Assessor'];
        const FOSTAC_TYPES = ['General', 'Catering', 'Manufacturing', 'Retail & Distribution', 'Storage & Transport', 'Milk & Milk Products', 'Meat & Poultry', 'Fish & Seafood', 'Bakery', 'Edible Oil & Fat', 'Water', 'Health Supplements', 'FSMS'];
        const FOSTAC_VALIDITY = ['1 Year', '2 Years'];

        // --- Status Calculation (Includes Days Left) ---
        function calculateOverallStatus(employeeTrainingData, isFinalizing = false) {
            if (!employeeTrainingData) { return { status: 'pending', isExpired: false, calculatedExpiryDate: null, daysLeft: null }; }
            const today = new Date(); today.setHours(0, 0, 0, 0);
            let status = 'pending'; let isExpired = false; let calculatedExpiryDate = null; let daysLeft = null;
            const trainingDateStr = employeeTrainingData.trainingDate; const validity = employeeTrainingData.certificateValidity; let tempDaysLeft = null;
            if (trainingDateStr && validity) {
                try {
                    const trainingDate = new Date(trainingDateStr + 'T00:00:00');
                    if (!isNaN(trainingDate.getTime())) {
                        let expiryYear = trainingDate.getFullYear(); let expiryMonth = trainingDate.getMonth(); let expiryDay = trainingDate.getDate();
                        if (validity === '1 Year') expiryYear += 1; else if (validity === '2 Years') expiryYear += 2;
                        calculatedExpiryDate = new Date(expiryYear, expiryMonth, expiryDay);
                        let expiryCheckDate = new Date(calculatedExpiryDate); expiryCheckDate.setDate(expiryCheckDate.getDate() - 1); expiryCheckDate.setHours(23, 59, 59, 999);
                        if (today > expiryCheckDate) { isExpired = true; status = 'expired'; tempDaysLeft = -1 * Math.ceil(Math.abs(today.getTime() - expiryCheckDate.getTime()) / (1000 * 60 * 60 * 24)); }
                        else { const diffTime = expiryCheckDate.getTime() - today.getTime(); tempDaysLeft = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24))); status = 'completed'; }
                    } else { console.warn(`Invalid training date format: ${trainingDateStr}`); status = 'pending'; }
                } catch (e) { console.error("Error calculating expiry date:", e, "for data:", employeeTrainingData); status = 'pending'; }
            } else { status = 'pending'; }
            daysLeft = tempDaysLeft;
            if (isFinalizing && employeeTrainingData?.status === 'draft') { /* Use calculated status/daysLeft */ }
            else if (employeeTrainingData?.status === 'draft' && !isFinalizing) { status = 'draft'; daysLeft = null; calculatedExpiryDate = null; }
            else if (status === 'pending') { daysLeft = null; calculatedExpiryDate = null; }
            else if (status === 'expired') { daysLeft = tempDaysLeft !== null ? tempDaysLeft : null; }
            const finalExpiryDate = calculatedExpiryDate ? new Date(new Date(calculatedExpiryDate).setDate(calculatedExpiryDate.getDate() - 1)) : null;
            return { status, isExpired, calculatedExpiryDate: finalExpiryDate, daysLeft };
        }


        // --- Dashboard Card Update Function ---
        function updateDashboardCards() {
            console.log("Updating dashboard cards...");
            const allEmployeeIds = Object.keys(trainingData);
            const totalRecords = allEmployeeIds.length; // Represents total employees for FOSTAC Training

            // *** NOTE: Unit Compliance Logic Placeholder ***
            let validCount = 0, expiredCount = 0, pendingDraftCount = 0, expiringSoonCount = 0, nearExpiryCount = 0;
            let earliestExpiryDateObj = null, earliestDaysLeft = Infinity;

            allEmployeeIds.forEach(empId => {
                const emp = trainingData[empId];
                const { status: calculatedStatus, daysLeft, calculatedExpiryDate } = calculateOverallStatus(emp, false);
                const effectiveStatus = emp.status === 'draft' ? 'draft' : (emp.status === 'pending' ? 'pending' : calculatedStatus);

                switch(effectiveStatus) {
                    case 'completed':
                        if (daysLeft !== null && daysLeft >= 0) {
                            if (daysLeft <= nearExpiryThreshold) { nearExpiryCount++; expiringSoonCount++; }
                            else if (daysLeft <= expiringSoonThreshold) { expiringSoonCount++; }
                            else { validCount++; }
                            if (calculatedExpiryDate) {
                                if (!earliestExpiryDateObj || calculatedExpiryDate < earliestExpiryDateObj) {
                                    earliestExpiryDateObj = calculatedExpiryDate; earliestDaysLeft = daysLeft;
                                } else if (calculatedExpiryDate && earliestExpiryDateObj && calculatedExpiryDate.getTime() === earliestExpiryDateObj.getTime()) {
                                    earliestDaysLeft = Math.min(earliestDaysLeft, daysLeft);
                                }
                            }
                        } else { pendingDraftCount++; }
                        break;
                    case 'expired': expiredCount++; break;
                    case 'pending': case 'draft': pendingDraftCount++; break;
                }
            });

            const compliantCount = validCount + expiringSoonCount; // Placeholder
            const needsAttentionCount = expiredCount + pendingDraftCount + expiringSoonCount; // Placeholder
            const compliancePercentage = totalRecords > 0 ? (compliantCount / totalRecords) * 100 : 0; // Placeholder
            const earliestExpiryDateStr = earliestExpiryDateObj ? earliestExpiryDateObj.toISOString().split('T')[0] : (totalRecords > 0 ? 'N/A' : '--');

            // --- Update FOSTAC Training Card Elements ---
            const fostacTrainingCard = document.getElementById('fostacTrainingCard');
            if (fostacTrainingCard) {
                const fostacStatusBadge = document.getElementById('fostac-training-status-badge');
                const fostacProgressBar = document.getElementById('fostac-training-progress-bar');
                const fostacProgressText = document.getElementById('fostac-training-progress-text');
                const fostacNextDue = document.getElementById('fostac-training-next-due');
                const fostacValidCertsText = document.getElementById('fostac-training-valid-certs');
                const fostacExpiredSpan = document.getElementById('fostac-training-expired');
                const fostacExpiredCount = document.getElementById('fostac-training-expired-count');
                const fostacNearExpirySpan = document.getElementById('fostac-training-near-expiry');
                const fostacNearExpiryCount = document.getElementById('fostac-training-near-expiry-count');
                const fostacExpiringSpan = document.getElementById('fostac-training-expiring-soon');
                const fostacExpiringCount = document.getElementById('fostac-training-expiring-soon-count');

                fostacTrainingCard.classList.remove('status-due-soon', 'status-non-compliant', 'status-compliant');
                let cardStatusText = 'COMPLIANT'; let cardStatusClass = 'status-compliant';
                 if (expiredCount > 0) { cardStatusText = 'ACTION REQUIRED'; cardStatusClass = 'status-non-compliant'; }
                 else if (nearExpiryCount > 0) { cardStatusText = 'DUE SOON'; cardStatusClass = 'status-due-soon'; }
                 else if (expiringSoonCount > 0) { cardStatusText = 'DUE SOON'; cardStatusClass = 'status-due-soon'; }
                 else if (pendingDraftCount > 0) { cardStatusText = 'PENDING DATA'; cardStatusClass = 'status-due-soon'; }
                fostacTrainingCard.classList.add(cardStatusClass);
                if(fostacStatusBadge) fostacStatusBadge.textContent = cardStatusText;
                if(fostacProgressBar) fostacProgressBar.style.width = `${compliancePercentage.toFixed(1)}%`;
                if(fostacProgressText) fostacProgressText.textContent = `${Math.round(compliancePercentage)}% Completed (${compliantCount}/${totalRecords})`;
                if(fostacNextDue) fostacNextDue.textContent = earliestExpiryDateStr;
                if(fostacValidCertsText) fostacValidCertsText.textContent = `${validCount}/${totalRecords}`;
                if(fostacExpiredSpan && fostacExpiredCount) { fostacExpiredCount.textContent = expiredCount; fostacExpiredSpan.style.display = (expiredCount > 0) ? 'inline-flex' : 'none'; }
                if(fostacNearExpirySpan && fostacNearExpiryCount) { fostacNearExpiryCount.textContent = nearExpiryCount; fostacNearExpirySpan.style.display = (nearExpiryCount > 0) ? 'inline-flex' : 'none'; }
                if(fostacExpiringSpan && fostacExpiringCount) { fostacExpiringCount.textContent = expiringSoonCount; fostacExpiringSpan.style.display = (expiringSoonCount > 0) ? 'inline-flex' : 'none'; }
            }

            // --- Update FoSTaC Unit Compliance Card ---
            const unitCard = document.getElementById('fostacUnitCard');
            if (unitCard) {
                const unitStatusBadge = document.getElementById('unit-card-status-badge');
                const unitProgressBar = document.getElementById('unit-card-progress-bar');
                const unitProgressText = document.getElementById('unit-card-progress-text');
                const unitDetailItemParentSpan = document.getElementById('unit-card-next-expiry-parent');
                const unitCompliantUnits = document.getElementById('unit-card-compliant-units');
                const unitNeedsAttentionSpan = document.getElementById('unit-card-needs-attention');
                const unitNeedsAttentionCount = document.getElementById('unit-card-needs-attention-count');

                unitCard.classList.remove('status-due-soon', 'status-non-compliant', 'status-compliant');
                const unitComplianceThreshold = 90; // Example threshold
                let unitCardStatusText = 'COMPLIANT'; let unitCardStatusClass = 'status-compliant';

                 if (expiredCount > 0) { unitCardStatusText = 'NON-COMPLIANT'; unitCardStatusClass = 'status-non-compliant'; }
                 else if (nearExpiryCount > 0) { unitCardStatusText = 'ACTION REQUIRED'; unitCardStatusClass = 'status-due-soon'; }
                 else if (expiringSoonCount > 0) { unitCardStatusText = 'ATTENTION'; unitCardStatusClass = 'status-due-soon'; }
                 else if (compliancePercentage < unitComplianceThreshold) { unitCardStatusText = 'LOW COMPLIANCE'; unitCardStatusClass = 'status-non-compliant'; }
                 else if (pendingDraftCount > 0) { unitCardStatusText = 'PENDING DATA'; unitCardStatusClass = 'status-due-soon'; }

                 unitCard.classList.add(unitCardStatusClass);
                 if(unitStatusBadge) unitStatusBadge.textContent = unitCardStatusText;
                 if(unitProgressBar) unitProgressBar.style.width = `${compliancePercentage.toFixed(1)}%`; // Placeholder %
                 if(unitProgressText) unitProgressText.textContent = `${Math.round(compliancePercentage)}% Compliant (${compliantCount}/${totalRecords})`; // Placeholder text

                 if (unitDetailItemParentSpan) {
                     const iconElement = unitDetailItemParentSpan.querySelector('i');
                     unitDetailItemParentSpan.textContent = '';
                     if (iconElement) {
                         unitDetailItemParentSpan.appendChild(iconElement);
                         unitDetailItemParentSpan.appendChild(document.createTextNode(' '));
                     }
                     unitDetailItemParentSpan.appendChild(document.createTextNode('Non-Compliant : Unit 12')); // Static Text
                 }

                 if(unitCompliantUnits) unitCompliantUnits.textContent = `${compliantCount}/${totalRecords}`; // Placeholder count
                 const unitAttentionValue = needsAttentionCount; // Placeholder
                 if(unitNeedsAttentionSpan && unitNeedsAttentionCount) {
                    unitNeedsAttentionCount.textContent = unitAttentionValue;
                    // Visibility handled by CSS based on card status
                 }
             }
             console.log("Dashboard cards updated.");
        }


        // --- Helper to Clear All Column Filters ---
        function clearAllColumnFilters(thead = null) {
             console.log("Clearing all column filters.");
             if (!thead) thead = document.getElementById('currentTrainingsTable')?.querySelector('thead');
             if (!thead) return;
             thead.querySelectorAll('th[data-filter-active="true"]').forEach(th => {
                 th.dataset.filterActive = 'false'; th.dataset.filterType = ''; th.dataset.filterValue = '';
                 const filterIcon = th.querySelector('.filter-icon'); if (filterIcon) filterIcon.style.color = '';
                  const dropdown = th.querySelector('.filter-dropdown');
                  if (dropdown) {
                       const filterType = determineFilterType(th.cellIndex);
                        if (filterType === 'unit') { dropdown.querySelectorAll('.filter-unit-select').forEach(sel => sel.selectedIndex = 0); dropdown.querySelector('#filter-regional').disabled = true; dropdown.querySelector('#filter-unit').disabled = true; }
                        else if (filterType === 'date') { dropdown.querySelectorAll('.filter-date-input').forEach(input => input.value = ''); }
                        else { dropdown.querySelectorAll('.filter-options input[type="checkbox"]').forEach(cb => cb.checked = false); const searchInput = dropdown.querySelector('.filter-search'); if (searchInput) searchInput.value = ''; filterDropdownOptions(dropdown, ''); }
                    }
             });
        }

        // --- Setup Card Click Listeners ---
        function setupCardClickListeners() {
            const validLink = document.getElementById('fostac-valid-count-link');
            const expiringLink = document.getElementById('fostac-expiring-count-link');
            const viewCertificateBtn = document.getElementById('fostac-view-all-btn');
            const cardFilterInfo = document.getElementById('activeCardFilterInfo');
            const recordsSection = document.querySelector('.employee-records-section');

            const applyCardFilter = (filterType, scrollToTable = false) => {
                 console.log(`${filterType} card filter applied.`);
                 currentTableFilter = filterType;
                 clearAllColumnFilters();
                 applyAllFilters();

                 if (cardFilterInfo) {
                     if (filterType === 'validOnly') cardFilterInfo.textContent = 'Showing: Valid Certificates Only (>60 days left)';
                     else if (filterType === 'expiringSoon') cardFilterInfo.textContent = 'Showing: Expiring Soon Only (<60d)';
                     else cardFilterInfo.textContent = '';
                 }

                 if (scrollToTable && recordsSection) {
                    recordsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                 }
            };

            if (validLink) validLink.addEventListener('click', (e) => { e.preventDefault(); applyCardFilter('validOnly', true); });
            if (expiringLink) expiringLink.addEventListener('click', (e) => { e.preventDefault(); applyCardFilter('expiringSoon', true); });
            if (viewCertificateBtn) viewCertificateBtn.addEventListener('click', (e) => { e.preventDefault(); applyCardFilter('validOnly', true); }); // Changed to 'validOnly' for consistency

            // Unit card view button listener (placeholder action)
             const unitViewBtn = document.getElementById('unit-card-view-btn');
             if (unitViewBtn) unitViewBtn.addEventListener('click', () => alert('Unit View Button Clicked (placeholder)'));
             // Removed listener for unit-card-schedule-btn as the button is removed
        }


        // --- DOMContentLoaded ---
        document.addEventListener('DOMContentLoaded', () => {
            document.title = "FoSTaC Training Tracker";
            const logoH2 = document.querySelector('.logo h2'); if(logoH2) logoH2.textContent = "FoSTaC Training Tracker";
            const mainHeaderH1 = document.getElementById('mainHeaderText'); if(mainHeaderH1) mainHeaderH1.textContent = "Employee FoSTaC Training Records";

            setupRowsPerPageSelector(); // Setup selector early to get initial value
            loadInitialData();
            setupModalClosers();
            setupFilterIcons();
            setupFileInputs();
            setupControlButtons(); // Sets up Add, Refresh, and Export listeners
            updateDashboardCards();
            setupCardClickListeners();
            applyAllFilters(); // Initial load with default filters & pagination
            setupPaginationEventListeners();
            document.getElementById('current-trainings-body')?.addEventListener('change', handleEmployeeSelectionChange);
        });

        // --- Data Loading ---
        function loadInitialData() {
            console.log("Loading initial FoSTaC training data...");
            const tableBody = document.getElementById('current-trainings-body');
            if (!tableBody) { console.error("Table body not found!"); return; }
            tableBody.innerHTML = ''; // Clear previous content

            const dataEntries = Object.entries(trainingData);

            if (dataEntries.length === 0) {
                 tableBody.innerHTML = `<tr><td colspan="18" style="text-align: center; padding: 20px; color: var(--dark-gray);">No training data found. Add records.</td></tr>`;
                 document.querySelector('.pagination-container')?.style.setProperty('display', 'none'); return;
            } else { document.querySelector('.pagination-container')?.style.removeProperty('display'); }

             // Sort data by name before creating rows
             dataEntries.sort(([,a], [,b]) => (a?.name || '').localeCompare(b?.name || ''));

             for (const [empId, employeeTraining] of dataEntries) {
                 const newRow = createTableRow(empId, employeeTraining);
                 newRow.style.display = 'none'; // Hide initially, pagination will show
                 tableBody.appendChild(newRow);
             }
            console.log(`Initial FoSTaC data structure built with ${dataEntries.length} records.`);
        }

  function createTableRow(empId, employeeTraining, isNew = false) {
    const row = document.createElement('tr');
    row.setAttribute('data-emp-id', empId);
    
    
    // if(isNew==false){
    //     var savefilename= 'old';
    // }else{
    //      var savefilename= 'new';
    // }

    const masterDetails = employeeMasterList[empId];
    const displayData = {
        empId: empId,
        name: employeeTraining?.name || masterDetails?.name || (isNew ? 'Select Employee' : 'N/A'),
        department: employeeTraining?.department || masterDetails?.department || '',
        designation: employeeTraining?.designation || masterDetails?.designation || '',
        foodHandlerCategory: employeeTraining?.foodHandlerCategory || masterDetails?.foodHandlerCategory || '',
        staffCategory: employeeTraining?.staffCategory || masterDetails?.staffCategory || '',
        dob: employeeTraining?.dob || masterDetails?.dob || '',
        doj: employeeTraining?.doj || masterDetails?.doj || '',
        unitName: employeeTraining?.unitName || '',
        trainingLevel: employeeTraining?.trainingLevel || null,
        trainingType: employeeTraining?.trainingType || (isNew ? 'General' : null),
        trainingDate: employeeTraining?.trainingDate || null,
        certificateValidity: employeeTraining?.certificateValidity || (isNew ? '2 Years' : null),
        certificate: employeeTraining?.certificate || null,
        status: employeeTraining?.status || 'pending'
    };

    const initialStage = (isNew || displayData.status === 'draft') ? 'drafting' : 'view';
    row.setAttribute('data-edit-stage', initialStage);
    if (isNew) row.classList.add('new-record-edit');

    const { status: overallStatus, daysLeft } = calculateOverallStatus(displayData, false);

    const createOptions = (optionsArray, selectedValue) => {
        let html = `<option value="" ${!selectedValue ? 'selected' : ''}>--</option>`;
        optionsArray.forEach(opt => {
            html += `<option value="${opt}" ${selectedValue === opt ? 'selected' : ''}>${opt}</option>`;
        });
        return html;
    };

    const createEmployeeOptions = (selectedEmpId) => {
        let html = `<option value="">-- Select Employee --</option>`;
        Object.keys(employeeMasterList)
            .sort((a, b) => employeeMasterList[a].name.localeCompare(employeeMasterList[b].name))
            .forEach(id => {
                const emp = employeeMasterList[id];
                html += `<option value="${id}" ${selectedEmpId === id ? 'selected' : ''}>${id} - ${emp.name}</option>`;
            });
        return html;
    };

    let mainButtonClass = 'update', mainButtonIcon = 'fa-pencil-alt', mainButtonText = 'Update';
    if (initialStage === 'drafting') {
        mainButtonClass = 'save-draft';
        mainButtonIcon = 'fa-save';
        mainButtonText = 'Save as Draft';
    }

    let daysLeftClass = '';
    if (daysLeft !== null && daysLeft >= 0) {
        if (daysLeft <= nearExpiryThreshold) daysLeftClass = 'days-left-very-low';
        else if (daysLeft <= expiringSoonThreshold) daysLeftClass = 'days-left-low';
    }

    const daysLeftDisplay = daysLeft !== null ? daysLeft : '-';
    const certificateDisplayText = displayData.certificate || 'Not uploaded';
    const certificateIsUploaded = !!displayData.certificate;
    const fileInputId = `cert-${empId.replace(/[^a-zA-Z0-9_-]/g, '')}`;
    const statusClass = overallStatus === 'overdue' ? 'expired' : (overallStatus || 'pending');
    const statusText = statusClass.charAt(0).toUpperCase() + statusClass.slice(1);


const savefilename = isNew ? 'new' : 'old';
const disabledAttr = savefilename === 'old' ? 'disabled' : '';

let actionButtonHTML = '';

actionButtonHTML='<a class="action-btn main-action-btn" target="_blank()" href="${certificateDisplayText}"><i class="fas fa-certificate"></i></a>';

if (savefilename === 'old') {
    actionButtonHTML += `
        <button type="button" class="action-btn main-action-btn ${mainButtonClass}" onclick="handleMainAction(this)" ${isNew ? 'disabled' : ''}>
            <i class="fas ${mainButtonIcon}"></i> <span>${mainButtonText}</span>
        </button>
    `;
} else {
    actionButtonHTML += `
        <button class="action-btn main-action-btn" type="submit">
            <i class="fas fa-check-circle"></i> <span>Final Submit</span>
        </button>
    `;
}

actionButtonHTML += `
    <button class="action-btn history-btn" onclick="showHistoryModal('${empId}')" ${initialStage !== 'view' || isNew ? 'style="display: none;"' : ''}>
        <i class="fas fa-history"></i> <span>History</span>
    </button>
    <button class="action-btn delete-btn" onclick="handleDeleteRecord(this)" ${initialStage !== 'view' || isNew ? 'style="display: none;"' : ''}>
        <i class="fas fa-trash-alt"></i> <span>Delete</span>
    </button>
    <button class="action-btn cancel-btn" onclick="cancelMultiStageEdit(this)" ${initialStage === 'view' ? 'style="display: none;"' : ''}>
        <i class="fas fa-times"></i> <span>Cancel</span>
    </button>
`;



    row.innerHTML = `
        <td class="sl-no"></td>
        <td data-field="unitName" contenteditable="false"><?= Auth::user()->company_name ?></td>
        <td data-field="empId">${isNew ? `<select name="empId" class="employee-select">${createEmployeeOptions(null)}</select>` : empId}</td>
        <td data-field="name">${displayData.name}</td>
        <td data-field="department">${displayData.department || 'N/A'}</td>
        <td data-field="designation">${displayData.designation || 'N/A'}</td>
        <td data-field="foodHandlerCategory">${displayData.foodHandlerCategory || 'N/A'}</td>
        <td data-field="staffCategory">${displayData.staffCategory || 'N/A'}</td>
        <td data-field="dob">${displayData.dob || '-'}</td>
        <td data-field="doj">${displayData.doj || '-'}</td>
        <td data-field="trainingLevel"><select class="training-level-select" name="trainingLevel" ${disabledAttr}>${createOptions(FOSTAC_LEVELS, displayData.trainingLevel)}</select></td>
        <td data-field="trainingType" ><input type="text" name="trainingType" class="training-date-input" value="${displayData.trainingType || 'N/A'}" ${disabledAttr}></td>
        <td data-field="trainingDate"><input type="date" name="trainingDate" class="training-date-input" value="${displayData.trainingDate || ''}" ${disabledAttr}></td>
        <td data-field="certificateValidity"><select name="certificateValidity" class="validity-select" ${disabledAttr}>${createOptions(FOSTAC_VALIDITY, displayData.certificateValidity)}</select></td>
        <td data-field="daysLeft" class="${daysLeftClass}">${daysLeftDisplay}</td>
        <td data-field="certificate">
            <div class="certificate-upload">
                <input type="file" name="${savefilename}" class="certificate-input" ${disabledAttr} data-emp="${empId}" accept=".pdf,.jpg,.png,.jpeg,.doc,.docx" >
                <label for="${fileInputId}" class="certificate-btn"><i class="fas fa-upload"></i> Upload</label>
                <span class="certificate-status ${certificateIsUploaded ? 'uploaded' : ''}" title="${certificateDisplayText}">${certificateDisplayText}</span>
            </div>
        </td>
        <td data-field="status"><span class="status ${statusClass}">${statusText}</span></td>
        <td>
            <div class="action-buttons">
            
             ${actionButtonHTML}
            </div>
        </td>
    `;

    return row;
}



        // --- Handle Employee Selection Change (for New Records) ---
         function handleEmployeeSelectionChange(event) {
             if (event.target.classList.contains('employee-select')) {
                 const selectElement = event.target; const row = selectElement.closest('tr');
                 const selectedEmpId = selectElement.value; const mainActionButton = row.querySelector('.main-action-btn.save-draft');
                 if (!row || !row.classList.contains('new-record-edit')) return;
                 const fieldsToClear = ['name', 'department', 'designation', 'foodHandlerCategory', 'staffCategory', 'dob', 'doj', 'unitName', 'trainingType']; fieldsToClear.forEach(field => { const cell = row.querySelector(`td[data-field="${field}"]`); if (cell) cell.textContent = ''; });
                 row.querySelector('select.training-level-select').value = ''; row.querySelector('input.training-date-input').value = ''; row.querySelector('select.validity-select').value = '';
                 const certStatus = row.querySelector('.certificate-status'); if(certStatus) { certStatus.textContent = 'Not uploaded'; certStatus.classList.remove('uploaded'); certStatus.title = 'Not uploaded'; }
                 if (selectedEmpId && employeeMasterList[selectedEmpId]) {
                     const empDetails = employeeMasterList[selectedEmpId]; row.setAttribute('data-emp-id', selectedEmpId);
                     const fieldsToUpdate = { name: empDetails.name, department: empDetails.department, designation: empDetails.designation, foodHandlerCategory: empDetails.foodHandlerCategory, staffCategory: empDetails.staffCategory, dob: empDetails.dob || '-', doj: empDetails.doj || '-' };
                     for (const field in fieldsToUpdate) { const cell = row.querySelector(`td[data-field="${field}"]`); if (cell) cell.textContent = fieldsToUpdate[field] || 'N/A'; }
                     row.querySelector('td[data-field="unitName"]').textContent = 'N/A'; row.querySelector('td[data-field="trainingType"]').textContent = 'General'; row.querySelector('select.validity-select').value = '2 Years';
                     if (trainingData[selectedEmpId]) setTimeout(() => alert(`Warning: Employee ${selectedEmpId} - ${empDetails.name} already has a training record. You are adding another record.`), 0);
                     makeRowEditable(row, true); if(mainActionButton) mainActionButton.disabled = false; updateButtonUI(row, 'drafting'); row.dataset.editStage = 'drafting';
                 } else { row.setAttribute('data-emp-id', 'NEW_RECORD_' + Date.now()); if(mainActionButton) mainActionButton.disabled = true; makeRowEditable(row, false); }
             }
         }

        // --- Modal Handling ---
        function showModal(modalId) { const modal = document.getElementById(modalId); if (modal) { modal.classList.add('show'); document.body.style.overflow = 'hidden'; } }
        function closeModal(modalId) { const modal = document.getElementById(modalId); if (modal) { modal.classList.remove('show'); document.body.style.overflow = ''; } }
        function setupModalClosers() { document.querySelectorAll('.modal').forEach(modal => { modal.addEventListener('click', function(event) { if (event.target === this) { closeModal(this.id); } }); }); }

        // --- Control Buttons & Export ---
        function setupControlButtons() {
            const addBtn = document.getElementById('addNewEmployeeBtn');
            const refreshBtn = document.getElementById('refreshTableBtn');
            const exportBtn = document.getElementById('exportTableBtn'); // Get the export button

            if (addBtn) addBtn.addEventListener('click', addNewEmployeeRecord);
            if (refreshBtn) refreshBtn.addEventListener('click', refreshTable);
            if (exportBtn) exportBtn.addEventListener('click', exportTableToCSV); // Add listener
        }

        function addNewEmployeeRecord() {
            const existingNewRow = document.querySelector('tr.new-record-edit');
            if (existingNewRow) { alert("Please complete or cancel the current new record first."); existingNewRow.scrollIntoView({ behavior: 'smooth', block: 'center' }); existingNewRow.querySelector('select.employee-select')?.focus(); return; }
            const tableBody = document.getElementById('current-trainings-body');
            if (!tableBody) return;
            const tempId = 'NEW_RECORD_' + Date.now(); const newRow = createTableRow(tempId, {}, true);
            const placeholderRow = tableBody.querySelector('td[colspan="18"]'); if (placeholderRow) placeholderRow.closest('tr').remove();
            tableBody.insertBefore(newRow, tableBody.firstChild);
            makeRowEditable(newRow, false);
            newRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
            newRow.querySelector('select.employee-select')?.focus();
            applyAllFilters(); // To ensure correct pagination/display state
        }

        function refreshTable() {
            console.log("Refreshing FoSTaC table...");
            const cardFilterInfo = document.getElementById('activeCardFilterInfo');
            closeAllFilterDropdowns();
            clearAllColumnFilters();
            currentTableFilter = 'default';
            if (cardFilterInfo) cardFilterInfo.textContent = '';
            const newRecordRow = document.querySelector('tr.new-record-edit'); if (newRecordRow) newRecordRow.remove();
            loadInitialData();
            applyAllFilters(); // Apply default filters and pagination
            updateDashboardCards();
            console.log("Table refreshed.");
        }

        /**
         * Escapes a value for safe inclusion in a CSV file.
         * @param {*} value The value to escape.
         * @returns {string} The escaped value.
         */
        function escapeCSVValue(value) {
            const stringValue = value === null || value === undefined ? '' : String(value);
            if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n') || stringValue.includes('\r')) {
                const escapedValue = stringValue.replace(/"/g, '""');
                return `"${escapedValue}"`;
            }
            return stringValue;
        }

        /**
         * Gathers visible data from the table and triggers a CSV download.
         */
        function exportTableToCSV() {
            console.log("Exporting visible FoSTaC data to CSV...");
            const table = document.getElementById('currentTrainingsTable');
            const tableBody = document.getElementById('current-trainings-body');
            if (!table || !tableBody) { alert("Error: Could not find the table to export."); return; }

            const visibleRows = getVisibleRows(tableBody); // Use existing function

            if (visibleRows.length === 0) { alert("No data available to export based on current filters."); return; }

            const csv = [];
            const headers = [];
            const headerCells = table.querySelectorAll('thead th');

            // Extract headers, skipping 'Actions'
            headerCells.forEach((th, index) => {
                if (index < headerCells.length - 1) {
                    // Attempt to get text content excluding potential icon text
                    let headerText = th.firstChild?.textContent?.trim() || th.textContent.trim();
                    headers.push(escapeCSVValue(headerText));
                }
            });
            csv.push(headers.join(','));

            // Extract data from visible rows
            visibleRows.forEach(row => {
                const rowData = [];
                const cells = row.querySelectorAll('td');
                cells.forEach((td, index) => {
                    if (index < cells.length - 1) { // Skip 'Actions'
                        let cellValue = '';
                        const field = td.dataset.field;

                        if (field === 'empId' && td.querySelector('select')) cellValue = td.querySelector('select').value || 'N/A';
                        else if (field === 'trainingLevel' && td.querySelector('select')) cellValue = td.querySelector('select').value || '';
                        else if (field === 'certificateValidity' && td.querySelector('select')) cellValue = td.querySelector('select').value || '';
                        else if (field === 'trainingDate' && td.querySelector('input[type="date"]')) cellValue = td.querySelector('input[type="date"]').value || '';
                        else if (field === 'certificate') cellValue = td.querySelector('.certificate-status')?.textContent.trim() || 'Not uploaded';
                        else if (field === 'status') cellValue = td.querySelector('.status')?.textContent.trim() || 'Pending';
                        else cellValue = td.textContent.trim();

                        rowData.push(escapeCSVValue(cellValue));
                    }
                });
                csv.push(rowData.join(','));
            });

            // Create CSV file and trigger download
            const csvContent = csv.join('\n');
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement("a");

            if (link.download !== undefined) {
                const url = URL.createObjectURL(blob);
                const today = new Date().toISOString().split('T')[0];
                link.setAttribute("href", url);
                link.setAttribute("download", `fostac_export_${today}.csv`);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
                console.log("CSV export triggered.");
            } else {
                alert("CSV export is not supported in your browser.");
            }
        }
        // --- End Control Buttons & Export ---


        // --- Edit Handling ---
        function handleMainAction(button) { const row = button.closest('tr'); const currentStage = row.dataset.editStage || 'view'; console.log(`Handling main action for stage: ${currentStage}`); switch (currentStage) { case 'view': startEditing(button); break; case 'drafting': saveAsDraft(button); break; case 'finalizing': finalSubmit(button); break; default: console.error("Unknown edit stage:", currentStage); } }
        function startEditing(button) { const row = button.closest('tr'); const empId = row.dataset.empId; if (!empId || empId.startsWith('NEW_RECORD_')) return; const currentlyEditingRow = document.querySelector('tr.edit-mode'); if (currentlyEditingRow && currentlyEditingRow !== row) { alert("Please save or cancel the currently editing row first."); currentlyEditingRow.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; } console.log(`Starting FoSTaC edit for existing record ${empId}`); if (!trainingData[empId]) { console.log(`No training data for ${empId}, initializing.`); const master = employeeMasterList[empId] || {}; trainingData[empId] = { empId: empId, name: master.name, department: master.department, designation: master.designation, foodHandlerCategory: master.foodHandlerCategory, staffCategory: master.staffCategory, dob: master.dob, doj: master.doj, unitName: 'N/A', trainingLevel: null, trainingType: 'General', trainingDate: null, certificateValidity: '2 Years', certificate: null, status: 'pending', history: [] }; } originalRowData[empId] = JSON.parse(JSON.stringify(trainingData[empId])); makeRowEditable(row, true); updateButtonUI(row, 'drafting'); row.dataset.editStage = 'drafting'; }
        function saveAsDraft(button) { const row = button.closest('tr'); const empId = row.dataset.empId; console.log(`Saving FoSTaC draft for ${empId}`); if (empId.startsWith('NEW_RECORD_')) { alert("Please select an employee first."); return; } if (!employeeMasterList[empId]) { alert(`Error: Employee ${empId} not found in master list.`); return; } const collectedData = collectRowData(row); const empMasterDetails = employeeMasterList[empId]; const isNewRecord = !originalRowData[empId]; trainingData[empId] = { ...(trainingData[empId] || {}), empId: empId, unitName: collectedData.unitName || 'N/A', name: empMasterDetails.name, department: empMasterDetails.department, designation: empMasterDetails.designation, foodHandlerCategory: empMasterDetails.foodHandlerCategory, staffCategory: empMasterDetails.staffCategory, dob: empMasterDetails.dob, doj: empMasterDetails.doj, trainingLevel: collectedData.trainingLevel, trainingType: collectedData.trainingType || 'General', trainingDate: collectedData.trainingDate, certificateValidity: collectedData.certificateValidity || '2 Years', certificate: collectedData.certificate, status: 'draft', history: trainingData[empId]?.history || [] }; if (!originalRowData[empId]) { originalRowData[empId] = { status: 'pending' }; } row.classList.remove('new-record-edit'); makeRowNonEditable(row, empId); updateButtonUI(row, 'finalizing'); row.dataset.editStage = 'finalizing'; alert('Draft saved successfully! Click "Final Submit" or "Cancel".'); updateDashboardCards(); if (isNewRecord) applyAllFilters(); else displayTablePage(currentPage); }
       // function finalSubmit(button) { const row = button.closest('tr'); const empId = row.dataset.empId; console.log(`Finalizing FoSTaC submit for ${empId}`); if (empId.startsWith('NEW_RECORD_')) { alert("Cannot submit, invalid state."); return; } if (!trainingData[empId] || trainingData[empId].status !== 'draft') { alert(`Error: Draft data for ${empId} not found or not in draft state.`); return; } const draftData = trainingData[empId]; const { status: calculatedFinalStatus } = calculateOverallStatus(draftData, true); if (!originalRowData[empId]) { console.warn("Original data not found for final submit comparison for", empId); originalRowData[empId] = JSON.parse(JSON.stringify(draftData)); } const original = originalRowData[empId]; const changes = {}; let hasChanges = false; const fieldsToCompare = ['unitName', 'trainingLevel', 'trainingType', 'trainingDate', 'certificateValidity', 'certificate']; fieldsToCompare.forEach(field => { let originalValue = (original[field] === null || original[field] === undefined) ? "" : String(original[field]); let draftValue = (draftData[field] === null || draftData[field] === undefined) ? "" : String(draftData[field]); if (field === 'certificate' && (originalValue === 'Not uploaded')) originalValue = ""; if (field === 'certificate' && (draftValue === 'Not uploaded')) draftValue = ""; if (originalValue !== draftValue) { changes[field] = { from: original[field], to: draftData[field] }; hasChanges = true; } }); const previousStatusForHistory = original.status === 'draft' ? calculateOverallStatus(original, true).status : original.status; if (calculatedFinalStatus !== previousStatusForHistory) { changes['status'] = { from: previousStatusForHistory, to: calculatedFinalStatus }; hasChanges = true; } trainingData[empId].status = calculatedFinalStatus; if (hasChanges) { const historyEntry = { date: new Date().toISOString().split('T')[0], action: 'final_submit', changedBy: currentUser, changes: changes }; if (!trainingData[empId].history) trainingData[empId].history = []; trainingData[empId].history.unshift(historyEntry); console.log(`Final Submit for ${empId}: Changes recorded`, changes); alert('Data submitted successfully!'); } else { console.log(`Final Submit for ${empId}: Record finalized from draft. No data changes detected.`); alert('Record finalized.'); } makeRowNonEditable(row, empId); updateButtonUI(row, 'view'); delete originalRowData[empId]; row.dataset.editStage = 'view'; updateDashboardCards(); applyAllFilters(); }
        function cancelMultiStageEdit(button) { const row = button.closest('tr'); const empId = row.dataset.empId; const currentStage = row.dataset.editStage; console.log(`Cancelling edit for ${empId} at stage ${currentStage}`); if (empId.startsWith('NEW_RECORD_')) { row.remove(); console.log(`Removed new record placeholder.`); const tableBody = document.getElementById('current-trainings-body'); if (tableBody && getVisibleRows(tableBody).length === 0 && Object.keys(trainingData).length === 0) loadInitialData(); applyAllFilters(); } else if (currentStage === 'drafting' && originalRowData[empId]) { trainingData[empId] = JSON.parse(JSON.stringify(originalRowData[empId])); delete originalRowData[empId]; makeRowNonEditable(row, empId); updateButtonUI(row, 'view'); row.dataset.editStage = 'view'; displayTablePage(currentPage); } else if (currentStage === 'finalizing' && trainingData[empId]?.status === 'draft') { if (originalRowData[empId]) { trainingData[empId] = JSON.parse(JSON.stringify(originalRowData[empId])); delete originalRowData[empId]; makeRowNonEditable(row, empId); updateButtonUI(row, 'view'); row.dataset.editStage = 'view'; alert('Draft changes discarded. Reverted to previous state.'); updateDashboardCards(); applyAllFilters(); } else { console.warn(`Cannot fully revert ${empId}, no backup found. Staying in draft state.`); updateButtonUI(row, 'finalizing'); row.dataset.editStage = 'finalizing'; alert('Cancellation reverted. Record remains as saved draft.'); } } else { console.warn(`Could not cleanly cancel edit for ${empId}.`); if (trainingData[empId]){ makeRowNonEditable(row, empId); updateButtonUI(row, 'view'); row.dataset.editStage = 'view'; } else { row.remove(); } delete originalRowData[empId]; applyAllFilters(); } }



function finalSubmit(button) {
    const row = button.closest('tr');
    const empId = row.dataset.empId;

    console.log(`Finalizing FoSTaC submit for ${empId}`);

    if (empId.startsWith('NEW_RECORD_')) {
        alert("Cannot submit, invalid state.");
        return;
    }

    if (!trainingData[empId] || trainingData[empId].status !== 'draft') {
        alert(`Error: Draft data for ${empId} not found or not in draft state.`);
        return;
    }

    const draftData = trainingData[empId];
    const { status: calculatedFinalStatus } = calculateOverallStatus(draftData, true);

    if (!originalRowData[empId]) {
        console.warn("Original data not found for final submit comparison for", empId);
        originalRowData[empId] = JSON.parse(JSON.stringify(draftData));
    }

    const original = originalRowData[empId];
    const changes = {};
    let hasChanges = false;

    const fieldsToCompare = ['unitName', 'trainingLevel', 'trainingType', 'trainingDate', 'certificateValidity', 'certificate'];
    fieldsToCompare.forEach(field => {
        let originalValue = (original[field] === null || original[field] === undefined) ? "" : String(original[field]);
        let draftValue = (draftData[field] === null || draftData[field] === undefined) ? "" : String(draftData[field]);

        if (field === 'certificate' && (originalValue === 'Not uploaded')) originalValue = "";
        if (field === 'certificate' && (draftValue === 'Not uploaded')) draftValue = "";

        if (originalValue !== draftValue) {
            changes[field] = { from: original[field], to: draftData[field] };
            hasChanges = true;
        }
    });

    const previousStatusForHistory = original.status === 'draft' ? calculateOverallStatus(original, true).status : original.status;
    if (calculatedFinalStatus !== previousStatusForHistory) {
        changes['status'] = { from: previousStatusForHistory, to: calculatedFinalStatus };
        hasChanges = true;
    }

    trainingData[empId].status = calculatedFinalStatus;

    if (hasChanges) {
        const historyEntry = {
            date: new Date().toISOString().split('T')[0],
            action: 'final_submit',
            changedBy: currentUser,
            changes: changes
        };
        if (!trainingData[empId].history) trainingData[empId].history = [];
        trainingData[empId].history.unshift(historyEntry);
        console.log(`Final Submit for ${empId}: Changes recorded`, changes);
        alert('Data submitted successfully!');
    } else {
        console.log(`Final Submit for ${empId}: Record finalized from draft. No data changes detected.`);
        alert('Record finalized.');
    }

const data = trainingData[empId];

const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

// Create FormData and add fields
const formData = new FormData();
formData.append('_token', csrfToken); // ✅ CSRF token added here

// Add other form fields
formData.append('empId', trainingData[empId].empId);
formData.append('trainingDate', trainingData[empId].trainingDate);
formData.append('trainingLevel', trainingData[empId].trainingLevel);
formData.append('trainingType', trainingData[empId].trainingType);
formData.append('certificateValidity', trainingData[empId].certificateValidity);

// If uploading a file
if (trainingData[empId].certificate instanceof File) {
    formData.append('certificate', trainingData[empId].certificate);
}



    makeRowNonEditable(row, empId);
    updateButtonUI(row, 'view');
    delete originalRowData[empId];
    row.dataset.editStage = 'view';
    updateDashboardCards();
    applyAllFilters();
}


        // --- Delete Record Handling ---
        function handleDeleteRecord(button) {
            const row = button.closest('tr'); const empId = row.dataset.empId; if (!empId || empId.startsWith('NEW_RECORD_')) return; const employeeName = trainingData[empId]?.name || employeeMasterList[empId]?.name || empId; if (confirm(`Are you sure you want to delete the training record for ${employeeName} (ID: ${empId})? This action cannot be undone.`)) { console.log(`Deleting record for ${empId}`); let recordExisted = false; if (trainingData[empId]) { delete trainingData[empId]; recordExisted = true; } if (originalRowData[empId]) delete originalRowData[empId]; row.remove(); const tableBody = document.getElementById('current-trainings-body'); if (tableBody && Object.keys(trainingData).length === 0) { // Check if data source is empty
                loadInitialData(); // Reload placeholder if all data deleted
            } if (recordExisted) { updateDashboardCards(); applyAllFilters(); alert(`Record for ${employeeName} deleted successfully.`); } else { applyAllFilters(); alert(`Row for ${employeeName} removed.`); } } else { console.log(`Deletion cancelled for ${empId}`); }
        }


        // --- Row Editability ---
        function makeRowEditable(row, isSetupAfterSelection = false) { row.classList.add('edit-mode'); const isNewRecordRow = row.classList.contains('new-record-edit'); const empIdSelect = row.querySelector('select.employee-select'); if (isNewRecordRow && !isSetupAfterSelection) { if (empIdSelect) empIdSelect.disabled = false; row.querySelectorAll('td[data-field="unitName"], td[data-field="trainingType"]').forEach(td => td.contentEditable = false); row.querySelectorAll('select.training-level-select, input.training-date-input, select.validity-select, input.certificate-input').forEach(el => el.disabled = false); const fileInputLabel = row.querySelector('.certificate-btn'); if (fileInputLabel) { fileInputLabel.style.cursor = 'not-allowed'; fileInputLabel.style.opacity = '0.7'; } if (empIdSelect) empIdSelect.focus(); return; } if (empIdSelect) empIdSelect.disabled = false; row.querySelector('td[data-field="unitName"]').contentEditable = true; row.querySelector('td[data-field="trainingType"]').contentEditable = true; row.querySelectorAll('select.training-level-select, input.training-date-input, select.validity-select, input.certificate-input').forEach(el => el.disabled = false); const fileInput = row.querySelector('.certificate-input'); if (fileInput && !fileInput.disabled) { const label = fileInput.nextElementSibling; if (label?.classList.contains('certificate-btn')) { label.style.cursor = 'pointer'; label.style.opacity = '1'; } } const daysLeftCell = row.querySelector('td[data-field="daysLeft"]'); if (daysLeftCell) daysLeftCell.textContent = '-'; const firstEditable = row.querySelector('td[data-field="unitName"]'); if (firstEditable) setTimeout(() => firstEditable.focus(), 0); }
        function makeRowNonEditable(row, empId) { row.classList.remove('edit-mode'); const employeeTraining = trainingData[empId]; if (!employeeTraining) { console.error("Cannot make row non-editable, data missing for", empId); return; } const setFieldValue = (selector, value, isSelect = false) => { const element = row.querySelector(selector); if (element) { element.value = value || (isSelect ? "" : ""); element.disabled = true; } else { console.warn(`Element not found: ${selector} in row ${empId}`); } }; const setTdText = (field, value) => { const td = row.querySelector(`td[data-field="${field}"]`); if (td) { td.textContent = value || 'N/A'; td.contentEditable = false; } else { console.warn(`TD not found for field: ${field} in row ${empId}`); } }; const empIdCell = row.querySelector('td[data-field="empId"]'); if (empIdCell && empIdCell.querySelector('select')) { empIdCell.innerHTML = empId; } else if (empIdCell) { empIdCell.textContent = empId; } setTdText('name', employeeTraining.name); setTdText('department', employeeTraining.department); setTdText('designation', employeeTraining.designation); setTdText('foodHandlerCategory', employeeTraining.foodHandlerCategory); setTdText('staffCategory', employeeTraining.staffCategory); setTdText('dob', employeeTraining.dob || '-'); setTdText('doj', employeeTraining.doj || '-'); setTdText('unitName', employeeTraining.unitName); setTdText('trainingType', employeeTraining.trainingType); setFieldValue('select.training-level-select', employeeTraining.trainingLevel, true); setFieldValue('input.training-date-input', employeeTraining.trainingDate); setFieldValue('select.validity-select', employeeTraining.certificateValidity, true); const fileInput = row.querySelector('.certificate-input'); const certStatusSpan = row.querySelector('.certificate-status'); const certLabel = row.querySelector('.certificate-btn'); if (fileInput) { fileInput.value = ''; fileInput.disabled = true; } if (certLabel) { certLabel.style.cursor = 'not-allowed'; certLabel.style.opacity = '0.7'; } if (certStatusSpan) { const cert = employeeTraining.certificate; const certText = cert ? cert : 'Not uploaded'; certStatusSpan.textContent = certText; certStatusSpan.title = certText; certStatusSpan.classList.toggle('uploaded', !!cert); } const { status: overallStatus, daysLeft } = calculateOverallStatus(employeeTraining, false); updateStatusPill(row, overallStatus); updateDaysLeftCell(row, daysLeft); }

        // --- Helper to update Days Left Cell ---
        function updateDaysLeftCell(row, daysLeft) {
             const daysLeftCell = row.querySelector('td[data-field="daysLeft"]');
             if (daysLeftCell) {
                 let daysLeftClass = ''; if (daysLeft !== null && daysLeft >= 0) { if (daysLeft <= nearExpiryThreshold) daysLeftClass = 'days-left-very-low'; else if (daysLeft <= expiringSoonThreshold) daysLeftClass = 'days-left-low'; }
                 const daysLeftDisplay = daysLeft !== null ? daysLeft : '-'; daysLeftCell.textContent = daysLeftDisplay; daysLeftCell.classList.remove('days-left-low', 'days-left-very-low'); if (daysLeftClass) daysLeftCell.classList.add(daysLeftClass);
             }
        }

        // --- Data Collection ---
        function collectRowData(row) {
            const empId = row.dataset.empId; const collectedData = {}; const getValue = (selector, isContentEditable = false, isDate = false, isFile = false) => { const element = row.querySelector(selector); if (!element) { console.warn(`Element not found: ${selector} in row ${empId}`); return isFile ? null : ''; } let value; if (isFile) { if (element.files && element.files.length > 0) value = element.files[0].name; else { const statusSpan = row.querySelector('.certificate-status'); const currentText = statusSpan ? statusSpan.textContent.trim() : ''; value = (currentText && currentText !== 'Not uploaded') ? currentText : null; } } else if (isContentEditable) value = element.textContent.trim(); else value = element.value; if (isDate && value === "") value = null; if (element.tagName === 'SELECT' && value === "") value = null; return value; }; collectedData.unitName = getValue('td[data-field="unitName"]', true); collectedData.trainingLevel = getValue('select.training-level-select'); collectedData.trainingType = getValue('td[data-field="trainingType"]', true); collectedData.trainingDate = getValue('input.training-date-input', false, true); collectedData.certificateValidity = getValue('select.validity-select'); collectedData.certificate = getValue('.certificate-input', false, false, true); return collectedData;
        }

        // --- UI Updates ---
        function updateButtonUI(row, stage) {
             const saveDraftBtn = row.querySelector('.main-action-btn.save-draft'); const finalSubmitBtn = row.querySelector('.main-action-btn.final-submit'); const updateBtn = row.querySelector('.main-action-btn.update'); const cancelBtn = row.querySelector('.cancel-btn'); const historyBtn = row.querySelector('.history-btn'); const deleteBtn = row.querySelector('.delete-btn');
             [saveDraftBtn, finalSubmitBtn, updateBtn, cancelBtn, historyBtn, deleteBtn].forEach(btn => { if (btn) btn.style.display = 'none'; });
             switch (stage) {
                 case 'drafting': if (saveDraftBtn) saveDraftBtn.style.display = 'inline-flex'; if (cancelBtn) cancelBtn.style.display = 'inline-flex'; const isNewPlaceholder = row.classList.contains('new-record-edit') && !row.querySelector('select.employee-select')?.disabled; if(saveDraftBtn) saveDraftBtn.disabled = isNewPlaceholder; break;
                 case 'finalizing': if (finalSubmitBtn) finalSubmitBtn.style.display = 'inline-flex'; if (cancelBtn) cancelBtn.style.display = 'inline-flex'; if(finalSubmitBtn) finalSubmitBtn.disabled = false; break;
                 case 'view': default: let updateButtonInstance = updateBtn; if (!updateButtonInstance) { const container = row.querySelector('.action-buttons'); if(container){ updateButtonInstance = document.createElement('button'); updateButtonInstance.className = 'action-btn main-action-btn update'; updateButtonInstance.innerHTML = '<i class="fas fa-pencil-alt"></i> <span>Update</span>'; updateButtonInstance.onclick = () => handleMainAction(updateButtonInstance); container.insertBefore(updateButtonInstance, container.firstChild); }} if (updateButtonInstance) updateButtonInstance.style.display = 'inline-flex'; if (historyBtn) historyBtn.style.display = 'inline-flex'; if (deleteBtn) deleteBtn.style.display = 'inline-flex'; if (updateButtonInstance) updateButtonInstance.disabled = false; break;
             }
        }
        function updateStatusPill(row, status) {
             const statusCell = row.querySelector('td[data-field="status"]');
             if (statusCell) {
                 const statusClass = status || 'pending'; const displayClass = statusClass === 'overdue' ? 'expired' : statusClass; const statusText = displayClass ? displayClass.charAt(0).toUpperCase() + displayClass.slice(1) : 'Pending';
                 statusCell.innerHTML = `<span class="status ${displayClass}">${statusText}</span>`;
             }
        }

        // --- History Modal ---
        function showHistoryModal(empId) {
            console.log(`Show FoSTaC history for ${empId}`); const employeeTraining = trainingData[empId]; const masterDetails = employeeMasterList[empId]; const name = employeeTraining?.name || masterDetails?.name || 'N/A';
            document.getElementById('history-emp-name').textContent = name; document.getElementById('history-emp-id').textContent = empId;
            const statusSpanModal = document.getElementById('history-current-status'); const historyTableBody = document.getElementById('training-history-details'); const changeLogTableBody = document.getElementById('change-history-details'); historyTableBody.innerHTML = ''; changeLogTableBody.innerHTML = '';
            if (!employeeTraining) { statusSpanModal.className = "status pending"; statusSpanModal.textContent = "Pending"; historyTableBody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 20px; color: var(--dark-gray);">No training record found.</td></tr>`; changeLogTableBody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 20px; color: var(--dark-gray);">No training record found.</td></tr>`; showModal('historyModal'); return; }
            const { status: currentStatus } = calculateOverallStatus(employeeTraining, false); const currentStatusClass = currentStatus === 'overdue' ? 'expired' : (currentStatus || 'pending'); const currentStatusText = currentStatusClass.charAt(0).toUpperCase() + currentStatusClass.slice(1); statusSpanModal.className = `status ${currentStatusClass}`; statusSpanModal.textContent = currentStatusText;
            const currentHistoryRow = historyTableBody.insertRow(); currentHistoryRow.classList.add('history-header'); currentHistoryRow.innerHTML = `<td>Current</td><td>${employeeTraining.trainingLevel || 'N/A'}</td><td>${employeeTraining.trainingType || 'N/A'}</td><td>${employeeTraining.trainingDate || 'N/A'}</td><td>${employeeTraining.certificateValidity || 'N/A'}</td><td>jhgjhgj</td><td><span class="status ${currentStatusClass}">${currentStatusText}</span></td><td>N/A</td>`;
            if (!employeeTraining.history || employeeTraining.history.length === 0) { changeLogTableBody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 20px; color: var(--dark-gray);">No change history recorded.</td></tr>`; historyTableBody.insertRow().innerHTML = `<td colspan="8" style="text-align: center; padding: 15px; color: var(--dark-gray); font-style: italic;">No previous versions recorded.</td>`; }
            else { employeeTraining.history.forEach((entry) => { const changeLogRow = changeLogTableBody.insertRow(); const formatValue = (val) => (val === null || val === undefined || val === '' || val === 'Not uploaded') ? 'Empty' : String(val); const details = Object.entries(entry.changes || {}).map(([key, change]) => { let fieldName = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()); const fromValText = formatValue(change.from); const toValText = formatValue(change.to); if (fieldName === 'Status') { const formatStatus = (s) => s ? (s === 'overdue' ? 'Expired' : s.charAt(0).toUpperCase() + s.slice(1)) : 'Empty'; return `Status: ${formatStatus(toValText)} (from ${formatStatus(fromValText)})`; } if (fieldName === 'Certificate') { const truncate = (str, len = 20) => (str && str.length > len) ? str.substring(0, len - 3) + '...' : str; return `${fieldName}: ${truncate(toValText)} (from ${truncate(fromValText)})`; } return `${fieldName}: ${toValText} (from ${fromValText})`; }).join('<br>'); let actionText = entry.action === 'final_submit' ? 'Final Submit' : (entry.action === 'draft_save' ? 'Saved as Draft' : entry.action); changeLogRow.innerHTML = `<td>${entry.date || 'N/A'}</td><td>${actionText}</td><td>${entry.changedBy || 'System'}</td><td>${details || 'N/A'}</td>`; }); historyTableBody.insertRow().innerHTML = `<td colspan="8" style="text-align: center; padding: 15px; color: var(--dark-gray); font-style: italic;">See Change Log below for modification details.</td>`; }
            showModal('historyModal');
        }


        // --- File Input Handling ---
        function setupFileInputs() {
            const tableBody = document.getElementById('current-trainings-body'); if(tableBody) { tableBody.addEventListener('change', function(event) { if (event.target.classList.contains('certificate-input')) { const input = event.target; const uploadDiv = input.closest('.certificate-upload'); if (!uploadDiv) return; const statusSpan = uploadDiv.querySelector('.certificate-status'); if (!statusSpan) return; if (input.files && input.files.length > 0) { const fileName = input.files[0].name; statusSpan.textContent = fileName; statusSpan.classList.add('uploaded'); statusSpan.title = fileName; } else { const row = input.closest('tr'); const empId = row?.dataset.empId; let previousCert = null; if (row?.classList.contains('edit-mode') && originalRowData[empId]) previousCert = originalRowData[empId].certificate; else if (trainingData[empId]) previousCert = trainingData[empId].certificate; const displayText = previousCert ? previousCert : 'Not uploaded'; statusSpan.textContent = displayText; statusSpan.title = displayText; statusSpan.classList.toggle('uploaded', !!previousCert); } } }); }
        }


        // --- Filtering Logic ---
        function setupFilterIcons() { document.querySelectorAll('#currentTrainingsTable th .filter-icon[data-column]').forEach(icon => { icon.addEventListener('click', (event) => { event.stopPropagation(); toggleFilterDropdown(icon.closest('th'), parseInt(icon.dataset.column, 10)); }); }); document.addEventListener('click', (event) => { const activeDropdown = document.querySelector('.filter-dropdown.show'); if (activeDropdown && !event.target.closest('.filter-dropdown') && !event.target.closest('.filter-icon')) { closeAllFilterDropdowns(); } }); }
        function toggleFilterDropdown(th, columnIndex) { const existingDropdown = th.querySelector('.filter-dropdown'); const isCurrentlyOpen = existingDropdown && existingDropdown.classList.contains('show'); closeAllFilterDropdowns(); if (isCurrentlyOpen) return; let dropdown = existingDropdown; if (!dropdown) { const template = document.getElementById('filterDropdownTemplate'); if (!template) { console.error("Filter template not found!"); return; } dropdown = template.cloneNode(true); dropdown.id = ''; dropdown.style.display = ''; dropdown.querySelector('.filter-apply-btn').addEventListener('click', () => applyFilter(th)); dropdown.querySelector('.filter-clear-btn').addEventListener('click', () => clearFilter(th)); th.appendChild(dropdown); } populateFilterContent(th, dropdown, columnIndex); dropdown.classList.add('show'); const thRect = th.getBoundingClientRect(); dropdown.style.left = `0px`; dropdown.style.top = `${thRect.height}px`; dropdown.style.minWidth = `${thRect.width < 200 ? 200 : thRect.width}px`; }
        function closeAllFilterDropdowns() { document.querySelectorAll('.filter-dropdown.show').forEach(d => d.classList.remove('show')); }
        function populateFilterContent(th, dropdown, columnIndex) { const standardContent = dropdown.querySelector('.standard-filter-content'); const customContent = dropdown.querySelector('.custom-filter-content'); const optionsContainer = standardContent.querySelector('.filter-options'); const searchInput = standardContent.querySelector('.filter-search'); standardContent.style.display = 'none'; customContent.innerHTML = ''; customContent.style.display = 'none'; if (optionsContainer) optionsContainer.innerHTML = ''; if (searchInput) searchInput.value = ''; const filterType = determineFilterType(columnIndex); if (!filterType) return; if (filterType === 'unit') { customContent.style.display = 'block'; populateUnitFilter(customContent); } else if (filterType === 'date') { customContent.style.display = 'block'; let prefix = ''; if (columnIndex === 8) prefix = 'dob'; else if (columnIndex === 9) prefix = 'doj'; else if (columnIndex === 12) prefix = 'trainingDate'; populateDateFilter(customContent, prefix); } else { standardContent.style.display = 'block'; if (filterType === 'status') populateStatusCheckboxOptions(th, dropdown); else if (filterType === 'certificateStatus') populateCertificateCheckboxOptions(th, dropdown); else populateCheckboxFilterOptions(th, dropdown); if (searchInput) { const newSearchInput = searchInput.cloneNode(true); standardContent.replaceChild(newSearchInput, searchInput); newSearchInput.addEventListener('input', (e) => filterDropdownOptions(dropdown, e.target.value)); } } loadFilterState(th, dropdown); }
        function populateUnitFilter(container) { container.innerHTML = `<div style="margin-bottom: 8px;"><label for="filter-corporate">Corporate:</label><select id="filter-corporate" class="filter-unit-select"><option value="">-- All --</option></select></div><div style="margin-bottom: 8px;"><label for="filter-regional">Regional:</label><select id="filter-regional" class="filter-unit-select" disabled><option value="">-- All --</option></select></div><div><label for="filter-unit">Unit:</label><select id="filter-unit" class="filter-unit-select" disabled><option value="">-- All --</option></select></div>`; const corpSelect = container.querySelector('#filter-corporate'); const regSelect = container.querySelector('#filter-regional'); const unitSelect = container.querySelector('#filter-unit'); Object.keys(unitHierarchy).sort().forEach(corpName => corpSelect.add(new Option(corpName, corpName))); corpSelect.addEventListener('change', () => { populateRegionalOptions(corpSelect.value, regSelect); unitSelect.innerHTML = '<option value="">-- All --</option>'; unitSelect.disabled = true; regSelect.disabled = !corpSelect.value; }); regSelect.addEventListener('change', () => { populateUnitOptions(corpSelect.value, regSelect.value, unitSelect); unitSelect.disabled = !regSelect.value; }); }
        function populateRegionalOptions(corpName, regSelect) { regSelect.innerHTML = '<option value="">-- All --</option>'; if (corpName && unitHierarchy[corpName]) Object.keys(unitHierarchy[corpName]).sort().forEach(regName => regSelect.add(new Option(regName, regName))); regSelect.disabled = !(corpName && unitHierarchy[corpName] && Object.keys(unitHierarchy[corpName]).length > 0); }
        function populateUnitOptions(corpName, regName, unitSelect) { unitSelect.innerHTML = '<option value="">-- All --</option>'; if (corpName && regName && unitHierarchy[corpName]?.[regName]) unitHierarchy[corpName][regName].sort().forEach(unitName => unitSelect.add(new Option(unitName, unitName))); unitSelect.disabled = !(corpName && regName && unitHierarchy[corpName]?.[regName] && unitHierarchy[corpName][regName].length > 0); }
        function populateDateFilter(container, prefix) { container.innerHTML = `<div style="margin-bottom: 8px;"><label for="${prefix}-filter-date-from">From:</label><input type="date" id="${prefix}-filter-date-from" class="filter-date-input"></div><div><label for="${prefix}-filter-date-to">To:</label><input type="date" id="${prefix}-filter-date-to" class="filter-date-input"></div>`; }
        function populateCheckboxFilterOptions(th, dropdown) { const columnIndex = th.cellIndex; const tableBody = th.closest('table').querySelector('tbody'); const optionsContainer = dropdown.querySelector('.filter-options'); optionsContainer.innerHTML = ''; if (!tableBody || !optionsContainer) return; const uniqueValues = new Set(); Array.from(tableBody.rows).forEach(row => { if (row.dataset.filteredOut === 'true' || row.querySelector('td[colspan]') || row.classList.contains('new-record-edit') || row.cells.length <= columnIndex) return; const cell = row.cells[columnIndex]; let value = ''; const inputElement = cell.querySelector('select'); if (inputElement) value = inputElement.options[inputElement.selectedIndex]?.textContent.trim() || inputElement.value; else value = cell.textContent.trim(); if (value === null || value === undefined || value === '' || value === '--' || value === '-' || value === 'N/A') value = '(Empty)'; uniqueValues.add(value); }); const sortedValues = Array.from(uniqueValues).sort((a, b) => { if (a === '(Empty)') return -1; if (b === '(Empty)') return 1; return a.localeCompare(b); }); if (sortedValues.length === 0) { optionsContainer.innerHTML = '<span style="color: var(--dark-gray); font-style: italic; padding: 5px;">No options</span>'; return; } sortedValues.forEach(value => { const label = document.createElement('label'); const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.value = value; label.append(checkbox, ` ${value}`); optionsContainer.appendChild(label); }); }
         function populateStatusCheckboxOptions(th, dropdown) {
            const optionsContainer = dropdown.querySelector('.filter-options'); optionsContainer.innerHTML = '';
            const statusOrder = ['Completed', 'Draft', 'Pending', 'Expired'];
            statusOrder.forEach(value => { const label = document.createElement('label'); const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.value = value; label.append(checkbox, ` ${value}`); optionsContainer.appendChild(label); });
         }
         function populateCertificateCheckboxOptions(th, dropdown) { const optionsContainer = dropdown.querySelector('.filter-options'); optionsContainer.innerHTML = ''; ['Uploaded', 'Not uploaded'].forEach(value => { const label = document.createElement('label'); const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.value = value; label.append(checkbox, ` ${value}`); optionsContainer.appendChild(label); }); }
        function filterDropdownOptions(dropdown, searchTerm) { const optionsContainer = dropdown.querySelector('.filter-options'); if (!optionsContainer) return; const lowerSearchTerm = searchTerm.toLowerCase(); optionsContainer.querySelectorAll('label').forEach(label => label.style.display = (lowerSearchTerm === '' || label.textContent.toLowerCase().includes(lowerSearchTerm)) ? 'flex' : 'none'); }
         function loadFilterState(th, dropdown) { const filterType = th.dataset.filterType; const filterValueJSON = th.dataset.filterValue; if (!filterType || !filterValueJSON) return; try { const filterValues = JSON.parse(filterValueJSON); if (filterType === 'unit' && filterValues.corp) { const corpSelect = dropdown.querySelector('#filter-corporate'); const regSelect = dropdown.querySelector('#filter-regional'); const unitSelect = dropdown.querySelector('#filter-unit'); if(corpSelect) corpSelect.value = filterValues.corp; populateRegionalOptions(filterValues.corp, regSelect); if(regSelect) regSelect.value = filterValues.region || ''; populateUnitOptions(filterValues.corp, filterValues.region, unitSelect); if(unitSelect) unitSelect.value = filterValues.unit || ''; } else if (filterType === 'date' && (filterValues.from || filterValues.to)) { let prefix = ''; const colIndex = th.cellIndex; if (colIndex === 8) prefix = 'dob'; else if (colIndex === 9) prefix = 'doj'; else if (colIndex === 12) prefix = 'trainingDate'; const fromInput = dropdown.querySelector(`#${prefix}-filter-date-from`); const toInput = dropdown.querySelector(`#${prefix}-filter-date-to`); if (fromInput) fromInput.value = filterValues.from || ''; if (toInput) toInput.value = filterValues.to || ''; } else if (['checkbox', 'status', 'certificateStatus'].includes(filterType) && filterValues.values) { const selectedValues = new Set(filterValues.values); dropdown.querySelectorAll('.filter-options input[type="checkbox"]').forEach(cb => cb.checked = selectedValues.has(cb.value)); } } catch (e) { console.error("Error parsing filter state:", e); } }
        function applyFilter(th) { const columnIndex = th.cellIndex; const dropdown = th.querySelector('.filter-dropdown'); if (!dropdown || columnIndex === 14) return; let isActiveFilter = false; let filterData = {}; const filterType = determineFilterType(columnIndex); if (filterType === 'unit') { const unitV = dropdown.querySelector('#filter-unit')?.value; const regV = dropdown.querySelector('#filter-regional')?.value; const corpV = dropdown.querySelector('#filter-corporate')?.value; if (corpV || regV || unitV) { filterData = { type: 'unit', corp: corpV, region: regV, unit: unitV }; isActiveFilter = true; } } else if (filterType === 'date') { let prefix = ''; if (columnIndex === 8) prefix = 'dob'; else if (columnIndex === 9) prefix = 'doj'; else if (columnIndex === 12) prefix = 'trainingDate'; const fromV = dropdown.querySelector(`#${prefix}-filter-date-from`)?.value || ''; const toV = dropdown.querySelector(`#${prefix}-filter-date-to`)?.value || ''; if (fromV || toV) { filterData = { type: 'date', from: fromV, to: toV }; isActiveFilter = true; } } else if (['checkbox', 'status', 'certificateStatus'].includes(filterType)) { const selectedCheckboxes = Array.from(dropdown.querySelectorAll('.filter-options input[type="checkbox"]:checked')).map(cb => cb.value); if (selectedCheckboxes.length > 0) { filterData = { type: filterType, values: selectedCheckboxes }; isActiveFilter = true; } } th.dataset.filterActive = isActiveFilter ? 'true' : 'false'; th.dataset.filterType = isActiveFilter ? filterData.type : ''; th.dataset.filterValue = isActiveFilter ? JSON.stringify(filterData) : ''; const filterIcon = th.querySelector('.filter-icon'); if (filterIcon) filterIcon.style.color = isActiveFilter ? 'var(--primary-color)' : ''; applyAllFilters(th.closest('thead')); closeAllFilterDropdowns(); }
        function clearFilter(th) { const columnIndex = th.cellIndex; const dropdown = th.querySelector('.filter-dropdown'); if (!dropdown || columnIndex === 14) return; const filterType = determineFilterType(columnIndex); if (filterType === 'unit') { dropdown.querySelectorAll('.filter-unit-select').forEach(sel => sel.selectedIndex = 0); dropdown.querySelector('#filter-regional').disabled = true; dropdown.querySelector('#filter-unit').disabled = true; } else if (filterType === 'date') { dropdown.querySelectorAll('.filter-date-input').forEach(input => input.value = ''); } else { dropdown.querySelectorAll('.filter-options input[type="checkbox"]').forEach(cb => cb.checked = false); const searchInput = dropdown.querySelector('.filter-search'); if (searchInput) searchInput.value = ''; filterDropdownOptions(dropdown, ''); } th.dataset.filterActive = 'false'; th.dataset.filterType = ''; th.dataset.filterValue = ''; const filterIcon = th.querySelector('.filter-icon'); if (filterIcon) filterIcon.style.color = ''; applyAllFilters(th.closest('thead')); closeAllFilterDropdowns(); }
         function determineFilterType(columnIndex) { const colMap = { 1: 'unit', 8: 'date', 9: 'date', 12: 'date', 15: 'certificateStatus', 16: 'status', 14: null }; return colMap[columnIndex] ?? 'checkbox'; }

        function applyAllFilters(thead = null) {
             if (!thead) thead = document.getElementById('currentTrainingsTable')?.querySelector('thead');
             const tableBody = document.getElementById('current-trainings-body');
             if (!tableBody || !thead) return;
             console.log(`Applying ALL filters (Card Filter: ${currentTableFilter})...`);

             const activeColumnFilters = [];
             thead.querySelectorAll('th[data-filter-active="true"]').forEach(th => {
                 try { activeColumnFilters.push({ columnIndex: th.cellIndex, type: th.dataset.filterType, config: JSON.parse(th.dataset.filterValue || '{}') }); }
                 catch (e) { console.error("Error parsing column filter config for column", th.cellIndex, e); }
             });

             Array.from(tableBody.rows).forEach(row => {
                  if (row.querySelector('td[colspan]') || row.classList.contains('new-record-edit')) { row.dataset.filteredOut = 'false'; return; } // Skip placeholder/new rows
                  let showRow = true; const empId = row.dataset.empId;
                  let rowStatus = 'pending'; let rowDaysLeft = null;

                  // --- 1. Apply Card Filter Logic ---
                  if (empId && trainingData[empId]) {
                      const { status: calculatedStatus, daysLeft } = calculateOverallStatus(trainingData[empId], false);
                       rowStatus = trainingData[empId].status === 'draft' ? 'draft' : calculatedStatus;
                       rowDaysLeft = daysLeft;

                       if (currentTableFilter === 'default' && rowStatus === 'expired') showRow = false; // Default: hide expired
                       else if (currentTableFilter === 'validOnly' && !(rowStatus === 'completed' && rowDaysLeft !== null && rowDaysLeft > expiringSoonThreshold)) showRow = false;
                       else if (currentTableFilter === 'expiringSoon' && !(rowStatus === 'completed' && rowDaysLeft !== null && rowDaysLeft >= 0 && rowDaysLeft <= expiringSoonThreshold)) showRow = false;
                   } else {
                       rowStatus = 'pending'; // Assume pending if data missing
                       if (currentTableFilter === 'validOnly' || currentTableFilter === 'expiringSoon') showRow = false;
                   }

                  // --- 2. Apply Column Filters (if still visible) ---
                  if (showRow) {
                      for (const filter of activeColumnFilters) {
                          if (!showRow) break; const cell = row.cells[filter.columnIndex]; if (!cell) { showRow = false; break; }
                          let cellValue = '';

                          if (filter.type === 'status') cellValue = (rowStatus === 'overdue' ? 'Expired' : (rowStatus || 'pending').charAt(0).toUpperCase() + (rowStatus || 'pending').slice(1));
                          else if (filter.type === 'certificateStatus') cellValue = cell.querySelector('span.certificate-status')?.classList.contains('uploaded') ? 'Uploaded' : 'Not uploaded';
                          else if (filter.type === 'date') cellValue = cell.querySelector('input[type="date"]')?.value || cell.textContent.trim();
                          else { const sel = cell.querySelector('select'); cellValue = sel ? (sel.options[sel.selectedIndex]?.textContent.trim() || sel.value) : cell.textContent.trim(); if ([null, undefined, '', '--', '-', 'N/A'].includes(cellValue)) cellValue = '(Empty)'; }

                          switch (filter.type) {
                              case 'unit': const unit = cell.textContent.trim(); const cfg = filter.config; let match = true; if (cfg.unit && unit !== cfg.unit) match = false; else if (cfg.region && !cfg.unit) { const units = unitHierarchy[cfg.corp]?.[cfg.region] || []; if (!units.includes(unit)) match = false; } else if (cfg.corp && !cfg.region) { const units = Object.values(unitHierarchy[cfg.corp] || {}).flat(); if (!units.includes(unit)) match = false; } if (!match) showRow = false; break;
                              case 'date': if (!cellValue || cellValue === '-') { if (filter.config.from || filter.config.to) showRow = false; } else { try { const rd = new Date(cellValue+'T00:00:00'); const fd = filter.config.from ? new Date(filter.config.from+'T00:00:00') : null; const td = filter.config.to ? new Date(filter.config.to+'T23:59:59') : null; if(isNaN(rd.getTime())) {showRow = false; break;} if (fd && rd < fd) showRow = false; if (td && rd > td) showRow = false; } catch(e){ showRow = false; } } break;
                              case 'status': case 'certificateStatus': case 'checkbox': const selected = new Set(filter.config.values || []); if (!selected.has(cellValue)) showRow = false; break;
                          }
                      }
                  }
                  row.dataset.filteredOut = showRow ? 'false' : 'true';
             });
             displayTablePage(1); // Reset pagination after filtering
        }


        // --- Pagination ---
        function setupRowsPerPageSelector() {
            const selector = document.getElementById('rowsPerPageSelect');
            if (selector) {
                // Set initial value based on the selected option in HTML or default
                rowsPerPage = parseInt(selector.value, 10);
                selector.addEventListener('change', (event) => {
                    rowsPerPage = parseInt(event.target.value, 10);
                    console.log(`Rows per page changed to: ${rowsPerPage}`);
                    displayTablePage(1); // Go to first page when changing rows per page
                });
            } else {
                console.warn("Rows per page selector not found.");
                rowsPerPage = 10; // Fallback default
            }
        }

        function setupPaginationEventListeners() {
            document.getElementById('prevPageBtn')?.addEventListener('click', () => {
                if (currentPage > 1) displayTablePage(currentPage - 1);
            });
            document.getElementById('nextPageBtn')?.addEventListener('click', () => {
                const tableBody = document.getElementById('current-trainings-body');
                if (!tableBody) return;
                const totalPages = Math.ceil(getVisibleRows(tableBody).length / rowsPerPage);
                if (currentPage < totalPages) displayTablePage(currentPage + 1);
            });
        }

        function getVisibleRows(tableBody) {
            if (!tableBody) return [];
            return Array.from(tableBody.rows).filter(row =>
                row.dataset.filteredOut !== 'true' &&
                !row.querySelector('td[colspan]') && // Exclude placeholder like "Loading..."
                !row.classList.contains('new-record-edit') // Exclude the row for adding new employee
            );
        }

        function displayTablePage(page) {
            console.log(`Displaying FoSTaC page: ${page}`);
            currentPage = page;
            const tableBody = document.getElementById('current-trainings-body');
            if (!tableBody) return;

            const rowsToPaginate = getVisibleRows(tableBody);
            const totalVisibleRows = rowsToPaginate.length;
            const startIndex = (page - 1) * rowsPerPage;
            const endIndex = startIndex + rowsPerPage;

            // Hide all data rows first (except the new record row if present)
            Array.from(tableBody.rows).forEach(row => {
                if (!row.classList.contains('new-record-edit') && !row.querySelector('td[colspan]')) {
                    row.style.display = 'none';
                }
            });

             // Display the rows for the current page and update SL No
            rowsToPaginate.slice(startIndex, endIndex).forEach((row, index) => {
                row.style.display = ''; // Or 'table-row'
                const slNoCell = row.querySelector('td.sl-no');
                if (slNoCell) slNoCell.textContent = startIndex + index + 1;
            });

            // Ensure the new record row is always visible if it exists
            const newRecordRow = tableBody.querySelector('tr.new-record-edit');
            if (newRecordRow) {
                newRecordRow.style.display = ''; // Or 'table-row'
                 const slNoCell = newRecordRow.querySelector('td.sl-no');
                 if(slNoCell) slNoCell.textContent = '+';
            }

            setupPagination(rowsToPaginate); // Update pagination controls
        }

        function setupPagination(rowsToPaginate) {
            const pageNumbersContainer = document.getElementById('pageNumbers');
            const pageInfoSpan = document.getElementById('pageInfo');
            const prevBtn = document.getElementById('prevPageBtn');
            const nextBtn = document.getElementById('nextPageBtn');
            const paginationContainer = document.querySelector('.pagination-container');

            if (!pageNumbersContainer || !pageInfoSpan || !prevBtn || !nextBtn || !paginationContainer) {
                 console.error("Pagination elements not found!");
                 return;
            }

            const totalRows = rowsToPaginate.length;
            const totalPages = Math.ceil(totalRows / rowsPerPage);
            pageNumbersContainer.innerHTML = ''; // Clear existing page numbers

            if (totalPages <= 1 && totalRows === 0) {
                paginationContainer.style.display = 'none';
                pageInfoSpan.textContent = 'No items matching filters';
                return;
            } else if (totalPages <= 1) {
                 paginationContainer.style.display = 'none'; // Hide if only one page
                 pageInfoSpan.textContent = `Total: ${totalRows} item${totalRows !== 1 ? 's' : ''}`;
                 return;
            } else {
                 paginationContainer.style.display = 'flex'; // Show if more than one page
            }

            pageNumbersContainer.style.display = 'inline-flex'; // Use flex for alignment

            const maxPageButtons = 5; // Max buttons to show (e.g., 1 ... 4 5 6 ... 10)
            let startPage, endPage;

            if (totalPages <= maxPageButtons) {
                startPage = 1;
                endPage = totalPages;
            } else {
                // Calculate start and end pages with ellipsis logic
                const maxPagesBeforeCurrent = Math.floor((maxPageButtons - 3) / 2);
                const maxPagesAfterCurrent = Math.ceil((maxPageButtons - 3) / 2);

                if (currentPage <= maxPagesBeforeCurrent + 1) {
                    // Near the beginning
                    startPage = 1;
                    endPage = maxPageButtons - 1; // Leave space for '...' and last page
                } else if (currentPage >= totalPages - maxPagesAfterCurrent) {
                    // Near the end
                    startPage = totalPages - (maxPageButtons - 2); // Leave space for first page and '...'
                    endPage = totalPages;
                } else {
                    // In the middle
                    startPage = currentPage - maxPagesBeforeCurrent;
                    endPage = currentPage + maxPagesAfterCurrent;
                }
            }

            // Add first page button if needed
            if (startPage > 1) {
                pageNumbersContainer.appendChild(createPageButton(1));
                if (startPage > 2) {
                     // Add ellipsis if there's a gap
                    const ellipsis = document.createElement('span');
                    ellipsis.textContent = '...';
                    pageNumbersContainer.appendChild(ellipsis);
                }
            }

            // Add page buttons for the calculated range
            for (let i = startPage; i <= endPage; i++) {
                pageNumbersContainer.appendChild(createPageButton(i));
            }

            // Add last page button if needed
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                     // Add ellipsis if there's a gap
                    const ellipsis = document.createElement('span');
                    ellipsis.textContent = '...';
                    pageNumbersContainer.appendChild(ellipsis);
                }
                pageNumbersContainer.appendChild(createPageButton(totalPages));
            }

            // Update page info text
            const startIndex = (currentPage - 1) * rowsPerPage;
            const startItem = totalRows === 0 ? 0 : startIndex + 1;
            const endItem = Math.min(startIndex + rowsPerPage, totalRows);
            pageInfoSpan.textContent = totalRows > 0 ? `Showing ${startItem}-${endItem} of ${totalRows} item${totalRows !== 1 ? 's' : ''}` : 'No items';

            // Enable/disable previous/next buttons
            prevBtn.disabled = currentPage === 1;
            nextBtn.disabled = currentPage === totalPages;
        }

        function createPageButton(pageNumber) {
            const button = document.createElement('button');
            button.textContent = pageNumber;
            button.classList.add('page-number-btn');
            if (pageNumber === currentPage) {
                button.classList.add('active');
            }
            button.addEventListener('click', () => displayTablePage(pageNumber));
            return button;
        }
        // --- End Pagination ---

    </script>

@endsection
   