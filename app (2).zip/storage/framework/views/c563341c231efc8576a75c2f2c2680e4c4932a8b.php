</div>
</div>

<?php echo $__env->make('StudentDashboard.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/StudentDashboard/bottom.blade.php ENDPATH**/ ?>