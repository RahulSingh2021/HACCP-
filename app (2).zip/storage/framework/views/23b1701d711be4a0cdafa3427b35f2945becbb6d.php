<div class="tab-pane fade" id="pm-schedule-maker" role="tabpanel">
    
    <?php if($is_role !="2"): ?>
                                            <div class="row row-cols-auto g-3">
                                                <div class="col">
                                                    <button type="button" class="btn btn-outline-dark px-3">Updated List 30-10-2022</button>
                                                </div>
                                                <div class="col">
                                                    <button type="button" class="btn btn-outline-dark px-3">Discarded List</button>
                                                </div>
                                                <div class="col">
													<button type="button" class="btn btn-outline-dark px-3 " data-bs-toggle="modal" data-bs-target="#addcleaning1">+</button>
													
													 <button type="button" id="delbuttoncleaning_schedular1" class="btn btn-danger btn-xs" value="delete">Delete Selected</button>
                                              
                                                </div>
                                            </div> 
                                            
                                            <?php endif; ?>
                                            <table class="table table-bordered table-striped mt-4" id="pm-schedule-maker_table">
                                                <thead>
                                                  <tr>
													  													  <th width="30"><input type="checkbox" class="checkboxclickcleaning_schedular1"></th>

                                                    <th width="30">No.</th>
                                                    <th>Equipment Name</th>
                                                    <th>Location</th>
                                                       <th>Responsibility</th>
													  <th>Corporate</th>
													  <th>Regional</th>
													  <th>Unit Name</th>
                                                    <th>Frequency</th>
                                                    <th>Task Start Date</th>
                                                    <th>Created On</th>
                                                    <th>Created By</th>
                                                    <th width="30">Action</th>
                                                  </tr>
                                                </thead>
                                                <tbody>
													
													<?php $k=1; ?>
													<?php $__currentLoopData = $schedulemakerlist1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedulemakerlists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="cleaning_schedular1_detailss_<?php echo e($schedulemakerlists->id); ?>">
                                       <td><input class="checkboxcleaning_schedularvalue1" type="checkbox" value="<?php echo e($schedulemakerlists->id); ?>"></td>
                                                    <td><?php echo e($k); ?></td>
                                                    <td><?php echo e($schedulemakerlists->name); ?></td>
                                                    <td><?php 
														$details = DB::table('locations')->where('id',$schedulemakerlists->location_id)->first();
														echo $details->name ?? '';
														
														?></td>
                                                             <td><?php echo e(Helper::ResponsibilityName($schedulemakerlists->responsibility_id ?? '')); ?></td>
                                                          <td><?php echo e(Helper::CorporateName($schedulemakerlists->corporate_id ?? '')); ?></td>
														   <td><?php echo e(Helper::RegionalName($schedulemakerlists->corporate_id ?? '')); ?></td>
														   <td><?php echo e($schedulemakerlists->hotel_name ?? ''); ?></td>
                                                          <td><?php echo e($schedulemakerlists->frequency); ?></td>
                                                        <td><?php echo e($schedulemakerlists->task_start_date); ?></td>
                                                           <td><?php echo e($schedulemakerlists->create_at); ?></td>
                                                            <td><?php 
														$details = DB::table('users')->where('id',$schedulemakerlists->created_by)->first();
														echo $details->name ?? '';
														
														?></td>
                                                    <td>
														<i data-bs-toggle="modal" data-bs-target="#editcleaningpm<?php echo e($schedulemakerlists->id); ?>" class="font-20 bx bxs-edit" style="cursor:pointer;"></i>
														<a href="<?php echo e(route('facility_schedule_delete',$schedulemakerlists->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"><i class="font-20 bx bxs-trash"></i></a></td>

													  <div class="modal fade" id="editcleaningpm<?php echo e($schedulemakerlists->id ?? ''); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                      <h5 class="modal-title">Edit PM Schedule Maker</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                         <form></form>
                        <form method="post" action="<?php echo e(route('schedule_maker_edit')); ?>">
                            <?php echo csrf_field(); ?>
                    <div class="row">
						
						<input type="hidden" name="schedule_maker_id" value="<?php echo e($schedulemakerlists->id); ?>">
						
						         <div class="mb-3 col-md-6">
                            <label class="form-label">Select Corporate :</label>
									 
										 <select name="corporate_id" id="schedule_id_edit"  onchange="myFunction(this)" class="form-control" >
										 <option value="">Please Select Corporate </option>
										 
										   <?php
											 $corporate_id = $schedulemakerlists->corporate_id;
												 
												 $unit_list = DB::table('users')->where('is_role', "2")->get(); ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											 
	 <option value="<?php echo e($unit_lists->id); ?>" <?php if($corporate_id == $unit_lists->id ): ?> selected <?php endif; ?> > 
        <?php echo e($unit_lists->company_name); ?>

    </option>
	
										 
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									 
									 </select>

                        </div>
						
							       <div class="mb-3 col-md-6">
                            <label class="form-label">Select Regional Name:</label>
				 
									 
									 <select name="regional_id" id="mySelect111" class="form-control mySelect111" >
								
										 	   <?php 
										 
										 $regional_id = $schedulemakerlists->regional_id;
											 
											 $unit_list = DB::table('users')->where('created_by', $schedulemakerlists->corporate_id ?? '')->where('is_role', "1")->get(); ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 
										 	 <option value="<?php echo e($unit_lists->id); ?>" <?php if($regional_id == $unit_lists->id ): ?> selected <?php endif; ?> > 
        <?php echo e($unit_lists->company_name); ?>

    </option>
							
										 
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									 </select>

                        </div>

                        <div class="mb-3 col-md-6">
                            <label class="form-label">Unit Name:</label>
							 <select name="hotel_name" id="schedulemySelect22" class="form-control schedulemySelect22" >
												 	   <?php 
										 
										 $regional_id = $schedulemakerlists->hotel_name;
											 
											 $unit_list = DB::table('users')->where('created_by1', $schedulemakerlists->regional_id ?? '')->where('is_role', "3")->get(); ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 
										 	 <option value="<?php echo e($unit_lists->id); ?>" <?php if($regional_id == $unit_lists->company_name ): ?> selected <?php endif; ?> > 
        <?php echo e($unit_lists->company_name); ?>

    </option>
							
										 
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									

								
									 </select>
                        </div>
						
					
						
				                    <div class="mb-6 col-md-6">
												<label class="form-label">Equipment Name:</label>
																 <select name="name" id="mySelect" class="form-control" >
										 <option value="">Please  Select Equipment </option>
										   <?php $unit_list = DB::table('facility_equipment')->get(); ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 <option value="<?php echo e($unit_lists->name); ?>" <?php if($unit_lists->name == $schedulemakerlists->name ): ?> selected <?php endif; ?>><?php echo e($unit_lists->name); ?></option>
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									 </select>
                        </div>
						
						     <div class="mb-6 col-md-6">
                            <label class="form-label">Frequency Name:</label>
                            <input type="number" class="form-control"  name="frequency" value="<?php echo e($schedulemakerlists->frequency ?? ''); ?>" placeholder="" required>
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>
                        </div>
						
						
					
						
						
					

        

						
					
						
					<div class="mb-3 col-md-6">
                            <label class="form-label">Select Department:</label>
									 
										 <select name="department" id="scheduleeditmydepartment1" class="form-control scheduleeditmydepartment1" >
										 <option value="">Please Select Department </option>
										 
										   <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmentss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 <option value="<?php echo e($departmentss->id); ?>"  <?php if($schedulemakerlists->department == $departmentss->id ): ?> selected <?php endif; ?>><?php echo e($departmentss->name); ?></option>
										 
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									 
									 </select>
                        </div>
						
									<div class="mb-3 col-md-6">
                            <label class="form-label">Select Location:</label>
										
													 <select name="location_id" id="schedulemydepartment11" class="form-control schedulemydepartment11" >
												 	   <?php 
														 	 $regional_id = $schedulemakerlists->location_id;
								 $unit_list = DB::table('locations')->where('department_id', $schedulemakerlists->department ?? '')->get();
						 ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 
										 	 <option value="<?php echo e($unit_lists->id); ?>" <?php if($regional_id == $unit_lists->id ): ?> selected <?php endif; ?> > 
        <?php echo e($unit_lists->name); ?>

    </option>
							
										 
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
									 </select>
						
                        </div>
						
						<div class="mb-3 col-md-6">
                            <label class="form-label">Sub Location:</label>
													 <select name="sub_location" id="schedulemydepartment22" class="form-control schedulemydepartment22" >
												 	   <?php 
														 	 $regional_id = $schedulemakerlists->sub_location;
														 $unit_list = DB::table('locations')->where('parent', $schedulemakerlists->location_id ?? '')->get();
								
						 ?>
										 <?php $__currentLoopData = $unit_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 
										 	 <option value="<?php echo e($unit_lists->id); ?>" <?php if($regional_id == $unit_lists->id ): ?> selected <?php endif; ?> > 
        <?php echo e($unit_lists->name); ?>

    </option>
							
										 
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
									 </select>
                     
                        </div>
						
									         <div class="mb-3 col-md-6">
                            <label class="form-label">Select Responsibility:</label>
									 
										 <select name="responsibility_id" id="mySelect" class="form-control" >
										 <option value="">Please Select Responsibility </option>
										 
										
										 <?php $__currentLoopData = $authority; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $authoritys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 <option value="<?php echo e($authoritys->id); ?>" <?php if($schedulemakerlists->responsibility_id == $authoritys->id ): ?> selected <?php endif; ?>><?php echo e($authoritys->name); ?></option>
										 
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									 
									 </select>

                        </div>
						
						
 	     <div class="mb-6 col-md-6">
                            <label class="form-label">Task Start Date:</label>
                            <input type="date" class="form-control"  name="task_start_date" placeholder="" value="<?php echo e($schedulemakerlists->task_start_date ?? ''); ?>" required>
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>
                        </div>
            
       
               
                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

													                  

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>


                                                  </tr>
                                	<?php $k++; ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  
                                                </tbody>
                                              </table>
                         
                                        </div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>


<script>
function myFunction(sel) {

  var id = sel.value;

	        $.ajax({
           type:'GET',
           url:"<?php echo e(route('regional_list')); ?>",
           data:{id:id},
				dataType: "json",
           success:function(datalist){
          var data =  datalist.data;
					
			    $('.mySelect111').empty();
			   
			   
					           var selOpts = "";
            for (i=0;i<data.length;i++)
            {
                var id = data[i]['id'];
                var val = data[i]['company_name'];
                selOpts += "<option value='"+id+"'>"+val+"</option>";
            }
            $('.mySelect111').append(selOpts);
                    //alert(data.success);
                    //location.reload();
             
           }
        });
	
}
	
	
		
$('.mySelect111').change(function(){ 
    var id = $(this).val();
	        $.ajax({
           type:'GET',
           url:"<?php echo e(route('regional_unitlist')); ?>",
           data:{id:id},
				dataType: "json",
           success:function(datalist){
          var data =  datalist.data;
					$('.schedulemySelect22').empty();
					           var selOpts = "";
            for (i=0;i<data.length;i++)
            {
                var id = data[i]['id'];
                var val = data[i]['company_name'];
                selOpts += "<option value='"+val+"'>"+val+"</option>";
            }
            $('.schedulemySelect22').append(selOpts);
                    //alert(data.success);
                    //location.reload();
             
           }
        });
});
	
		$('.scheduleeditmydepartment1').change(function(){ 
		
    var id = $(this).val();
	        $.ajax({
           type:'GET',
           url:"<?php echo e(route('department_location')); ?>",
           data:{id:id},
				dataType: "json",
           success:function(datalist){
          var data =  datalist.data;
					$('.schedulemydepartment11').empty();
					           var selOpts = "";
            for (i=0;i<data.length;i++)
            {
                var id = data[i]['id'];
                var val = data[i]['name'];
                selOpts += "<option value='"+id+"'>"+val+"</option>";
            }
            $('.schedulemydepartment11').append(selOpts);
                    //alert(data.success);
                    //location.reload();
             
           }
        });
});
	
			$('.schedulemydepartment11').change(function(){ 
    var id = $(this).val();
	        $.ajax({
           type:'GET',
           url:"<?php echo e(route('location_sublocation')); ?>",
           data:{id:id},
				dataType: "json",
           success:function(datalist){
          var data =  datalist.data;
					$('.schedulemydepartment22').empty();
					           var selOpts = "";
            for (i=0;i<data.length;i++)
            {
                var id = data[i]['id'];
                var val = data[i]['name'];
                selOpts += "<option value='"+id+"'>"+val+"</option>";
            }
            $('.schedulemydepartment22').append(selOpts);
                    //alert(data.success);
                    //location.reload();
             
           }
        });
});
</script>

<script>
$(document).ready(function () {
    $('#pm-schedule-maker_table').DataTable();
});

</script><?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/popups/fhm/cleaning_schedular1.blade.php ENDPATH**/ ?>