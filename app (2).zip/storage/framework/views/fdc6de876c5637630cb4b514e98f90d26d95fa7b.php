                <div class="modal fade" id="addnewuser" tabindex="-1" aria-hidden="true" >
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                      <h5 class="modal-title">Add COA</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                        <form method="post" action="<?php echo e(route('supplier_coa')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                    <div class="row">
			
						
											<div class="mb-3 col-md-6">
<label class="form-label">Image:</label>
<input type="file" class="form-control"  name="coaimage" placeholder="" required>
<?php if($errors->has('coaimage')): ?>
<div class="error"><?php echo e($errors->first('coaimage')); ?></div>
<?php endif; ?>
</div>

<div class="mb-3 col-md-6">
<label class="form-label">Material:</label>
<textarea rows="4" name="Material_description" class="form-control"></textarea>
</div>

<div class="mb-3 col-md-6">
<label class="form-label">Brand name:</label>
<input  name="brand_name" class="form-control">
</div>


						   <div class="mb-3 col-md-6">
                            <label class="form-label">Supplier</label>
                            
                            <select class="form-control"  name="supplier_id">
                                <?php $__currentLoopData = $Supplier_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Supplier_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($Supplier_lists->id ?? ''); ?>"><?php echo e($Supplier_lists->supplier_name ?? ''); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          
                        </div>
                        
                        				   <div class="mb-3 col-md-6">
                            <label class="form-label">Product category</label>
                            
                              <select class="form-control"  name="Product_category">
                                <?php $__currentLoopData = $product_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product_categorys->id ?? ''); ?>"><?php echo e($product_categorys->name ?? ''); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            
                            
                            

                        </div>
						





                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary">Add New</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
<?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/popups/cop/add.blade.php ENDPATH**/ ?>