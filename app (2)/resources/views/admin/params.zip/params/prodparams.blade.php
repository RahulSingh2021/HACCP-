@extends('layouts.app', ['pagetitle'=>'Regulation Product Parameter Management'])
@section('content')

<style>
    .modal-dialog {
    max-width: 840px;
    margin: 1.75rem auto;
}

td.perm_desc_div {
    max-width: 645px;
}
</style>
<div class="content-body">
  <div class="d-sm-flex align-items-center justify-content-between mb-3">
    <div class="flex-grow-1">
      <ol class="breadcrumb df-breadcrumbs mg-b-10">
        <li class="breadcrumb-item"><a href="{{route('home')}}">Dashboard</a></li>
            <li class="breadcrumb-item active"> Regulation Product Parameter</li>
      </ol>
      <h4 class="pagetitle">Regulation Parameter Category</h4>
    </div>
    <div class="mg-l-auto">
      <div class="text-right">

        <a class="btn btn-success btn-xs" href="{{route('prodparamsimport')}}">Import Regulation Product Parameter</a>

        <!--<a class="btn btn-primary btn-xs" title="Add Inspection" href="javascript:void(0);" id="btnaddinspection">Add Regulation Product Parameter</a>-->
        <a class="btn btn-primary btn-xs" title="Add Inspection" href="{{route('add_prodparams')}}">Add Regulation Product Parameter</a>
      </div>
    </div>
  </div>
  <div class=" pd-x-0">

<!-- <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30 row">
  <div class="col-sm-12 col-lg-12">
    <div class="row">
      <div class="col-4">
            <a href="{{route('home')}}">Dashboard</a> / Regulation Product Parameter
      </div>
      <div class="col-4 text-right">
        <a class="btn btn-success btn-xs" href="{{route('prodparamsimport')}}">Import Regulation Product Parameter</a>
      </div>
      <div class="col-4 text-right">
        <a class="btn btn-success btn-xs" href="javascript:void(0);" id="createProdparamButton">Add Regulation Product Parameter</a>
      </div>
    </div>
  </div>
</div> -->


<div class="row row-xs">
  <div class="col-sm-12 col-lg-12">
    <div class="alert alert-success" style="display: none;" role="alert" id="success-alert"></div>
  </div>
</div>
    <form name="deldata" class="form-horizontal" method="post" action="{{route('prodparamsdelete')}}">
      @csrf
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <table class="table" id="prodparamsList1" style="width:100%">
          <thead>
            <tr>
              <th>#</th>
            <th> <input type="checkbox" class="checked_all" name="checkall" value="checkall"/> </th>
              <th>Description</th>
              <th>Category</th>
              <th>Product</th>
              <th>Added By</th>
              <th>Added On</th>
              <th>Action</th> 
            </tr>
          </thead>
          
          <tbody>
              
               @php
                $sno = 1;
            @endphp
              <?php         
              $result =DB::table('prodparams')
                ->select('prodparams.*')
                ->selectRaw('cusers.first_name AS cname, uusers.first_name AS uname, regulationcats.cat_name AS pcat_name, paramcats.cat_name')
                ->leftJoin('regulationcats', 'regulationcats.id', 'prodparams.regproducts_id')
                ->leftJoin('paramcats', 'paramcats.id', 'prodparams.paramcats_id')
                ->leftJoin('users AS cusers', 'cusers.id', 'prodparams.created_by')
                ->leftJoin('users AS uusers', 'uusers.id', 'prodparams.updated_by')->orderBy('id', 'DESC')->get(); 
                
                foreach($result as $results){
              ?>
                              <tr role="row" class="odd"><td class=" text-center">{{$sno++}}</td><td><input type="checkbox" name="deldata[]" value="{{$results->id}}" class="cb-element" /></td><td class=" perm_desc_div">	{!! $results->perm_desc !!}</td><td>{{$results->cat_name}}</td><td>{{$results->pcat_name}}</td><td>{{$results->updated_by}}</td><td class=" text-center">{{$results->cname}}</td><td><a href="https://www.safefoodmitra.com/admin/prodparams/edit_prodparams?id={{$results->id}}" title="Edit Food Safety Category" class="createProdparamButtonEdit"><i class="text-primary fa fa-edit"></i></a>&nbsp;<a href="javascript:void(0);" data-status="0" data-rowid="4" class="changeProdparamStatus" title="De-active"><i class="text-danger fa fa-circle"></i></a>&nbsp;<a href="javascript:void(0);" data-rowid="{{$results->id}}" class="deleteProdparam" title="Delete FSS Category"><i class="text-danger fa fa-trash"></i></a></td></tr>

               <?php  }?>
              </tbody>
        </table>
        
               <div class="col-sm-12 col-lg-12 mg-b-20">
          <button type="submit" id="delbutton" class="btn btn-danger btn-xs" value="delete">Delete Selected</button>
        </div>
         </div>
  
      </div>
    </form>
  </div>
</div>
<div id="createForm" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="prodparamsCrudModal">Create Regulation Product Parameter</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <form id="prodparamsForm" name="prodparamsForm" class="form-horizontal">
        <div class="modal-body">


          <div class="row row-sm">
            <div class="col-sm-12">
              <label>Parent Product Category <span class="text-danger">*</span></label>
              <select class="form-control" name="parentcat" id="disparentcat" required="required">
                <option value="">Select category</option>
                <?php
                foreach ($parcatlist as $cat) {
                  echo '<option value="'.$cat->id.'">'.$cat->cat_name.'</option>';
                }
                ?>
              </select>
            </div>
          </div>

          <div class="row row-sm">
            
            <div class="col-sm-12">
              <label>Product <span class="text-danger">*</span></label>
              <select class="form-control" name="regproducts_id" id="regproducts_id" required="required">
                <option value="0">Product</option>
                <?php
                foreach ($prolist as $key=>$cat) {
                  echo '<option value="'.$key.'" class="allSubCats Sub_'.$cat['parent'].'">'.$cat['prod_name'].'</option>';
                }
                ?>
              </select>
            </div>

            <div class="col-sm-12">
              <label>Category <span class="text-danger">*</span></label>
              <select class="form-control" name="paramcats_id" id="paramcats_id" required="required">
                <option value="0">Category</option>
                <?php
                foreach ($catlist as $key=>$cat) {
                  echo '<option value="'.$cat->id.'" class="allSubCats Sub_'.$cat->parentcategory.'">'.$cat->cat_name.'</option>';
                }
                ?>
              </select>
            </div>
            <!--<div class="col-sm-12 mg-t-10">-->
            <!--  <label>Parameter</label>-->
            <!--  <input type="text" class="form-control" name="parameter" id="parameter"  oninvalid="this.setCustomValidity('Please Enter Parameter')" oninput="setCustomValidity('')">-->
            <!--</div>-->
            <!--<div class="col-sm-12 mg-t-10">-->
            <!--  <label>Parameter Limit</label>-->
            <!--  <input type="text" class="form-control" name="perm_limit" id="perm_limit"  oninvalid="this.setCustomValidity('Please Enter Parameter Limit')" oninput="setCustomValidity('')">-->
            <!--</div>-->

            <div class="col-sm-12 mg-t-10">
              <label>Parameter Description</label>
              <textarea class="form-control" oninvalid="this.setCustomValidity('Please Enter Parameter Description')" oninput="setCustomValidity('')" name="perm_desc" id="perm_desc" ></textarea>
            </div>

            <input type="hidden" class="form-control" name="prodparams_id" id="prodparams_id" value="">
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" id="createProdparam" class="btn btn-success" id="btn-save" value="create">Save Regulation Product Parameter</button>
          <button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>
@endsection
@section('footerscript')
<script>
$('table').DataTable();

// See:
// http://www.sitepoint.com/responsive-data-tables-comprehensive-list-solutions

$(document).ready(function() {
  var SITEURL = $('base').attr('href');
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });
  $('#prodparamsList').DataTable({
    pageLength: 10,
    processing: true,
    serverSide: true,
    ajax: {
      url: SITEURL + "prodparams",
      type: 'GET',
    },
    language: {
      'loadingRecords': '&nbsp;',
      'processing': '<div class="spinner"></div>',
      searchPlaceholder: 'Search...',
      sSearch: '',
      lengthMenu: '_MENU_ Categories/Page',
    },
    columns: [
    {data: 'id', name: 'id', visible:false},
    {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false,searchable: false , sClass: "text-center"},

    {data: 'deldata',
    render: function(data, type, row, meta){
      return '<input type="checkbox" name="deldata[]" value="'+row.id+'" class="cb-element" />';
    },
    name: 'deldata', orderable: false,searchable: false},



    {data: 'perm_desc', name: 'perm_desc', sClass: "perm_desc_div" },

    {data: 'cat_name', name: 'paramcats.cat_name' },
    {data: 'pcat_name', name: 'regulationcats.cat_name' },
    {data: 'cname', name: 'cusers.first_name' },
    {data: 'created_at', 
    render: function(data, type, row, meta){
      if(data && data!='0000-00-00 00:00:00'){
        data = formatDate(data);
      } else{
        data = '-';
      }
      return data;
    },
    name: 'created_at', sClass: "text-center" },
    {data: 'action',
    render: function(data, type, row, meta){
      var SITEURL = $('base').attr('href');
      var Status='';
      if(row.is_active==1){
        Status='<a href="javascript:void(0);" data-status="'+row.is_active+'" data-rowid="'+row.id+'" class="changeProdparamStatus" title="Active"><i class="text-success fa fa-circle"></i></a>';
      }else{
        Status='<a href="javascript:void(0);" data-status="'+row.is_active+'" data-rowid="'+row.id+'" class="changeProdparamStatus" title="De-active"><i class="text-danger fa fa-circle"></i></a>';
      }
      var DELHTML='&nbsp;<a href="javascript:void(0);" data-rowid="'+row.id+'" class="deleteProdparam" title="Delete FSS Category"><i class="text-danger fa fa-trash"></i></a>';
      data = '<a  href="https://www.safefoodmitra.com/admin/prodparams/edit_prodparams?id='+row.id+'" title="Edit Food Safety Category"   class="createProdparamButtonEdit"><i class="text-primary fa fa-edit"></i></a>&nbsp;'+Status+DELHTML;

      return data;
    },
    name: 'action', orderable: false,searchable: false},
    ],
    order: [[0, 'desc']]
  });
  $('body').on('click', '.deleteProdparam', function () {
    var rowID=$(this).data("rowid");
    if (confirm("Are you sure you want to delete this product?\nThis action can not be reversed!")) {
      $.get(SITEURL + 'prodparams/'+rowID+'/delete', function (data) {
        $("#success-alert").html('Product deleted successfully!!');
        $("#success-alert").fadeTo(500, 2000);
        $("#success-alert").slideDown(1000);
        $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
          $("#success-alert").slideUp(2000);
        });
        var oTable = $('#prodparamsList').dataTable();
        oTable.fnDraw(false);
      })
    }
  });
  //$('.allSubCats').hide();
  $('.allSubCats').prop('disabled', true);
  //allSubCats
  $("#disparentcat").change(function () {  
      $('.allSubCats').prop('disabled', true);
      var parent_id=$(this).val();
      $("#regproducts_id").val('0');
      $("#paramcats_id").val('0');
      $('.allSubCats').hide();
      $('.Sub_'+parent_id).show();
      $('.Sub_'+parent_id).prop('disabled', false);
      
      $("#regproducts_id").select2("destroy");
      $("#regproducts_id").select2();

      $("#paramcats_id").select2("destroy");
      $("#paramcats_id").select2();
      
  });

  $('#btnaddinspection').click(function () {

    $('#btn-save').val("create-prodparams");
    $('#prodparams_id').val('');
    $('#prodparamsForm').trigger("reset");    
    $('#prodparamsForm .form-control').removeClass("error");
    $('#prodparamsForm label.error').hide();

    $('.allSubCats').hide();

    $('#perm_desc').val('');

    $('#iconDoc').hide();  
    $('#downloadLink').html('');

    $("#regproducts_id").val(0).trigger("change");
    $("#paramcats_id").val(0).trigger("change");
    $('#prodparamsCrudModal').html("Create Food Safety Category");
    $('#createProdparam').html('Save Food Safety Category');
    $('#createForm').modal('show');
  });

  $('body').on('click', '.createProdparamButtonEdit', function () {
    var rowID=$(this).data("rowid");
    $.get(SITEURL + 'prodparams/'+rowID+'/edit', function (data) {
      $('#btn-save').val("create-prodparams");
      $('#prodparamsForm').trigger("reset");    
      $('#prodparams_id').val(data.id);
      
      //$("#paramcats_id").val(data.paramcats_id).trigger("change");
      $('#perm_desc').html(data.perm_desc);

      //$("#prodparams_parent_id").select2('data', {id: data.parent_id, text: 'MyLabel'});
       
        $('.allSubCats').hide();
        $('.Sub_'+data.parent_id).show();
        $("#regproducts_id").val(data.regproducts_id);
        //$("#regproducts_id").val(data.regproducts_id).trigger("change");

        $("#disparentcat").val(data.parent_id);
        $("#paramcats_id").val(data.paramcats_id);

      $('#example').select2('destroy');

      $('#parameter').val(data.parameter);
      $('#perm_limit').val(data.perm_limit);
      if(data.icon_path!=''){
        $('#iconDoc').show();
        $('#iconLink').html('<img src="'+SITEURL+'public/icon_path/'+data.icon_path+'" class="img-fluid" />');
      }

      $('#prodparamsForm .form-control').removeClass("error");
      $('#prodparamsForm label.error').hide();
      $('#prodparamsCrudModal').html("Edit Food Safety Category");
      $('#createProdparam').html('Update Food Safety Category');
      $('#createForm').modal('show');
    })
  });
  $("#prodparamsForm").submit(function(e){
    e.preventDefault()
    var actionType = $('#btn-save').val();
    $('#createProdparam').html('Saving..');


    $.ajax({
      data:new FormData(this),
      url: SITEURL + "prodparams/store",
      type: "POST",
      dataType: 'json',
      contentType:false,
      cache:false,
      processData:false,
      success: function (data) {
        var curredit=$('#prodparams_id').val();
        if(curredit){
          $("#success-alert").html('Product updated successfully!!');
        }else{
          $("#success-alert").html('Product added successfully!!');
        }
        $("#success-alert").fadeTo(500, 2000);
        $("#success-alert").slideDown(1000);
        $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
          $("#success-alert").slideUp(2000);
        });
        $('#prodparamsForm').trigger("reset");
        $('#createForm').modal('hide');
        $('#createProdparam').html('Save');

        var oTable = $('#prodparamsList').dataTable();
        oTable.fnDraw(false);
      },
      error: function (data) {
        console.log('Error:', data);
        $('#createProdparam').html('Save');
      }
    });
  });
  $('body').on('click', '.changeProdparamStatus', function () {
    var rowID=$(this).data("rowid");
    if (confirm("Are you sure you want to change PRODUCT PARAMETER status!")) {
      $.get(SITEURL+"prodparams/status/"+rowID, function(data, status){

        $("#success-alert").html('PRODUCT PARAMETER Status updated');
        $("#success-alert").fadeTo(500, 2000);
        $("#success-alert").slideDown(1000);
        $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
          $("#success-alert").slideUp(2000);
        });

        var oTable = $('#prodparamsList').dataTable();
        oTable.fnDraw(false);
      });
    }

  });
  var formatDate = function(dateString) {
    var datePartsU = dateString.split(" ");
    var dateParts = datePartsU[0].split("-");
    var date = new Date(dateParts[0], dateParts[1] - 1, dateParts[2].substr(0,2));
    return(((date.getDate() > 9) ? date.getDate() : ('0' + date.getDate())) + '/' + ((date.getMonth() > 8) ? (date.getMonth() + 1) : ('0' + (date.getMonth() + 1))) + '/' + date.getFullYear());
  };
});


</script>



<script src="https://cdn.ckeditor.com/4.17.2/standard/ckeditor.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/23.1.0/classic/ckeditor.js"></script>

  <script>
                        CKEDITOR.replace( 'perm_desc' );
                </script>
@endsection
