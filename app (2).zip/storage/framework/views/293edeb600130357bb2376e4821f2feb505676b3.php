

<style type="text/css">
    .error {
    color: red;
    margin: 10px 0px;
}

.collapseButton {
  vertical-align: text-top;
}

th, td {
  padding: 1em;
}

#hidden {
  display: none;
}


table {
  border-collapse: collapse;
}
p {
    margin-top: 0;
    margin-bottom: 5px !important;
}



table th, td {
  padding: 1em;
  text-align: center;
}


</style>
<?php $__env->startSection('content'); ?>

     <?php echo $__env->make('admin.users.popups.reginoal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.users.popups.unit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                     
 
                      
                  <div class="row">
                         <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <ul class="nav nav-pills nav-pills-success mb-3" role="tablist" style="
    display: block !important;">
                                        <li class="nav-item" role="presentation" style="
    display: block !important;">
                                            <a class="nav active" style="
    display: block !important;" data-bs-toggle="pill" href="#company-details" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center" style="width: 87%;
    display: block !important;">
                                                     
         <?php echo $__env->make('admin.includes.flashMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         
                                                </div>
                                            </a>
                                        </li>
                                        
                                 
                              
                                
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane fade  show active " id="company-details" role="tabpanel">
                                            <div class="row row-cols-auto g-3" style="    float: right;
    margin-bottom: 20px;">
                                                <div class="col">
                                                    
                                                    <?php  $is_role = Auth::user()->is_role; ?>
                                                     <?php if($is_role==0): ?>
                    <button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#addcompanydetails" >+ Add Corporate</button>
                    
                    <?php endif; ?>
                    
                     <?php if($is_role !=1 && $is_role !=3): ?>
                   <button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#addregionaldetails">+ Add Regional</button>
                    <?php endif; ?>
													
													
													  <button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#addunitdetails" >+ Add Unit</button>
                                                </div>
                                            </div>
                                            
                                            
                    


          <tr id="hidden">
            <td></td>
            <td colspan=5>
         <table class="table table-bordered table-responsive table-striped" style="display: flow;">

                                                <thead>
                                                  <tr style="background: #426fc2;color: #fff;height: 55px;">
                                                    <th width="30">SI No.</th>
													     <th>Unit Details</th>
													   <th>linces and mandatory Audit details</th>
													   <th>People Management</th>
                                                    <th>Mandatory Testing</th>
													
                                                    <!--<th width="120">Action</th>-->
                                                  </tr>
                                                </thead>
                                                <tbody>

                                                    
<?php $i=1; ?>

                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <tr>
                                                    <td><?php echo e($i); ?></td>
        <td>
        <p><?php echo e($userss->login_id ?? ''); ?></p>
        <p><?php echo e($userss->name ?? ''); ?> </p>
        
        <p> <?php echo e($userss->designation ?? ''); ?> </p>
        <p><?php echo e($userss->Company_address ?? ''); ?></p>
        <p><?php echo e($userss->company_name ?? ''); ?></p>
        <p><?php echo e($userss->mobile_number ?? ''); ?></p>
        <p><a href=""><?php echo e($userss->email ?? ''); ?></a></p>
     
        
        
           
        </td>
						
						
																
<div class="modal fade " id="uploadlinces<?php echo e($userss->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">

<h5 class="modal-title">Upload License:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('lincesupload')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="type" placeholder="" value="1" required>
<input type="hidden" class="form-control"  name="unit_id" placeholder="" value="<?php echo e($userss->id ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="regional_id" placeholder="" value="<?php echo e($userss->created_by1 ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="corporate_id" placeholder="" value="<?php echo e($userss->created_by ?? ''); ?>" required>

<div class="mb-3 col-md-6">
<label class="form-label">Next Due Date:</label>
<input type="date" class="form-control"  name="due_date" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload License: <span style="color: red;">*(Maxium Size 2MB)</span></label>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>

<div class="mb-3 col-md-6">
<label class="form-label">Select Type Of License:</label>

<select class="form-control" name="cat_type">
<option value="Central">Central</option>
<option value="State">State</option>
<option value="Registration">Registration</option>

</select>

</div>



<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>	


<div class="modal fade " id="uploadhra<?php echo e($userss->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">

<h5 class="modal-title">Upload HRA:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('lincesupload')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="type" placeholder="" value="2" required>
<input type="hidden" class="form-control"  name="unit_id" placeholder="" value="<?php echo e($userss->id ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="regional_id" placeholder="" value="<?php echo e($userss->created_by1 ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="corporate_id" placeholder="" value="<?php echo e($userss->created_by ?? ''); ?>" required>

<div class="mb-3 col-md-6">
<label class="form-label">Renewal Due Date:</label>
<input type="date" class="form-control"  name="due_date" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload License:<span style="color: red;">*(Maxium Size 2MB)</span></label>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>

<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>


<div class="modal fade " id="uploadtpa<?php echo e($userss->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">

<h5 class="modal-title">Upload TPA:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('lincesupload')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="type" placeholder="" value="3" required>
<input type="hidden" class="form-control"  name="unit_id" placeholder="" value="<?php echo e($userss->id ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="regional_id" placeholder="" value="<?php echo e($userss->created_by1 ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="corporate_id" placeholder="" value="<?php echo e($userss->created_by ?? ''); ?>" required>

<div class="mb-3 col-md-6">
<label class="form-label">Renewal Due Date:</label>
<input type="date" class="form-control"  name="due_date" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload TPA:</label>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>

<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
													 
														    <td>
													        
        <table class="table table-bordered table-responsive table-striped">
        <th>License</th>
        <th>Audit</th>
        
        <tbody>
        <td><p><strong><a style="color: #000;"  data-bs-toggle="modal" data-bs-target="#uploadlinces<?php echo e($userss->id); ?>" ><i class="font-20 bx bxs-cloud-upload"></i> Upload license </a></strong></p>
        <br>
        
        <?php $documents_list = DB::table('tbl_documents_list')->where('unit_id', $userss->id)->where('type', 1)->get(); ?>
        <?php $__currentLoopData = $documents_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade " id="edit_documents<?php echo e($documents_lists->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Upload:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('updatelinces')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="edit_linces_id" value="<?php echo e($documents_lists->id ?? ''); ?>" placeholder="" >

<div class="mb-3 col-md-6">
<label class="form-label">Update Date:</label>
<input type="date" class="form-control"  name="due_date" value="<?php echo e($documents_lists->due_date ?? ''); ?>" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload:</label>
<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>"><i class="font-20 bx bxs-file"></i></a>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>

<div class="mb-3 col-md-6">
<label class="form-label">Select Type Of License:</label>

<select class="form-control" name="cat_type">
<option value="Central" <?php if($documents_lists->cat_type=="Central"): ?> selected <?php endif; ?>>Central</option>
<option value="State" <?php if($documents_lists->cat_type=="State"): ?> selected <?php endif; ?>>State</option>
<option value="Registration" <?php if($documents_lists->cat_type=="Registration"): ?> selected <?php endif; ?>>Registration</option>

</select>

</div>


<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>


        <p><strong>License Category:<?php echo e($documents_lists->cat_type ?? ''); ?></strong> 
        (<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>">View)
        <a style="color: #000;    color: #0a58ca;cursor: pointer;"  data-bs-toggle="modal" data-bs-target="#edit_documents<?php echo e($documents_lists->id); ?>" ><i class="font-20 bx bx-pencil font-18 me-1"></i>Edit </a>
</a>

<a href="<?php echo e(route('destoryDocuments',$documents_lists->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="font-20 bx bxs-trash"></i></a>

</p>
        <p><strong>Renewal Due Date:<?php echo e($documents_lists->due_date ?? ''); ?></strong></p>
        <p><strong>Uploaded Date:<?php echo e($documents_lists->created_at ?? ''); ?></strong></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td><p><strong><a style="color: #000;"  data-bs-toggle="modal" data-bs-target="#uploadhra<?php echo e($userss->id); ?>" ><i class="font-20 bx bxs-cloud-upload"></i> Upload HRA </a></strong>
        
</p>
        <br>
        <?php $documents_list = DB::table('tbl_documents_list')->where('unit_id', $userss->id)->where('type', 2)->get(); ?>
        <?php $__currentLoopData = $documents_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                <div class="modal fade " id="edit_documentshra<?php echo e($documents_lists->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Upload:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('updatelinces')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="edit_linces_id" value="<?php echo e($documents_lists->id ?? ''); ?>" placeholder="" >

<div class="mb-3 col-md-6">
<label class="form-label">Update Date:</label>
<input type="date" class="form-control"  name="due_date" value="<?php echo e($documents_lists->due_date ?? ''); ?>" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload:</label>
<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>"><i class="font-20 bx bxs-file"></i>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>
<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
        <p><strong>HRA</strong> (<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>">View)
        
        <a style="color: #000;color: #0a58ca;cursor: pointer;"  data-bs-toggle="modal" data-bs-target="#edit_documentshra<?php echo e($documents_lists->id); ?>" ><i class="font-20 bx bx-pencil font-18 me-1"></i>Edit </a>
        </a>
        <a href="<?php echo e(route('destoryDocuments',$documents_lists->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="font-20 bx bxs-trash"></i></a>
</p>
        <p><strong>Renewal Due Date:<?php echo e($documents_lists->due_date ?? ''); ?></strong></p>
        <p><strong>Uploaded Date:<?php echo e($documents_lists->created_at ?? ''); ?></strong></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <p><strong><a style="color: #000;"  data-bs-toggle="modal" data-bs-target="#uploadtpa<?php echo e($userss->id); ?>" ><i class="font-20 bx bxs-cloud-upload"></i> Upload TPA </a></strong></p>
        <br>
            <?php $documents_list = DB::table('tbl_documents_list')->where('unit_id', $userss->id)->where('type', 3)->get(); ?>
        <?php $__currentLoopData = $documents_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                        <div class="modal fade " id="edit_documentshra<?php echo e($documents_lists->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Upload:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('updatelinces')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="edit_linces_id" value="<?php echo e($documents_lists->id ?? ''); ?>" placeholder="" >

<div class="mb-3 col-md-6">
<label class="form-label">Update Date:</label>
<input type="date" class="form-control"  name="due_date" value="<?php echo e($documents_lists->due_date ?? ''); ?>" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload:</label>
<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>"><i class="font-20 bx bxs-file"></i>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>
<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>

        <p><strong>TPA</strong> (<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>">View)
        </a>
                <a style="color: #000;color: #0a58ca;cursor: pointer;"  data-bs-toggle="modal" data-bs-target="#edit_documentshra<?php echo e($documents_lists->id); ?>" ><i class="font-20 bx bx-pencil font-18 me-1"></i>Edit </a>

        <a href="<?php echo e(route('destoryDocuments',$documents_lists->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="font-20 bx bxs-trash"></i></a>
</p>
        <p><strong>Renewal Due Date:<?php echo e($documents_lists->due_date ?? ''); ?></strong></p>
        <p><strong>Uploaded Date:<?php echo e($documents_lists->created_at ?? ''); ?></strong></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </td>
        
        
        </tbody>
        </table>
           </td>
                                                    <td>        <table class="table table-bordered table-responsive table-striped">
        <th>Food Handlers Medical Test</th>
        <th>Fostac Certificate</th>
        <th>Mandatory Internal Training1</th>
        
        <tbody>
        <td><p><strong>Unit Complied:20</strong></p>
        <p><strong>Unit About to expried:0</strong></p>
          <p><strong>Expried:0</strong></p>
        <p><strong>Unit Non Complied:20</strong></p>
       
        </td>
      <td><p><strong>Unit Complied:20</strong></p>
        <p><strong>Unit About to expried:0</strong></p>
          <p><strong>Expried:0</strong></p>
        <p><strong>Unit Non Complied:20</strong></p>
       
        </td>
      <td><p><strong>Unit Complied:20</strong></p>
        <p><strong>Unit About to expried:0</strong></p>
          <p><strong>Expried:0</strong></p>
        <p><strong>Unit Non Complied:20</strong></p>
       
        </td>
        
        
        
        </tbody>
        </table></td>
                                              
                                                  
                                                    <td>     <table class="table table-bordered table-responsive table-striped">
        <th>Food Test Report</th>
        <th>Water Test Report</th>
        
        <tbody>
         <td><p><strong><a style="color: #000;"  data-bs-toggle="modal" data-bs-target="#uploadh1testfood<?php echo e($userss->id); ?>" ><i class="font-20 bx bxs-cloud-upload"></i> Upload Food Test Report </a></strong></p>
        <br>
               <?php $documents_list = DB::table('tbl_documents_list')->where('unit_id', $userss->id)->where('type', 4)->get(); ?>
        <?php $__currentLoopData = $documents_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                                <div class="modal fade " id="edit_testfood<?php echo e($documents_lists->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Upload:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('updatelinces')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="edit_linces_id" value="<?php echo e($documents_lists->id ?? ''); ?>" placeholder="" >



<div class="mb-3 col-md-6">
<label class="form-label">Food Test Report:</label>
<input type="text" class="form-control"  name="name" value="<?php echo e($documents_lists->name ?? ''); ?>" placeholder="" >
</div>



<div class="mb-3 col-md-6">
<label class="form-label">Update Date:</label>
<input type="date" class="form-control"  name="due_date" value="<?php echo e($documents_lists->due_date ?? ''); ?>" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload:</label>
<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>"><i class="font-20 bx bxs-file"></i>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>
<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
        <p><strong><?php echo e($documents_lists->name ?? ''); ?></strong> (<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>">View)
        </a>
           <a style="color: #000;color: #0a58ca;cursor: pointer;"  data-bs-toggle="modal" data-bs-target="#edit_testfood<?php echo e($documents_lists->id); ?>" ><i class="font-20 bx bx-pencil font-18 me-1"></i>Edit </a>
        <a href="<?php echo e(route('destoryDocuments',$documents_lists->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="font-20 bx bxs-trash"></i></a>
</p>
        <p><strong>Renewal Due Date:<?php echo e($documents_lists->due_date ?? ''); ?></strong></p>
        <p><strong>Uploaded Date:<?php echo e($documents_lists->created_at ?? ''); ?></strong></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
   
        </td>
             <td><p><strong><a style="color: #000;"  data-bs-toggle="modal" data-bs-target="#uploadh2testfood<?php echo e($userss->id); ?>" ><i class="font-20 bx bxs-cloud-upload"></i> Upload Water Test Report </a></strong></p>
        <br>
                <?php $documents_list = DB::table('tbl_documents_list')->where('unit_id', $userss->id)->where('type', 5)->get(); ?>
        <?php $__currentLoopData = $documents_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                                        <div class="modal fade " id="edit_documents<?php echo e($documents_lists->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Upload:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('updatelinces')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="edit_linces_id" value="<?php echo e($documents_lists->id ?? ''); ?>" placeholder="" >



<div class="mb-3 col-md-6">
<label class="form-label">Water Test Report:</label>
<input type="text" class="form-control"  name="name" value="<?php echo e($documents_lists->name ?? ''); ?>" placeholder="" >
</div>


<div class="mb-3 col-md-6">
<label class="form-label">Update Date:</label>
<input type="date" class="form-control"  name="due_date" value="<?php echo e($documents_lists->due_date ?? ''); ?>" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload:</label>
<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>"><i class="font-20 bx bxs-file"></i>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>
<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
        <p><strong><?php echo e($documents_lists->name ?? ''); ?></strong> (<a target="_blank()" href="<?php echo e(asset('documents')); ?>/<?php echo e($documents_lists->image ?? ''); ?>">View)
        </a>
        
           <a style="color: #000;color: #0a58ca;cursor: pointer;"  data-bs-toggle="modal" data-bs-target="#edit_documents<?php echo e($documents_lists->id); ?>" ><i class="font-20 bx bx-pencil font-18 me-1"></i>Edit </a>
        <a href="<?php echo e(route('destoryDocuments',$documents_lists->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="font-20 bx bxs-trash"></i></a>
</p>
        <p><strong>Renewal Due Date:<?php echo e($documents_lists->due_date ?? ''); ?></strong></p>
        <p><strong>Uploaded Date:<?php echo e($documents_lists->created_at ?? ''); ?></strong></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </td>
        
        
        
        </tbody>
        </table></td>
        
<div class="modal fade " id="uploadh1testfood<?php echo e($userss->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">

<h5 class="modal-title">Upload Food Test Report:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('lincesupload')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="type" placeholder="" value="4" required>
<input type="hidden" class="form-control"  name="unit_id" placeholder="" value="<?php echo e($userss->id ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="regional_id" placeholder="" value="<?php echo e($userss->created_by1 ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="corporate_id" placeholder="" value="<?php echo e($userss->created_by ?? ''); ?>" required>

<div class="mb-3 col-md-6">
<label class="form-label">Food Test Report:</label>
<input type="text" class="form-control"  name="name" value="" placeholder="" >
</div>


<div class="mb-3 col-md-6">
<label class="form-label">Sample Report  Date:</label>
<input type="date" class="form-control"  name="due_date" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload Food Test Report:<span style="color: red;">*(Maxium Size 2MB)</span></label>
<input type="file" class="form-control"  name="image" placeholder="" >

</div>

<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>


<div class="modal fade " id="uploadh2testfood<?php echo e($userss->id); ?>" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">

<h5 class="modal-title">Upload Water Test Report:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="<?php echo e(route('lincesupload')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<input type="hidden" class="form-control"  name="type" placeholder="" value="5" required>
<input type="hidden" class="form-control"  name="unit_id" placeholder="" value="<?php echo e($userss->id ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="regional_id" placeholder="" value="<?php echo e($userss->created_by1 ?? ''); ?>" required>
<input type="hidden" class="form-control"  name="corporate_id" placeholder="" value="<?php echo e($userss->created_by ?? ''); ?>" required>

<div class="mb-3 col-md-6">
<label class="form-label">Water Test Report:</label>
<input type="text" class="form-control"  name="name" value="" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Renewal Due Date:</label>
<input type="date" class="form-control"  name="due_date" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload Water Test Report:<span style="color: red;">*(Maxium Size 2MB)</span></label>
<input type="file" class="form-control"  name="image" placeholder="" >
<?php if($errors->has('image1')): ?>
<div class="error"><?php echo e($errors->first('image1')); ?></div>
<?php endif; ?>
</div>

<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
    </div>
                                                  </tr>
<?php $i++; ?>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                                  
                                                </tbody>
                                              </table>
 


                                           
                                        </div>
                              
                                                
                                                    </div> 
                                                   </div>
                                                
                                                
                                                
                                            </div>
                                            

                                            
                                            
                                       </div>
                          
                         
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
       
                        
                    </div>




<?php $__env->stopSection(); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
<script>
    $(function(){
  $('.header-level').click(function(){
    $(this).next('.sub-level').find('table').toggle();
  });
});
</script>

<script>
    function collapse(cell){
  var row = cell.parentElement;
  var target_row = row.parentElement.children[row.rowIndex + 1];
  if (target_row.style.display == 'table-row') {
    cell.innerHTML = '+';
    target_row.style.display = 'none';
  } else {
    cell.innerHTML = '-';
    target_row.style.display = 'table-row';
  }
}
</script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>

<?php if($errors->any()): ?>
<script>
    $(document).ready(function() {
    $('#addcompanydetails').modal('show');
});
     </script>
<?php endif; ?>



   
<?php echo $__env->make('layouts.app', ['pagetitle'=>'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/users/regional_units.blade.php ENDPATH**/ ?>