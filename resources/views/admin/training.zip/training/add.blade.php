@extends('layouts.app', ['pagetitle'=>'Dashboard'])

<style>
        .step-number {border-top: #333 2px solid; width: 100%; display: flex; justify-content: space-between; margin-top:30px; position: relative;}
    .step-number:before{content: ""; background: #fff; display: block; position: absolute; height: 3px; width: 27px; top: -2px; z-index: 0;}
    .step-number:after{content: ""; background: #fff; display: block; position: absolute; height: 3px; width: 27px; top: -2px; z-index: 0; right: 0;}
    .step-number span{margin-top: -15px; text-align: center; z-index: 1;}
    .step-number em {width: 30px; height: 30px; border-radius: 50%; display: inline-block; text-align: center; font-style: normal; line-height: 30px; font-weight: 600; margin-bottom: 5px; }
    .ins-t td{ font-size: 13px; padding:5px 0px;}
    .cam-img {width: 100%;background: #f7f7f7;height: 80%;border-radius: 6px;display: flex;align-items: center;justify-content: center;cursor: pointer;}
    .imageuploadify {min-height: 150px;}
    .imageuploadify-message{ display: none !important;}
    .imageuploadify .imageuploadify-images-list i {font-size: 3em;height: 50px;}

    /* Template List CSS*/

    .img-profile {
    width: 8rem;
    height: 8rem;
    padding: 0px;
    flex-shrink: 0;
    -webkit-box-flex: 0;
    flex-grow: 0;
    background-color: rgb(255, 255, 255);
    border: 1px dashed rgb(191, 198, 212);
    border-radius: 12px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;  
    font-size: 0.875rem;
    flex-direction: row;
    align-self: center;
    -webkit-box-pack: center;
    justify-content: center;
    padding: 1.5rem 2rem;
    font-weight: 500;
    text-align: center; position: relative;
    color: rgb(103, 93, 244); cursor: pointer;
}

.template-logo-hover{display:none;}

.img-profile:hover .template-logo-hover {
    font-weight: 500;
    color: rgb(84, 95, 112);
    display: flex;
    flex-direction: column;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
    gap: 1rem;
    border-radius: 12px;
    position: absolute;
    background-color: rgb(219 223 234);
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
}
.title-editable-block { font-size: 30px; padding: 0 0px; font-weight:600; line-height: 1.1; margin-bottom:20px; outline: none; color: rgb(55, 53, 47); caret-color: rgb(55, 53, 47); white-space: pre-wrap; word-break: break-word; cursor: text; display: inline-block;
}

.title-editable-block:empty::before {
    content: attr(placeholder);
    display: block;
    -webkit-text-fill-color: rgb(130, 142, 160);
}
.content-editable-block {  line-height: 1.1; outline: none;   cursor: text; min-height: 30px; line-height: 1.5; padding: 3px 0px; outline: none; display: inline-block;
    color: rgb(55, 53, 47); caret-color: rgb(55, 53, 47); white-space: inherit; word-break: break-word;
}

.content-editable-block:empty::before {
    content: attr(placeholder);
    display: block;
    -webkit-text-fill-color: rgb(187, 186, 184);
}
.accordion-button::before {
    flex-shrink: 0;
    width: 1.25rem;
    height: 1.25rem;
    margin-left:0;
    content: "";
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23212529'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-size: 1.25rem; margin-right:10px;
    transition: transform .2s ease-in-out; transform: rotate(-90deg);
}
.accordion-button::after {display:none;}
.accordion-button:focus {
    border-color: #fff; box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0);
}
.accordion-button:not(.collapsed) {
    color: #333;
    background-color: #fff;
}
.accordion-button:not(.collapsed)::before {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23212529'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
    transform: rotate(0deg);
}

.darg-icon{cursor: -webkit-grab;
    cursor: grab; width: 30px; height: 30px;
    position: relative;
    overflow: hidden;
    outline: none;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center; text-align: center;
    border-radius: 50%; display: inline-flex;
     z-index: 1;}

.darg-icon:hover{
    inset: 0px;
    background: rgb(191, 198, 212);
    opacity: 1;
    border-radius: 100%;
    transition: transform 500ms ease-out 0s;}  

.required-icon{ width: 10px; text-align: center;}

.arrow-icon1{ float: right; cursor: pointer;}

.info {
    font-size: 0.8rem;
    font-weight: 400;
    margin-right: 0.4rem;
    display: inline-block;
    vertical-align: inherit;
    white-space: nowrap;
    line-height: initial;
    padding: 0.2rem 0.4rem;
    border-radius: 0.75rem;
    max-width: 8.75rem;
    overflow: hidden;
    text-overflow: ellipsis;
    flex-shrink: 0;
    color: rgb(19, 133, 95);
    border: 1px solid transparent;
    background-color: rgba(19, 133, 95, 0.1);
}
.risk {
    font-size: 0.8rem;
    font-weight: 400;
    margin-right: 0.4rem;
    display: inline-block;
    vertical-align: inherit;
    white-space: nowrap;
    line-height: initial;
    padding: 0.2rem 0.4rem;
    border-radius: 0.75rem;
    max-width: 8.75rem;
    overflow: hidden;
    text-overflow: ellipsis;
    flex-shrink: 0;
    color: rgb(198, 0, 34);
    border: 1px solid transparent;
    background-color: rgba(198, 0, 34, 0.1);
}
.na{
    font-size: 0.8rem;
    font-weight: 400;
    margin-right: 0.4rem;
    display: inline-block;
    vertical-align: inherit;
    white-space: nowrap;
    line-height: initial;
    padding: 0.2rem 0.4rem;
    border-radius: 0.75rem;
    max-width: 8.75rem;
    overflow: hidden;
    text-overflow: ellipsis;
    flex-shrink: 0;
    color: rgb(112, 112, 112);
    border: 1px solid transparent;
    background-color: rgba(112, 112, 112, 0.1);
}

.border-l{border-left:#dee2e6 thin solid;}

tbody, td, tfoot, th, thead, tr {
    border-color: rgb(191, 198, 212);
    border-style: solid;
    border-width: thin;
}
.table>:not(:last-child)>:last-child>* {
    border-bottom-color: rgb(191, 198, 212);
}
.fr1::before{-webkit-text-fill-color:#000 !important}
.fr1:focus{border: #0d6efd 2px solid;
    border-radius: 6px;
    padding: 6px;}

.p-icon {
    display: block;
    background: rgb(255, 255, 255);
    border-radius: 50%;
    width: 1.5rem;
    height: 1.5rem;
    padding: 0.1rem;position: absolute;
    right: 4px;
    top: 22px;
    border: 1px solid rgb(171, 181, 196);
}
.add-p {
    display: inline-block;
    font-size: 0.875rem;
    pointer-events: auto;
    cursor: pointer;
    text-decoration: underline;
    color: rgb(130, 142, 160);
}

.pop-arrow{ border: none; background: none;}
.pop-arrow:after{ display: none;;}

input:focus,button:focus{outline: none; box-shadow: none;}

.eUAmnn {
    font-size: 0.875rem;
    font-weight: 400;
    color: rgb(31, 37, 51);
    line-height: 1.25rem;
    cursor: pointer;
    padding: 0.6rem 0.875rem;
    min-height: 2rem;
    white-space: nowrap;
    user-select: none;
    overflow: hidden;
    background-color: rgb(236, 237, 254);
}
.djjqoz {
    margin-right: 0.7rem;
    border-radius: 50%;
    background: rgba(100, 143, 255, 0.1);
    padding: 0.3rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}
.cJpwRx {
    font-size: 0.875rem;
    font-weight: 400;
    color: rgb(31, 37, 51);
    line-height: 1.25rem;
    cursor: pointer;
    padding: 0.6rem 0.875rem;
    min-height: 2rem;
    white-space: nowrap;
    user-select: none;
    overflow: hidden;
    background-color: inherit;
}
.bhYnZk {
    margin-right: 0.7rem;
    border-radius: 50%;
    background: rgba(254, 133, 0, 0.1);
    padding: 0.3rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}
.cJpwRx {
    font-size: 0.875rem;
    font-weight: 400;
    color: rgb(31, 37, 51);
    line-height: 1.25rem;
    cursor: pointer;
    padding: 0.6rem 0.875rem;
    min-height: 2rem;
    white-space: nowrap;
    user-select: none;
    overflow: hidden;
    background-color: inherit;
}
.jpgcYH {
    margin-right: 0.7rem;
    border-radius: 50%;
    background: rgba(94, 156, 255, 0.1);
    padding: 0.3rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}
.iDhWfr {
    -webkit-box-align: center;
    align-items: center;
}
.flVgHp {
    margin-right: 0.7rem;
    border-radius: 50%;
    background: rgba(129, 181, 50, 0.1);
    padding: 0.3rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}
.ipAtGo {
    margin-right: 0.7rem;
    border-radius: 50%;
    background: rgba(0, 182, 203, 0.1);
    padding: 0.3rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}
.imuKGG {
    margin-right: 0.7rem;
    border-radius: 50%;
    background: rgba(30, 207, 147, 0.1);
    padding: 0.3rem;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}
    </style>
@section('content')
 @include('admin.popups.templates.addtemplate')
<div class="row">
                    <div class="col">
                      <div class="card">
                                <div class="card-body">
                                    <div>
                                        <h5 class="mb-3">Template List</h5>
                                        <hr>
                                    </div>
                                    <div class="row row-cols-auto g-3 mb-0 p-3">
                                        <div class="col-2">
                                           <div class="img-profile">
                                            <svg width="48" height="48" xmlns="http://www.w3.org/2000/svg"><path d="M39,34 L36,34 L36,31 C36,30.44775 35.55273,30 35,30 C34.44727,30 34,30.44775 34,31 L34,34 L31,34 C30.44727,34 30,34.44775 30,35 C30,35.55225 30.44727,36 31,36 L34,36 L34,39 C34,39.55225 34.44727,40 35,40 C35.55273,40 36,39.55225 36,39 L36,36 L39,36 C39.55273,36 40,35.55225 40,35 C40,34.44775 39.55273,34 39,34 Z" id="Shape" fill="#FFFFFF"></path><path d="M42,37 L37,42 L2,42 C0.89543,42 0,41.10457 0,40 L0,2 C0,0.89543 0.89543,0 2,0 L40,0 C41.10457,0 42,0.89543 42,2 L42,37 Z" id="Shape" fill="#EEF5FF"></path><circle id="Oval" fill="#5E9CFF" cx="18" cy="12" r="4"></circle><path d="M40.791103,32.3878833 L30.7918482,19.36966 C30.4139463,18.87678 29.5849081,18.87678 29.2070063,19.36966 L20.9649405,30.1001308 L14.7813214,22.3591948 C14.4024396,21.8839195 13.5987895,21.8839195 13.2199178,22.3591948 L5.22051392,32.3732128 C4.69807285,33.0261568 5.16230825,34 6.00121573,34 L39.998682,34 C40.8276403,34 41.2964253,33.0459845 40.791103,32.3878833 Z" id="Shape" fill="#5E9CFF"></path><circle id="Oval" fill="#1ECF93" cx="38" cy="38" r="8"></circle><path d="M41,37 L39,37 L39,35 C39,34.44769 38.55231,34 38,34 C37.44769,34 37,34.44769 37,35 L37,37 L35,37 C34.44769,37 34,37.44769 34,38 C34,38.55225 34.44769,39 35,39 L37,39 L37,41 C37,41.55225 37.44769,42 38,42 C38.55231,42 39,41.55225 39,41 L39,39 L41,39 C41.55231,39 42,38.55225 42,38 C42,37.44769 41.55231,37 41,37 Z" id="Shape" fill="#FFFFFF"></path></svg>
                                            
                                            <div class="template-logo-hover"><svg viewBox="0 0 24 24" width="20" height="20" focusable="false"><path d="M6.293 7.707a1 1 0 010-1.414l5-5a1 1 0 011.414 0l5 5a1 1 0 01-1.414 1.414L13 4.414V16a1 1 0 11-2 0V4.414L7.707 7.707a1 1 0 01-1.414 0z" fill="#545f70"></path><path d="M2 15a1 1 0 011 1v4a1 1 0 001 1h16a1 1 0 001-1v-4a1 1 0 112 0v4a3 3 0 01-3 3H4a3 3 0 01-3-3v-4a1 1 0 011-1z" fill="#545f70"></path></svg>Upload image</div>

                                           </div>  
                                        </div>
                                        <div class="col-8 align-self-center">
                                            <div data-bs-toggle="tooltip" data-bs-placement="top" title="" class="title-editable-block" id="" contenteditable="true" placeholder="Enter template title" tabindex="0" data-bs-original-title="Edit the title of your template" aria-label="Edit the title of your template"></div> 
                                            <div class="clearfix"></div>
                                            <div data-bs-toggle="tooltip" data-bs-placement="right" title="" class="content-editable-block" id="" contenteditable="true" placeholder="Add a description" tabindex="0" data-bs-original-title="Describe your template" aria-label="Describe your template"></div>
                                        </div>
                                       
                                    </div> 
                                    <div class="row row-cols-auto g-3 mb-3 p-3">
                                        <div class="col-12">
                                            <div class="accordion accordion-flush" id="accordionFlushExample">
                                                <div class="accordion-item">
                                                    <h2 class="accordion-header" id="flush-headingOne">
                                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-controls="flush-collapseOne">
                                                           <b>Title Page</b> 
                                                        </button>
                                                    </h2>
                                                    <div id="flush-collapseOne" class="accordion-collapse collapse show" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                                        <div class="accordion-body">
                                                          <p>The Title Page is the first page of your inspection report. You can customize the Title Page below.</p>
                                                          <div class="card col-md-9">
                                                              
        

<!-- Text input-->
<div  class="form-group">
 <table class="table mb-0" border="1">
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col">Questions</th>
                                                                            <th scope="col" width="300">Type of responce</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="items">
                                                                        <tr>
                                                                            <td class="d-flex align-items-center" style="border:none;">
                                                                             <div class="darg-icon"><svg viewBox="0 0 24 24" width="24" height="24" focusable="false"><path fill="none" d="M0 0h24v24H0V0z"></path><path fill="#333" d="M11 18c0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2 2 .9 2 2zm-2-8c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm6 4c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"></path></svg></div>    
                                                                             <span class="required-icon">*</span> 
                                                                             <div class="content-editable-block w-100 fr1" id="" contenteditable="true" placeholder="Site conducted" tabindex="0"></div>
                                                                            </td>
                                                                            <td>
                                                                             <span class="info">Safe</span>
                                                                             <span class="risk">At Risk</span>
                                                                             <span class="na">N/A</span>

                                                                             <div class="dropdown" style="float: right;">
                                                                                <button class="pop-arrow dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                                                    <span class="arrow-icon1">
                                                                                        <svg viewBox="0 0 24 24" width="16" height="16" class="" focusable="false"><path d="M12.819 17.633l8.866-9.52a1.323 1.323 0 0 0-.028-1.745 1.113 1.113 0 0 0-1.625-.03l-7.663 8.228a.509.509 0 0 1-.755 0L3.968 6.354a1.113 1.113 0 0 0-1.625.03 1.323 1.323 0 0 0-.028 1.745l8.85 9.504c.22.235.517.368.827.367a1.12 1.12 0 0 0 .827-.367z" fill="#545f70" fill-rule="nonzero"></path></svg>
                                                                                    </span>    
                                                                                </button>
                                                                                <div class="dropdown-menu p-3" style="margin: 0px; width: 600px; overflow: auto; max-height:90vh; inset: auto auto 0px 0px !important;
                                                                                transform: translate(-570.857px, -28px) !important;" data-popper-placement="top-end">
                                                                                  <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <div class="position-relative search-bar-box w-100 ps-0 mb-3">
                                                                                            <input type="text" class="form-control search-control" placeholder="Type to search..."> 
                                                                                            <span class="position-absolute top-50 search-show translate-middle-y" style="left:10px;"><i class="bx bx-search"></i></span>
                                                                                            <span class="position-absolute top-50 search-close translate-middle-y"><i class="bx bx-x"></i></span>
                                                                                        </div>
                                                                                        <div class="d-flex justify-content-between mb-3">
                                                                                            <span>Site conducted</span>
                                                                                            <a role="button" class="text-primary">+ Responses</a>
                                                                                        </div>
                                                                                        <div class="d-flex justify-content-between mb-1">
                                                                                            <span>
                                                                                                <span class="info">Safe</span>
                                                                                                <span class="risk">At Risk</span>
                                                                                                <span class="na">N/A</span>
                                                                                            </span>
                                                                                            <span><i class="bx bx-pencil" role="button"></i></span>
                                                                                        </div>
                                                                                        <div class="d-flex justify-content-between mb-1">
                                                                                            <span>
                                                                                                <span class="info">Safe</span>
                                                                                                <span class="risk">At Risk</span>
                                                                                                <span class="na">N/A</span>
                                                                                            </span>
                                                                                            <span><i class="bx bx-pencil" role="button"></i></span>
                                                                                        </div>
                                                                                        <div class="d-flex justify-content-between mb-1">
                                                                                            <span>
                                                                                                <span class="info">Safe</span>
                                                                                                <span class="risk">At Risk</span>
                                                                                                <span class="na">N/A</span>
                                                                                            </span>
                                                                                            <span><i class="bx bx-pencil" role="button"></i></span>
                                                                                        </div>
                                                                                        <div class="d-flex justify-content-between mb-1">
                                                                                            <span>
                                                                                                <span class="info">Safe</span>
                                                                                                <span class="risk">At Risk</span>
                                                                                                <span class="na">N/A</span>
                                                                                            </span>
                                                                                            <span><i class="bx bx-pencil" role="button"></i></span>
                                                                                        </div>
                                                                                        <div class="d-flex justify-content-between mb-1">
                                                                                            <span>
                                                                                                <span class="info">Safe</span>
                                                                                                <span class="risk">At Risk</span>
                                                                                                <span class="na">N/A</span>
                                                                                            </span>
                                                                                            <span><i class="bx bx-pencil" role="button"></i></span>
                                                                                        </div>
                                                                                    </div>
                                                                                  </div>
                                                                                </div>
                                                                            </div>

                                                                            </td>
                                                                        </tr>
                                                                    
                                                                    </tbody>
                                                                </table>
</div>



                                                            <div class="card-body position-relative">
                                                                <svg class="p-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="" viewBox="0 0 24 24" width="14" height="14" focusable="false" data-anchor="plus-svg" style="cursor: pointer;" data-bs-original-title="View score column" aria-label="View score column"><path d="M0 0h24v24H0z" fill="none"></path><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" fill="#545f70"></path></svg>
                                                                
                                                                
                                                                <div class="mt-3">
                                                                    


                                                                    <button id="add" class="btn btn-primary me-2"><svg viewBox="0 0 24 24" width="16" height="16" focusable="false" data-anchor="plus-svg"><path d="M0 0h24v24H0z" fill="none"></path><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" fill="#fff"></path></svg> Add Question</button>
                                                                    <button class="btn btn-primary"><svg width="16" height="16" viewBox="0 0 14 14" focusable="false"><g transform="translate(1 1)" fill="#fff" fill-rule="nonzero"><rect width="12" height="4.066" rx="0.733"></rect><path d="M.8 5.947v5.164h10.4V5.947H.8zm0-.89h10.4c.442 0 .8.399.8.89v5.164c0 .491-.358.889-.8.889H.8c-.442 0-.8-.398-.8-.889V5.947c0-.491.358-.89.8-.89z"></path></g></svg> Add section</button>
                                                                </div>
                                                                <div class="mt-3 add-p">Add Page</div>
                                                            </div>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 align-self-center">
                                            
                                            
                                        </div>
                                       
                                    </div> 
                                </div>
                                
                            </div>

                    </div>
                    <!--end row-->
                </div>

@endsection

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
 <script>
  // For ToolTip //
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl)
    })

// For  File Upload //
  function readUrl(input) {
  
  if (input.files && input.files[0]) {
    let reader = new FileReader();
    reader.onload = (e) => {
      let imgData = e.target.result;
      let imgName = input.files[0].name;
      input.setAttribute("data-title", imgName);
      console.log(e.target.result);
    }
    reader.readAsDataURL(input.files[0]);
  }

}

// For  popover //
var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
  return new bootstrap.Popover(popoverTriggerEl)
})

// For View Dropdown toggle box //
$(".show-dm-menu").click(function(){
  $(".dm-menu").toggle();
});

// For right slide //
function openNav() {
  document.getElementById("mySidenav").style.width = "300px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

</script>  

<script>
    $(document).ready(function() {
  $(".delete").hide();
  //when the Add Field button is clicked
  $("#add").click(function(e) {
    $(".delete").fadeIn("1500");
    //Append a new row of code to the "#items" div
    $("#items").append(
      '<tr><td class="d-flex align-items-center" style="border:none;"><div class="darg-icon"><svg viewBox="0 0 24 24" width="24" height="24" focusable="false"><path fill="none" d="M0 0h24v24H0V0z"></path><path fill="#333" d="M11 18c0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2 2 .9 2 2zm-2-8c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm6 4c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"></path></svg></div><span class="required-icon">*</span><div class="content-editable-block w-100 fr1" id="" contenteditable="true" placeholder="Site conducted" tabindex="0"></div></td><td><span class="info">Safe</span><span class="risk">At Risk</span><span class="na">N/A</span><div class="dropdown" style="float: right;"><button class="pop-arrow dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><span class="arrow-icon1"><svg viewBox="0 0 24 24" width="16" height="16" class="" focusable="false"><path d="M12.819 17.633l8.866-9.52a1.323 1.323 0 0 0-.028-1.745 1.113 1.113 0 0 0-1.625-.03l-7.663 8.228a.509.509 0 0 1-.755 0L3.968 6.354a1.113 1.113 0 0 0-1.625.03 1.323 1.323 0 0 0-.028 1.745l8.85 9.504c.22.235.517.368.827.367a1.12 1.12 0 0 0 .827-.367z" fill="#545f70" fill-rule="nonzero"></path></svg></span></button><div class="dropdown-menu p-3" style="margin: 0px; width: 600px; overflow: auto; max-height:90vh; inset: auto auto 0px 0px !important;transform: translate(-570.857px, -28px) !important;" data-popper-placement="top-end"><div class="row"><div class="col-md-12"><div class="position-relative search-bar-box w-100 ps-0 mb-3"><input type="text" class="form-control search-control" placeholder="Type to search..."><span class="position-absolute top-50 search-show translate-middle-y" style="left:10px;"><i class="bx bx-search"></i></span><span class="position-absolute top-50 search-close translate-middle-y"><i class="bx bx-x"></i></span></div><div class="d-flex justify-content-between mb-3"><span>Site conducted</span><a role="button" class="text-primary">+ Responses</a></div><div class="d-flex justify-content-between mb-1"><span><span class="info">Safe</span><span class="risk">At Risk</span><span class="na">N/A</span></span><span><i class="bx bx-pencil" role="button"></i></span></div><div class="d-flex justify-content-between mb-1"><span><span class="info">Safe</span><span class="risk">At Risk</span><span class="na">N/A</span></span><span><i class="bx bx-pencil" role="button"></i></span></div><div class="d-flex justify-content-between mb-1"><span><span class="info">Safe</span><span class="risk">At Risk</span><span class="na">N/A</span></span><span><i class="bx bx-pencil" role="button"></i></span></div><div class="d-flex justify-content-between mb-1"><span><span class="info">Safe</span><span class="risk">At Risk</span><span class="na">N/A</span></span><span><i class="bx bx-pencil" role="button"></i></span></div><div class="d-flex justify-content-between mb-1"><span><span class="info">Safe</span><span class="risk">At Risk</span><span class="na">N/A</span></span><span><i class="bx bx-pencil" role="button"></i></span></div></div></div></div></div></td></tr>'
    );
  });
  $("body").on("click", ".delete", function(e) {
    $(".next-referral").last().remove();
  });
});

</script>
   