<div class="modal fade" id="addcompanydetails1" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Responsibility Name</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                         <form></form>
                        <form method="post" action="<?php echo e(route('add_authority')); ?>">
                            <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="mb-12 col-md-12">
                            <label class="form-label"> Responsibility Name:</label>
                            <input type="text" class="form-control"  name="name" placeholder="">
                            <?php if($errors->has('name')): ?>
    <div class="error"><?php echo e($errors->first('name')); ?></div>
<?php endif; ?>
                        </div>
                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary">Add  Details</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div><?php /**PATH /var/www/vhosts/efsms.in/httpdocs/admin/resources/views/admin/popups/Authority.blade.php ENDPATH**/ ?>