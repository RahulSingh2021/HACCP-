<!doctype html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title', 'Student'); ?></title>
    
    <?php echo $__env->make('StudentDashboard.layouts.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('StudentDashboard.layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    
    <?php echo $__env->make('StudentDashboard.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="userprofilemain">
            
            <?php echo $__env->make('StudentDashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/StudentDashboard/top.blade.php ENDPATH**/ ?>