<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use DB,Helper;
use Illuminate\Support\Facades\Session;

use Illuminate\Routing\Controller as BaseController;

class InspectionController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;


 


    public function index(Request $request) {
        

if(!empty(Session::get('unit_id'))  ){
$login_user=  Session::get('unit_id');
}
else{
$login_user=  Auth::user()->id;   
}

		  $s_date = $_GET['s_date'] ?? '';
		  $e_date = $_GET['e_date'] ?? '';
		  $sublocation = $_GET['sublocation']  ?? '';
		  $location =$_GET['location']  ?? '';
		  $concern = $_GET['concern'] ?? '';
		  $subconcern = $_GET['subconcern'] ?? '';
		   $responsibilitys = $_GET['responsibilitys'] ?? '';
		   $status = $_GET['status'] ?? '';
		   $entries = $_GET['entries'] ?? '';
$responsibility = DB::table('authority')->where('unit_id',$login_user)->get();
$locations = DB::table('locations')->where('created_by',$login_user)->whereNull('parent')->get();
$concern_list = DB::table('tbl_concern')->where('Responsibility', 'like', '%'.$responsibilitys.'%')->where('created_by',$login_user)->whereNull('parent')->get();

if(!empty($concern)){
    
    
   if(!empty($responsibilitys)){
 $subconcern_list = DB::table('tbl_concern')->where('Responsibility', 'like', '%'.$responsibilitys.'%')->where('parent',$concern)->get();
  
   }
else{
  $subconcern_list = DB::table('tbl_concern')->where('parent',$concern)->get();
   
}
}
else{
    
 $subconcern_list = DB::table('tbl_concern')->where('parent',$concern)->get();
   
}

    if(!empty(Session::get('unit_id'))  ){
    $unit_id =Session::get('unit_id');
    }
    else{
    
    $unit_id =Auth::user()->id;
    
    }
    



    		$inspection_list = DB::table('inspection');
    		
    			         if(!empty($location)  ){
              $inspection_list =  $inspection_list->where('location', $location);  
          }
          
          		         if(!empty($status)  ){
              $inspection_list =  $inspection_list->where('select_action', $status);  
          }
          
          			         if(!empty($responsibilitys)){
          			
              $inspection_list =  $inspection_list->where('responsibility', $responsibilitys);  
          }
          
          			         if(!empty($sublocation)  ){
              $inspection_list =  $inspection_list->where('sublocation', $sublocation);  
          }
          
          			         if(!empty($concern)  ){
              $inspection_list =  $inspection_list->where('concern', $concern);  
          }
          
          			         if(!empty($subconcern)  ){
              $inspection_list =  $inspection_list->where('subconcern', $subconcern);  
          }
    		
    			         if(!empty($s_date && $e_date)  ){
              $inspection_list =  $inspection_list->whereDate('created_at', '>=', $s_date)->whereDate('created_at', '<=', $e_date);  
          }
          
          
        
        			         if(!empty($entries)  ){
        			             
        			             if($entries=="All"){
        			                 
        			              $inspection_list = $inspection_list->where('unit_id',$unit_id)->orderBy('id', 'DESC')->paginate(350);
   
        			             }
        			             else{
        			                 
        			              $inspection_list = $inspection_list->where('unit_id',$unit_id)->orderBy('id', 'DESC')->paginate($entries);
   
        			             }
          }
          else{
              $inspection_list = $inspection_list->where('unit_id',$unit_id)->orderBy('id', 'DESC')->paginate(9);
          }
          
          
          $sub_location = DB::table('locations')->where('parent', $location)->get();
          
          $url = url()->full();


    		$lastinspection = DB::table('inspection')->where('unit_id',$unit_id)->orderBy('id', 'DESC')->first();
    		$inspection_status = DB::table('inspection_status')->where('unit_id', $unit_id)->first();

    		
    
return view('admin.inspection.list',compact('responsibility','locations','inspection_list','concern_list','subconcern_list','sub_location','url','lastinspection','inspection_status'));
}

   public function dashboard(Request $request) {
        
                if(!empty(Session::get('unit_id'))  ){
$login_user=  Session::get('unit_id');
}
else{
$login_user=  Auth::user()->id;   
}

		  $s_date = $_GET['s_date'] ?? '';
		  $e_date = $_GET['e_date'] ?? '';
		   $responsibilitys = $_GET['responsibilitys'] ?? '';
		   
		   if($responsibilitys==2){
		     $responsibility = DB::table('locations')->where('created_by',$login_user)->whereNull('parent')->get();
		     
		     $responsibilityvalue="2";
   $data=[];
   $locationdata=[];
		   }
		   else{
		     $responsibility = DB::table('authority')->where('unit_id',$login_user)->get();
		     $responsibilityvalue="1";
		     
		     $data=[];
		     $data1=[];
		       foreach($responsibility as $responsibilitys){
		         $data1['name']  =$responsibilitys->name ??'';
		         
		         
                        $dataarray1=[];
                        $dataarray=[];
                        if(!empty($responsibilitys->location))
                        
                        {
                        $authorityslocation = json_decode($responsibilitys->location) ;
                        
                        $first = 0;
                        $first1 = 0;
                        foreach($authorityslocation as $authorityslocations){
                                $first+= Helper::opencase($authorityslocations ?? '',$responsibilitys->id ?? '',$responsibilityvalue,$s_date,$e_date);
                                $first1+= Helper::closecase($authorityslocations ?? '',$responsibilitys->id ?? '',$responsibilityvalue,$s_date,$e_date);
                                $dataarray['subname']= DB::table('locations')->where('id',$authorityslocations)->value('name');
                                $dataarray['opencase']= Helper::opencase($authorityslocations ?? '',$responsibilitys->id ?? '',$responsibilityvalue,$s_date,$e_date);
                                $dataarray['closecase']= Helper::closecase($authorityslocations ?? '',$responsibilitys->id ?? '',$responsibilityvalue,$s_date,$e_date);
                        array_push($data1,$dataarray);
                        }
                        
                                   $data1['first']= $first;
                    
                    $data1['first1']= $first1;
                    $data1['total']= $first+$first1;
                        
                        }
                        else{
                        
                        $dataarray=[];
                        array_push($data1,$dataarray);
                                   $data1['first']= 0;
                    
                    $data1['first1']= 0;
                    $data1['total']= 0;
                        }
                        
         
		          array_push($data,$data1);
		           
		       }
		       
		       
		       
		       		     $locationresponsibility = DB::table('locations')->where('created_by',$login_user)->whereNull('parent')->get();

		       
		       	     $locationdata=[];
		     $locationdata1=[];
		       foreach($locationresponsibility as $responsibilitys){
		         $locationdata1['name']  =$responsibilitys->name ??'';
		         
		         
                        $dataarray1=[];
                        $dataarray=[];
                   
                        $authorityslocation = DB::table('locations')->where('parent',$responsibilitys->id ?? '')->get();
                        
                        $first = 0;
                        $first1 = 0;
                        foreach($authorityslocation as $authorityslocations){
                            $responsibilityvalue1="2";
                                $first+= Helper::opencase($authorityslocations->id ?? '',$responsibilitys->id ?? '',$responsibilityvalue1,$s_date,$e_date);
                                $first1+= Helper::closecase($authorityslocations->id ?? '',$responsibilitys->id ?? '',$responsibilityvalue1,$s_date,$e_date);
                                $dataarray['subname']= $authorityslocations->name ?? '';
                                $dataarray['opencase']= Helper::opencase($authorityslocations->id ?? '',$responsibilitys->id ?? '',$responsibilityvalue1,$s_date,$e_date);
                                $dataarray['closecase']= Helper::closecase($authorityslocations->id ?? '',$responsibilitys->id ?? '',$responsibilityvalue1,$s_date,$e_date);
                        array_push($locationdata1,$dataarray);
                        }
                        
                                   $locationdata1['first']= $first;
                    $locationdata1['first1']= $first1;
                    $locationdata1['total']= $first+$first1;
		          array_push($locationdata,$locationdata1);
		           
		       }

		   }
		   
		   		       		     $concenlist = DB::table('tbl_concern')->where('created_by',$login_user)->whereNull('parent')->get();
		   		       		  
		   		       		     

		   		       		     

		       
		       	     $concerndata=[];
		     $concerndata1=[];
		       foreach($locationresponsibility as $responsibilitys){
		         $concerndata1['name']  =$responsibilitys->name ??'';
		         
		         
                        $dataarray1=[];
                        $dataarray=[];
                   
                        $authorityslocation = DB::table('tbl_concern')->where('parent',$responsibilitys->id ?? '')->get();
                        
                        $first = 0;
                        $first1 = 0;
                        foreach($authorityslocation as $authorityslocations){
                            $responsibilityvalue1="2";
                                $dataarray['subname']= $authorityslocations->name ?? '';
                                $dataarray['opencase']= 1;
                                $dataarray['closecase']= 3;
                        array_push($locationdata1,$dataarray);
                        }
                        
                                   $concerndata1['first']= $first;
                    $concerndata1['first1']= $first1;
                    $concerndata1['total']= $first+$first1;
		          array_push($concerndata,$concerndata1);
		           
		       }
		   

		   
		   
		   
		   
		   $concern_list = DB::table('tbl_concern')
->join('inspection', 'tbl_concern.id', '=', 'inspection.subconcern')
->select('tbl_concern.id as id', 'tbl_concern.name as title', DB::raw("count(inspection.subconcern) as count"))->orderBy('count', 'DESC')
->groupBy('tbl_concern.id')->where('tbl_concern.created_by',$login_user)->whereNotNull('tbl_concern.parent')
->get();
		   
		   
		   
		   		   $ssubconcern_list = DB::table('tbl_concern')
->join('inspection', 'tbl_concern.id', '=', 'inspection.subconcern')
->select('tbl_concern.id as id', 'tbl_concern.name as title', DB::raw("count(inspection.subconcern) as count"))->orderBy('count', 'DESC')
->groupBy('tbl_concern.id')->where('tbl_concern.created_by',$login_user)->whereNotNull('tbl_concern.parent')->take(5)->get();



		   $concern_itemlist = DB::table('tbl_concern')
->join('inspection', 'tbl_concern.id', '=', 'inspection.concern')
->select('tbl_concern.id as id', 'tbl_concern.name as title', DB::raw("count(inspection.concern) as count"))->orderBy('count', 'DESC')
->groupBy('tbl_concern.id')->where('tbl_concern.created_by',$login_user)
->get();




		       
		       	     $subconcern_list11=[];
		     $subconcern_list1=[];
		       foreach($ssubconcern_list as $responsibilitys){
		           
		  
                        $dataarray1=[];
                        $dataarray=[];
                        
     
                        $authorityslocation = DB::table('tbl_concern')->where('id',$responsibilitys->id ?? '')->first();
                        
   
                            if(!empty($authorityslocation->Responsibility)){
                            
                            $Responsibility = json_decode($authorityslocation->Responsibility);
                            foreach($Responsibility as $Responsibilitys){
                            $dataarray['subname']= DB::table('authority')->where('id',$Responsibilitys)->value('name');
                            
                            $responsibilitycount = DB::table('inspection')->where('responsibility',$Responsibilitys)->count();
                            $dataarray['total']= $responsibilitycount;
                            array_push($subconcern_list1,$dataarray);
                            }
                            }
                        
                        		          array_push($subconcern_list11,$subconcern_list1);
		           
		       }
		       
		       //$subconcern_list11 =$subconcern_list11[0];
// echo "<pre>";
// print_r($subconcern_list11);
// die();


$responsibilityList = DB::table('authority')->where('unit_id',$login_user)->get();


		   		       		     $concenvaluelistdata = DB::table('tbl_concern')->where('created_by',$login_user)->whereNull('parent')->get();

return view('admin.inspection.dashboard',compact('responsibilityList','concern_itemlist','concenvaluelistdata','responsibility','responsibilityvalue','login_user','s_date','e_date','data','locationdata','concern_list','concerndata','ssubconcern_list','subconcern_list11'));
}
    public function store(Request $request) {
    if(!empty(Session::get('unit_id'))  ){
    $unit_id =Session::get('unit_id');
    }
    else{
    
    $unit_id =Auth::user()->id;
    
    }
    $dataArr['responsibility']=$request->responsibility;
    $dataArr['unit_id']=$unit_id;
    $dataArr['location']=$request->location;
    $dataArr['sublocation']=$request->sublocation;
    $dataArr['concern']=$request->concern;
    $dataArr['subconcern']=$request->subconcern;
    $dataArr['comments']=$request->comments;
    if($request->file('image')){
    $file= $request->file('image');
    $filename= date('YmdHi').$file->getClientOriginalName();
    $file-> move(public_path('inspection'), $filename);
    $dataArr['image']= $filename;
    }
    

    
    if($request->edit_id){
        
     
    $dataArr['updated_by']=$unit_id;
    DB::table('inspection')->where('id',$request->edit_id)->update($dataArr);
    return redirect($request->url);
    
    if(!empty($request->page_number)){
        
        return redirect($request->url);
        
        
       //   return redirect('https://efsm.safefoodmitra.com/admin/public/index.php/inspection/list?page='.$request->page_number);
  
    }
    else{
     return redirect()->route('inspection_list')->with('status', 'Add Successfully');   
    }

    	//	

    }
    
    else{
    DB::table('inspection')->insert($dataArr);
    		return redirect()->route('inspection_list')->with('status', 'Add Successfully');

    }
         
}

									    public function inspection_edit(Request $request) {
							
			
							        if($request->file('image1')){
    $file= $request->file('image1');
    $filename= date('YmdHi').$file->getClientOriginalName();
    $file-> move(public_path('inspection'), $filename);
    $dataArr['image1']= $filename;
    }		        
									        
									            if(!empty(Session::get('unit_id'))  ){
    $unit_id =Session::get('unit_id');
    }
    else{
    
    $unit_id =Auth::user()->id;
    
    }
    
    
					    $dataArr['updated_by']=$unit_id;
    $dataArr['select_action']=$request->select_action;
    $dataArr['time_line']=$request->time_line;
    $dataArr['price']=$request->price;
    $dataArr['closure_comments']=$request->closure_comments;
    DB::table('inspection')->where('id',$request->edit_id1)->update($dataArr);
    


          return redirect($request->url);

    
    
    		return redirect()->route('inspection_list')->with('status', 'Add Successfully');


}
	


									    public function delete($id) {
								    DB::table("inspection")->where('id',$id)->delete();  
		return redirect()->route('inspection_list')->with('status', 'Deleted successfully');

}

	
	
										    public function exportdata() {
										      return view('admin.inspection.export');

}

  public function inspectionsavestatus(Request $request)
    {
        // Determine the unit_id from session or auth user
        $unit_id = Session::get('unit_id', Auth::user()->id);

        $type = $request->input('type');
        $value = $request->input('value');

        // Prepare the data to be updated or inserted
        $data = [$type => $value];

        // Check if the record exists
        $inspection = DB::table('inspection_status')->where('unit_id', $unit_id)->first();
        if ($inspection) {
            // Update the existing record
            DB::table('inspection_status')->where('unit_id', $unit_id)->update($data);
        } else {
            // Insert a new record
            $data['unit_id'] = $unit_id;
            DB::table('inspection_status')->insert($data);
        }

        return response()->json(['success' => true, 'message' => 'Status updated successfully']);
    }
	
	
}
