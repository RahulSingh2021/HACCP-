
<!-- Sign in message -->

<?php if(\Session::has('login_error')): ?>

<div class="alert alert-danger">
<ul>
   <li><?php echo \Session::get('login_error'); ?></li>
</ul>
</div>
 <?php endif; ?>

<?php if(session()->has('login_message')): ?>
<div class="alert alert-success  alert-block">

<?php echo e(Session::get('login_message')); ?>

</div>
<?php endif; ?>


<?php if(session()->has('login_both_invalid')): ?>


<div class="alert alert-danger  alert-block">

<?php echo e(Session::get('login_both_invalid')); ?>

</div>
<?php endif; ?>


<!-- Sign up Error -->


 <?php if(\Session::has('register_error')): ?>

<div class="alert alert-danger">
<ul>
   <li><?php echo \Session::get('register_error'); ?></li>
</ul>
</div>
 <?php endif; ?>


<!-- Forgot password  -->
<?php if(\Session::has('forgot_error')): ?>

<div class="alert alert-danger">
<ul>
   <li><?php echo \Session::get('forgot_error'); ?></li>
</ul>
</div>
 <?php endif; ?>

<?php if(session()->has('forgot_message')): ?>
<div class="alert alert-success  alert-block">

<?php echo e(Session::get('forgot_message')); ?>

</div>
<?php endif; ?>


<?php if(session()->has('success')): ?>
<div class="alert alert-success  alert-block">

<?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>



<?php if(session()->has('error')): ?>


<div class="alert alert-danger  alert-block">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
   <span aria-hidden="true">&times;</span>
</button>
<?php echo e(Session::get('error')); ?>

</div>
<?php endif; ?>




<?php /**PATH /var/www/vhosts/efsms.in/httpdocs/admin/resources/views/admin/includes/flashMessage.blade.php ENDPATH**/ ?>