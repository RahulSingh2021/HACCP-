<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use DB;
use Helper;
use Illuminate\Support\Facades\Session;


use Illuminate\Routing\Controller as BaseController;

class TemplatesController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;




    public function index(Request $request) {
        
  $list = DB::table('templates')
            ->whereNotNull('template_name')
            ->get();
return view('admin.training.list',compact('list'));
}
   
   
       public function store(Request $request) {
        
        
        $data['template_name']="";
$insert_id = DB::table('templates')->insertGetId($data);


            
  return redirect()->route('templates_update', ['id' => $insert_id]);

}


       public function updateTemplate(Request $request,$id) {
           
   $template_id = $id;
  $optionList = DB::table('template_options')->get();
  $multipleoptionList = DB::table('multiple_choice_response')
                        ->groupBy('unique_id')
                        ->get();
                        
                         $template_details = DB::table('templates')->where('id',$id)->first();
                         
                         
return view('admin.training.add',compact('optionList','multipleoptionList','template_id','template_details'));
}



 public function uploadImage(Request $request)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);


 
    
        if ($request->file('image')) {
            
            
            
                $file= $request->file('image');
    $filename= date('YmdHi').$file->getClientOriginalName();
    $file-> move(public_path('template'), $filename);
    $dataArr['image']= $filename;
    DB::table('templates')->where('id',$request->template_id)->update($dataArr);
            return response()->json(['success' => true, 'image' => $filename]);
        }

        return response()->json(['success' => false, 'message' => 'Image upload failed']);
    }
    
    
    
public function updatetemplatemeta(Request $request)
{
    
$id =$request->id;
    $template = DB::table('templates')->where('id',$id)->first();

    if ($template) {
        $templates['template_name'] = $request->input('templatename');
        $templates['template_desc'] = $request->input('templatedesc');
        // Assuming you might also update template_image if required
        // $template->template_image = $request->input('templateimage');

         DB::table('templates')->where('id',$id)->update($templates);

        return response()->json(['success' => true]);
    }

    return response()->json(['success' => false], 404);
}
   
   
   
   public function addquestion(Request $request)
{

    $id =$request->id;
    $templates['template_id'] = $id;
    DB::table('template_question')->insert($templates);
    $insert_id = DB::getPdo()->lastInsertId();
    return response()->json(['success' => true,'id' => $insert_id]);
}
  
  
  
     
   public function addpage(Request $request)
{

    $id =$request->id;
    $templates['template_id'] = $id;
    DB::table('template_page')->insert($templates);
    $insert_id = DB::getPdo()->lastInsertId();
    return response()->json(['success' => true,'id' => $insert_id]);
}



  
      
public function updatequestion(Request $request)
{
    
$id =$request->id;
    $template = DB::table('template_question')->where('id',$id)->first();

    if ($template) {
        $templates['question'] = $request->input('question');
         DB::table('template_question')->where('id',$id)->update($templates);
        return response()->json(['success' => true]);
    }

    return response()->json(['success' => false], 404);
}



public function updatepage(Request $request)
{
    
$id =$request->id;
    $template = DB::table('template_page')->where('id',$id)->first();

    if ($template) {
        $templates['name'] = $request->input('name');
         DB::table('template_page')->where('id',$id)->update($templates);
        return response()->json(['success' => true]);
    }

    return response()->json(['success' => false], 404);
}




   public function addquestionsection(Request $request)
{

$id =$request->id;
   $question_id = DB::table('template_question')
                ->where('template_id', $id)
                ->orderBy('id', 'desc')
                ->value('id');
    $id =$request->id;
    $templates['template_id'] = $id;
    $templates['question_id'] = $question_id;
    DB::table('template_question_section')->insert($templates);
    $insert_id = DB::getPdo()->lastInsertId();
    return response()->json(['success' => true,'id' => $insert_id,'question_id' => $id]);
}
   
   
   
   public function updatequestionsection(Request $request)
{
    
$id =$request->id;
    $template = DB::table('template_question_section')->where('id',$id)->first();

    if ($template) {
        $templates['section_name'] = $request->input('question');
        $templates['section_description'] = $request->input('sectionname');
         DB::table('template_question_section')->where('id',$id)->update($templates);
        return response()->json(['success' => true]);
    }

    return response()->json(['success' => false], 404);
}


   
    
	

	
			    public function facility_tool_update(Request $request) {

    	 $dataArr['name']=$request->name;
			$dataArr['purpose']=$request->purpose;
			$dataArr['target_surface']=$request->target_surface;

					
						      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
					
					
					          DB::table('toolselection')->where('id',$request->tool_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	    public function update(Request $request) {

    	    	 $dataArr['name']=$request->name;
		$dataArr['type']=$request->type;
		$dataArr['brand']=$request->brand;
		$dataArr['capacity_range']=$request->capacity_range;
		$dataArr['capacity_utility_range']=$request->capacity_utility_range;
		$dataArr['corporate_id']=$request->corporate_id;
		$dataArr['regional_id']=$request->regional_id;
		$dataArr['hotel_name']=$request->hotel_name;
		$dataArr['department']=$request->department;
		$dataArr['location_id']=$request->location_id;
		$dataArr['sub_location']=$request->sub_location;

  
		
		
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
			
		
            DB::table('facility_equipment')->where('id',$request->equipments_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	
	
		    public function destory($id) {
    	$retData=DB::table('facility_equipment')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}	
	
	
	 
		    public function template_delete($id) {
    	$retData=DB::table('templates')->where('id',$id)->delete();
return redirect()->route('templates_list')->with('success', 'Delete Successfully');
}	
	
	
			    public function template_details($id) {
			        
			          $template_id = $id;
  $optionList = DB::table('template_options')->get();
  $template_pages = DB::table('template_page')->where('template_id',$id)->get();
  $firsttemplate_id = DB::table('template_page')->where('template_id',$id)->first();
    $template_pages_questionlist = DB::table('template_question')->where('template_id',$template_id)->get();
  
  
  
  $multipleoptionList = DB::table('multiple_choice_response')
                        ->groupBy('unique_id')
                        ->get();
                        
                         $template_details = DB::table('templates')->where('id',$id)->first();
                         
                         
return view('admin.training.template_details',compact('optionList','multipleoptionList','template_id','template_details','template_pages','template_pages_questionlist'));
}
}
