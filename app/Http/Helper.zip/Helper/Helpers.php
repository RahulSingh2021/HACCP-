<?php
if(!function_exists('numberToCurrency')){
	function numberToCurrency($number, $Decimal=0, $Seprator=','){
		$explrestunits = "" ;
		$PreFix=''; 
		if($number<0)$PreFix='-';
		$number = explode('.', abs(round($number,$Decimal)));
		$num = $number[0];
		if(strlen($num)>3){
			$lastthree = substr($num, strlen($num)-3, strlen($num));
			$restunits = substr($num, 0, strlen($num)-3); 
			$restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; 
			$expunit = str_split($restunits, 2);
			for($i=0; $i<sizeof($expunit); $i++){
				if($i==0){
					$explrestunits .= (int)$expunit[$i].$Seprator; 
				}else{
					$explrestunits .= $expunit[$i].$Seprator;
				}
			}
			$thecash = $explrestunits.$lastthree;
		}else{
			$thecash = $num;
		}
		if($Decimal>0) {
			if(isset($number[1]) && strlen($number[1]) == 1) {
				return $PreFix.$thecash . '.' . $number[1] . '0';
			} else if(isset($number[1]) && strlen($number[1]) == 2){
				return $PreFix.$thecash . '.' . $number[1];
			} else {
				return $PreFix.$thecash . '.00';
			}
		} else {
			return $PreFix.$thecash;
		}
	}
}
if(!function_exists('show')){
	function show($arr){
		echo '<pre>';
		print_r($arr);
		echo '</pre>';
	}
}
if(!function_exists('convertDate')){
	function convertDate($MysqlDate){
		if($MysqlDate){				
			return date('d/m/Y', strtotime($MysqlDate)); 
		}else{
			return '-'; 
		}
	}
}
if(!function_exists('getCompanyList')){
	function getCompanyList($compid=0){
		if($compid>0){
			$compList=DB::table('companies')->where('id',$compid)->first();
		}else{
			$compList=DB::table('companies')->get();
		}
		return $compList;
	}
}

if(!function_exists('GetServiceName')){
	function GetServiceName($serviceid){
		$serviceList=DB::table('services')->select('service_name')->where('id',$serviceid)->first();
		return $serviceList->service_name;
	}
}

if(!function_exists('GetUserRoleName')){
	function GetUserRoleName($roleid){
		$rolename=DB::table('user_roles')->select('user_role')->where('id',$roleid)->first();
		return $rolename->user_role;
	}
}
if(!function_exists('GenTicketCode')){
	function GenTicketCode($compid){
		$compcode=DB::table('companies')->select('comp_code')->where('id',$compid)->first();
		$maxtid=DB::table('tickets')->select('id')->where('companies_id',$compid)->orderBy('id', 'DESC')->first();
		$maxRet=1;
		if($maxtid){
			$maxRet=$maxtid->id+1;
		}
		return $compcode->comp_code.'/ST/'.str_pad(($maxRet), 5, "0", STR_PAD_LEFT);
	}
}

if(!function_exists('GenEnggCode')){
	function GenEnggCode($compid){
		$compcode=DB::table('companies')->select('comp_code')->where('id',$compid)->first();
		$maxeid=DB::table('engineers')->select('id')->where('companies_id',$compid)->orderBy('id', 'DESC')->first();
		return $compcode->comp_code.'/EMP/'.str_pad(($maxeid->id+1), 4, "0", STR_PAD_LEFT);
	}
}
if(!function_exists('getUsermenu')){
	function getUsermenu($routeName=''){
//		if(Auth::user()->userroles_id==0){
			$userMenus=DB::table('menus')->orderBy('menucat')->orderBy('order_by')->get();
			return $userMenus;
/*		}else{			
			$userMenus=DB::table('menus')->orderBy('menucat')->orderBy('order_by')->get();
			if($userRoles && $userRoles->menuids!=''){
				$accessArr=explode(',',$userRoles->menuids);
				if($routeName){
					$userMenus=DB::table('menus')->whereIn('id',$accessArr)->where('routename',$routeName)->orderBy('order_by')->get();
					//dd('==================');
				}else{
					$userMenus=DB::table('menus')->whereIn('id',$accessArr)->orderBy('order_by')->get();
				}
				return $userMenus;
			}else{
				return '';
			}	
		}*/
		
	}
}
if(!function_exists('getStateList')){
	function getStateList(){
		$stateList=DB::table('states')->where('is_active','1')->orderBy('state_name')->get();
		return $stateList;
	}
}
if(!function_exists('getBankList')){
	function getBankList(){
		$bankList=DB::table('banks')->where('is_active','1')->orderBy('bank_name')->get();
		return $bankList;
	}
}
if(!function_exists('getFobUnitList')){
	function getFobUnitList($userid=''){
        if($userid){
            $fobunitList=DB::table('fobunits')->where('users_id', $userid)->orderBy('unit_name')->get();
        }else{
            $fobunitList=DB::table('fobunits')->orderBy('unit_name')->get();
        }
		
		return $fobunitList;
	}
}
if(!function_exists('sendNotification')){
	function sendNotification($fbtoken, $title, $message, $activity){
        $notification = [
            "description"           =>  $message,
            "title"         =>  ucwords($title),
            "type"          =>  $activity,
            "date"          =>  date('d/m/Y'),
            'vibrate'   => 1,
            'sound'     => 1
        ];
        $fcmNotification = [
            'to'              =>  $fbtoken, 
            'data'              =>  $notification,
            //"condition"=> "('allmsg' in topics)"
        ];

        $headers = [
            'Authorization: key=AAAAQL0tOkE:APA91bEDaFklyEuugIjh7KhK5zNEev9w7eOau82zBpsephkDeDdTY7fNmC9Z-D4g7Gu1I3RaZuLHwCSWa5G5P96UqSu3OFjAinPpGpN_emu--6T9x9ss1tACHXJrDrPTim0usPvVuAj2',                            
            'Content-Type: application/json'
        ];
        $fcmUrl = 'https://fcm.googleapis.com/fcm/send';
/*        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$fcmUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
        $result = curl_exec($ch);
        curl_close($ch);*/
    }
}

if(!function_exists('getselects')){
	function getselects($table, $unit=0, $parent=-1){
        $user = Auth::user();
        $dataList=[];
        if($table=='fobunits'){
            if(Auth::user()->userroles_id==3){
                $dataList=DB::table('fobunits')
                ->select('fobunits.id', 'fobunits.unit_name', 'fobtypes.fobtype')
                ->leftJoin('fobtypes', 'fobtypes.id', 'fobunits.fobtypes_id')
                ->leftJoin('userfobunits', 'userfobunits.fobunits_id', 'fobunits.id')
                ->where('userfobunits.users_id',Auth::user()->id)
                ->orderBy('fobtypes.fobtype')
                ->orderBy('fobunits.unit_name')
                ->get();
            }else{
                $dataList=DB::table('fobunits')
                ->select('fobunits.id', 'fobunits.unit_name', 'fobtypes.fobtype')
                ->leftJoin('fobtypes', 'fobtypes.id', 'fobunits.fobtypes_id')
                ->where('fobunits.users_id',Auth::user()->id)
                ->orderBy('fobtypes.fobtype')
                ->orderBy('fobunits.unit_name')
                ->get();
            }
        }elseif($table=='zones'){
            $dataList=DB::table('zones')
            ->select('id', 'zone_name')
            ->where('fobunits_id', $unit)
            ->orderBy('zone_name')
            ->get();
        }elseif($table=='concernareas'){
            $dataList=DB::table('concernareas')
            ->select('id', 'area_name')
            ->orderBy('area_name')
            ->get();
        }elseif($table=='locations'){
            if($parent==0){
                $locList=DB::table('locations')
                ->select('id', 'loc_name')
                ->where('fobunits_id', $unit)
                ->where('parent_id', 0)
                ->orderBy('loc_name')
                ->get();
                foreach ($locList as $parLoc){
                    $dataList[]=['id'=>$parLoc->id, 'loc_name'=>$parLoc->loc_name, 'parent_id'=>0, 'parent_name'=>''];
                }
            }elseif($parent>0){
                $locList=DB::table('locations')
                ->select('id', 'loc_name')
                ->where('fobunits_id', $unit)
                ->where('id', $parent)
                ->orderBy('loc_name')
                ->get();
                foreach ($locList as $parLoc){
                    $sublocList=DB::table('locations')
                    ->select('id', 'loc_name')
                    ->where('fobunits_id', $unit)
                    ->where('parent_id', $parLoc->id)
                    ->orderBy('loc_name')
                    ->get();
                    foreach ($sublocList as $subloc){
                        $dataList[]=['id'=>$subloc->id, 'loc_name'=>$subloc->loc_name, 'parent_id'=>$parLoc->id, 'parent_name'=>$parLoc->loc_name];
                    }
                }
            }else{
                $locList=DB::table('locations')
                ->select('id', 'loc_name')
                ->where('fobunits_id', $unit)
                ->where('parent_id', 0)
                ->orderBy('loc_name')
                ->get();
                foreach ($locList as $parLoc){
                    $dataList[]=['id'=>$parLoc->id, 'loc_name'=>$parLoc->loc_name, 'parent_id'=>0, 'parent_name'=>''];
                    $sublocList=DB::table('locations')
                    ->select('id', 'loc_name')
                    ->where('fobunits_id', $unit)
                    ->where('parent_id', $parLoc->id)
                    ->orderBy('loc_name')
                    ->get();
                    foreach ($sublocList as $subloc){
                        $dataList[]=['id'=>$subloc->id, 'loc_name'=>$subloc->loc_name, 'parent_id'=>$parLoc->id, 'parent_name'=>$parLoc->loc_name];
                    }
                }
            }
        }elseif($table=='departments'){
            if($parent==0){
                $deptList=DB::table('departments')
                ->select('id', 'dept_name')
                ->where('fobunits_id', $unit)
                ->where('parent_id', 0)
                ->orderBy('dept_name')
                ->get();
                foreach ($deptList as $parDept){
                    $dataList[]=['id'=>$parDept->id, 'dept_name'=>$parDept->dept_name, 'parent_id'=>0, 'parent_name'=>''];
                }
            }else{
                $deptList=DB::table('departments')
                ->select('id', 'dept_name')
                ->where('fobunits_id', $unit)
                ->where('parent_id', 0)
                ->orderBy('dept_name')
                ->get();
                foreach ($deptList as $parDept){
                    $dataList[]=['id'=>$parDept->id, 'dept_name'=>$parDept->dept_name, 'parent_id'=>0, 'parent_name'=>''];
                    $subdeptList=DB::table('departments')
                    ->select('id', 'dept_name')
                    ->where('fobunits_id', $unit)
                    ->where('parent_id', $parDept->id)
                    ->orderBy('dept_name')
                    ->get();
                    foreach ($subdeptList as $subdept){
                        $dataList[]=['id'=>$subdept->id, 'dept_name'=>$subdept->dept_name, 'parent_id'=>$parDept->id, 'parent_name'=>$parDept->dept_name];
                    }
                }
            }
        }elseif($table=='equipments'){
            $dataList=DB::table('equipments')
            ->select('id', 'equip_name')
            ->where('fobunits_id', $unit)
            ->orderBy('equip_name')
            ->get();
        }elseif($table=='records'){
            $recList=DB::table('records')
            ->select('records.id', 'records.record_name', 'departments.dept_name')
            ->leftJoin('departments', 'departments.id', 'records.departments_id')
            ->where('records.fobunits_id', $unit)
            ->orderBy('dept_name')
            ->orderBy('record_name')
            ->get();
            $deptname='';
            foreach($recList as $recs){
                if($deptname!=$recs->dept_name){
                    $dataList[]=["id"=>0, "record_name"=>"", "dept_name"=>$recs->dept_name];
                    $deptname=$recs->dept_name;
                }
                $dataList[]=["id"=>$recs->id, "record_name"=>$recs->record_name, "dept_name"=>$recs->dept_name];
            }
        }elseif($table=='responsibilities'){
            $recList=DB::table('responsibilities')
            ->select('responsibilities.id', 'responsibilities.users_id', 'departments.dept_name', 'users.first_name', 'users.last_name')
            ->join('departments', 'departments.id', 'responsibilities.departments_id')
            ->leftJoin('users', 'users.id', 'responsibilities.users_id')            
            ->where('departments.fobunits_id', $unit)
            ->orderBy('dept_name')
            ->orderBy('users_id')
            ->get();
            $deptname='';
            foreach($recList as $recs){
                if($deptname!=$recs->dept_name){
                    $dataList[]=["id"=>0, "record_name"=>"", "dept_name"=>$recs->dept_name];
                    $deptname=$recs->dept_name;
                }
                $dataList[]=["id"=>$recs->id, "record_name"=>$recs->first_name." ".$recs->last_name, "dept_name"=>$recs->dept_name];
            }
        }elseif($table=='appadmin'){
            $dataList=DB::table('users')
            ->select('users.*')
            ->selectRaw('cusers.first_name AS cname, uusers.first_name AS uname, user_roles.user_role as user_role_name')
            ->leftJoin('user_roles', 'user_roles.id', 'users.userroles_id')
            ->leftJoin('users AS cusers', 'cusers.id', 'users.created_by')
            ->leftJoin('users AS uusers', 'uusers.id', 'users.updated_by')
            ->where('users.userroles_id',2)->get();
        }elseif($table=='appuser'){
            $dataList=DB::table('users')
            ->select('users.*')
            ->selectRaw('cusers.first_name AS cname, uusers.first_name AS uname, user_roles.user_role as user_role_name')
            ->leftJoin('user_roles', 'user_roles.id', 'users.userroles_id')
            ->leftJoin('users AS cusers', 'cusers.id', 'users.created_by')
            ->leftJoin('users AS uusers', 'uusers.id', 'users.updated_by')
            ->join('userfobunits', 'userfobunits.users_id', 'users.id')
            ->where('users.userroles_id',3)
            ->where('userfobunits.fobunits_id', $unit)
            //->where('users.parent_id',Auth::user()->id)
            ->groupBy('users.id')
            ->get();
        }else{
            $dataList=DB::table($table)->get();
        }
        return $dataList;
    }
}

if(!function_exists('getNewsViewsCount')){
    function getNewsViewsCount($id){
        return DB::table('news_views')->where('news_id',$id)->count();        
    }
}

if(!function_exists('getUsersList')){
    function getUsersList(){
        return DB::table('users')->where('userroles_id', '<>', 1)->orderByDesc('id')->get();        
    }
}

if(!function_exists('time_elapsed_string')){
    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }

    if(!function_exists('getCourseCategory')){
        function getCourseCategory(){
            return DB::table('course_categories')->where('status',1)->orderByDesc('id')->get();        
        }
    }

    if(!function_exists('getCourseTitle')){
        function getCourseTitle($id){
            return DB::table('course_titles')->where('course_categories_id', $id)->where('status',1)->orderByDesc('id')->get();        
        }
    }
}
