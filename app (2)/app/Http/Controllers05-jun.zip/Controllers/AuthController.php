<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;



use DB;
use Illuminate\Routing\Controller as BaseController;

class AuthController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;


    public function logout(Request $request) {
        
         Session::forget('unit_id');

  Auth::logout();
  return redirect('/login');
}



    public function switch_account(Request $request) {
         Session::forget('unit_id');
	return redirect()->back()->with('success', 'Successfully Changed');  
}

  public function login_user_set(Request $request) {
      
       $corporate_id = $request->corporate_id;
       $regional_id = $request->regional_id;
       $unit_id = $request->unit_id;
       
       
     

      
    //   if(!empty($unit_id)){
    //      $id = Auth::loginUsingId($unit_id);   
          
    //   }
      
    //     if(!empty($regional_id)){
          
    //      $id = Auth::loginUsingId($regional_id);   
    //   }
      
    //     if(!empty($corporate_id)){
          
    //       $id = Auth::loginUsingId($corporate_id); 
    //   }
      
      
      
      Session::put('unit_id', $unit_id);



return redirect()->intended('https://efsm.safefoodmitra.com/admin/public/index.php/users');

//return redirect()->route('dashboard');

      
  }

    public function index(Request $request) {
        
   
   
    $is_role = Auth::user()->is_role;
   
   
   if($is_role==0){
       
       $users = DB::table('users')->where('is_role', "2")->get();
              return view('admin.users.list',compact('users','is_role'));

   }
   
    if($is_role==2){
       
       
       $users = DB::table('users')->where('is_role', "1")->where('created_by', Auth::user()->id)->get();
       return view('admin.users.corporate_regionallist',compact('users','is_role'));

   }
   
       if($is_role==1){
       $users = DB::table('users')->where('is_role', "3")->where('created_by1', Auth::user()->id)->get();
              return view('admin.users.regional_units',compact('users','is_role'));
   }
   
          if($is_role==3){
       $users = DB::table('users')->where('is_role', "3")->where('created_by1', Auth::user()->id)->get();
              return view('admin.users.list',compact('users','is_role'));

   }
   
}
	
	
	    public function regionals($id) {
	        
	        $is_role = Auth::user()->is_role;
			
			$users = DB::table('users')->where('created_by', $id)->where('is_role', "1")->get();
return view('admin.users.regionals',compact('users','is_role'));
}
	
	
	    public function units($id,$type,$status) {
	 
	        
	        if($status=="pending"){
	            
	            
	            $unit_id = DB::table('tbl_documents_list')->pluck('unit_id');
	          
	            
	                        $is_role = Auth::user()->is_role;
	             
            if($is_role==2){
            
            if($type==1){
            $users = DB::table('users')->where('created_by1', $id)->whereNotIn('id', $unit_id)->where('is_role', "3")->get();
            
            
            }
            else{
            $users = DB::table('users')->where('created_by1', $id)->whereNotIn('id', $unit_id)->where('is_role', "3")->get();
            
            }
            }else{
            if($type==1){
            $users = DB::table('users')->where('created_by', $id)->whereNotIn('id', $unit_id)->where('is_role', "3")->get();
            }
            else{
            $users = DB::table('users')->where('created_by', $id)->whereNotIn('id', $unit_id)->where('is_role', "3")->get();
            
            }   
            }
	            
	        }else{
	            
	                    $is_role = Auth::user()->is_role;
            if($is_role==2){
            
            if($type==1){
            $users = DB::table('users')->where('created_by1', $id)->where('is_role', "3")->get();
            
            
            }
            else{
            $users = DB::table('users')->where('created_by1', $id)->where('is_role', "3")->get();
            
            }
            }else{
            if($type==1){
            $users = DB::table('users')->where('created_by', $id)->where('is_role', "3")->get();
            }
            else{
            $users = DB::table('users')->where('created_by', $id)->where('is_role', "3")->get();
            
            }   
            }    
	        }

return view('admin.users.units',compact('users','is_role'));
}
	
	

    public function index1(Request $request) {
return view('admin.users.list1');
}
    public function store(Request $request) {

    	$request->validate([
    		'name' => 'required',
    		'login_id' => 'required',
    		'email' => 'required|email|unique:users,email',
      'password' => 'required'
  ]);
    	 $dataArr['name']=$request->name;
    	 $dataArr['login_id']=$request->login_id;
            $dataArr['email']=$request->email;
            $dataArr['mobile_number']=$request->mobile_number;
            $dataArr['is_role']=$request->is_role;
		$dataArr['created_by']=$request->created_by;
		$dataArr['created_by1']=$request->created_by1;
               $dataArr['company_name']=$request->company_name;
            $dataArr['Company_address']=$request->Company_address;
      
            $dataArr['designation']=$request->designation;
            $dataArr['password']=Hash::make($request->password);
            
            // echo "<pre>";
            // print_r($dataArr);
            // die;
            DB::table('users')->insert($dataArr);
		return redirect()->back()->with('success', 'Add  Successfully');  
             // return redirect(route('users'));
}


    public function update(Request $request) {

      $request->validate([
        'name' => 'required',
        'login_id' => 'required',
        'email' => 'required|email|unique:users,email,'.$request->id
  ]);
       $dataArr['name']=$request->name;
       $dataArr['login_id']=$request->login_id;
            $dataArr['email']=$request->email;
            $dataArr['mobile_number']=$request->mobile_number;
		$dataArr['created_by']=$request->created_by;
           
            $dataArr['company_name']=$request->company_name;
            $dataArr['Company_address']=$request->Company_address;
            $dataArr['designation']=$request->designation;
            DB::table('users')->where('id',$request->id)->update($dataArr);
		return redirect()->back()->with('success', 'update Successfully');   
             // return redirect(route('users'));
}

	
	public function regional_list(Request $request){
	
$users = DB::table('users')->where('created_by', $request->id)->where('is_role',"1")->get();
		
		return response()->json(['data' => $users]);
	
	}

	
		public function regional_unitlist(Request $request){
	
$users = DB::table('users')->where('created_by1', $request->id)->where('is_role',"3")->get();
		
		return response()->json(['data' => $users]);
	
	}
    public function destory($id) {
    	$retData=DB::table('users')->where('id',$id)->delete();
		
		 return redirect()->back()->with('success', 'Delete Successfullye');   

//return redirect()->route('users')->with('success', 'Delete Successfully');
}

public function lincesupload(Request $request) {
    
  
    if($request->file('image')){
    $file= $request->file('image');
    $filename= date('YmdHi').$file->getClientOriginalName();
    $file-> move(public_path('documents'), $filename);
    $dataArr['image']= $filename;
    }
    
 $dataArr['name']= $request->name ?? '';
   
    
if($request->due_date){
$dataArr['due_date']= $request->due_date ?? '';
}

if($request->cat_type){
$dataArr['cat_type']= $request->cat_type ?? '';
}

if($request->type){
$dataArr['type']= $request->type ?? '';
}

$dataArr['unit_id']= $request->unit_id ?? '';
$dataArr['regional_id']= $request->regional_id ?? '';
$dataArr['corporate_id']= $request->corporate_id ?? '';
         DB::table('tbl_documents_list')->insert($dataArr);
		return redirect()->back()->with('success', 'Upload  successfully');  
}



    public function destoryDocuments($id) {
    	$retData=DB::table('tbl_documents_list')->where('id',$id)->delete();
		 return redirect()->back()->with('success', 'Delete Successfullye');   

//return redirect()->route('users')->with('success', 'Delete Successfully');
}


	    public function getDocuments($id,$type,$user_type) {
	        
	              if($user_type=="Corporate"){
	             $list = DB::table('tbl_documents_list')->where('corporate_id', $id)->where('type', 1)->where('cat_type', $type)->get();
  
                }
                else{
	             $list = DB::table('tbl_documents_list')->where('regional_id', $id)->where('type', 1)->where('cat_type', $type)->get();
  
                }
                
return view('admin.users.getdocuments',compact('list'));
}


	    public function getotherDocuments($id,$type,$user_type) {
	        
	          if($user_type=="Corporate"){
	             $list = DB::table('tbl_documents_list')->where('corporate_id', $id)->where('type', $type)->get();
  
                }
                else{
	             $list = DB::table('tbl_documents_list')->where('regional_id', $id)->where('type', $type)->get();
  
                }
                
return view('admin.users.getotherdocuments',compact('list'));
}


	    public function getexpDocuments($id,$type,$status,$user_type) {
            if($status==1){
                $currentDate = Carbon::now()->addDay(60)->format('Y-m-d');
                
                if($user_type=="Corporate"){
                                  $list = DB::table('tbl_documents_list')->where('corporate_id', $id)->where('type', 1)->where('cat_type', $type)->where('due_date',$currentDate)->get();   
  
                }
                else{
                                  $list = DB::table('tbl_documents_list')->where('regional_id', $id)->where('type', 1)->where('cat_type', $type)->where('due_date',$currentDate)->get();   
  
                }
            }
            else{
                $current_date = Carbon::now();
                $currentDate = Carbon::parse($current_date)->format('Y-m-d');
                
                      if($user_type=="Corporate"){
                $list = DB::table('tbl_documents_list')->where('corporate_id', $id)->where('type', 1)->where('cat_type', $type)->where('due_date','<=',$currentDate)->get();    
  
                }
                else{
                $list = DB::table('tbl_documents_list')->where('regional_id', $id)->where('type', 1)->where('cat_type', $type)->where('due_date','<=',$currentDate)->get();    
  
                }
                
                
            }

return view('admin.users.getexpDocuments',compact('list'));
}


	    public function getexpotherDocuments($id,$type,$status,$user_type) {
	        
	              if($status==1){
                $currentDate = Carbon::now()->addDay(60)->format('Y-m-d');
                
                if($user_type=="Corporate"){
                                   $list = DB::table('tbl_documents_list')->where('corporate_id', $id)->where('type', $type)->where('due_date',$currentDate)->get();   
                }
                else{
                                  $list = DB::table('tbl_documents_list')->where('regional_id', $id)->where('type', $type)->where('due_date',$currentDate)->get();   
                }
            }
            else{
              $current_date = Carbon::now();
$currentDate = Carbon::parse($current_date)->format('Y-m-d');

   if($user_type=="Corporate"){
	             $list = DB::table('tbl_documents_list')->where('corporate_id', $id)->where('type', $type)->where('due_date','<=',$currentDate)->get();   
                }
                else{
	             $list = DB::table('tbl_documents_list')->where('regional_id', $id)->where('type', $type)->where('due_date','<=',$currentDate)->get();   
                }
                
                
            }
            
            
            

return view('admin.users.getexpotherDocuments',compact('list'));
}


public function updatelinces(Request $request) {
    
  
    if($request->file('image')){
    $file= $request->file('image');
    $filename= date('YmdHi').$file->getClientOriginalName();
    $file-> move(public_path('documents'), $filename);
    $dataArr['image']= $filename;
    }
    
    
    
if($request->due_date){
$dataArr['due_date']= $request->due_date ?? '';
}

if($request->name){
$dataArr['name']= $request->name ?? '';
}

if($request->cat_type){
$dataArr['cat_type']= $request->cat_type ?? '';
}

DB::table('tbl_documents_list')->where('id',$request->edit_linces_id)->update($dataArr);
		return redirect()->back()->with('success', 'Upload  successfully');  
}

}
