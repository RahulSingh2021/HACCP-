<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOPs Management</title>
    
    <!-- Links from your provided code -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <!-- Style block for the Tab Interface -->
    <style>
        /* Basic styles for the body */
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f4f7f9;
            padding: 20px;
            margin: 0; /* Reset margin */
        }

        /* The main container for the tabs */
        .tab-container {
            width: 100%;
            max-width: 95%; /* Increased max-width for the larger content */
            margin: 20px auto;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden; 
        }

        /* The container for the tab buttons */
        .tab-buttons {
            display: flex;
            background-color: #e9ecef;
            border-bottom: 1px solid #dee2e6;
        }

        /* Individual tab button styling */
        .tab-button {
            padding: 15px 25px;
            cursor: pointer;
            border: none;
            background-color: transparent;
            font-size: 16px;
            font-weight: 500;
            color: #495057;
            transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out;
            border-bottom: 3px solid transparent; 
        }

        .tab-button:not(.active):hover {
            background-color: #f1f3f5;
        }

        .tab-button.active {
            color: #007bff;
            background-color: #ffffff; 
            border-bottom: 3px solid #007bff;
        }

        .tab-content-area {
             padding: 0; /* Remove padding to allow full-width content from your app */
        }
        
        /* Adjusted padding for the second tab's content */
        .tab-content-area .observation-content {
            padding: 25px;
        }

        .tab-content {
            display: none; 
        }

        .tab-content.active {
            display: block; 
        }
        
        /* Simple styling for the Observation Tab content */
        .observation-content h3 {
            margin-top: 0;
            color: #343a40;
        }
        
        .observation-content textarea {
            width: 100%;
            min-height: 400px;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box; 
        }
    </style>
    
    <!-- Style block from your provided code -->
    <style>
        :root {
            --primary-bg: #eef1f5; --container-bg: #ffffff; --border-color: #d1d9e6; --text-primary: #333a45; --text-secondary: #5a6576; --text-muted: #7b879a; --accent-color: #0077b6; --accent-color-darker: #005b8e; --accent-color-hover: #006aa3; --success-color: #2a9d8f; --success-color-hover: #268c80; --danger-color: #e76f51; --danger-color-hover: #d96343; --info-color: #457b9d;  --info-color-hover: #3c6a89; --warning-color: #f4a261; --warning-color-hover: #e09050; --modal-bg: rgba(0, 0, 0, 0.5); --modal-content-bg: #fff; --input-border-color: #ced4da; --input-focus-border-color: #86b7fe; --input-focus-box-shadow: 0 0 0 0.25rem rgba(0, 119, 182, 0.25); --font-family-sans-serif: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; --base-font-size: 16px; --line-height-base: 1.6; --border-radius: 0.375rem; --spacing-unit: 1rem;
        }
        *, *::before, *::after { box-sizing: border-box; } 
        #sopsTab { font-family: var(--font-family-sans-serif); color: var(--text-primary); line-height: var(--line-height-base); background-color: var(--primary-bg);}
        #sopsTab body { font-family: var(--font-family-sans-serif); margin: 0; background-color: var(--primary-bg); color: var(--text-primary); line-height: var(--line-height-base); display: flex; flex-direction: column; min-height: auto; }
        .app-header { background-color: var(--container-bg); padding: var(--spacing-unit) calc(var(--spacing-unit) * 1.5); text-align: center; border-bottom: 1px solid var(--border-color); box-shadow: 0 2px 5px rgba(0,0,0,0.07); z-index: 100; }
        .app-header h1 { margin: 0; font-size: 1.6rem; font-weight: 600; color: var(--accent-color); }
        .main-content-area { flex-grow: 1; padding: calc(var(--spacing-unit) * 1.5); width: 100%; }
        .filters-container { background-color: var(--container-bg); padding: var(--spacing-unit); border-radius: calc(var(--border-radius) * 1.5); box-shadow: 0 3px 8px rgba(0, 30, 80, 0.08); border: 1px solid var(--border-color); margin-bottom: calc(var(--spacing-unit) * 1.5); }
        .filters-container h3 { margin-top: 0; margin-bottom: var(--spacing-unit); font-size: 1.2rem; color: var(--accent-color); font-weight: 600; border-bottom: 1px solid var(--border-color); padding-bottom: calc(var(--spacing-unit) * 0.5); }
        .filter-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--spacing-unit); align-items: end; }
        .filters-container .form-group { margin-bottom: 0; }
        .filters-container label { display: block; margin-bottom: 0.5rem; font-weight: 500; color: var(--text-secondary); font-size: 0.9rem; }
        .filters-container select, .filters-container input[type="text"] { width: 100%; padding: 0.5rem 0.75rem; font-size: 0.9rem; line-height: 1.5; color: var(--text-primary); background-color: #fff; background-clip: padding-box; border: 1px solid var(--input-border-color); border-radius: var(--border-radius); transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out; }
        .filters-container select { appearance: none; -webkit-appearance: none; -moz-appearance: none; background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 0.75rem center; background-size: 16px 12px; }
        .filters-container select:focus, .filters-container input[type="text"]:focus { border-color: var(--input-focus-border-color); outline: 0; box-shadow: var(--input-focus-box-shadow); }
        .filters-container .btn { padding: 0.5rem 1rem; font-size: 0.9rem; border-radius: var(--border-radius); cursor: pointer; text-decoration: none; border: none; width: 100%; font-weight: 500; }
        .filters-container .btn-secondary { background-color: var(--text-muted); color: white; }
        .filters-container .btn-secondary:hover { background-color: var(--text-secondary); }
        .hidden { display: none !important; }
        .top-action-buttons-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: var(--spacing-unit); align-items: start; }
        .action-group { background-color: var(--container-bg); padding: var(--spacing-unit); border-radius: calc(var(--border-radius) * 1.5); box-shadow: 0 3px 8px rgba(0, 30, 80, 0.08); border: 1px solid var(--border-color); display: flex; flex-direction: column; }
        .action-group h3 { margin-top: 0; margin-bottom: calc(var(--spacing-unit) * 0.75); font-size: 1.1rem; color: var(--accent-color); font-weight: 600; border-bottom: 1px solid var(--border-color); padding-bottom: calc(var(--spacing-unit) * 0.5); }
        .action-group button:not(.btn-icon-action) { width: 100%; margin-bottom: calc(var(--spacing-unit) * 0.5); } .action-group button:last-child:not(.btn-icon-action) { margin-bottom: 0; }
        .button-pair { display: flex; gap: calc(var(--spacing-unit) * 0.5); } .button-pair button { flex-grow: 1; }
        .super-admin-dashboard-details { background-color: var(--container-bg); border: 1px solid var(--border-color); border-radius: calc(var(--border-radius) * 1.5); box-shadow: 0 3px 8px rgba(0, 30, 80, 0.08); margin-bottom: calc(var(--spacing-unit) * 1.5); overflow: hidden; }
        .super-admin-dashboard-summary { padding: var(--spacing-unit) calc(var(--spacing-unit) * 1.25); font-weight: 600; font-size: 1.15rem; color: var(--accent-color); cursor: pointer; list-style: none; display: flex; justify-content: space-between; align-items: center; background-color: #f8f9fa; border-bottom: 1px solid transparent; flex-wrap: wrap; }
        .super-admin-dashboard-details[open] > .super-admin-dashboard-summary { background-color: var(--accent-color); color: white; border-bottom-color: var(--accent-color-darker); }
        .super-admin-dashboard-details[open] > .super-admin-dashboard-summary .summary-content-wrapper .entity-name-display, .super-admin-dashboard-details[open] > .super-admin-dashboard-summary .summary-content-wrapper .entity-icon, .super-admin-dashboard-details[open] > .super-admin-dashboard-summary .summary-actions .entity-count, .super-admin-dashboard-details[open] > .super-admin-dashboard-summary .summary-actions .entity-count strong, .super-admin-dashboard-details[open] > .super-admin-dashboard-summary .toggler-icon { color: white; }
        .super-admin-dashboard-details[open] > .super-admin-dashboard-summary .summary-actions .entity-count { border-color: rgba(255,255,255,0.4); background-color: rgba(255,255,255,0.1); }
        .super-admin-dashboard-summary::-webkit-details-marker, .super-admin-dashboard-summary::marker { display: none; }
        .super-admin-dashboard-summary .summary-actions { font-size: 0.8rem; margin-left: var(--spacing-unit); }
        .super-admin-dashboard-summary .toggler-icon { font-size: 0.875em; color: var(--text-muted); transition: transform 0.25s ease-out; margin-left: auto; }
        .super-admin-dashboard-details[open] > .super-admin-dashboard-summary .toggler-icon { transform: rotate(90deg); }
        .super-admin-dashboard-details .dashboard-action-buttons-container { padding: calc(var(--spacing-unit) * 1.25); border-top: 1px solid var(--border-color); }
        .super-admin-dashboard-details .dashboard-action-buttons-container .top-action-buttons-grid { margin-bottom: 0; }
        #addTrainingProgramButton, #downloadFullSampleCsvButton, #uploadFullCsvButton { padding: 0.6rem 1.2rem; font-size: 0.9rem; font-weight: 500; color: #fff; border: none; border-radius: var(--border-radius); cursor: pointer; transition: background-color 0.2s ease, box-shadow 0.2s ease; text-align: center; }
        #addTrainingProgramButton:hover, #downloadFullSampleCsvButton:hover, #uploadFullCsvButton:hover { box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        #addTrainingProgramButton { background-color: var(--accent-color); } #addTrainingProgramButton:hover { background-color: var(--accent-color-hover); }
        #downloadFullSampleCsvButton { background-color: var(--success-color); } #downloadFullSampleCsvButton:hover { background-color: var(--success-color-hover); }
        #uploadFullCsvButton { background-color: var(--danger-color); } #uploadFullCsvButton:hover { background-color: var(--danger-color-hover); }
        .scoped-upload-section, .keyword-management-section { margin-top: 0; padding: var(--spacing-unit); background-color: #f7f9fc; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: var(--spacing-unit); }
        .scoped-upload-section { border-bottom: 1px solid var(--border-color); }
        .keyword-management-section { border-top: 1px dashed var(--border-color); margin-top: var(--spacing-unit); }
        details > .scoped-upload-section + .entity-content-wrapper { border-top: none; }
        .entity-content-wrapper > .scoped-upload-section { margin-top: var(--spacing-unit); padding-top: var(--spacing-unit); border-top: 1px dashed var(--border-color); background-color: transparent; border-bottom: none; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: var(--spacing-unit); }
        .scoped-upload-section h4, .keyword-management-section h4 { font-size: 1rem; color: var(--text-secondary); margin-bottom: 0; font-weight: 500; flex-grow: 1; }
        .scoped-upload-section .button-pair, .keyword-management-section .button-pair { flex-shrink: 0; }
        .scoped-upload-section .button-pair button, .scoped-upload-section .action-button, .keyword-management-section .button-pair button { font-size: 0.8rem; padding: 0.4rem 0.8rem; margin-bottom: 0; }
        .action-button.download-sample { background-color: var(--success-color); color: white; } .action-button.download-sample:hover { background-color: var(--success-color-hover); }
        .action-button.upload-scoped { background-color: var(--info-color); color: white; } .action-button.upload-scoped:hover { background-color: var(--info-color-hover); }
        .upload-status-area { margin-top: 1rem; font-weight: 500; padding: 0.75rem; border-radius: var(--border-radius); background-color: #e9ecef; border: 1px solid var(--border-color); min-height: 40px; font-size: 0.85rem; line-height: 1.5; }
        details.entity-level { margin-bottom: calc(var(--spacing-unit) * 1.25); border-radius: calc(var(--border-radius) * 1.5); background-color: var(--container-bg); box-shadow: 0 3px 8px rgba(0, 30, 80, 0.08); border: 1px solid var(--border-color); overflow: hidden; transition: box-shadow 0.3s ease, opacity 0.3s ease; }
        details.entity-level:hover { box-shadow: 0 5px 15px rgba(0, 30, 80, 0.1); }
        summary.entity-summary { padding: var(--spacing-unit) calc(var(--spacing-unit) * 1.25); font-weight: 600; cursor: pointer; list-style: none; display: flex; justify-content: space-between; align-items: center; transition: background-color 0.2s ease, color 0.2s ease; flex-wrap: wrap; }
        summary.entity-summary::-webkit-details-marker, summary.entity-summary::marker { display: none; }
        summary.entity-summary:hover { background-color: #f8f9fa; }
        details.training-program > summary.entity-summary { background-color: #f8f9fa; color: var(--text-primary); font-size: 1.1rem; border-bottom: 1px solid transparent; } 
        details.training-program[open] > summary.entity-summary { background-color: var(--accent-color); color: white; border-bottom-color: var(--accent-color-darker); }
        details.course-item > summary.entity-summary { background-color: #fafbfc; font-size: 1rem; color: var(--text-secondary); border-bottom: 1px solid transparent; } 
        details.course-item[open] > summary.entity-summary { background-color: var(--info-color); color: white; border-bottom-color: var(--info-color-hover); }
        details.entity-level[open] > summary.entity-summary .entity-icon, details.entity-level[open] > summary.entity-summary .toggler-icon, details.entity-level[open] > summary.entity-summary .summary-action-btn, details.entity-level[open] > summary.entity-summary .edit-btn, details.entity-level[open] > summary.entity-summary .activation-btn, details.entity-level[open] > summary.entity-summary .entity-count, details.entity-level[open] > summary.entity-summary .delete-btn  { color: white; }
        .summary-content-wrapper { display: flex; align-items: center; gap: calc(var(--spacing-unit) * 0.5); flex-grow: 1; min-width: 0; flex-wrap: wrap; } 
        .entity-icon { font-size: 1.25em; color: var(--text-muted); line-height: 1; flex-shrink: 0; } 
        .entity-name-display { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; } 
        .summary-actions { display: flex; align-items: center; gap: calc(var(--spacing-unit) * 0.5); flex-shrink: 0; flex-wrap: wrap; } 
        .toggler-icon { font-size: 0.875em; color: var(--text-muted); transition: transform 0.25s ease-out; padding: 0.25rem; line-height: 1; } 
        details[open] > summary.entity-summary .toggler-icon { transform: rotate(90deg); }
        .entity-content-wrapper { padding: calc(var(--spacing-unit) * 1.25); border-top: 1px solid var(--border-color); background-color: var(--container-bg); transition: opacity 0.3s ease; }
        .entity-content-wrapper > details.entity-level { margin-top: var(--spacing-unit); } 
        .entity-description { font-size: 0.95rem; color: var(--text-secondary); margin-bottom: 1rem; padding: 0.75rem var(--spacing-unit); background-color: #f7f9fc; border-left: 4px solid var(--accent-color); border-radius: 0 var(--border-radius) var(--border-radius) 0; }
        
        .keywords-display-container { margin-top: 1rem; margin-bottom: 0; padding: 0.75rem var(--spacing-unit); background-color: #f7f9fc; border-left: 4px solid var(--info-color); border-radius: 0 var(--border-radius) var(--border-radius) 0; display: flex; flex-wrap: wrap; align-items: flex-start; gap: 0.75rem; }
        .keywords-display-container strong { color: var(--text-secondary); font-weight: 500; line-height: 1.8; flex-shrink: 0; }
        .keywords-list { display: inline-flex; flex-wrap: wrap; gap: 0.5rem; align-items: center; }
        .keyword-tag { background-color: var(--info-color); color: white; padding: 0.2rem 0.4rem 0.2rem 0.6rem; border-radius: var(--border-radius); font-size: 0.8rem; font-weight: 500; display: inline-flex; align-items: center; gap: 0.3rem; }
        .delete-keyword-btn { background: transparent; border: none; color: white; opacity: 0.6; cursor: pointer; padding: 0 0.2rem; font-size: 1.1em; line-height: 1; transition: opacity 0.2s; }
        .delete-keyword-btn:hover { opacity: 1; }
        .add-keyword-wrapper { position: relative; }
        .add-keyword-btn { background-color: transparent; border: 1px dashed var(--text-muted); color: var(--text-muted); padding: 0.2rem 0.6rem; font-size: 0.8rem; border-radius: var(--border-radius); cursor: pointer; transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 0.3em; }
        .add-keyword-btn:hover { background-color: var(--text-muted); color: white; border-style: solid; }
        .add-keyword-input-group { display: flex; align-items: center; gap: 0.25rem; }
        .add-keyword-input { font-size: 0.8rem; padding: 0.2rem 0.4rem; border: 1px solid var(--input-border-color); border-radius: var(--border-radius); width: 120px; }
        .add-keyword-input-group button { background: var(--text-muted); color: white; border: none; cursor: pointer; border-radius: var(--border-radius); font-size: 0.9rem; line-height: 1; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; transition: background-color 0.2s; }
        .add-keyword-input-group button.save-keyword-btn { background-color: var(--success-color); }
        .add-keyword-input-group button.save-keyword-btn:hover { background-color: var(--success-color-hover); }
        .add-keyword-input-group button.cancel-keyword-btn { background-color: var(--danger-color); }
        .add-keyword-input-group button.cancel-keyword-btn:hover { background-color: var(--danger-color-hover); }
        
        .action-button, .edit-btn, .delete-btn { padding: 0.3rem 0.75rem; font-size: 0.8rem; font-weight: 500; line-height: 1.2; border-radius: calc(var(--border-radius) * 0.75); margin-top: 0; box-shadow: none; text-decoration: none; white-space: nowrap; transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease; cursor: pointer; display: inline-flex; align-items: center; border: 1px solid transparent; }
        .action-button:hover, .edit-btn:hover, .delete-btn:hover { box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .action-button > span, .edit-btn > span, .delete-btn > span { display: inline-block; } .action-button .btn-icon, .edit-btn .btn-icon, .delete-btn .btn-icon { margin-right: 0.3em; } 
        .edit-btn { background-color: transparent; border-color: var(--warning-color); color: var(--warning-color); } 
        .edit-btn:hover { background-color: var(--warning-color); color: white !important; } 
        details[open] > summary.entity-summary .edit-btn { border-color: rgba(255,255,255,0.6); color: white; } 
        details[open] > summary.entity-summary .edit-btn:hover { background-color: rgba(255,255,255,0.2); border-color: white; } 
        .delete-btn { background-color: transparent; border-color: var(--danger-color); color: var(--danger-color); } 
        .delete-btn:hover { background-color: var(--danger-color); color: white !important; } 
        details[open] > summary.entity-summary .delete-btn { border-color: rgba(255,255,255,0.6); color: white; } 
        details[open] > summary.entity-summary .delete-btn:hover { background-color: rgba(255,255,255,0.2); border-color: white; } 
        details.training-program:not([open]) > summary.entity-summary .summary-action-btn.add-course { color: var(--success-color); border-color: var(--success-color); background-color: transparent; } 
        details.training-program:not([open]) > summary.entity-summary .summary-action-btn.add-course:hover { background-color: var(--success-color); color: white; } 
        details[open] > summary.entity-summary .summary-action-btn { color: white; border-color: rgba(255,255,255,0.6); background-color: rgba(255,255,255,0.1); } 
        details[open] > summary.entity-summary .summary-action-btn:hover { background-color: rgba(255,255,255,0.2); border-color: white; } 
        .activation-btn.active-state { border-color: var(--success-color); color: var(--success-color); background-color: transparent; } 
        .activation-btn.active-state:hover { background-color: var(--success-color); color: white !important; } 
        .activation-btn.inactive-state { border-color: var(--danger-color); color: var(--danger-color); background-color: transparent; } 
        .activation-btn.inactive-state:hover { background-color: var(--danger-color); color: white !important; } 
        details[open] > summary.entity-summary .activation-btn { border-color: rgba(255,255,255,0.6); color: white; background-color: rgba(255,255,255,0.1); } 
        details[open] > summary.entity-summary .activation-btn.active-state:hover { background-color: rgba(40, 167, 69, 0.5); border-color: white; } 
        details[open] > summary.entity-summary .activation-btn.inactive-state:hover { background-color: rgba(220, 53, 69, 0.5); border-color: white; }
        .entity-count { font-size: 0.75rem; color: var(--text-muted); margin-right: calc(var(--spacing-unit) * 0.25); padding: 0.2rem 0.4rem; border: 1px solid var(--border-color); border-radius: calc(var(--border-radius) * 0.5); background-color: #f8f9fa; white-space: nowrap; line-height: 1.2; align-self: center; } 
        details[open] > summary.entity-summary .entity-count { color: white; border-color: rgba(255,255,255,0.4); background-color: rgba(255,255,255,0.1); }
        details.entity-level[data-status="inactive"] > summary.entity-summary { opacity: 0.75; background-image: repeating-linear-gradient( -45deg, transparent, transparent 4px, rgba(0,0,0,0.02) 4px, rgba(0,0,0,0.02) 8px ); } 
        details.training-program[data-status="inactive"] > summary.entity-summary { background-color: #e0e0e0; } 
        details.course-item[data-status="inactive"] > summary.entity-summary { background-color: #f0f0f0; } 
        details.entity-level[data-status="inactive"] > summary.entity-summary .entity-name-display { text-decoration: line-through; color: var(--text-muted) !important; } 
        details.entity-level[data-status="inactive"] .entity-content-wrapper { opacity: 0.6; pointer-events: none; } 
        details.entity-level[data-status="inactive"][open] > summary.entity-summary { color: var(--text-secondary) !important; } 
        details.training-program[data-status="inactive"][open] > summary.entity-summary { background-color: #d0d0d0 !important; } 
        details.course-item[data-status="inactive"][open] > summary.entity-summary { background-color: #e0e0e0 !important; } 
        details.entity-level[data-status="inactive"][open] > summary.entity-summary .entity-icon, details.entity-level[data-status="inactive"][open] > summary.entity-summary .toggler-icon, details.entity-level[data-status="inactive"][open] > summary.entity-summary .summary-action-btn, details.entity-level[data-status="inactive"][open] > summary.entity-summary .edit-btn, details.entity-level[data-status="inactive"][open] > summary.entity-summary .activation-btn, details.entity-level[data-status="inactive"][open] > summary.entity-summary .entity-count, details.entity-level[data-status="inactive"][open] > summary.entity-summary .delete-btn { color: var(--text-secondary) !important; opacity: 0.7; border-color: rgba(0,0,0,0.2) !important; } 
        details.entity-level[data-status="inactive"][open] > summary.entity-summary .summary-action-btn:hover, details.entity-level[data-status="inactive"][open] > summary.entity-summary .edit-btn:hover, details.entity-level[data-status="inactive"][open] > summary.entity-summary .activation-btn:hover, details.entity-level[data-status="inactive"][open] > summary.entity-summary .delete-btn:hover { background-color: rgba(0,0,0,0.05) !important; }
        details:not([open]) > summary.entity-summary .summary-action-btn > span { color: inherit; } 
        details[open] > summary.entity-summary .summary-action-btn > span, details[open] > summary.entity-summary .edit-btn > span, details[open] > summary.entity-summary .activation-btn > span, details[open] > summary.entity-summary .delete-btn > span { color: white; }
        .modal { display: none; position: fixed; z-index: 1050; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: var(--modal-bg); } .modal-content { background-color: var(--modal-content-bg); margin: 5% auto; padding: calc(var(--spacing-unit) * 1.5); border: 1px solid var(--border-color); width: 80%; max-width: 650px; border-radius: var(--border-radius); box-shadow: 0 5px 15px rgba(0,0,0,0.3); position: relative; } .modal-content[style*="max-width: 700px;"] { max-width: 750px !important; } .modal-content[style*="max-width: 450px;"] { max-width: 450px !important; } .modal-header { padding-bottom: var(--spacing-unit); border-bottom: 1px solid var(--border-color); margin-bottom: var(--spacing-unit); } .modal-header h2 { margin: 0; font-size: 1.5rem; color: var(--text-primary); font-weight: 600; } .close-btn { color: #aaa; position: absolute; top: calc(var(--spacing-unit) * 0.75); right: calc(var(--spacing-unit) * 1); font-size: 28px; font-weight: bold; line-height: 1; } .close-btn:hover, .close-btn:focus { color: black; text-decoration: none; cursor: pointer; } .modal-body .form-group { margin-bottom: var(--spacing-unit); } .modal-body label { display: block; margin-bottom: 0.5rem; font-weight: 500; color: var(--text-secondary); } .modal-body input[type="text"], .modal-body input[type="email"], .modal-body input[type="tel"], .modal-body input[type="date"], .modal-body textarea, .modal-body select, .modal-body input[type="file"].form-control { width: 100%; padding: 0.5rem 0.75rem; font-size: 1rem; line-height: 1.5; color: var(--text-primary); background-color: #fff; background-clip: padding-box; border: 1px solid var(--input-border-color); border-radius: var(--border-radius); transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out; } .modal-body input[type="text"]:focus, .modal-body input[type="email"]:focus, .modal-body input[type="tel"]:focus, .modal-body input[type="date"]:focus, .modal-body textarea:focus, .modal-body select:focus, .modal-body input[type="file"].form-control:focus { border-color: var(--input-focus-border-color); outline: 0; box-shadow: var(--input-focus-box-shadow); } .modal-body select { appearance: none; -webkit-appearance: none; -moz-appearance: none; background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 0.75rem center; background-size: 16px 12px; } .modal-body textarea { min-height: 80px; resize: vertical; } .modal-body .subscription-fields { border-top: 1px solid var(--border-color); margin-top: var(--spacing-unit); padding-top: var(--spacing-unit); } .modal-footer { padding-top: var(--spacing-unit); border-top: 1px solid var(--border-color); margin-top: var(--spacing-unit); text-align: right; } .modal-footer .btn { padding: 0.625rem 1.25rem; font-size: 1rem; font-weight: 500; border-radius: var(--border-radius); cursor: pointer; text-decoration: none; border: none; margin-left: 0.5rem; } .modal-footer .btn-primary { background-color: var(--accent-color); color: white; } .modal-footer .btn-primary:hover { background-color: var(--accent-color-hover); } .modal-footer .btn-secondary { background-color: var(--text-muted); color: white; } .modal-footer .btn-secondary:hover { background-color: var(--text-secondary); } 
        .btn-icon-action { background: none; border: none; cursor: pointer; font-size: 1.1em; padding: 0.2rem; color: var(--text-muted); line-height: 1; }
        @media (max-width: 1200px) { }
        @media (max-width: 768px) { 
            .app-header h1 { font-size: 1.5rem; } 
            .main-content-area { padding: var(--spacing-unit); } 
            .action-group button:not(.btn-icon-action), .button-pair button { font-size: 0.9rem; padding: 0.6rem 1.2rem; width: 100%; } 
            .button-pair { flex-direction: column;} 
            summary.entity-summary { padding: calc(var(--spacing-unit) * 0.75) var(--spacing-unit); } 
            .entity-description { padding: 0.6rem calc(var(--spacing-unit) * 0.75); } 
            .action-button, .edit-btn, .delete-btn { padding: 0.25rem 0.5rem; font-size: 0.75rem; } 
            .entity-count { font-size: 0.7rem; padding: 0.15rem 0.3rem; margin-right: calc(var(--spacing-unit) * 0.3); } 
            .summary-actions { gap: calc(var(--spacing-unit) * 0.3); } 
            .modal-content { margin: 5% auto; width: 90%; } 
            .filter-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 480px) { 
            .summary-actions .edit-btn > span, .summary-actions .summary-action-btn > span, .summary-actions .activation-btn > span, .summary-actions .delete-btn > span { display: none; } 
            .summary-actions .edit-btn .btn-icon, .summary-actions .summary-action-btn .btn-icon, .summary-actions .activation-btn .btn-icon, .summary-actions .delete-btn .btn-icon { margin-right:0; } 
            .action-button, .edit-btn, .summary-actions .activation-btn, .delete-btn { padding: 0.3rem 0.5rem; } 
            .entity-count { font-size: 0.65rem; padding: 0.1rem 0.25rem; margin-right: calc(var(--spacing-unit) * 0.2); } 
            .entity-count .count-label { display: none; }
            .scoped-upload-section, .keyword-management-section { flex-direction: column; align-items: stretch; } 
            .scoped-upload-section h4, .keyword-management-section h4 { margin-bottom: calc(var(--spacing-unit) * 0.5); text-align: center;} 
            .scoped-upload-section .button-pair, .keyword-management-section .button-pair { flex-direction: column; }
        }
    </style>
</head>
<body>

    <div class="tab-container">
        <!-- Tab Buttons -->
        <div class="tab-buttons">
            <button class="tab-button active" data-tab="sopsTab">SOPs Name</button>
            <button class="tab-button" data-tab="observationTab">Observation Text</button>
        </div>

        <!-- Tab Content Area -->
        <div class="tab-content-area">
            
            <!-- Tab 1 Content: SOPs Name (Your application is pasted here) -->
            <div id="sopsTab" class="tab-content active">
                <header class="app-header"> <h1>SOPs Management</h1> </header>
                <main class="main-content-area" id="mainContentArea">
                    <div class="filters-container">
                        <h3>Filter View</h3>
                        <div class="filter-grid">
                            <div class="form-group"> <label for="filterProgram">SOPs:</label> <select id="filterProgram" class="form-control"> <option value="all">All SOPs</option> </select> </div>
                            <div class="form-group"> <label for="filterCourse">Sub-SOP:</label> <select id="filterCourse" class="form-control"> <option value="all">All Sub-SOPs</option> </select> </div>
                            <div class="form-group"> <label for="filterKeyword">Keyword Search:</label> <input type="text" id="filterKeyword" class="form-control" placeholder="Search name, description, keywords..."> </div>
                            <div class="form-group filter-actions"> <button type="button" id="clearFiltersButton" class="btn btn-secondary">Clear Filters</button> </div>
                        </div>
                    </div>
            
                    <details class="super-admin-dashboard-details">
                        <summary class="super-admin-dashboard-summary">
                            <div class="summary-content-wrapper"> <span class="entity-icon">📊</span> <span class="entity-name-display">SOPs Dash Board</span> </div>
                            <div class="summary-actions" id="superAdminDashboardStatsContainer"> 
                                <span class="entity-count"><span class="count-label">Total SOPs: </span><strong id="dashStatTotalPrograms">1</strong></span> 
                                <span class="entity-count"><span class="count-label">Total Sub-SOPs: </span><strong id="dashStatTotalCourses">1</strong></span> 
                            </div>
                            <span class="toggler-icon">▶</span>
                        </summary>
                        <div class="dashboard-action-buttons-container">
                            <div class="top-action-buttons-grid">
                                <div class="action-group manual-entry"> <h3>Manual / Detailed Entry</h3> 
                                    <button type="button" id="addTrainingProgramButton" onclick="openAddModal('program', null, null)">🎓 Add SOPs</button> 
                                </div>
                                <div class="action-group super-admin-csv"> <h3>Admin - Bulk Upload All SOPs (CSV)</h3> <div class="button-pair"> <button type="button" id="downloadFullSampleCsvButton" onclick="downloadFullSampleCsv()">📄 Full Sample CSV</button> <button type="button" id="uploadFullCsvButton" onclick="openSuperAdminCsvUploadModal()">⬆️ Upload Full CSV</button> </div> </div>
                            </div>
                        </div>
                    </details>
            
                    <details class="entity-level training-program" id="prog_1" data-status="active" data-keywords="onboarding, core, new hire"> 
                        <summary class="entity-summary"> <div class="summary-content-wrapper"> <span class="entity-icon">🎓</span> <span class="entity-name-display">SOPs-(Foundational Skills Program)</span> </div> <div class="summary-actions"> <span class="entity-count course-count" id="prog_1-course-count"><span class="count-label">Sub-SOPs: </span>1</span> <button type="button" class="edit-btn" onclick="openEditModal('program', 'prog_1')"> <span class="btn-icon">✏️</span><span>Edit</span> </button> <button type="button" class="delete-btn" onclick="deleteProgramOrCourse('program', 'prog_1')"><span class="btn-icon">🗑️</span><span>Delete</span></button> <button type="button" onclick="openAddModal('course', 'prog_1', 'Foundational Skills Program')" class="action-button summary-action-btn add-course"> <span class="btn-icon">➕</span><span>Add Sub-SOP</span> </button> <button type="button" class="action-button summary-action-btn activation-btn active-state" onclick="toggleActivation('prog_1', 'program', this)"> <span class="btn-icon">🟢</span><span>Active</span> </button> <span class="toggler-icon">▶</span> </div> </summary>
                        <div class="scoped-upload-section"> <h4>Bulk Add Sub-SOPs to this SOPs</h4> <div class="button-pair"> <button type="button" class="action-button download-sample" onclick="downloadCourseSampleCsv('prog_1', 'Foundational Skills Program')">📄 Sample CSV for Sub-SOPs</button> <button type="button" class="action-button upload-scoped" onclick="openUploadCoursesCsvModal('prog_1', 'Foundational Skills Program')">⬆️ Upload Sub-SOPs CSV</button> </div> </div>
                        <div class="entity-content-wrapper"> 
                            <p class="entity-description" data-field="description">Core training for all new employees.</p>
                            <div class="keywords-display-container"></div>
                            <div class="keyword-management-section">
                                <h4>Bulk Keyword Management</h4>
                                <div class="button-pair">
                                    <button type="button" class="action-button download-sample" onclick="downloadKeywordSampleCsv('prog_1', 'Foundational Skills Program')">📄 Sample Keywords CSV</button>
                                    <button type="button" class="action-button upload-scoped" onclick="openUploadKeywordsCsvModal('prog_1', 'Foundational Skills Program')">⬆️ Upload Keywords CSV</button>
                                </div>
                            </div>
                            <div class="course-container"> 
                                <details class="entity-level course-item" id="course_1_1" data-status="active" data-keywords="hr, policy, procedures"> 
                                    <summary class="entity-summary"> <div class="summary-content-wrapper"> <span class="entity-icon">📖</span> <span class="entity-name-display">Sub-SOP-(Introduction to Company Policies)</span> </div> <div class="summary-actions"> <button type="button" class="edit-btn" onclick="openEditModal('course', 'course_1_1')"><span class="btn-icon">✏️</span><span>Edit</span></button>  <button type="button" class="delete-btn" onclick="deleteProgramOrCourse('course', 'course_1_1')"><span class="btn-icon">🗑️</span><span>Delete</span></button> <button type="button" class="action-button summary-action-btn activation-btn active-state" onclick="toggleActivation('course_1_1', 'course', this)"><span class="btn-icon">🟢</span><span>Active</span></button> <span class="toggler-icon">▶</span> </div> </summary>
                                    <div class="entity-content-wrapper"> 
                                        <p class="entity-description" data-field="description">Overview of key company policies and procedures.</p>
                                        <div class="keywords-display-container"></div>
                                        <div class="keyword-management-section">
                                            <h4>Bulk Keyword Management</h4>
                                            <div class="button-pair">
                                                <button type="button" class="action-button download-sample" onclick="downloadKeywordSampleCsv('course_1_1', 'Introduction to Company Policies')">📄 Sample Keywords CSV</button>
                                                <button type="button" class="action-button upload-scoped" onclick="openUploadKeywordsCsvModal('course_1_1', 'Introduction to Company Policies')">⬆️ Upload Keywords CSV</button>
                                            </div>
                                        </div>
                                    </div>
                                </details>
                            </div>
                        </div>
                    </details>
                    <div id="entityContainer" class="entity-container"></div>
                </main>
            
                <!-- MODALS -->
                <div id="programModal" class="modal"> <div class="modal-content"> <div class="modal-header"> <h2 id="programModalTitle">Add/Edit SOPs</h2> <span class="close-btn" onclick="closeModal('programModal')">×</span> </div> <form id="programForm" class="modal-body" onsubmit="event.preventDefault(); saveProgram();"> <input type="hidden" id="programEntityId"> <div class="form-group"> <label for="programNameModal">SOPs Name</label> <input type="text" id="programNameModal" required> </div> <div class="form-group"> <label for="programDescriptionModal">Description</label> <textarea id="programDescriptionModal"></textarea> </div> <div class="form-group"> <label for="programKeywordsModal">Keywords (comma-separated)</label> <input type="text" id="programKeywordsModal" placeholder="e.g., leadership, management, new hire"> </div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" onclick="closeModal('programModal')">Cancel</button> <button type="submit" class="btn btn-primary">Save</button> </div> </form> </div> </div>
                <div id="courseModal" class="modal"> <div class="modal-content"> <div class="modal-header"> <h2 id="courseModalTitle">Add/Edit Sub-SOP</h2> <span class="close-btn" onclick="closeModal('courseModal')">×</span> </div> <form id="courseForm" class="modal-body" onsubmit="event.preventDefault(); saveCourse();"> <input type="hidden" id="courseEntityId"> <input type="hidden" id="courseParentId"> <div class="form-group"> <label for="courseNameModal">Sub-SOP Name</label> <input type="text" id="courseNameModal" required> </div> <div class="form-group"> <label for="courseDescriptionModal">Description</label> <textarea id="courseDescriptionModal"></textarea> </div> <div class="form-group"> <label for="courseKeywordsModal">Keywords (comma-separated)</label> <input type="text" id="courseKeywordsModal" placeholder="e.g., compliance, safety, policy"> </div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" onclick="closeModal('courseModal')">Cancel</button> <button type="submit" class="btn btn-primary">Save</button> </div> </form> </div> </div>
                <div id="superAdminCsvUploadModal" class="modal"> <div class="modal-content" style="max-width: 700px;"> <div class="modal-header"> <h2 id="superAdminCsvUploadModalTitle">Admin - Upload All SOPs CSV</h2> <span class="close-btn" onclick="closeModal('superAdminCsvUploadModal')">×</span> </div> <form id="superAdminCsvUploadForm" class="modal-body" onsubmit="event.preventDefault(); handleSuperAdminCsvUpload();"> <p>Upload a CSV file... Ensure your CSV matches the <a href="#" onclick="event.preventDefault(); downloadFullSampleCsv();">full sample CSV</a>.</p> <div class="form-group"> <label for="superAdminFileCsv">Select CSV File (.csv):</label> <input type="file" id="superAdminFileCsv" accept=".csv, text/csv" class="form-control" required> </div> <div class="form-group"> <strong>CSV Format Key Columns:</strong> <ul style="font-size: 0.85rem; padding-left: 1.5rem; color: var(--text-secondary);"> <li>`Level`: "SOPs", "Sub-SOP".</li> <li>`ParentName`: Name of the parent entity (SOPs for Sub-SOP).</li> <li>`Name`: Name of the current entity (Required).</li> <li>Others (Optional): `Description`, `Keywords`.</li><li><em>Order:</em> Parents before children if nesting.</li> </ul> </div> <div id="superAdminCsvUploadStatus" class="upload-status-area"></div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" onclick="closeModal('superAdminCsvUploadModal')">Cancel</button> <button type="submit" class="btn btn-primary">Process Full CSV</button> </div> </form> </div> </div>
                <div id="uploadCoursesModal" class="modal"> <div class="modal-content" style="max-width: 700px;"> <div class="modal-header"> <h2 id="uploadCoursesModalTitle">Upload Sub-SOPs CSV</h2> <span class="close-btn" onclick="closeModal('uploadCoursesModal')">×</span> </div> <form id="uploadCoursesForm" class="modal-body" onsubmit="event.preventDefault(); handleUploadCoursesCsv();"> <input type="hidden" id="uploadCoursesProgramId"> <input type="hidden" id="uploadCoursesProgramName"> <p>Upload CSV to add Sub-SOPs to SOPs: <strong id="uploadCoursesTargetProgramName"></strong>.</p> <p>`Level`: "Sub-SOP". `ParentName` for Sub-SOPs is <strong id="uploadCoursesTargetProgramNameMirror"></strong>. <a href="#" onclick="event.preventDefault(); document.getElementById('downloadSampleCourseScoped').click();">Sample</a>.</p> <button type="button" id="downloadSampleCourseScoped" style="display:none;" onclick="downloadCourseSampleCsv(document.getElementById('uploadCoursesProgramId').value, document.getElementById('uploadCoursesProgramName').value)"></button> <div class="form-group"> <label for="uploadCoursesFileCsv">Select CSV File (.csv):</label> <input type="file" id="uploadCoursesFileCsv" accept=".csv, text/csv" class="form-control" required> </div> <div id="uploadCoursesStatus" class="upload-status-area"></div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" onclick="closeModal('uploadCoursesModal')">Cancel</button> <button type="submit" class="btn btn-primary">Process CSV</button> </div> </form> </div> </div>
                <div id="uploadKeywordsModal" class="modal"> <div class="modal-content" style="max-width: 700px;"> <div class="modal-header"> <h2 id="uploadKeywordsModalTitle">Upload Keywords CSV</h2> <span class="close-btn" onclick="closeModal('uploadKeywordsModal')">×</span> </div> <form id="uploadKeywordsForm" class="modal-body" onsubmit="event.preventDefault(); handleUploadKeywordsCsv();"> <input type="hidden" id="uploadKeywordsEntityId"> <input type="hidden" id="uploadKeywordsEntityName"> <p>Upload a CSV file to add/merge keywords for: <strong id="uploadKeywordsTargetEntityName"></strong>.</p> <p>The CSV should have one column with the header "Keywords". <a href="#" onclick="event.preventDefault(); document.getElementById('downloadSampleKeywordScoped').click();">Download Sample</a>.</p> <button type="button" id="downloadSampleKeywordScoped" style="display:none;" onclick="downloadKeywordSampleCsv(document.getElementById('uploadKeywordsEntityId').value, document.getElementById('uploadKeywordsEntityName').value)"></button> <div class="form-group"> <label for="uploadKeywordsFileCsv">Select CSV File (.csv):</label> <input type="file" id="uploadKeywordsFileCsv" accept=".csv, text/csv" class="form-control" required> </div> <div id="uploadKeywordsStatus" class="upload-status-area"></div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" onclick="closeModal('uploadKeywordsModal')">Cancel</button> <button type="submit" class="btn btn-primary">Process Keywords CSV</button> </div> </form> </div> </div>
            </div>

            <!-- Tab 2 Content: Observation Text -->
            <div id="observationTab" class="tab-content">
                <!-- Content removed as per request -->
            </div>
        </div>
    </div>

    <!-- Script for Tab functionality -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const tabButtons = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');

            tabButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const targetTabId = button.dataset.tab;
                    const targetTabContent = document.getElementById(targetTabId);

                    tabButtons.forEach(btn => btn.classList.remove('active'));
                    tabContents.forEach(content => content.classList.remove('active'));

                    button.classList.add('active');
                    targetTabContent.classList.add('active');
                });
            });
        });
    </script>
    
    <!-- Script from your provided code -->
    <script>
        // --- CONSTANTS & GLOBALS ---
        let currentEntityType = null, currentEntityId = null, currentParentId = null, currentParentName = '';
        let filterProgramEl, filterCourseEl, filterKeywordEl, clearFiltersButtonEl; 
    
        // --- UTILITY FUNCTIONS ---
        function generateId(prefix) { return `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1000)}`; }
        function getOriginalName(displayName) {
            if (displayName.startsWith('SOPs-(') && displayName.endsWith(')')) {
                return displayName.substring(6, displayName.length - 1);
            }
            if (displayName.startsWith('Sub-SOP-(') && displayName.endsWith(')')) {
                return displayName.substring(9, displayName.length - 1);
            }
            return displayName;
        }

        // --- MODAL FUNCTIONS ---
        function openModal(modalId) { document.getElementById(modalId).style.display = 'block'; }
        function closeModal(modalId) { 
            const modalElement = document.getElementById(modalId); 
            if (!modalElement) return; 
            modalElement.style.display = 'none'; 
            if (modalId === 'programModal' || modalId === 'courseModal') { 
                const form = document.getElementById(modalId.replace('Modal', 'Form')); 
                if (form) form.reset(); 
                currentEntityType = currentEntityId = currentParentId = currentParentName = null; 
            } else if (modalId === 'uploadCoursesModal' || modalId === 'superAdminCsvUploadModal' || modalId === 'uploadKeywordsModal') {
                const formId = modalId.replace('Modal','Form');
                const statusId = modalId.replace('Modal','Status');
                document.getElementById(formId)?.reset(); 
                const statusEl = document.getElementById(statusId);
                if(statusEl) {
                    statusEl.innerHTML = ''; 
                    statusEl.style.backgroundColor = '#e9ecef'; 
                    statusEl.style.color = 'var(--text-primary)'; 
                }
            }
        }
        function getDisplayValue(element, fieldName) { 
            const contentWrapper = element.querySelector('.entity-content-wrapper'); 
            if (!contentWrapper) return '';
            const el = contentWrapper.querySelector(`p[data-field="${fieldName}"]`);
            return el ? el.textContent.trim() : ''; 
        }
        
        // --- INLINE KEYWORD & ALIAS MANAGEMENT ---
        function renderInteractiveKeywords(entityElement) {
            if (!entityElement) return;
            const entityId = entityElement.id;
            const keywordsContainer = entityElement.querySelector('.keywords-display-container');
            if (!keywordsContainer) return;
    
            const keywordsString = entityElement.dataset.keywords || '';
            const keywords = keywordsString.split(',').map(k => k.trim()).filter(Boolean);
    
            const keywordsListHTML = keywords.map(k => {
                const keywordEscaped = k.replace(/'/g, "\\'");
                return `<span class="keyword-tag">${k}<button class="delete-keyword-btn" onclick="deleteInlineKeyword('${entityId}', '${keywordEscaped}')">×</button></span>`;
            }).join('');
    
            const addKeywordHTML = `
                <div class="add-keyword-wrapper">
                    <button class="add-keyword-btn" onclick="toggleAddKeywordInput(this, true)">
                        <span class="btn-icon">+</span> Add Keyword
                    </button>
                    <div class="add-keyword-input-group hidden">
                        <input type="text" class="add-keyword-input" placeholder="New keyword" onkeydown="handleKeywordInputKeydown(event, '${entityId}')">
                        <button class="save-keyword-btn" onclick="saveNewInlineKeyword(this, '${entityId}')">✓</button>
                        <button class="cancel-keyword-btn" onclick="toggleAddKeywordInput(this.parentElement, false)">×</button>
                    </div>
                </div>
            `;
    
            keywordsContainer.innerHTML = `
                <strong>Keywords:</strong>
                <div class="keywords-list">${keywordsListHTML}</div>
                ${addKeywordHTML}
            `;
            keywordsContainer.style.display = 'flex';
        }
    
        function toggleAddKeywordInput(element, show) {
            const wrapper = element.closest('.add-keyword-wrapper');
            const addButton = wrapper.querySelector('.add-keyword-btn');
            const inputGroup = wrapper.querySelector('.add-keyword-input-group');
            const inputField = wrapper.querySelector('.add-keyword-input');
    
            if (show) {
                addButton.classList.add('hidden');
                inputGroup.classList.remove('hidden');
                inputField.value = '';
                inputField.focus();
            } else {
                addButton.classList.remove('hidden');
                inputGroup.classList.add('hidden');
                inputField.value = '';
            }
        }
    
        function handleKeywordInputKeydown(event, entityId) {
            if (event.key === 'Enter') {
                event.preventDefault();
                saveNewInlineKeyword(event.target, entityId);
            } else if (event.key === 'Escape') {
                event.preventDefault();
                toggleAddKeywordInput(event.target, false);
            }
        }
    
        function saveNewInlineKeyword(element, entityId) {
            const inputGroup = element.closest('.add-keyword-input-group');
            const inputField = inputGroup.querySelector('.add-keyword-input');
            const newKeyword = inputField.value.trim();
    
            if (newKeyword === '') {
                inputField.focus();
                return;
            }
    
            const entityElement = document.getElementById(entityId);
            if (!entityElement) return;
    
            let existingKeywords = (entityElement.dataset.keywords || '').split(',').map(k => k.trim()).filter(Boolean);
            if (!existingKeywords.includes(newKeyword)) {
                existingKeywords.push(newKeyword);
                entityElement.dataset.keywords = existingKeywords.join(', ');
            }
            
            renderInteractiveKeywords(entityElement);

            const newAddButton = entityElement.querySelector('.add-keyword-btn');
            if (newAddButton) {
                toggleAddKeywordInput(newAddButton, true);
            }
        }
    
        function deleteInlineKeyword(entityId, keywordToDelete) {
            const entityElement = document.getElementById(entityId);
            if (!entityElement) return;
            let keywords = (entityElement.dataset.keywords || '').split(',').map(k => k.trim()).filter(Boolean);
            const updatedKeywords = keywords.filter(k => k !== keywordToDelete);
            entityElement.dataset.keywords = updatedKeywords.join(', ');
            renderInteractiveKeywords(entityElement);
        }
    
        // --- CORE CRUD & DISPLAY FUNCTIONS ---
        function openAddModal(entityType, parentId, parentName) {
            currentEntityType = entityType; currentParentId = parentId; currentParentName = parentName; currentEntityId = null;
            let modalId, modalTitleElId, formId, titlePrefix = "Add New";
            if (entityType === 'program') { 
                modalId = 'programModal'; modalTitleElId = 'programModalTitle'; formId = 'programForm';
                document.getElementById('programEntityId').value = '';
                document.getElementById(modalTitleElId).textContent = `${titlePrefix} SOPs`;
            } else if (entityType === 'course') { 
                modalId = 'courseModal'; modalTitleElId = 'courseModalTitle'; formId = 'courseForm';
                document.getElementById('courseParentId').value = parentId;
                document.getElementById(modalTitleElId).textContent = `${titlePrefix} Sub-SOP under "SOPs-(${parentName})"`;
            }
            if (modalId) {
                const formElement = document.getElementById(formId);
                if (formElement) formElement.reset();
                openModal(modalId);
            }
        }
    
        function openEditModal(entityType, entityId) {
            currentEntityType = entityType; currentEntityId = entityId; currentParentId = null;
            const entityEl = document.getElementById(entityId);
            if (!entityEl) { console.error("Entity not found:", entityId); return; }
            let modalId, modalTitleElId, titlePrefix = "Edit";
            const entityNameDisplay = entityEl.querySelector('.entity-name-display').textContent;
            const originalName = getOriginalName(entityNameDisplay);
            const keywords = entityEl.dataset.keywords || '';
    
            if (entityType === 'program') {
                modalId = 'programModal'; modalTitleElId = 'programModalTitle';
                document.getElementById('programEntityId').value = entityId;
                document.getElementById('programNameModal').value = originalName;
                document.getElementById('programDescriptionModal').value = getDisplayValue(entityEl, 'description');
                document.getElementById('programKeywordsModal').value = keywords;
                document.getElementById(modalTitleElId).textContent = `${titlePrefix} SOPs`;
            } else if (entityType === 'course') {
                modalId = 'courseModal'; modalTitleElId = 'courseModalTitle';
                document.getElementById('courseEntityId').value = entityId;
                document.getElementById('courseNameModal').value = originalName;
                document.getElementById('courseDescriptionModal').value = getDisplayValue(entityEl, 'description');
                document.getElementById('courseKeywordsModal').value = keywords;
                document.getElementById(modalTitleElId).textContent = `${titlePrefix} Sub-SOP`;
            }
            if (modalId) openModal(modalId);
        }
    
        function updateDisplay(element, fieldName, newValue) { 
            const contentWrapper = element.querySelector('.entity-content-wrapper');
            if (!contentWrapper) return;
            const descEl = contentWrapper.querySelector(`p[data-field="${fieldName}"]`);
            if (descEl) {
                descEl.textContent = newValue || 'No description provided.'; 
            }
        }
    
        function saveProgram() { 
            const entityIdInput = document.getElementById('programEntityId'); 
            const entityId = entityIdInput.value; 
            const name = document.getElementById('programNameModal').value; 
            const description = document.getElementById('programDescriptionModal').value; 
            const keywords = document.getElementById('programKeywordsModal').value;
            const nameEscaped = name.replace(/'/g, "\\'"); 
            const displayName = `SOPs-(${name})`;
            
            if (entityId) { 
                const progElement = document.getElementById(entityId); 
                if (!progElement) return; 
                progElement.querySelector('.entity-name-display').textContent = displayName; 
                progElement.querySelector('.summary-action-btn.add-course')?.setAttribute('onclick', `openAddModal('course', '${entityId}', '${nameEscaped}')`); 
                progElement.querySelector('.scoped-upload-section .download-sample').setAttribute('onclick', `downloadCourseSampleCsv('${entityId}', '${nameEscaped}')`); 
                progElement.querySelector('.scoped-upload-section .upload-scoped').setAttribute('onclick', `openUploadCoursesCsvModal('${entityId}', '${nameEscaped}')`); 
                progElement.querySelector('.keyword-management-section .download-sample').setAttribute('onclick', `downloadKeywordSampleCsv('${entityId}', '${nameEscaped}')`); 
                progElement.querySelector('.keyword-management-section .upload-scoped').setAttribute('onclick', `openUploadKeywordsCsvModal('${entityId}', '${nameEscaped}')`);
                updateDisplay(progElement, 'description', description); 
                progElement.dataset.keywords = keywords; 
                renderInteractiveKeywords(progElement); 
            } else { 
                const newProgId = generateId('prog'); 
                const mainContentArea = document.getElementById('mainContentArea'); 
                const firstProgram = mainContentArea.querySelector('.training-program'); 
                const programHTML = ` <details class="entity-level training-program" id="${newProgId}" data-status="active" data-keywords="${keywords}"> <summary class="entity-summary"> <div class="summary-content-wrapper"> <span class="entity-icon">🎓</span> <span class="entity-name-display">${displayName}</span> </div> <div class="summary-actions"> <span class="entity-count course-count" id="${newProgId}-course-count"><span class="count-label">Sub-SOPs: </span>0</span> <button type="button" class="edit-btn" onclick="openEditModal('program', '${newProgId}')"><span class="btn-icon">✏️</span><span>Edit</span></button> <button type="button" class="delete-btn" onclick="deleteProgramOrCourse('program', '${newProgId}')"><span class="btn-icon">🗑️</span><span>Delete</span></button> <button type="button" onclick="openAddModal('course', '${newProgId}', '${nameEscaped}')" class="action-button summary-action-btn add-course"><span class="btn-icon">➕</span><span>Add Sub-SOP</span></button> <button type="button" class="action-button summary-action-btn activation-btn active-state" onclick="toggleActivation('${newProgId}', 'program', this)"><span class="btn-icon">🟢</span><span>Active</span></button> <span class="toggler-icon">▶</span> </div> </summary> <div class="scoped-upload-section"> <h4>Bulk Add Sub-SOPs to this SOPs</h4> <div class="button-pair"> <button type="button" class="action-button download-sample" onclick="downloadCourseSampleCsv('${newProgId}', '${nameEscaped}')">📄 Sample CSV for Sub-SOPs</button> <button type="button" class="action-button upload-scoped" onclick="openUploadCoursesCsvModal('${newProgId}', '${nameEscaped}')">⬆️ Upload Sub-SOPs CSV</button> </div> </div> <div class="entity-content-wrapper"><p class="entity-description" data-field="description">${description || 'No description provided.'}</p><div class="keywords-display-container"></div><div class="keyword-management-section"><h4>Bulk Keyword Management</h4><div class="button-pair"><button type="button" class="action-button download-sample" onclick="downloadKeywordSampleCsv('${newProgId}', '${nameEscaped}')">📄 Sample Keywords CSV</button><button type="button" class="action-button upload-scoped" onclick="openUploadKeywordsCsvModal('${newProgId}', '${nameEscaped}')">⬆️ Upload Keywords CSV</button></div></div><div class="course-container"></div></div></details>`; 
                if (firstProgram) { 
                    firstProgram.insertAdjacentHTML('beforebegin', programHTML); 
                } else { 
                    const dashboardDetails = document.querySelector('.super-admin-dashboard-details'); 
                    if(dashboardDetails) dashboardDetails.insertAdjacentHTML('afterend', programHTML); 
                    else { mainContentArea.insertAdjacentHTML('afterbegin', programHTML); } 
                } 
                const newProgElement = document.getElementById(newProgId); 
                if (newProgElement) { 
                    renderInteractiveKeywords(newProgElement); 
                    updateProgramEntityCounts(newProgElement); 
                } 
                entityIdInput.value = ''; 
            } 
            closeModal('programModal'); 
            populateProgramFilter(); 
            applyAllFilters(); 
            updateSuperAdminDashboardStats(); 
        }
    
        function saveCourse() { 
            const entityId = document.getElementById('courseEntityId').value; 
            const parentId = document.getElementById('courseParentId').value; 
            const courseName = document.getElementById('courseNameModal').value; 
            const description = document.getElementById('courseDescriptionModal').value; 
            const keywords = document.getElementById('courseKeywordsModal').value;
            const courseNameEscaped = courseName.replace(/'/g, "\\'");
            const displayName = `Sub-SOP-(${courseName})`;
            
            if (entityId) { 
                const courseElement = document.getElementById(entityId); 
                if (!courseElement) return; 
                courseElement.querySelector('.entity-name-display').textContent = displayName;
                courseElement.querySelector('.keyword-management-section .download-sample').setAttribute('onclick', `downloadKeywordSampleCsv('${entityId}', '${courseNameEscaped}')`);
                courseElement.querySelector('.keyword-management-section .upload-scoped').setAttribute('onclick', `openUploadKeywordsCsvModal('${entityId}', '${courseNameEscaped}')`);
                updateDisplay(courseElement, 'description', description); 
                courseElement.dataset.keywords = keywords; 
                renderInteractiveKeywords(courseElement); 
            } else if (parentId) { 
                const programElement = document.getElementById(parentId); 
                if (!programElement) return; 
                const newCourseId = generateId('course'); 
                const courseHTML = ` <details class="entity-level course-item" id="${newCourseId}" data-status="active" data-keywords="${keywords}"> <summary class="entity-summary"> <div class="summary-content-wrapper"> <span class="entity-icon">📖</span> <span class="entity-name-display">${displayName}</span> </div> <div class="summary-actions">  <button type="button" class="edit-btn" onclick="openEditModal('course', '${newCourseId}')"><span class="btn-icon">✏️</span><span>Edit</span></button> <button type="button" class="delete-btn" onclick="deleteProgramOrCourse('course', '${newCourseId}')"><span class="btn-icon">🗑️</span><span>Delete</span></button> <button type="button" class="action-button summary-action-btn activation-btn active-state" onclick="toggleActivation('${newCourseId}', 'course', this)"><span class="btn-icon">🟢</span><span>Active</span></button> <span class="toggler-icon">▶</span> </div> </summary>  <div class="entity-content-wrapper"><p class="entity-description" data-field="description">${description || 'No description.'}</p><div class="keywords-display-container"></div><div class="keyword-management-section"><h4>Bulk Keyword Management</h4><div class="button-pair"><button type="button" class="action-button download-sample" onclick="downloadKeywordSampleCsv('${newCourseId}', '${courseNameEscaped}')">📄 Sample Keywords CSV</button><button type="button" class="action-button upload-scoped" onclick="openUploadKeywordsCsvModal('${newCourseId}', '${courseNameEscaped}')">⬆️ Upload Keywords CSV</button></div></div></div> </details>`; 
                const courseContainer = programElement.querySelector('.course-container'); 
                courseContainer.insertAdjacentHTML('beforeend', courseHTML); 
                const newCourseElement = document.getElementById(newCourseId); 
                if(newCourseElement) {
                    renderInteractiveKeywords(newCourseElement); 
                }
                updateProgramEntityCounts(programElement); 
            } 
            closeModal('courseModal'); 
            populateCourseFilter(); 
            applyAllFilters(); 
            updateSuperAdminDashboardStats(); 
        }
    
        function deleteProgramOrCourse(entityType, entityId) {
            const entityElement = document.getElementById(entityId);
            if (!entityElement) return;
            const entityName = entityElement.querySelector('.entity-name-display').textContent;
            let message = `Are you sure you want to delete the ${entityType === 'program' ? 'SOPs' : 'Sub-SOP'} "${entityName}"?`;
            if (entityType === 'program') {
                message += " This will also delete all its Sub-SOPs.";
            }
            if (confirm(message)) {
                const parentProgramElement = entityElement.closest('.training-program');
                if (entityType === 'program') {
                    const courses = entityElement.querySelectorAll('.course-item');
                    courses.forEach(course => course.remove());
                }
                entityElement.remove();
                
                if (parentProgramElement && entityType === 'course' && parentProgramElement.id !== entityId) {
                    updateProgramEntityCounts(parentProgramElement);
                }
                populateProgramFilter();
                populateCourseFilter();
                applyAllFilters();
                updateSuperAdminDashboardStats();
            }
        }
        
        function toggleActivation(entityId, entityType, buttonElement) { const entityElement = document.getElementById(entityId); if (!entityElement) return; const currentStatus = entityElement.dataset.status; const newStatus = currentStatus === 'active' ? 'inactive' : 'active'; entityElement.dataset.status = newStatus; buttonElement.classList.toggle('active-state', newStatus === 'active'); buttonElement.classList.toggle('inactive-state', newStatus === 'inactive'); buttonElement.innerHTML = `<span class="btn-icon">${newStatus === 'active' ? '🟢' : '🔴'}</span><span>${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)}</span>`; applyAllFilters(); updateAllCountsAndDisplays(); }
        
        function setSpanText(spanId, label, count) { 
            const spanElement = document.getElementById(spanId); 
            if (spanElement) { 
                const strongElement = spanElement.querySelector('strong');
                const labelElement = spanElement.querySelector('.count-label');
                if(strongElement) {
                    strongElement.textContent = count;
                } else if (labelElement) {
                    spanElement.innerHTML = `<span class="count-label">${label} </span>${count}`; 
                } else {
                    spanElement.innerHTML = `<span class="count-label">${label} </span><strong>${count}</strong>`; 
                }
            }
        }
        
        function updateCourseEntityCounts(courseElement) { 
            if (!courseElement) return; 
        }
    
        function updateProgramEntityCounts(progElement) { 
            if (!progElement) return; 
            const progId = progElement.id; 
            const courses = progElement.querySelectorAll('.course-container .entity-level.course-item:not(.hidden-by-filter)'); 
            setSpanText(`${progId}-course-count`, 'Sub-SOPs: ', courses.length); 
        }
    
        function updateSuperAdminDashboardStats() {
            const allPrograms = document.querySelectorAll('.training-program'); 
            const allCourses = document.querySelectorAll('.course-item'); 
            document.getElementById('dashStatTotalPrograms').textContent = allPrograms.length;
            document.getElementById('dashStatTotalCourses').textContent = allCourses.length;
        }
    
        function updateAllCountsAndDisplays() { 
            document.querySelectorAll('.training-program:not(.hidden-by-filter)').forEach(updateProgramEntityCounts);
            document.querySelectorAll('.course-item:not(.hidden-by-filter)').forEach(updateCourseEntityCounts); 
            updateSuperAdminDashboardStats();
        }
    
        // --- FILTER FUNCTIONS ---
        function populateProgramFilter() { 
            const filterEl = document.getElementById('filterProgram');
            if (!filterEl) return;
            const currentValue = filterEl.value;
            filterEl.innerHTML = '<option value="all">All SOPs</option>';
            document.querySelectorAll('.training-program').forEach(prog => { 
                const name = prog.querySelector('.entity-name-display').textContent;
                filterEl.innerHTML += `<option value="${prog.id}">${name}</option>`;
            });
            filterEl.value = currentValue; 
        }
    
        function populateCourseFilter() { 
            const filterEl = document.getElementById('filterCourse');
            if (!filterEl) return;
            const currentValue = filterEl.value;
            filterEl.innerHTML = '<option value="all">All Sub-SOPs</option>';
            const selectedProgramId = document.getElementById('filterProgram').value;
    
            document.querySelectorAll('.course-item').forEach(course => { 
                const parentProgram = course.closest('.training-program');
                if (selectedProgramId === 'all' || (parentProgram && parentProgram.id === selectedProgramId)) {
                    const name = course.querySelector('.entity-name-display').textContent;
                    const progName = parentProgram?.querySelector('.entity-name-display').textContent || 'Unknown SOPs';
                    filterEl.innerHTML += `<option value="${course.id}">${name} (${progName})</option>`;
                }
            });
             filterEl.value = currentValue; 
        }
    
        function applyAllFilters() {
            const progFilterValue = document.getElementById('filterProgram').value;
            const courseFilterValue = document.getElementById('filterCourse').value;
            const keywordFilterValue = document.getElementById('filterKeyword').value.toLowerCase().trim();
    
            document.querySelectorAll('.training-program, .course-item').forEach(el => el.classList.remove('hidden-by-filter'));
    
            document.querySelectorAll('.training-program').forEach(prog => {
                const name = prog.querySelector('.entity-name-display').textContent.toLowerCase();
                const description = getDisplayValue(prog, 'description').toLowerCase();
                const userKeywords = (prog.dataset.keywords || '').toLowerCase();
                
                const programMatchesKeyword = keywordFilterValue === '' || `${name} ${description} ${userKeywords}`.includes(keywordFilterValue);
                const programMatchesDropdown = progFilterValue === 'all' || prog.id === progFilterValue;
    
                let hasVisibleCourse = false;
    
                prog.querySelectorAll('.course-item').forEach(course => {
                    const cName = course.querySelector('.entity-name-display').textContent.toLowerCase();
                    const cDescription = getDisplayValue(course, 'description').toLowerCase();
                    const cUserKeywords = (course.dataset.keywords || '').toLowerCase();

                    const courseMatchesKeyword = keywordFilterValue === '' || `${cName} ${cDescription} ${cUserKeywords}`.includes(keywordFilterValue);
                    const courseMatchesDropdown = courseFilterValue === 'all' || course.id === courseFilterValue;
                    
                    const courseIsVisible = courseMatchesDropdown && courseMatchesKeyword;
                    
                    if (!courseIsVisible) {
                        course.classList.add('hidden-by-filter');
                    }
                    if (courseIsVisible && programMatchesDropdown) {
                        hasVisibleCourse = true;
                    }
                });
                const programIsVisible = programMatchesDropdown && (programMatchesKeyword || hasVisibleCourse);
                
                if(!programIsVisible) {
                    prog.classList.add('hidden-by-filter');
                }
            });
    
            populateCourseFilter();
            updateAllCountsAndDisplays();
        }
    
        function clearAllFilters() {
            document.getElementById('filterProgram').value = 'all';
            document.getElementById('filterCourse').value = 'all';
            document.getElementById('filterKeyword').value = '';
            applyAllFilters();
        }
    
        // --- CSV HANDLING FUNCTIONS ---
        function downloadFullSampleCsv() {
            const csvContent = `Level,ParentName,Name,Description,Keywords
SOPs,,Foundational Skills Program,"Core training for all new employees","onboarding, core, compliance"
Sub-SOP,Foundational Skills Program,Intro to Company Policies,"Overview of key company policies","hr, policy, procedures"
SOPs,,Advanced Leadership Development,"For senior managers and team leads","leadership, management, advanced"
Sub-SOP,Advanced Leadership Development,Strategic Thinking Workshop,"Develop strategic planning skills","strategy, planning, executive"`;
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', 'full_sops_sample.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    
        function downloadCourseSampleCsv(progId, progName) { 
            const csvContent = `Level,ParentName,Name,Description,Keywords
Sub-SOP,${progName},New Sub-SOP Title,"Sub-SOP description details","keyword1, keyword2"`;
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', `sub-sops_sample_for_${progName.replace(/[^a-z0-9]/gi, '_')}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    
        function downloadKeywordSampleCsv(entityId, entityName) {
            const csvContent = `Keywords\nkeyword1\nsample-keyword\nanother-one`;
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', `keywords_sample_for_${entityName.replace(/[^a-z0-9]/gi, '_')}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function openUploadKeywordsCsvModal(entityId, entityName) {
            document.getElementById('uploadKeywordsForm').reset(); 
            document.getElementById('uploadKeywordsStatus').innerHTML = ''; 
            document.getElementById('uploadKeywordsEntityId').value = entityId; 
            document.getElementById('uploadKeywordsEntityName').value = entityName; 
            document.getElementById('uploadKeywordsTargetEntityName').textContent = entityName; 
            openModal('uploadKeywordsModal'); 
        }

        function handleUploadKeywordsCsv() {
            const fileInput = document.getElementById('uploadKeywordsFileCsv');
            const statusEl = document.getElementById('uploadKeywordsStatus');
            const entityId = document.getElementById('uploadKeywordsEntityId').value;
            const entityElement = document.getElementById(entityId);

            if (!fileInput.files.length) {
                statusEl.textContent = 'Please select a CSV file first.';
                statusEl.style.backgroundColor = '#ffebee'; statusEl.style.color = '#c62828';
                return;
            }
            if (!entityElement) {
                statusEl.textContent = 'Target entity not found. Please close and try again.';
                statusEl.style.backgroundColor = '#ffebee'; statusEl.style.color = '#c62828';
                return;
            }

            const file = fileInput.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const csvData = e.target.result;
                    const lines = csvData.split(/\r?\n/).filter(line => line.trim() !== '');
                    if (lines.length <= 1) { // Header only or empty
                        throw new Error('CSV is empty or contains only a header.');
                    }
                    
                    const newKeywords = lines.slice(1).map(line => line.split(',')[0].trim()).filter(Boolean);
                    
                    if(newKeywords.length === 0) {
                        throw new Error('No valid keywords found in the CSV file.');
                    }

                    const existingKeywords = new Set((entityElement.dataset.keywords || '').split(',').map(k => k.trim()).filter(Boolean));
                    newKeywords.forEach(k => existingKeywords.add(k));

                    entityElement.dataset.keywords = Array.from(existingKeywords).join(', ');
                    renderInteractiveKeywords(entityElement); 

                    statusEl.innerHTML = `Successfully added/merged ${newKeywords.length} keywords.`;
                    statusEl.style.backgroundColor = '#e8f5e9'; statusEl.style.color = '#2e7d32';

                    setTimeout(() => closeModal('uploadKeywordsModal'), 2000);
                } catch (error) {
                    console.error('Error processing Keywords CSV:', error);
                    statusEl.innerHTML = 'Error processing CSV file: ' + error.message;
                    statusEl.style.backgroundColor = '#ffebee'; statusEl.style.color = '#c62828';
                }
            };
            reader.readAsText(file);
        }

        function openSuperAdminCsvUploadModal() {
            document.getElementById('superAdminCsvUploadForm').reset();
            document.getElementById('superAdminCsvUploadStatus').innerHTML = '';
            openModal('superAdminCsvUploadModal');
        }
    
        function openUploadCoursesCsvModal(progId, progName) { 
            document.getElementById('uploadCoursesForm').reset(); 
            document.getElementById('uploadCoursesStatus').innerHTML = ''; 
            document.getElementById('uploadCoursesProgramId').value = progId; 
            document.getElementById('uploadCoursesProgramName').value = progName; 
            document.getElementById('uploadCoursesTargetProgramName').textContent = `SOPs-(${progName})`; 
            document.getElementById('uploadCoursesTargetProgramNameMirror').textContent = `SOPs-(${progName})`; 
            openModal('uploadCoursesModal'); 
        }
        
        function handleSuperAdminCsvUpload() {
            const fileInput = document.getElementById('superAdminFileCsv');
            const statusEl = document.getElementById('superAdminCsvUploadStatus');
            if (!fileInput.files.length) {
                statusEl.textContent = 'Please select a CSV file first.';
                statusEl.style.backgroundColor = '#ffebee';
                statusEl.style.color = '#c62828';
                return;
            }
    
            const file = fileInput.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const csvData = e.target.result;
                    const lines = csvData.split('\n').filter(line => line.trim() !== ''); 
                    const headers = lines[0].split(',').map(h => h.trim().toLowerCase()); 
                    
                    const requiredHeaders = ['level', 'name'];
                    if (!requiredHeaders.every(rh => headers.includes(rh))) {
                        statusEl.innerHTML = 'Error: CSV must contain "Level" and "Name" columns.';
                        statusEl.style.backgroundColor = '#ffebee';
                        statusEl.style.color = '#c62828';
                        return;
                    }
    
                    const programEntities = []; 
                    const courseEntities = []; 
    
                    for (let i = 1; i < lines.length; i++) {
                        const values = lines[i].split(',');
                        const entity = {};
                        headers.forEach((header, index) => {
                            entity[header] = values[index] ? values[index].trim() : '';
                        });
                        
                        if (entity.level.toLowerCase() === 'sops') { 
                            programEntities.push(entity);
                        } else if (entity.level.toLowerCase() === 'sub-sop') { 
                            courseEntities.push(entity);
                        }
                    }
    
                    programEntities.forEach(processProgramFromCsv); 
                    courseEntities.forEach(processCourseFromCsv); 
    
                    statusEl.innerHTML = 'Successfully processed CSV file!<br>' +
                        `SOPs: ${programEntities.length}<br>` +
                        `Sub-SOPs: ${courseEntities.length}`;
                    statusEl.style.backgroundColor = '#e8f5e9';
                    statusEl.style.color = '#2e7d32';
    
                } catch (error) {
                    console.error('Error processing CSV:', error);
                    statusEl.innerHTML = 'Error processing CSV file: ' + error.message;
                    statusEl.style.backgroundColor = '#ffebee';
                    statusEl.style.color = '#c62828';
                } finally {
                    populateProgramFilter();
                    populateCourseFilter();
                    updateAllCountsAndDisplays();
                    applyAllFilters(); 
                    setTimeout(() => closeModal('superAdminCsvUploadModal'), 2000);
                }
            };
            reader.readAsText(file);
        }
    
        function processProgramFromCsv(csvRow) { 
            const name = csvRow.name;
            const description = csvRow.description || 'No description provided.';
            const keywords = csvRow.keywords || '';
            const displayName = `SOPs-(${name})`;
            
            const existingProgElement = Array.from(document.querySelectorAll('.training-program .entity-name-display'))
                                       .find(el => el.textContent.trim() === displayName.trim());
            if (existingProgElement) {
                console.log(`SOPs "${name}" already exists. Skipping creation.`);
                return existingProgElement.closest('.training-program').id;
            }
    
            const progId = generateId('prog'); 
            const nameEscaped = name.replace(/'/g, "\\'");
            const progHTML = `
                <details class="entity-level training-program" id="${progId}" data-status="active" data-keywords="${keywords}">
                    <summary class="entity-summary"> <div class="summary-content-wrapper"> <span class="entity-icon">🎓</span> <span class="entity-name-display">${displayName}</span> </div> <div class="summary-actions"> <span class="entity-count course-count" id="${progId}-course-count"><span class="count-label">Sub-SOPs: </span>0</span> <button type="button" class="edit-btn" onclick="openEditModal('program', '${progId}')"><span class="btn-icon">✏️</span><span>Edit</span></button> <button type="button" class="delete-btn" onclick="deleteProgramOrCourse('program', '${progId}')"><span class="btn-icon">🗑️</span><span>Delete</span></button> <button type="button" onclick="openAddModal('course', '${progId}', '${nameEscaped}')" class="action-button summary-action-btn add-course"><span class="btn-icon">➕</span><span>Add Sub-SOP</span></button> <button type="button" class="action-button summary-action-btn activation-btn active-state" onclick="toggleActivation('${progId}', 'program', this)"><span class="btn-icon">🟢</span><span>Active</span></button> <span class="toggler-icon">▶</span> </div> </summary>
                    <div class="scoped-upload-section"> <h4>Bulk Add Sub-SOPs to this SOPs</h4> <div class="button-pair"> <button type="button" class="action-button download-sample" onclick="downloadCourseSampleCsv('${progId}', '${nameEscaped}')">📄 Sample CSV for Sub-SOPs</button> <button type="button" class="action-button upload-scoped" onclick="openUploadCoursesCsvModal('${progId}', '${nameEscaped}')">⬆️ Upload Sub-SOPs CSV</button> </div> </div>
                    <div class="entity-content-wrapper"><p class="entity-description" data-field="description">${description}</p><div class="keywords-display-container"></div><div class="keyword-management-section"><h4>Bulk Keyword Management</h4><div class="button-pair"><button type="button" class="action-button download-sample" onclick="downloadKeywordSampleCsv('${progId}', '${nameEscaped}')">📄 Sample Keywords CSV</button><button type="button" class="action-button upload-scoped" onclick="openUploadKeywordsCsvModal('${progId}', '${nameEscaped}')">⬆️ Upload Keywords CSV</button></div></div><div class="course-container"></div></div>
                </details>`;
            
            const mainContentArea = document.getElementById('mainContentArea');
            const firstProgram = mainContentArea.querySelector('.training-program');
            if (firstProgram) {
                firstProgram.insertAdjacentHTML('beforebegin', progHTML);
            } else {
                const dashboardDetails = document.querySelector('.super-admin-dashboard-details');
                if (dashboardDetails) {
                    dashboardDetails.insertAdjacentHTML('afterend', progHTML);
                } else { 
                    mainContentArea.insertAdjacentHTML('afterbegin', progHTML);
                }
            }
            const newProgElement = document.getElementById(progId);
            if(newProgElement) {
                renderInteractiveKeywords(newProgElement);
            }
            return progId;
        }
    
    
        function processCourseFromCsv(csvRow) { 
            const programName = csvRow.parentname;
            const name = csvRow.name;
            const description = csvRow.description || 'No description.';
            const keywords = csvRow.keywords || '';
            const courseNameEscaped = name.replace(/'/g, "\\'");
            const courseDisplayName = `Sub-SOP-(${name})`;
            const programDisplayName = `SOPs-(${programName})`;
            
            const programElement = Array.from(document.querySelectorAll('.training-program')).find(prog =>
                prog.querySelector('.entity-name-display').textContent.trim() === programDisplayName.trim()
            );
    
            if (!programElement) {
                console.warn(`CSV Warning: SOPs parent "${programName}" not found for Sub-SOP "${name}". Skipping.`);
                return null;
            }
            
            const existingCourseElement = Array.from(programElement.querySelectorAll('.course-item .entity-name-display')).find(el => el.textContent.trim() === courseDisplayName.trim());
            if (existingCourseElement) {
                console.log(`Sub-SOP "${name}" under SOPs "${programName}" already exists. Skipping.`);
                return existingCourseElement.closest('.course-item').id;
            }
    
            const courseId = generateId('course'); 
            const courseHTML = `
                <details class="entity-level course-item" id="${courseId}" data-status="active" data-keywords="${keywords}">
                    <summary class="entity-summary"> <div class="summary-content-wrapper"> <span class="entity-icon">📖</span> <span class="entity-name-display">${courseDisplayName}</span> </div> <div class="summary-actions"> <button type="button" class="edit-btn" onclick="openEditModal('course', '${courseId}')"><span class="btn-icon">✏️</span><span>Edit</span></button> <button type="button" class="delete-btn" onclick="deleteProgramOrCourse('course', '${courseId}')"><span class="btn-icon">🗑️</span><span>Delete</span></button> <button type="button" class="action-button summary-action-btn activation-btn active-state" onclick="toggleActivation('${courseId}', 'course', this)"><span class="btn-icon">🟢</span><span>Active</span></button> <span class="toggler-icon">▶</span> </div> </summary>
                    <div class="entity-content-wrapper"><p class="entity-description" data-field="description">${description}</p><div class="keywords-display-container"></div><div class="keyword-management-section"><h4>Bulk Keyword Management</h4><div class="button-pair"><button type="button" class="action-button download-sample" onclick="downloadKeywordSampleCsv('${courseId}', '${courseNameEscaped}')">📄 Sample Keywords CSV</button><button type="button" class="action-button upload-scoped" onclick="openUploadKeywordsCsvModal('${courseId}', '${courseNameEscaped}')">⬆️ Upload Keywords CSV</button></div></div></div>
                </details>`;
            
            const courseContainer = programElement.querySelector('.course-container');
            if (courseContainer) {
                courseContainer.insertAdjacentHTML('beforeend', courseHTML);
                const newCourseElement = document.getElementById(courseId);
                if(newCourseElement) {
                    renderInteractiveKeywords(newCourseElement);
                }
            } else {
                console.error(`CRITICAL ERROR: Could not find .course-container in SOPs "${programName}" (ID: ${programElement.id}) while trying to add Sub-SOP "${name}".`);
                return null; 
            }
            return courseId;
        }
    
        function handleUploadCoursesCsv() { 
            const fileInput = document.getElementById('uploadCoursesFileCsv'); 
            const statusEl = document.getElementById('uploadCoursesStatus'); 
            const progId = document.getElementById('uploadCoursesProgramId').value; 
            const progName = document.getElementById('uploadCoursesProgramName').value; 
            
            if (!fileInput.files.length) {
                statusEl.textContent = 'Please select a CSV file first.';
                statusEl.style.backgroundColor = '#ffebee';
                statusEl.style.color = '#c62828';
                return;
            }
    
            const file = fileInput.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const csvData = e.target.result;
                    const lines = csvData.split('\n').filter(line => line.trim() !== '');
                    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
                    
                    const requiredHeaders = ['level', 'name'];
                    if (!requiredHeaders.every(rh => headers.includes(rh))) {
                        statusEl.innerHTML = 'Error: CSV must contain "Level" and "Name" columns.';
                        statusEl.style.backgroundColor = '#ffebee';
                        statusEl.style.color = '#c62828';
                        return;
                    }
    
                    const courseEntities = []; 
    
                    for (let i = 1; i < lines.length; i++) {
                        const values = lines[i].split(',');
                        const entity = {};
                        headers.forEach((header, index) => {
                            entity[header] = values[index] ? values[index].trim() : '';
                        });
    
                        if (entity.level.toLowerCase() === 'sub-sop') { 
                            entity.parentname = progName; 
                            courseEntities.push(entity);
                        }
                    }
    
                    courseEntities.forEach(processCourseFromCsv); 
    
                    statusEl.innerHTML = 'Successfully processed CSV file!<br>' +
                        `Sub-SOPs Added: ${courseEntities.length}`;
                    statusEl.style.backgroundColor = '#e8f5e9';
                    statusEl.style.color = '#2e7d32';
                } catch (error) {
                    console.error('Error processing CSV:', error);
                    statusEl.innerHTML = 'Error processing CSV file: ' + error.message;
                    statusEl.style.backgroundColor = '#ffebee';
                    statusEl.style.color = '#c62828';
                } finally {
                    const programElement = document.getElementById(progId);
                    if (programElement) updateProgramEntityCounts(programElement);
                    populateCourseFilter(); 
                    updateAllCountsAndDisplays();
                    applyAllFilters();
                    setTimeout(() => closeModal('uploadCoursesModal'), 2000);
                }
            };
            reader.readAsText(file);
        }
    
    
        // --- INITIALIZATION ---
        document.addEventListener('DOMContentLoaded', function() {
            filterProgramEl = document.getElementById('filterProgram'); 
            filterCourseEl = document.getElementById('filterCourse');
            filterKeywordEl = document.getElementById('filterKeyword'); 
            clearFiltersButtonEl = document.getElementById('clearFiltersButton');
    
            if (filterProgramEl) filterProgramEl.addEventListener('change', () => {
                if(filterCourseEl) filterCourseEl.value = 'all';
                applyAllFilters();
            });
            if (filterCourseEl) filterCourseEl.addEventListener('change', applyAllFilters);
            if (filterKeywordEl) filterKeywordEl.addEventListener('input', applyAllFilters);
            if (clearFiltersButtonEl) clearFiltersButtonEl.addEventListener('click', clearAllFilters);
            
            document.querySelectorAll('.entity-level').forEach(el => {
                renderInteractiveKeywords(el);
            });
    
            populateProgramFilter(); 
            populateCourseFilter(); 
            updateAllCountsAndDisplays();
            applyAllFilters(); 
        });
    
        // Close modals when clicking outside
        window.addEventListener('click', function(event) {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                if (event.target === modal) {
                    closeModal(modal.id);
                }
            });
        });
    </script>

</body>
</html>
<?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/training/topiclist.blade.php ENDPATH**/ ?>