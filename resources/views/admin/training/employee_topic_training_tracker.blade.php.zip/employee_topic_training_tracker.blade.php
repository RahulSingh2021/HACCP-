@extends('layouts.app1', ['pagetitle' => 'Dashboard'])
@section('content')
    <link href="{{ asset('assets/plugins/fancy-file-uploader/fancy_fileupload.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/plugins/Drag-And-Drop/dist/imageuploadify.min.css') }}" rel="stylesheet" />
    <style>
        .step-number {
            border-top: #333 2px solid;
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            position: relative;
        }

        .step-number:before {
            content: "";
            background: #fff;
            display: block;
            position: absolute;
            height: 3px;
            width: 27px;
            top: -2px;
            z-index: 0;
        }

        .step-number:after {
            content: "";
            background: #fff;
            display: block;
            position: absolute;
            height: 3px;
            width: 27px;
            top: -2px;
            z-index: 0;
            right: 0;
        }

        .step-number span {
            margin-top: -15px;
            text-align: center;
            z-index: 1;
        }

        .step-number em {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: inline-block;
            text-align: center;
            font-style: normal;
            line-height: 30px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .ins-t td {
            font-size: 13px;
            padding: 5px 0px;
        }

        .cam-img {
            width: 100%;
            background: #f7f7f7;
            height: 80%;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .imageuploadify {
            min-height: 150px;
        }

        .imageuploadify-message {
            display: none !important;
        }

        .imageuploadify .imageuploadify-images-list i {
            font-size: 3em;
            height: 50px;
        }
        
        
        
        html {
  box-sizing: border-box;
}
*,
*:before,
*:after {
  box-sizing: inherit;
}
.intro {
  max-width: 1280px;
  margin: 1em auto;
}
.table-scroll {
  position: relative;
  width:100%;
  z-index: 1;
  margin: auto;
  overflow: auto;
  height: 350px;
}
.table-scroll table {
  width: 100%;
  min-width: 1280px;
  margin: auto;
  border-collapse: separate;
  border-spacing: 0;
}
.table-wrap {
  position: relative;
}
.table-scroll th,
.table-scroll td {
  padding: 5px 10px;
  border: 1px solid #000;
  background: #fff;
  vertical-align: top;
}
.table-scroll thead th {
  background: #333;
  color: #fff;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}
/* safari and ios need the tfoot itself to be position:sticky also */
.table-scroll tfoot,
.table-scroll tfoot th,
.table-scroll tfoot td {
  position: -webkit-sticky;
  position: sticky;
  bottom: 0;
  background: #666;
  color: #fff;
  z-index:4;
}

a:focus {
  background: red;
} /* testing links*/

th:first-child {
  position: -webkit-sticky;
  position: sticky;
  left: 0;
  z-index: 2;
  background: #ccc;
}
thead th:first-child,
tfoot th:first-child {
  z-index: 5;
}

    </style>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    @include('admin.training.training_navbar')
                    <div class="d-flex justify-content-between">
                        <h5 class="mb-0 d-flex align-items-center">Employee Training Tracker
                        </h5>
                        <div class="empopt">
                            <a href="{{ route('employee_month_training_tracker') }}"
                                class="{{ Request::is('trainers/employee_month_training_tracker') ? 'active' : '' }}">Month</a>
                            <a href="{{ route('employee_topic_training_tracker') }}"
                                class="{{ Request::is('trainers/employee_topic_training_tracker') ? 'active' : '' }}">Topic</a>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active">
                            <hr>
                            <div class="row row-cols-auto g-3 mb-3">
                                <div class="col-6">
                                    <div class="row row-cols-auto g-2">
                                        <div class="col-3"><label>Training topic </label>
                                            <input type="text" class="form-control" placeholder="">
                                        </div>
                                        <div class="col-2">
                                            <label>Status </label>
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected="">Select</option>
                                                <option value="1">Attended</option>
                                                <option value="2">Not Attended</option>
                                            </select>
                                        </div>
                                        <div class="col-3">
                                            <label>Select Department </label>
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected="">Select</option>
                                                <option value="1">Option 1</option>
                                                <option value="2">Option 2</option>
                                                <option value="3">Option 3</option>
                                            </select>
                                        </div>
                                        <div class="col-2"><label>From</label>
                                            <input type="date" class="form-control" placeholder="">
                                        </div>
                                        <div class="col-2"><label>To</label>
                                            <input type="date" class="form-control" placeholder="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="row row-cols-auto g-2">
                                        <div class="col-3">
                                            <label>Joning From</label>
                                            <input type="date" class="form-control" placeholder="">
                                        </div>
                                        <div class="col-3">
                                            <label>Joning To</label>
                                            <input type="date" class="form-control" placeholder="">
                                        </div>
                                        <div class="col-4">
                                            <label>Employee name or ID</label>
                                            <input type="text" class="form-control" placeholder="">
                                        </div>
                                        <div class="col-2">
                                            <label></label>
                                            <button type="button" class="btn w-100 btn-secondary px-3">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-cols-auto">
                                <div class="mt-3 col-12">
                                    <div class="table-responsive Hscrolldesign">
                                        <div class="employeeData" >
                                            <table border="0" cellpadding="0" cellspacing="0">
                                                <tbody>
                                                    <tr>
                                                        <th class="headcol">
                                                            <table border="0" cellpadding="0" cellspacing="0" class="employdetail table-responsive" style="width: 346px;margin-top: 8px;">
                                                                <tbody>
                                                                    <tr>
                                                                        <th><strong>Sr No.</strong></th>
                                                                        <th><strong>Employee Details</strong></th>
                                                                    </tr>
                                                                    @php $i=1; @endphp
                                                                    @forelse($unit_users_list as $unit_user)
                                                                        <tr>
                                                                            <td>
                                                                                <strong>{{ $i }}.</strong> <span
                                                                                    class="empselect"><input type="checkbox"
                                                                                        name=""></span>
                                                                            </td>
                                                                            <td>
                                                                                <strong
                                                                                    class="empName">{{ $unit_user->employer_fullname }}</strong>
                                                                                <span class="departmentbg"
                                                                                    title="Department">
                                                                                    @php
                                                                                        $department_name = DB::table('departments')
                                                                                            ->where('id', $unit_user->department)
                                                                                            ->first();
                                                                                    @endphp
                                                                                    {{ $department_name->name ?? '' }}
                                                                                </span>
                                                                                <!--<span class="assimanagerbg"-->
                                                                                <!--    title="Designation">-->
                                                                                <!--    {{ $unit_user->designation }}-->
                                                                                <!--</span>-->
                                                                                <span class="datejoinbg"
                                                                                    title="Date of joining">{{ $unit_user->dog }}</span>
                                                                            </td>
                                                                        </tr>
                                                                        @php $i++;@endphp
                                                                    @empty
                                                                        <tr>
                                                                            <td colspan="2" class="text-center">No Data
                                                                                Found</td>
                                                                        </tr>
                                                                    @endforelse
                                                                </tbody>
                                                            </table>
                                                        </th>
                                                        <td>
                                                            <table border="0" cellpadding="0" cellspacing="0"
                                                                class="monthwise">
                                                                <tbody>
                                                                    @php $i=1; @endphp
                                                                    <tr>
                                                                        
	
                                                                        
                                                                           <th><strong>FoSTaC</strong>
                                                                            </th>
                                                                        @forelse($training_types_list as $training_type)
                                                                            <th><strong>{{ $training_type->name }}</strong>
                                                                            </th>
                                                                        @empty
                                                                        @endforelse
                                                                    </tr>
                                                                    
                                                             

                                                                    @forelse($unit_users_list as $unit_user)
                                                                    
<div class="modal fade " id="upload{{$unit_user->id}}" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">

<h5 class="modal-title">Upload:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="{{route('saveDocuments')}}" enctype="multipart/form-data">
@csrf
<div class="row">

<input type="hidden" name="unit_id" value="{{$unit_user->id}}">

<div class="mb-3 col-md-6">
<label class="form-label">Next Due Date:</label>
<input type="date" class="form-control"  name="due_date" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload: <span style="color: red;">*(Maxium Size 2MB)</span></label>
<input type="file" class="form-control"  name="image" placeholder="" >
@if($errors->has('image1'))
<div class="error">{{ $errors->first('image1') }}</div>
@endif
</div>




<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
                                                                        <tr>
                                                                            <td>
  <strong><a style="color: #000;" data-bs-toggle="modal" data-bs-target="#upload{{$unit_user->id}}"><i class="font-20 bx bxs-cloud-upload"></i> Upload </a></strong>
  <br>

                                                                                
                                                                                  @php $documents_list = DB::table('pepole_managment_documents')->where('unit_id', $unit_user->id)->get(); @endphp
        @foreach($documents_list as $documents_lists)
        <div class="modal fade " id="edit_documents{{$documents_lists->id}}" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">

<h5 class="modal-title">Upload:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="{{route('saveDocuments')}}" enctype="multipart/form-data">
@csrf
<div class="row">

<input type="hidden" name="edit_id" value="{{$documents_lists->id}}">

<div class="mb-3 col-md-6">
<label class="form-label">Next Due Date:</label>
<input type="date" class="form-control"  name="due_date" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload: <span style="color: red;">*(Maxium Size 2MB)</span></label>
<input type="file" class="form-control"  name="image" placeholder="" >
@if($errors->has('image1'))
<div class="error">{{ $errors->first('image1') }}</div>
@endif
</div>




<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
        
        <a target="_blank()" href="{{asset('documents')}}/{{$documents_lists->image ?? ''}}">View</a><br>
              <a style="color: #000;    color: #0a58ca;cursor: pointer;"  data-bs-toggle="modal" data-bs-target="#edit_documents{{$documents_lists->id}}" ><i class="font-20 bx bx-pencil font-18 me-1"></i>Edit </a>
</a>
<a href="{{route('destorypepoleDocuments',$documents_lists->id)}}" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="font-20 bx bxs-trash"></i></a>
        @endforeach
                                                                                </td>
                                                                            @forelse($training_types_list as $training_type)
                                                                                <td>
                                                                                    <div class="trainingdetails">
                                                                                        <div class="tarainig01">
                                                                                            <span class="traininghrsbg"
                                                                                                title="Training Hrs">Tr: Mr.
                                                                                                Shrikant Prasad</span>
                                                                                            <span class="countbg"
                                                                                                title="Content Count">16/Jan/2024</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">00:30
                                                                                                Min</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">Test
                                                                                                Result</span>
                                                                                        </div>
                                                                                        <div class="tarainig01">
                                                                                            <span class="traininghrsbg"
                                                                                                title="Training Hrs">Tr:
                                                                                                Mr.
                                                                                                Shrikant Prasad</span>
                                                                                            <span class="countbg"
                                                                                                title="Content Count">16/Jan/2024</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">00:30
                                                                                                Min</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">Test
                                                                                                Result</span>
                                                                                        </div>
                                                                                        <div class="tarainig01">
                                                                                            <span class="traininghrsbg"
                                                                                                title="Training Hrs">Tr:
                                                                                                Mr.
                                                                                                Shrikant Prasad</span>
                                                                                            <span class="countbg"
                                                                                                title="Content Count">16/Jan/2024</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">00:30
                                                                                                Min</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">Test
                                                                                                Result</span>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="viewbtnbox"><a
                                                                                            href="#"
                                                                                            class="viewdetailbtn"
                                                                                            title="View Detail"><img
                                                                                                src="{{ asset('assets/images/view-details.png') }}"></a>
                                                                                    </div>
                                                                                </td>
                                                                            @empty
                                                                            @endforelse
                                                                        </tr>
                                                                    @empty
                                                                    @endforelse


                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end row-->
    </div>
    
<div id="table-scroll" class="table-scroll">
  <table id="main-table" class="main-table">
    <thead>
      <tr>
        <th scope="col">Employee Details</th>
            @php $i=1; @endphp
            
              <th><strong>FoSTaC</strong>
            @forelse($training_types_list as $training_type)
            <th scope="col"><strong>{{ $training_type->name }}</strong>
            </th>
            @empty
            @endforelse
                                                                 
      </tr>
    </thead>
    <tbody>

                                                                     @php $i=1; @endphp
                                                                    @forelse($unit_users_list as $unit_user)
<th>
                                                                                <strong
                                                                                    class="empName">{{ $unit_user->employer_fullname }}</strong>
                                                                                <span class="departmentbg"
                                                                                    title="Department">
                                                                                    @php
                                                                                        $department_name = DB::table('departments')->where('id', $unit_user->department)->first();
                                                                                    @endphp
                                                                                    {{ $department_name->name ?? '' }}
                                                                                </span>
                                                                                <span class="datejoinbg"
                                                                                    title="Date of joining">{{ $unit_user->dog }}</span>
                     
             </th>
             
             <td> <strong><a style="color: #000;" data-bs-toggle="modal" data-bs-target="#upload{{$unit_user->id}}"><i class="font-20 bx bxs-cloud-upload"></i> Upload </a></strong>
  <br>

                                                                                
                                                                                  @php $documents_list = DB::table('pepole_managment_documents')->where('unit_id', $unit_user->id)->get(); @endphp
        @foreach($documents_list as $documents_lists)
        <div class="modal fade " id="edit_documents{{$documents_lists->id}}" tabindex="-1" aria-hidden="true" >
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">

<h5 class="modal-title">Upload:</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="post" action="{{route('saveDocuments')}}" enctype="multipart/form-data">
@csrf
<div class="row">

<input type="hidden" name="edit_id" value="{{$documents_lists->id}}">

<div class="mb-3 col-md-6">
<label class="form-label">Next Due Date:</label>
<input type="date" class="form-control"  name="due_date" placeholder="" >
</div>
<div class="mb-3 col-md-6">
<label class="form-label">Upload: <span style="color: red;">*(Maxium Size 2MB)</span></label>
<input type="file" class="form-control"  name="image" placeholder="" >
@if($errors->has('image1'))
<div class="error">{{ $errors->first('image1') }}</div>
@endif
</div>




<div class="mb-3 col-md-12 text-center">
<hr>
<button type="submit" class="btn btn-primary">Upload</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
        
        <a target="_blank()" href="{{asset('documents')}}/{{$documents_lists->image ?? ''}}">View</a><br>
              <a style="color: #000;    color: #0a58ca;cursor: pointer;"  data-bs-toggle="modal" data-bs-target="#edit_documents{{$documents_lists->id}}" ><i class="font-20 bx bx-pencil font-18 me-1"></i>Edit </a>
</a>
<a href="{{route('destorypepoleDocuments',$documents_lists->id)}}" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="font-20 bx bxs-trash"></i></a>
        @endforeach</td>
             
                                                                                         @forelse($training_types_list as $training_type)

       <td>
           
           
                                                                                    <div class="trainingdetails">
                                                                                        <div class="tarainig01">
                                                                                            <span class="traininghrsbg"
                                                                                                title="Training Hrs">Tr: Mr.
                                                                                                Shrikant Prasad</span>
                                                                                            <span class="countbg"
                                                                                                title="Content Count">16/Jan/2024</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">00:30
                                                                                                Min</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">Test
                                                                                                Result</span>
                                                                                        </div>
                                                                                        <div class="tarainig01">
                                                                                            <span class="traininghrsbg"
                                                                                                title="Training Hrs">Tr:
                                                                                                Mr.
                                                                                                Shrikant Prasad</span>
                                                                                            <span class="countbg"
                                                                                                title="Content Count">16/Jan/2024</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">00:30
                                                                                                Min</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">Test
                                                                                                Result</span>
                                                                                        </div>
                                                                                        <div class="tarainig01">
                                                                                            <span class="traininghrsbg"
                                                                                                title="Training Hrs">Tr:
                                                                                                Mr.
                                                                                                Shrikant Prasad</span>
                                                                                            <span class="countbg"
                                                                                                title="Content Count">16/Jan/2024</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">00:30
                                                                                                Min</span>
                                                                                            <span class="lastattendbg"
                                                                                                title="Last Attended on">Test
                                                                                                Result</span>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="viewbtnbox"><a
                                                                                            href="#"
                                                                                            class="viewdetailbtn"
                                                                                            title="View Detail"><img
                                                                                                src="{{ asset('assets/images/view-details.png') }}"></a>
                                                                                    </div>
                                                                                </td>
          
                @empty
            @endforelse
   
      </tr>
      
             @php $i++;@endphp
               @empty
             @endforelse
      
    </tbody>
    <tfoot>
      <tr>
  <th scope="col">Employee Details</th>
@php $i=1; @endphp
            
             <td><strong>FoSTaC</strong>
            </td>
            @forelse($training_types_list as $training_type)
            <td><strong>{{ $training_type->name }}</strong>
            </td>
            @empty
            @endforelse
      </tr>
    </tfoot>
  </table>
</div>


@endsection
@section('footerscript')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn3.devexpress.com/jslib/19.1.8/js/dx.all.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/1.7.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#image-uploadify, #image-uploadify1').imageuploadify();
        })
    </script>
@endsection
