<!doctype html>
<html lang="en">
<head>
	<title>Student</title>
	  @include('StudentDashboard.layouts.meta')
	  @include('StudentDashboard.layouts.links')
</head>
<body>
