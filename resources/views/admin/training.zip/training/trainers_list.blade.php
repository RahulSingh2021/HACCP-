@extends('layouts.app1', ['pagetitle' => 'Dashboard'])
@section('content')
<style>	
	th {
        font-size: 14px !important;
    }
        
        td {
        padding: 8px 10px;
        font-size: 14px;
    }
        div#example_length {
        margin: 20px 0px;
    }
        
        
        div#example_filter {
        display: none;
    }
    table.dataTable.no-footer {
        border-bottom: 1px solid #ddd;
        border-top: 1px solid #ddd;
    }
        div#example_paginate {
        background: #17a00e;
        margin: 10px 0px;
        color: #fff;
        padding: 5px 0px;
    }
        
        div#example_paginate a {
        color: #fff !important;
    }
        
        .dataTables_wrapper .dataTables_paginate .paginate_button.current, .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        color: #333 !important;
        border: 1px solid #979797;
        background-color: white;
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, white), color-stop(100%, #dcdcdc));
        background: -webkit-linear-gradient(top, white 0%, #dcdcdc 100%);
        background: -moz-linear-gradient(top, white 0%, #dcdcdc 100%);
        background: -ms-linear-gradient(top, white 0%, #dcdcdc 100%);
        background: -o-linear-gradient(top, white 0%, #dcdcdc 100%);
        background: #d10b1e !important;
        border: 0px !important;
    }
        
        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        color: white !important;
        border: 0px;
        background-color: #585858;
        background: red;
        background: -webkit-linear-gradient(top, #585858 0%, #111 100%);
        background: -moz-linear-gradient(top, #585858 0%, #111 100%);
        background: -ms-linear-gradient(top, #585858 0%, #111 100%);
        background: -o-linear-gradient(top, #585858 0%, #111 100%);
        background: #d10b1e !important;
    }
        
        .table>:not(:last-child)>:last-child>* {
        border-bottom-color: transparent;
    }
        a.back {
        text-align: right;
        float: right;
        padding: 13px 30px;
        background: #17a00e;
        margin-bottom: 20px;
        border-radius: 6px;
        color: #fff;
    }

    a.active {
        color: #fff !important;
        text-decoration: none;
        background: #0d6efd;
    }
    .input-switch {
        display: none;
    }

    .label-switch {
        display: inline-block;
        position: relative;
    }

    .label-switch::before,
    .label-switch::after {
        content: "";
        display: inline-block;
        cursor: pointer;
        transition: all 0.5s;
    }

    .label-switch::before {
        width: 3em;
        height: 1em;
        border: 1px solid #b90731;
        border-radius: 4em;
        background: #e0525d;
    }

    .label-switch::after {
        position: absolute;
        left: 0;
        top: -3px;
        width: 1.5em;
        height: 1.5em;
        border: 1px solid #b90731;
        border-radius: 4em;
        background: #e0525d;
    }

    .input-switch:checked~.label-switch::before {
        background: #00a900;
        border-color: #008e00;
    }

    .input-switch:checked~.label-switch::after {
        left: unset;
        right: 0;
        background: #00ce00;
        border-color: #009a00;
    }

    .info-text {
        display: inline-block;
    }

    .info-text::before {
        content: "Inactive";
    }

    .input-switch:checked~.info-text::before {
        content: "Active";
    }

    .f-child tr th:first-child {
        width: 20px !important;
    }
</style>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    @include('admin.training.training_navbar')
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="training-types" role="tabpanel">
                            <div class="row row-cols-auto g-3 mb-3">
                                <div class="col-12">
                                    <div class="col-12 align-self-center">
                                        <form method="get" action="{{route('trainers_data_index')}}">
                                            <div class="row row-cols-auto g-1 mb-3">
                                                <div class="col-2">
                                                    <input type="text" class="form-control" name="search" value="{{Request::get('search')}}" placeholder="Search And Add Trainer">
                                                </div>
                                                <div class="col-10">
                                                    <button type="submit" class="btn btn-primary">Search</button>
                                                    <?php if(count($unit_users_list)>0){ ?>
                                                        <a href="javascript:void(0);" class="btn btn-primary addtrainers" onclick="return confirm('Are you sure you want to add this item?');">Add Selected</a>
                                                    <?php } ?>                                                 
                                                    <a href="javascript:void(0);" class="btn btn-danger deletetrainers" onclick="return confirm('Are you sure you want to delete this item?');">Delete Selected</a>
                                                </div>
                                            </div>
                                        <form>
                                        <?php if(!empty($unit_users_list)){ ?>
                                        <div class="table-responsive table-refresh">
                                            <table id="example" class="table table-striped table-bordered data-t f-child example"
                                                style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th width="30"><input type="checkbox" class="checkboxclickusermanagment"></th>
                                                        <th class="text-left">#</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Gender</th>
                                                        <th>Email</th>
                                                        <th>Contact Number</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                @php $i=1; @endphp
                                                @forelse($unit_users_list as $unit_user)
                                                    <tr>
                                                        <td><input class="checkboxvalueusermanagment" type="checkbox" value="{{ $unit_user->employe_id }}"></td>
                                                        <td>{{ $i }}</td>
                                                        <td>{{ $unit_user->employe_id }}</td>
                                                        <td>{{ $unit_user->employer_fullname }}</td>
                                                        <td>{{ $unit_user->gender ?? '' }}</td>
                                                        <td>{{ $unit_user->email ?? '' }}</td>
                                                        <td>{{ $unit_user->contact_number }}</td>
                                                        <td>
                                                            @if($unit_user->status==1)
                                                            <span class="badge badge-success" style="background-color: green">Active</span>
                                                            @else
                                                            <span class="badge badge-danger" style="background-color: red">Inactive</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            {{-- <a class="btn btn-primary btn-sm">Add</a> --}}
                                                            <a style="color: #008cff;" class="addtrainersplus" href="javascript:void(0);" 
                                                                onclick="return confirm('Are you sure you want to add this item?');" data-id="{{$unit_user->employe_id}}">
                                                                <i class="font-20 bx bxs-plus-circle"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    @php $i++;@endphp
                                                    @empty
                                                    <tr>
                                                        <td colspan="9" class="text-center">No Data Found</td>
                                                    </tr>
                                                    @endforelse
                                                </tbody>
                                            </table>
                                            <?php if(!empty($unit_users_list)){ ?>
                                            {!! $unit_users_list->withQueryString()->links('pagination::bootstrap-5') !!}
                                            <?php } ?>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="col-12 align-self-center">
                                        <h5>Trainers List</h5>
                                        <div class="table-responsive">
                                            <table id="example" class="table table-striped table-bordered data-t f-child"
                                                style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th width="30"><input type="checkbox" class="checkboxclickusermanagmentdelete"></th>
                                                        <th class="text-left">#</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Gender</th>
                                                        <th>Email</th>
                                                        <th>Contact Number</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                @php $i=1; @endphp
                                                @forelse($trainers_list_datas as $trainers_list_data)
                                                    <tr>
                                                        <td><input class="checkboxvalueusermanagmentdelete" type="checkbox" value="{{ $trainers_list_data->id }}"></td>
                                                        <td>{{ $i }}</td>
                                                        <td>{{ $trainers_list_data->employe_id }}</td>
                                                        <td>{{ $trainers_list_data->employer_fullname }}</td>
                                                        <td>{{ $trainers_list_data->gender ?? '' }}</td>
                                                        <td>{{ $trainers_list_data->email ?? '' }}</td>
                                                        <td>{{ $trainers_list_data->contact_number }}</td>
                                                        <td>
                                                            @if($trainers_list_data->status==1)
                                                            <span class="badge badge-success" style="background-color: green">Active</span>
                                                            @else
                                                            <span class="badge badge-danger" style="background-color: red">Inactive</span>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            <a style="color: #FF0000;" href="{{ route('trainers_data_delete', $trainers_list_data->id) }}"
                                                                onclick="return confirm('Are you sure you want to delete this item?');">
                                                                <i class="font-20 bx bxs-trash"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    @php $i++;@endphp
                                                    @empty
                                                    <tr>
                                                        <td colspan="9" class="text-center">No Data Found</td>
                                                    </tr>
                                                    @endforelse
                                                </tbody>
                                            </table>
                                            {!! $trainers_list_datas->withQueryString()->links('pagination::bootstrap-5') !!}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end row-->
    </div>
@endsection
@section('footerscript')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn3.devexpress.com/jslib/19.1.8/js/dx.all.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/1.7.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.min.js"></script>

    <script>
    var yourArray = [];
    var yourArray2 = [];
    $('.checkboxclickusermanagment').on('click', function(e) {
        if ($(this).is(':checked', true)) {
            $(".checkboxvalueusermanagment").prop('checked', true);
            yourArray = [];
            $(".checkboxvalueusermanagment:checked").each(function(){
                yourArray.push($(this).val());                
            });
        } else {
            $(".checkboxvalueusermanagment").prop('checked', false);
            yourArray = [];
        }
    });
    $( ".checkboxvalueusermanagment" ).each(function(index) {
        $(this).on('click', function(e) {
            if ($(this).is(':checked', true)) {
                $(this).prop('checked', true);
                yourArray.push($(this).val());   
            } else {
                $(this).prop('checked', false);
                yourArray = yourArray.filter(e => e !== $(this).val());
            }
        });
    });
    $( ".addtrainersplus" ).each(function(index) { 
        $(this).on('click', function(e) {
            yourArray.push($(this).data('id')); 
            $.ajax
            ({ 
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url : "{{ route('trainers_add') }}",
                data : {'ids' : yourArray},
                type : 'POST',
                dataType : 'json',
                success: function(result)
                {
                    location.replace('{{route("trainers_data_index")}}');
                }
            });
        });
    });
    $( ".addtrainers" ).on( "click", function() {
        console.log(yourArray);
        $.ajax
        ({ 
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url : "{{ route('trainers_add') }}",
            data : {'ids' : yourArray},
            type : 'POST',
            dataType : 'json',
            success: function(result)
            {
                location.replace('{{route("trainers_data_index")}}');
                console.log(result); return false;
            }
        });
    });

    $('.checkboxclickusermanagmentdelete').on('click', function(e) {
        if ($(this).is(':checked', true)) {
            $(".checkboxvalueusermanagmentdelete").prop('checked', true);
            yourArray2 = [];
            $(".checkboxvalueusermanagmentdelete:checked").each(function(){
                yourArray2.push($(this).val());                
            });
        } else {
            $(".checkboxvalueusermanagmentdelete").prop('checked', false);
            yourArray2 = [];
        }
    });
    $( ".checkboxvalueusermanagmentdelete" ).each(function(index) {
        $(this).on('click', function(e) {
            if ($(this).is(':checked', true)) {
                $(this).prop('checked', true);
                yourArray2.push($(this).val());   
            } else {
                $(this).prop('checked', false);
                yourArray2 = yourArray2.filter(e => e !== $(this).val());
            }
        });
    });
    $( ".deletetrainers" ).on( "click", function() {
        console.log(yourArray2);
        $.ajax
        ({ 
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url : "{{ route('trainers_delete') }}",
            data : {'ids' : yourArray2},
            type : 'POST',
            dataType : 'json',
            success: function(result)
            {
                location.replace('{{url()->full()}}');
                console.log(result); return false;
            }
        });
    });

    $( ".reserve-button" ).each(function(index) {
        $(this).on("click", function(){
            if($(this).val()=='1'){
                $(this).val('0');
            } else {
                $(this).val('1');
            }
            var training_status_id = $(this).data('id');
            var training_status_update = $(this).val();
            $.ajax
            ({ 
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url : "{{ route('training_status_update') }}",
                data : {'id' : training_status_id, 'status' : training_status_update},
                type : 'POST',
                dataType : 'json',
                success: function(result)
                {
                    console.log(result); return false;
                }
            });
        });
    });
    </script>
@endsection
