@extends('layouts.app', ['pagetitle'=>'Dashboard'])

<meta name="csrf-token" content="{{ csrf_token() }}">


<style type="text/css">
	
	button.dt-button.buttons-excel.buttons-html5 {
    display: inline-block;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    text-align: center;
    letter-spacing: 0.5px;f
    text-decoration: none;
    vertical-align: middle;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    user-select: none;
    background-color: transparent;
    border: 1px solid #000;c
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    border-radius: 0.25rem;
    transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
}
	
	.dt-buttons {
    text-align: right;
}

    .error {
    color: red;
    margin: 10px 0px;
}
	

	
		div#pm-schedule-maker_table_length {
    margin: 20px 0px;
}
	
	

table.dataTable.no-footer {
    border-bottom: 1px solid #ddd;
    border-top: 1px solid #ddd;
}
	div#pm-schedule-maker_table_paginate {
    background: #17a00e;
    margin: 10px 0px;
    color: #fff;
    padding: 5px 0px;
}
	
	div#pm-schedule-maker_table_paginate a {
    color: #fff !important;
}

    
img, svg {
    vertical-align: middle;
    width: 20px;
}
.flex.justify-between.flex-1.sm\:hidden {
    display: none;
}
.pagination {
    display: block !important;
        margin-bottom: 20px;
}
.hidden.sm\:flex-1.sm\:flex.sm\:items-center.sm\:justify-between {
    margin-top: 24px;
}
        .step-number {
            border-top: #333 2px solid;
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            position: relative;
        }

        .step-number:before {
            content: "";
            background: #fff;
            display: block;
            position: absolute;
            height: 3px;
            width: 27px;
            top: -2px;
            z-index: 0;
        }

        .step-number:after {
            content: "";
            background: #fff;
            display: block;
            position: absolute;
            height: 3px;
            width: 27px;
            top: -2px;
            z-index: 0;
            right: 0;
        }

        .step-number span {
            margin-top: -15px;
            text-align: center;
            z-index: 1;
        }

        .step-number em {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: inline-block;
            text-align: center;
            font-style: normal;
            line-height: 30px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .ins-t td {
            font-size: 13px;
            padding: 5px 0px;
        }

        .cam-img {
            width: 100%;
            background: #f7f7f7;
            height: 80%;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .imageuploadify {
            min-height: 150px;
        }

        .imageuploadify-message {
            display: none !important;
        }

        .imageuploadify .imageuploadify-images-list i {
            font-size: 3em;
            height: 50px;
        }
        
        
        
        html {
  box-sizing: border-box;
}
*,
*:before,
*:after {
  box-sizing: inherit;
}
.intro {
  max-width: 1280px;
  margin: 1em auto;
}
.table-scroll {
  position: relative;
  width:100%;
  z-index: 1;
  margin: auto;
  overflow: auto;
  /*height: 350px;*/
}
.table-scroll table {
  width: 100%;
  min-width: 1280px;
  margin: auto;
  border-collapse: separate;
  border-spacing: 0;
}
.table-wrap {
  position: relative;
}
.table-scroll th,
.table-scroll td {
  padding: 5px 10px;
  border: 1px solid #000;
  background: #fff;
  vertical-align: top;
}
.table-scroll thead th {
  background: #333;
  color: #fff;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}
/* safari and ios need the tfoot itself to be position:sticky also */
.table-scroll tfoot,
.table-scroll tfoot th,
.table-scroll tfoot td {
  position: -webkit-sticky;
  position: sticky;
  bottom: 0;
  background: #666;
  color: #fff;
  z-index:4;
}

a:focus {
  background: red;
} /* testing links*/

th:first-child {
  position: -webkit-sticky;
  position: sticky !import;
  left: 0;
  z-index: 2;
  background: #ccc;
}
thead th:first-child,
tfoot th:first-child {
  z-index: 5;
}

.intro {
  max-width: 1280px;
  margin: 1em auto;
}
.table-scroll {
  position: relative;
  width:100%;
  z-index: 1;
  margin: auto;
  overflow: auto;
  height: 950px;
}
.table-scroll table {
  width: 100%;
  min-width: 1280px;
  margin: auto;
  border-collapse: separate;
  border-spacing: 0;
}
.table-wrap {
  position: relative;
}
.table-scroll th,
.table-scroll td {
  padding: 5px 10px;
  border: 1px solid #000;
  background: #fff;
  vertical-align: top;
}
.table-scroll thead th {
  background: #333;
  color: #fff;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}
/* safari and ios need the tfoot itself to be position:sticky also */
.table-scroll tfoot,
.table-scroll tfoot th,
.table-scroll tfoot td {
  position: -webkit-sticky;
  position: sticky;
  bottom: 0;
  background: #666;
  color: #fff;
  z-index:4;
}

a:focus {
  background: red;
} /* testing links*/

th:first-child {
  position: -webkit-sticky;
  position: sticky;
  left: 0;
  z-index: 2;
  background: #ccc;
}
thead th:first-child,
tfoot th:first-child {
  z-index: 5;
}

#loader {
    position: fixed; /* Use fixed to make sure it's always in view */
    z-index: 9999999;
    width: 100%;
    height: 100%;
    background: rgba(147, 112, 219, 0.5); /* MediumVioletRed with opacity */
    text-align: center;
}

#loader::after {
    content: "";
    width: 60px;
    height: 60px;
    border: 6px solid #fff;
    border-radius: 50%;
    border-top-color: transparent;
    animation: spin 1s linear infinite; /* Animation to create spinner effect */
    position: absolute;
    left: 50%;
    top: 50%;
    margin-left: -30px; /* Half of width */
    margin-top: -30px; /* Half of height */
}


#accordionFlushExample {
    display: none; /* Use fixed to make sure it's always in view */
}

#accordionFlushExample1 {
    display: none; /* Use fixed to make sure it's always in view */
}
#accordionFlushExample2 {
    display: none; /* Use fixed to make sure it's always in view */
}

button.btn.btn-primary.addmore {
    display: none;
}



@keyframes spin {
    to {
        transform: rotate(360deg); /* Rotate 360 degrees */
    }
}

</style>
@section('content')
 
@include('admin.popups.fhm.addequipment')
@include('admin.popups.fhm.importequipment')

<div class="row">
                         <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <ul class="nav nav-pills nav-pills-success mb-3" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link active" data-bs-toggle="pill" href="#location-management" role="tab" aria-selected="true">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-icon"><i class="bx bx-user-pin font-18 me-1"></i>
                                                    </div>
                                                    <div class="tab-title">Equipment Master List</div>
                                                </div>
                                            </a>
                                        </li>

                                        @php
                                           $user = Auth::user();
                                        @endphp
                                        @if($user && $user->is_role == 2) 
                                            <li class="nav-item" role="presentation" style="margin-left: 20px;">
                                                <a class="nav-link active" href="{{ route('facility_hygiene_fhmcat') }}">
                                                    <div class="d-flex align-items-center">
                                                        <div class="tab-title">Fhm Category</div>
                                                    </div>
                                                </a>
                                            </li>
                                        @endif
                                          <li class="nav-item" role="presentation" style="margin-left: 20px;">
                                            <a class="nav-link active"  href="{{route('facility_hygiene_cleaning_schedule')}}" >
                                                <div class="d-flex align-items-center">
                                                 
                                                    <div class="tab-title">Cleaning Schedule</div>
                                                </div>
                                            </a>
                                        </li>
                                        
                                        
                                        <li class="nav-item" role="presentation" style="margin-left: 20px;">
                                            <a class="nav-link active"  href="{{route('facility_hygiene_pm_schedule')}}" >
                                                <div class="d-flex align-items-center">
                                                 
                                                    <div class="tab-title">PM Schedule</div>
                                                </div>
                                            </a>
                                        </li>
						
                                         <li class="nav-item" role="presentation" style="margin-left: 20px;">
                                            <a class="nav-link active"  href="{{route('breakdown')}}" >
                                                <div class="d-flex align-items-center">
                                                 
                                                    <div class="tab-title">Breakdown</div>
                                                </div>
                                            </a>
                                        </li>
						
										
										
                                        
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane fade active show" id="location-management" role="tabpanel">
                                            
                              
											                 <div class="row row-cols-auto g-1">
                                                <div class="col">
                                                    <button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#addequipment">Add Equipment Name</button>
													
													   <button type="button" class="btn btn-outline-dark px-3" data-bs-toggle="modal" data-bs-target="#importequipment">Import Equipment Data</button>
		
													<a href="{{config('app.url').'/companylogo/equipment.csv'}}" class="btn btn-outline-dark px-3" download >Sample Csv</a>
												
													
													      <button type="button" id="delbuttonequpitments" class="btn btn-danger btn-xs" value="delete">Delete Selected</button>
													      
                        										@php
                                                                   $user = Auth::user();
                                                                @endphp
                                                                @if($user && $user->is_role == 3) 
    													      	<a href="{{route('fhm-category-export')}}" class="btn btn-primary px-3" download >Fhm Category Export</a>
    													      	@endif
													      		<a href="{{route('fhm-responsibility-export')}}" class="btn btn-primary px-3" download >Responsibility Export</a>
													      			<a href="{{route('fhm-department-export')}}" class="btn btn-primary px-3" download >Department Export</a>

                                                </div>
												 </div>
                                          
											<form method="get" action="">
												    <div class="row">
														<div class="mb-2 col-md-2">

															
															
															<label class="form-label">Select Corporate :</label>
							<select name="corporate_id" id="schedule_id_edit"  onchange="myFunction(this)" class="form-control" >
																<option value="">Please Select Corporate </option>
																<?php
																$unit_list = DB::table('users')->where('is_role', "2")->get(); ?>
																@foreach($unit_list as $unit_lists)
																<option value="{{$unit_lists->id}}"  > 
																	{{$unit_lists->company_name}}
																</option>
																@endforeach
															</select>
														</div>
														<div class="mb-2 col-md-2">
															<label class="form-label">Select Regional Name:</label>
															<select name="regional_id" id="mySelect111" class="form-control mySelect111" >
																<option value=""  > Please Select Regional </option>
												
															</select>
														</div>
														
														<div class="mb-2 col-md-2">
															<label class="form-label">Unit Name:</label>
															<select name="hotel_name" id="schedulemySelect22" class="form-control schedulemySelect22" >
																<option value=""  > Please Select Unit </option>
												



															</select>
														</div>
														
														<div class="mb-2 col-md-2">
															<label class="form-label">Select Location:</label>

						<select name="location_id" id="schedulemydepartment11" class="form-control schedulemydepartment11 ">
								<option value=""  > Please Select Location </option>
														
															</select>
														</div>
														
															<div class="mb-2 col-md-1">
															<label class="form-label" style="color:#fff;">Select :</label>
													      <button type="submit"  class="btn btn-outline-dark px-3" > Submit</button>
																
														</div>
																	<div class="mb-2 col-md-2">
																																	<label class="form-label" style="color:#fff;">Select Location:</label>

																 <a class="btn btn-outline-dark px-3" href="https://efsms.in/admin/public/Facility-Hygiene">Clear Filter</a>
														</div>
                                            </div>  
														
													
											</form>
											
											
											            <div id="table-scroll" class="table-scroll">
  <table id="main-table" class="main-table  ">
    <thead>
      <tr>
          
            <!--<th scope="col" style="text-align: center; margin: 30px !important;padding: 9px;vertical-align: middle;">SI.No</th>-->
        <th scope="col" style="text-align: center; margin: 30px !important;padding: 9px;vertical-align: middle;">Equipment Name</th>
          
            
              <th style="text-align: center; margin: 30px !important;vertical-align: middle;padding: 9px !important;">Cleaning Plan
        
            </th>
            
             <th style="text-align: center; margin: 30px !important;vertical-align: middle;padding: 9px !important;">PM Plan
        
            </th>
            
            <th style="text-align: center; margin: 30px !important;vertical-align: middle;padding: 9px !important;">Brackdown History
        
            </th>
            
                     
            <th style="text-align: center; margin: 30px !important;vertical-align: middle;padding: 9px !important;">Calibration Details
        
            </th>
            
             <th style="text-align: center; margin: 30px !important;vertical-align: middle;padding: 9px !important;">QR Code Details
        
            </th>
    
                                                                 
      </tr>
    </thead>
    <tbody>
        
        								@php $i=1; @endphp
													@foreach($facility_equipment as $facility_equipments)
        <tr>
          <!--<th style="min-width: 20px !important;text-align: center;padding: 22px;    position: sticky;">-->
                 
          <!-- {{$i}}     -->
     
          <!--</th>-->
       <th style="min-width: 400px !important;text-align: center;padding: 22px;">
                 
          <p><strong>Equipment Name :</strong> {{$facility_equipments->name}} </p>
         
          <p><strong>Location :</strong>{{Helper::locationName($facility_equipments->location_id) ?? 'NA'}} </p>
          <!--<p><strong>Sub Location :</strong>{{Helper::locationName($facility_equipments->sub_location) ?? 'NA'}} </p>-->
          <p><strong>Brand :</strong>{{$facility_equipments->brand}} </p>
          
          <p><strong>Equipment ID : </strong>{{$facility_equipments->equipment_id}} </p>
          <p><strong>Calibration: </strong>{{$facility_equipments->Calibration_status}} </p>
          <!--<p><strong>PM: </strong>@if(!empty($facility_equipments->pm_task_start_date)) Yes @else No @endif </p>-->
          <!--<p><strong>Cleaning: </strong>@if(!empty($facility_equipments->cleaning_task_start_date)) Yes @else No @endif  </p>-->
          <!--<p><strong>Break Down: </strong>yes </p>-->
          <!--<p><strong>Add Cleaning Schedule Maker: </strong>yes </p>-->
          <!--<p><strong>Daily Cleaning: </strong>yes </p>-->
               <strong><a style="color: #008cff;cursor: pointer;" href="{{route('fhm_details',$facility_equipments->id)}}">Edit </a></strong> <br>
               <!--<strong><a  style="color: #008cff;cursor: pointer;" >View Equipment History Card </a></strong>-->
     
          </th>
          
  
        
           <td style="min-width: 300px !important;text-align: center;padding: 22px;">
                 
                 @if(!empty($facility_equipments->cleaning_task_start_date))
                 	 @php 		$responbalityName = DB::table('authority')->where('id',$facility_equipments->responsibility_id ?? '')->value('name'); @endphp
           <p><strong>Frequency :</strong> @if($facility_equipments->c_frequency_daily) {{$facility_equipments->c_frequency_daily}}, @endif{{$facility_equipments->c_frequency}} </p>
           <p><strong>Responsibility :</strong> {{$responbalityName ?? 'NA'}} </p>
           <p><strong>Task Start Date: :</strong> {{$facility_equipments->cleaning_task_start_date}} </p>
          <p><strong>Last Completed On: :</strong>{{$facility_equipments->cleaning_last_completed_on}} </p>
                        @else
                        
                        Not Assigned
     @endif
          </td>
          
              
       <td style="min-width: 300px !important;text-align: center;padding: 22px;">
                 @if(!empty($facility_equipments->pm_task_start_date))
                 	 @php 		$responbalityName = DB::table('authority')->where('id',$facility_equipments->responsibility_id ?? '')->value('name'); @endphp
           <p><strong>Frequency :</strong> {{$facility_equipments->p_frequency}} </p>
           <p><strong>Responsibility :</strong> {{$responbalityName ?? ''}} </p>
           <p><strong>Task Start Date: :</strong> {{$facility_equipments->pm_task_start_date}} </p>
          <p><strong>Last Completed On: :</strong>{{$facility_equipments->pm_last_completed_on}} </p>
          @else
            Not Assigned
                        @endif
          </td>
          
                   <td style="min-width: 300px !important;text-align: center;padding: 22px;">
                 
           In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without     
           <br>
          </td>
          
           <td style="min-width: 300px !important;text-align: center;padding: 22px;">
               
               @php $list = Helper::calibrationDetails($facility_equipments->id) @endphp
                 
                 
                 @foreach($list as $lists)
           <p style="margin: 10px;"><strong>Unique ID :</strong>{{$lists->unique_id ?? ''}}</p>
           <p><strong>Type:</strong>{{$lists->type ?? ''}}</p>
           <p><strong>Capacity Range:</strong>{{$lists->capacity_range ?? ''}}</p>
           <p><strong>Current utility Range:</strong>{{$lists->capacity_utility_range ?? ''}}</p>
           <p><strong>Calibration Range:</strong>{{$lists->unique_id ?? ''}}</p>
                      <p><strong>Least Count:</strong>{{$lists->least_count ?? ''}}</p>
           <p><strong>Calibration Date:</strong>{{$lists->calibration_date ?? ''}}</p>
     
                    <p><strong>Calibration Exp Date:</strong>{{$lists->calibration_due_date ?? ''}}</p>
                    <p><strong>Calibration Certificate Number:</strong>{{$lists->certificate_number ?? ''}}</p>
      
           
           
           
               <!--<strong><a href="{{config('app.url').'/companylogo/'.$lists->company_logo}}" target="_blank" style="color: #000;cursor: pointer;" >view certificate </a></strong><br>-->
                   
                    <hr>
                    <!--<strong><a href="{{route('facility_store_destoryCalibration',$lists->id)}}" style="color: #000;cursor: pointer;" >Delete</a></strong>-->
 
           @endforeach
            <strong><a href="{{route('Calibration_details',$facility_equipments->id)}}" style="color: #008cff;cursor: pointer;margin-bottom:15px;" >Edit/Upload</a></strong><br>
           <br>

          </td>
        
        
         <td style="min-width: 300px !important;text-align: center;padding: 22px;">
                 
           <img src="https://api.qrserver.com/v1/create-qr-code/?size=350x350&amp;data=https%3A%2F%2Fefsm.safefoodmitra.com%2Fadmin%2Fpublic%2Findex.php%2Fscanlms%2F167" alt="QR Code" style="    width: 116px;
    display: block;
    text-align: center;
    margin: 0 auto;">     
     
          </td>
          
          </tr>
          
          
          	@php $i++; @endphp
          @endforeach
        
         </tbody>
         
         </table>
        
    

                         
													
                                      
                                                  
                                                </tbody>
                                              </table>
                                              
                                                        <div class="mt-3 col-12" style="text-align: center;">
                                            
                                            {{ $facility_equipment->appends(request()->query())->links() }}

                                        </div>
                                        <br>
                        
                                        </div>

                          
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>

@endsection

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>


<script>
												/****************** Delete All Department Details ****************/

$(document).ready(function(){
	
										  $('.checkboxclickequpitments').on('click', function(e) {  
         if($(this).is(':checked',true))    
         {  
            $(".checkboxequpitmentsvalue").prop('checked', true);    
         } else {    
            $(".checkboxequpitmentsvalue").prop('checked',false);    
         }    
        }); 
  $("#delbuttonequpitments").click(function(){
         if (confirm("Are you sure you want to Delete Item!")) {
          $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      
		 
			   var ids = [];    
            $(".checkboxequpitmentsvalue:checked").each(function() {    
                ids.push($(this).val());  
            });

   if(ids.length <=0)    
            {    
                alert("Please select row.");    
            }  else {
				
				         
                  $.ajax({  
                      url:"{{ route('delete_all_equpitments') }}",
                        type: 'DELETE',  
                        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},  
                       data:{ ids:ids}, 
                        success: function (data) {  
                            if (data['success']) {  
                                $(".checkboxequpitmentsvalue:checked").each(function() {    
                                    $(this).parents("tr").remove();  
                                });  
                                alert(data['success']);  
                            } else if (data['error']) {  
                                alert(data['error']);  
                            } else {  
                                alert('Whoops Something went wrong!!');  
                            }  
                        },  
                        error: function (data) {  
                            alert(data.responseText);  
                        }  
                    });  
                  $.each(allVals, function( index, value ) {  
                      $('table tr').filter("[data-row-id='department_detailss_" + value + "']").remove();  
                  });
			}       
         }

  });
});

	/****************** End Delete All Department Details ****************/
	
	
													/****************** Delete All Department Details ****************/

$(document).ready(function(){
	
										  $('.checkboxclickcleaning_schedular').on('click', function(e) {  
         if($(this).is(':checked',true))    
         {  
            $(".checkboxcleaning_schedularvalue").prop('checked', true);    
         } else {    
            $(".checkboxcleaning_schedularvalue").prop('checked',false);    
         }    
        }); 
  $("#delbuttoncleaning_schedular").click(function(){
         if (confirm("Are you sure you want to Delete Item!")) {
          $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      
		 
			   var ids = [];    
            $(".checkboxcleaning_schedularvalue:checked").each(function() {    
                ids.push($(this).val());  
            });

   if(ids.length <=0)    
            {    
                alert("Please select row.");    
            }  else {
				
				         
                  $.ajax({  
                      url:"{{ route('delete_all_cleaning_schedular') }}",
                        type: 'DELETE',  
                        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},  
                       data:{ ids:ids}, 
                        success: function (data) {  
                            if (data['success']) {  
                                $(".checkboxcleaning_schedularvalue:checked").each(function() {    
                                    $(this).parents("tr").remove();  
                                });  
                                alert(data['success']);  
                            } else if (data['error']) {  
                                alert(data['error']);  
                            } else {  
                                alert('Whoops Something went wrong!!');  
                            }  
                        },  
                        error: function (data) {  
                            alert(data.responseText);  
                        }  
                    });  
                  $.each(allVals, function( index, value ) {  
                      $('table tr').filter("[data-row-id='cleaning_schedular_detailss_" + value + "']").remove();  
                  });
			}       
         }

  });
});

	/****************** End Delete All Department Details ****************/
	
	
	
	
													/****************** Delete All Department Details ****************/

$(document).ready(function(){
	
										  $('.checkboxclickcleaning_schedular1').on('click', function(e) {  
         if($(this).is(':checked',true))    
         {  
            $(".checkboxcleaning_schedularvalue1").prop('checked', true);    
         } else {    
            $(".checkboxcleaning_schedularvalue1").prop('checked',false);    
         }    
        }); 
  $("#delbuttoncleaning_schedular1").click(function(){
         if (confirm("Are you sure you want to Delete Item!")) {
          $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      
		 
			   var ids = [];    
            $(".checkboxcleaning_schedularvalue1:checked").each(function() {    
                ids.push($(this).val());  
            });

   if(ids.length <=0)    
            {    
                alert("Please select row.");    
            }  else {
				
				         
                  $.ajax({  
                      url:"{{ route('delete_all_cleaning_schedular1') }}",
                        type: 'DELETE',  
                        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},  
                       data:{ ids:ids}, 
                        success: function (data) {  
                            if (data['success']) {  
                                $(".checkboxcleaning_schedularvalue1:checked").each(function() {    
                                    $(this).parents("tr").remove();  
                                });  
                                alert(data['success']);  
                            } else if (data['error']) {  
                                alert(data['error']);  
                            } else {  
                                alert('Whoops Something went wrong!!');  
                            }  
                        },  
                        error: function (data) {  
                            alert(data.responseText);  
                        }  
                    });  
                  $.each(allVals, function( index, value ) {  
                      $('table tr').filter("[data-row-id='cleaning_schedular1_detailss_" + value + "']").remove();  
                  });
			}       
         }

  });
});

	/****************** End Delete All Department Details ****************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
													/****************** Delete All Department Details ****************/

$(document).ready(function(){
	
										  $('.checkboxclickchemicalselection').on('click', function(e) {  
         if($(this).is(':checked',true))    
         {  
            $(".chemicalselectionvalue").prop('checked', true);    
         } else {    
            $(".chemicalselectionvalue").prop('checked',false);    
         }    
        }); 
  $("#delbuttonchemicalselection").click(function(){
         if (confirm("Are you sure you want to Delete Item!")) {
          $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      
		 
			   var ids = [];    
            $(".chemicalselectionvalue:checked").each(function() {    
                ids.push($(this).val());  
            });

   if(ids.length <=0)    
            {    
                alert("Please select row.");    
            }  else {
				
				         
                  $.ajax({  
                      url:"{{ route('delete_all_chemicalselection') }}",
                        type: 'DELETE',  
                        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},  
                       data:{ ids:ids}, 
                        success: function (data) {  
                            if (data['success']) {  
                                $(".chemicalselectionvalue:checked").each(function() {    
                                    $(this).parents("tr").remove();  
                                });  
                                alert(data['success']);  
                            } else if (data['error']) {  
                                alert(data['error']);  
                            } else {  
                                alert('Whoops Something went wrong!!');  
                            }  
                        },  
                        error: function (data) {  
                            alert(data.responseText);  
                        }  
                    });  
                  $.each(allVals, function( index, value ) {  
                      $('table tr').filter("[data-row-id='chemicalselection_detailss_" + value + "']").remove();  
                  });
			}       
         }

  });
});

	/****************** End Delete All Department Details ****************/
	
	
	
	
	
													/****************** Delete All Department Details ****************/

$(document).ready(function(){
	
										  $('.checkboxclicktool_section').on('click', function(e) {  
         if($(this).is(':checked',true))    
         {  
            $(".checkboxtool_section").prop('checked', true);    
         } else {    
            $(".checkboxtool_section").prop('checked',false);    
         }    
        }); 
  $("#delbuttontool_section").click(function(){
         if (confirm("Are you sure you want to Delete Item!")) {
          $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      
		 
			   var ids = [];    
            $(".checkboxtool_section:checked").each(function() {    
                ids.push($(this).val());  
            });

   if(ids.length <=0)    
            {    
                alert("Please select row.");    
            }  else {
				
				         
                  $.ajax({  
                      url:"{{ route('delete_all_toolselection') }}",
                        type: 'DELETE',  
                        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},  
                       data:{ ids:ids}, 
                        success: function (data) {  
                            if (data['success']) {  
                                $(".checkboxtool_section:checked").each(function() {    
                                    $(this).parents("tr").remove();  
                                });  
                                alert(data['success']);  
                            } else if (data['error']) {  
                                alert(data['error']);  
                            } else {  
                                alert('Whoops Something went wrong!!');  
                            }  
                        },  
                        error: function (data) {  
                            alert(data.responseText);  
                        }  
                    });  
                  $.each(allVals, function( index, value ) {  
                      $('table tr').filter("[data-row-id='checkboxtool_section_detailss_" + value + "']").remove();  
                  });
			}       
         }

  });
});

	/****************** End Delete All Department Details ****************/
</script>
@section('footerscript')
<script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>

<script>
$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
       
            {
                extend: 'excelHtml5',
				text: 'Export Data',
                exportOptions: {
                   columns: [ 0, 1, 2,3,4,5,6,7,8,9 ]
                }
            },
   
            'colvis'
        ]
    } );
} );
</script>

@endsection

   