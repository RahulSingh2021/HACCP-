<header>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">My Course</a></li>
                </ul>
                <h2 class="mycourseheaing">My Course</h2>
            </div>

            <div class="col-sm-6 bookimg text-end">
                <img src="{{asset('student_dashboard/assets/img/bookimg.jpg')}}" alt="img" class="img-fluid">
            </div>
        </div>
    </div>
</header>
