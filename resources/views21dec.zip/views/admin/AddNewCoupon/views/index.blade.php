@include('Admin.AddNewCoupon.layouts.top')
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css" rel="stylesheet">

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment-with-locales.min.js"></script>

<div class="container mt-4">
    <div class="row">
        <div class="col-xl-12">
            <div class="card mb-4 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="mdi mdi-apple-keyboard-command title_icon"></i>
                        Coupons
                    </h4>
                    <a href="{{ url('/admin/add-new-category/category-add') }}" class="btn btn-outline-primary btn-rounded">
                        <i class="mdi mdi-plus"></i> Add New Coupon
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row">
        <div class="col-xl-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="mb-3">Coupons</h4>
                    <div class="table-responsive">
                        <table id="basic-datatable" class="table table-striped table-centered mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Coupon Code</th>
                                    <th>Discount Percentage</th>
                                    <th>Validity Till</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if($coupons)
                                    @foreach ($coupons as $coupon)
                                    <tr>
                                        <td>{{ $loop->index + 1 }}</td>
                                        <td><strong>{{ $coupon->coupon_code }}</strong></td>
                                        <td>{{ $coupon->discount_percentage }}%</td>
                                        <td>{{ \Carbon\Carbon::parse($coupon->validity_till)->format('D, d-M-Y') }}</td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <a class="dropdown-item" href="{{url('admin/add-new-coupon/edit-coupon',$coupon->id)}}">Edit</a>
                                                    <a class="dropdown-item" href="{{url('admin/add-new-coupon/delete-coupon',$coupon->id)}}">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                @else
                                <tr>
                                    <td colspan="5" class="text-center">No Data Found</td>
                                </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#basic-datatable').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": true,
        "responsive": true,
        "pageLength": 10,              
    });
});
</script>

@include('Admin.AddNewCoupon.layouts.bottom')
