<?php if($paginator->hasPages()): ?>
    <nav>
        <ul class="pagination justify-content-center">

            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">&laquo;</span></li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&laquo;</a>
                </li>
            <?php endif; ?>

            
            <li class="page-item <?php echo e($paginator->currentPage() == 1 ? 'active' : ''); ?>">
                <a class="page-link" href="<?php echo e($paginator->url(1)); ?>">1</a>
            </li>

            
            <?php if($paginator->currentPage() > 3): ?>
                <li class="page-item disabled"><span class="page-link">...</span></li>
            <?php endif; ?>

            
            <?php $__currentLoopData = range(max(2, $paginator->currentPage() - 1), min($paginator->lastPage() - 1, $paginator->currentPage() + 1)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="page-item <?php echo e($page == $paginator->currentPage() ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($paginator->url($page)); ?>"><?php echo e($page); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->currentPage() < $paginator->lastPage() - 2): ?>
                <li class="page-item disabled"><span class="page-link">...</span></li>
            <?php endif; ?>

            
            <?php if($paginator->lastPage() > 1): ?>
                <li class="page-item <?php echo e($paginator->currentPage() == $paginator->lastPage() ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($paginator->url($paginator->lastPage())); ?>"><?php echo e($paginator->lastPage()); ?></a>
                </li>
            <?php endif; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">&raquo;</a>
                </li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">&raquo;</span></li>
            <?php endif; ?>

        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/pagination/custom.blade.php ENDPATH**/ ?>