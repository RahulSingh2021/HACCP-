@extends('layouts.app1', ['pagetitle' => 'Dashboard'])
@section('content')
<link href="{{asset('assets/plugins/fancy-file-uploader/fancy_fileupload.css')}}" rel="stylesheet" />
<link href="{{asset('assets/plugins/Drag-And-Drop/dist/imageuploadify.min.css')}}" rel="stylesheet" />
<style>
    .step-number {
        border-top: #333 2px solid;
        width: 100%;
        display: flex;
        justify-content: space-between;
        margin-top: 30px;
        position: relative;
    }

    .step-number:before {
        content: "";
        background: #fff;
        display: block;
        position: absolute;
        height: 3px;
        width: 27px;
        top: -2px;
        z-index: 0;
    }

    .step-number:after {
        content: "";
        background: #fff;
        display: block;
        position: absolute;
        height: 3px;
        width: 27px;
        top: -2px;
        z-index: 0;
        right: 0;
    }

    .step-number span {
        margin-top: -15px;
        text-align: center;
        z-index: 1;
    }

    .step-number em {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: inline-block;
        text-align: center;
        font-style: normal;
        line-height: 30px;
        font-weight: 600;
        margin-bottom: 5px;
    }

    .ins-t td {
        font-size: 13px;
        padding: 5px 0px;
    }

    .cam-img {
        width: 100%;
        background: #f7f7f7;
        height: 80%;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }

    .imageuploadify {
        min-height: 150px;
    }

    .imageuploadify-message {
        display: none !important;
    }

    .imageuploadify .imageuploadify-images-list i {
        font-size: 3em;
        height: 50px;
    }
    .hidebox {
    display: none;
}
</style>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    @include('admin.training.training_navbar')
                    @include('admin.training.add_lms')

                    <div class="d-flex justify-content-between">
                        <h5 class="mb-0 d-flex align-items-center">Training Calendar
                        </h5>
                        <div class="empopt1">
                            <a href="#" data-bs-toggle="modal" data-bs-target="#add-lms" class="addlmsbtn">Add LMS</a>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active">
                            <hr>
                            <div class="row row-cols-auto g-2">
                                <div class="col-2"><label>Course Start Date</label>
                                    <input type="date" class="form-control" placeholder="">
                                </div>
                                <div class="col-2"><label>Course End Date</label>
                                    <input type="date" class="form-control" placeholder="">
                                </div>

                                <div class="col-2"><label>Course Category</label>
                                    <select class="form-control">
                                        <option>Course Category 1</option>
                                        <option>Course Category 2</option>
                                        <option>Course Category 3</option>
                                    </select>
                                </div>

                                <div class="col-2"><label>Course Title</label>
                                    <select class="form-control">
                                        <option>Course Title 1</option>
                                        <option>Course Title 2</option>
                                        <option>Course Title 3</option>
                                    </select>
                                </div>

                                <div class="col-2"><label>Select Status</label>
                                    <select class="form-control">
                                        <option>Select Status 1</option>
                                        <option>Select Status 2</option>
                                        <option>Select Status 3</option>
                                    </select>
                                </div>

                                <div class="col-1">
                                    <label></label>
                                    <button type="button"
                                        class="btn w-100 btn-secondary px-3">Search</button>
                                </div>
                            </div>
                            <div class="row row-cols-auto">
                                <div class="mt-3 col-12">
                                    <div class="table-responsive Hscrolldesign ">
                                        <div class="employeeData traiininlist">
                                            <table border="0" cellpadding="0" cellspacing="0">
                                                <tbody>
                                                    <tr>

                                                        <td>
                                                            <table border="0" cellpadding="0"
                                                                cellspacing="0" class="monthwise">
                                                                <tbody>
                                                                    <tr>
                                                                        <th><strong>Course Mode</strong>
                                                                        </th>
                                                                        <th><strong>Training Topic</strong>
                                                                        </th>
                                                                        <th><strong>Trainer Name</strong>
                                                                        </th>

                                                                        <th><strong>Time</strong></th>
                                                                        <th><strong>Add
                                                                                Participants</strong></th>
                                                                        <th><strong>Attendance</strong></th>

                                                                        <!--<th><strong>Add Test</strong></th>-->
                                                                        <th><strong>Action</strong></th>



                                                                    </tr>
                                                                    
                                                                    @foreach($lms_list as $lms_lists)

                                                                    <tr>
                                                                        <td>
                                                                            <div class="trainingdetails">
                                                                                <div class="tarainig01">

                                                                                    <span
                                                                                        class="traininghrsbg"
                                                                                        title="Training Hrs">{{$lms_lists->course_mode ?? ''}}</span>

                                                                                </div>
                                                                            </div>
                                                                            <!--   <div class="viewbtnbox"><a href="#" class="viewdetailbtn" title="View Detail"><img src="assets/images/view-details.png"></a></div> -->
                                                                        </td>

                                                                        <td>
                                                                            <span class="traininghrsbg"
                                                                                title="Training Hrs">{{$lms_lists->course_titles ?? ''}}
                                                                            </span>

                                                                        </td>

                                                                        <td>
                                                                            <span class="traininghrsbg"
                                                                                title="Training Hrs">{{$lms_lists->trainer ?? ''}}
                                                                                
                                                                                @if($lms_lists->company_name) ({{$lms_lists->company_name ?? ''}}) @endif</span>

                                                                        </td>

                                                                        <td>
                                                                            <span
                                                                                class="traininghrsbg traininghrsTime"
                                                                                title="Training Hrs">{{$lms_lists->start_time ?? ''}} to<br>
                                                                                {{$lms_lists->end_time ?? ''}}</span>

                                                                            <!--  <div class="viewbtnbox"><a href="#" class="viewdetailbtn" title="View Detail"><img src="assets/images/view-details.png"></a></div> -->
                                                                        </td>

                                                                        <td>
                                                                            <span class="traininghrsbg"
                                                                                title="Training Hrs">Enrolled
                                                                                Participants:12</span>

                                                                            <div
                                                                                class="viewbtnbox addviewbnt">
                                                                                <a href="{{route('add_lms_enrolled')}}?id={{$lms_lists->id}}"
                                                                                    class="viewdetailbtn"
                                                                                    title="View Detail">Add/View
                                                                                    <i class="fa fa-pencil"
                                                                                        aria-hidden="true"></i></a>
                                                                            </div>
                                                                        </td>

                                                                        <td>
                                                                            <span
                                                                                class="countbg presentspacing"
                                                                                title="Content Count">Present
                                                                                :</span>
                                                                            <br>
                                                                            <span class="traininghrsbg"
                                                                                title="Training Hrs">Absent
                                                                                :</span>

                                                                        </td>

                                                                        <!--<td>-->
                                                                        <!--    <span class="traininghrsbg"-->
                                                                        <!--        title="Training Hrs">11/12</span>-->
                                                                        <!--    <span class="countbg"-->
                                                                        <!--        title="Content Count">75%</span>-->

                                                                            <!--  <div class="viewbtnbox"><a href="#" class="viewdetailbtn" title="View Detail"><img src="assets/images/view-details.png"></a></div> -->
                                                                        <!--</td>-->

                                                                        <td>
                                                                            <div class="actionbts">
                                                                                <a href="#"><i
                                                                                        class="fa fa-paper-plane"
                                                                                        aria-hidden="true"></i></a>
                                                                                <a href="#"><i
                                                                                        class="fa fa-clone"
                                                                                        aria-hidden="true"></i></a>
                                                                                <a href="#"
                                                                                    class="activedeactivebtn"></a>
                                                                                <a href="#"><i
                                                                                        class="fa fa-pencil-square-o"
                                                                                        aria-hidden="true"></i></a>
                                                                                <a href="#"><i
                                                                                        class="fa fa-trash"
                                                                                        aria-hidden="true"></i></a>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    @endforeach

                                                                </tbody>
                                                            </table>
                                                        </td>

                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end row-->
    </div>
@endsection
@section('footerscript')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn3.devexpress.com/jslib/19.1.8/js/dx.all.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/1.7.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.min.js"></script>
    <script>
        $(document).ready(function () {
             $('#image-uploadify, #image-uploadify1').imageuploadify();
        })
    </script>
    
        <script>
        function getval(sel)
{

if(sel.value=="Resolved"){
  $('.hidebox').show();
}
else{
   $('.hidebox').hide();
}

}
    </script>
@endsection
