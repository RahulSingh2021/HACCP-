<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use DB;
use Helper;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;

use Illuminate\Routing\Controller as BaseController;

class FhmController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;


public function breakdown(Request $request){
    $breakdowns = DB::table('breakdown')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->paginate(10);;
    return view('admin.fhm.breakdown',compact('breakdowns'));
}

public function deletebreakdown($id){
     $breakdowns = DB::table('breakdown')->where('id',$id)->delete();
    return redirect()->back()->with('success','Deleted');
}


public function breakdownaddpage(){
     $location_id = $_GET['location'] ?? '';
$equipment = $_GET['equipment'] ?? '';

     $departments =  DB::table('departments')->where('unit_id',Auth::id())->get();
     $locations =  DB::table('locations')->where('created_by',Auth::id())->where('parent',null)->get();
     $equipments = DB::table('facility_equipment')->where('created_by',Auth::id())->get();
     
     $sub_locations = null;
     
     if($location_id){
         $sub_locations =  DB::table('locations')->where('parent',$location_id)->get();
     }
     
     $equipmentdata = null;
     if($equipment){
         $equipmentdata = DB::table('facility_equipment')->where('id',$equipment)->first();
     }
     return view('admin.fhm.add_breakdown',compact('departments','equipments','locations','sub_locations','equipmentdata'));  
}


public function breakdownadd(Request $request){
    print_r('not from web now');die;
}



// public function fhmcleaningschedule(Request $request)
// {
//     $authId = auth()->id();
//     $pageSize = 10; // Number of records per page
//     $currentDate = Carbon::now();

//     // Main query to get paginated results
//     $query = DB::table('facility_equipment_cleaning_schedules as schedules')
//         ->selectRaw("
//             facility_equipment_id, cleaning_task_start_date, id, created_by, time_period, row_num
//         ")
//         ->fromSub(function ($subQuery) use ($authId, $currentDate) {
//             $subQuery->selectRaw("
//                 facility_equipment_id, cleaning_task_start_date, id, created_by,
//                 ROW_NUMBER() OVER (PARTITION BY facility_equipment_id ORDER BY cleaning_task_start_date DESC) as row_num,
//                 'before' as time_period
//             ")
//             ->from('facility_equipment_cleaning_schedules')
//             ->where('cleaning_task_start_date', '<', $currentDate)
//             ->where('created_by', $authId)
//             ->unionAll(
//                 DB::table('facility_equipment_cleaning_schedules')
//                 ->selectRaw("
//                     facility_equipment_id, cleaning_task_start_date, id, created_by,
//                     ROW_NUMBER() OVER (PARTITION BY facility_equipment_id ORDER BY cleaning_task_start_date ASC) as row_num,
//                     'after' as time_period
//                 ")
//                 ->where('cleaning_task_start_date', '>', $currentDate)
//                 ->where('created_by', $authId)
//             );
//         }, 'RankedTasks')
//         ->where(function ($whereQuery) {
//             $whereQuery->where('time_period', 'before')->where('row_num', '<=', 3)
//                       ->orWhere('time_period', 'after')->where('row_num', '<=', 7);
//         })
//         ->orderBy('facility_equipment_id')
//         ->orderBy('cleaning_task_start_date');

//     // Paginate the results
//     $cleaning_schedule = $query->paginate($pageSize);

   
//      $departments =  DB::table('departments')->where('unit_id',Auth::id())->get();
//      $locations =  DB::table('locations')->where('created_by',Auth::id())->where('parent',null)->get();
//      $equipments = DB::table('facility_equipment')->where('created_by',Auth::id())->get();
     
//           $responsibility  =  DB::table('authority')->where('unit_id',Auth::id())->get();

     
//     return view('admin.fhm.cleaning_schedule', [
//         'cleaning_schedule' => $cleaning_schedule,
//         'departments' => $departments,
//         'locations' => $locations,
//         'responsibility'=>$responsibility,
//         'equipments' => $equipments,
//     ]);
// }

public function fhmcleaningschedule(Request $request)
{
    $this->fhmcleaningscheduleentries();
    $login_user = Auth::id();
    $s_date = $request->input('s_date');
    $e_date = $request->input('e_date');
    $sublocation = $request->input('sublocation');
    $location = $request->input('location');
    $status = $request->input('status');
    $responsibilitys = $request->input('responsibilitys');
    $entries = $request->input('entries', 10);
    $equipmentname = $request->input('equipment');

    $responsibility = DB::table('authority')->where('unit_id', $login_user)->get();
    $locations = DB::table('locations')->where('created_by', $login_user)->whereNull('parent')->get();
    $sub_location = DB::table('locations')->where('parent', $location)->get();
    $departments =  DB::table('departments')->where('unit_id',Auth::id())->get();
 
    $equipments = DB::table('facility_equipment')->where('created_by',Auth::id())->get();

    if ($s_date || $e_date || $sublocation || $location || $status || $responsibilitys || $equipmentname) {
        $cleaning_schedule_query = DB::table('facility_equipment_cleaning_schedules')
            ->join('facility_equipment', 'facility_equipment.id', '=', 'facility_equipment_cleaning_schedules.facility_equipment_id')
            ->select(
                'facility_equipment_cleaning_schedules.*',
                'facility_equipment.name as equipment_name',
                'facility_equipment.location_id',
                'facility_equipment.sub_location',
                'facility_equipment.responsibility_id'
            )
            ->orderBy('cleaning_task_start_date', 'desc');

        if ($location) {
            $cleaning_schedule_query->where('facility_equipment.location_id', $location);
        }
        if ($sublocation) {
            $cleaning_schedule_query->where('facility_equipment.sub_location', $sublocation);
        }
        if ($responsibilitys) {
            $cleaning_schedule_query->where('facility_equipment.responsibility_id', $responsibilitys);
        }
        if ($equipmentname) {
            $cleaning_schedule_query->where('facility_equipment.name', 'like', "%$equipmentname%");
        }
        if ($s_date && $e_date) {
            $cleaning_schedule_query->whereBetween('facility_equipment_cleaning_schedules.cleaning_task_start_date', [$s_date, $e_date]);
        }

        $cleaning_schedule = $cleaning_schedule_query->paginate($entries);
    } else {
        $currentPage = $request->get('page', 1);
        $pageSize = $entries; 
        $offset = ($currentPage - 1) * $pageSize;
        $today = Carbon::now()->toDateString();
        $threeDaysAgo = Carbon::now()->subDays(3)->toDateString();

        $cleaning_schedule = DB::table('facility_equipment_cleaning_schedules')
            ->orderByRaw("
                CASE 
                    WHEN cleaning_task_start_date = ? THEN 0 -- Today's data first
                    WHEN cleaning_task_start_date BETWEEN ? AND ? THEN 1 -- Last 3 days second
                    ELSE 2 -- The rest
                END", [$today, $threeDaysAgo, $today])
            ->orderBy('cleaning_task_start_date', 'asc')
            ->paginate($pageSize); 
    }


    return view('admin.fhm.cleaning_schedule', [
        'cleaning_schedule' => $cleaning_schedule,
        'responsibility' => $responsibility,
        'locations' => $locations,
        'sub_location' => $sub_location,
        'departments' => $departments,
        'equipments' => $equipments
    ]);
}


public function fhmpmschedule(Request $request)
{
    $this->fhmpmscheduleentries();
    $login_user = Auth::id();
    $s_date = $request->input('s_date');
    $e_date = $request->input('e_date');
    $sublocation = $request->input('sublocation');
    $location = $request->input('location');
    $status = $request->input('status');
    $responsibilitys = $request->input('responsibilitys');
    $entries = $request->input('entries', 10);
    $equipmentname = $request->input('equipment');

    $responsibility = DB::table('authority')->where('unit_id', $login_user)->get();
    $locations = DB::table('locations')->where('created_by', $login_user)->whereNull('parent')->get();
    $sub_location = DB::table('locations')->where('parent', $location)->get();
    $departments =  DB::table('departments')->where('unit_id',Auth::id())->get();
 
    $equipments = DB::table('facility_equipment')->where('created_by',Auth::id())->get();

    if ($s_date || $e_date || $sublocation || $location || $status || $responsibilitys || $equipmentname) {
        $cleaning_schedule_query = DB::table('pm_schedules')
            ->join('facility_equipment', 'facility_equipment.id', '=', 'pm_schedules.facility_equipment_id')
            ->select(
                'pm_schedules.*',
                'facility_equipment.name as equipment_name',
                'facility_equipment.location_id',
                'facility_equipment.sub_location',
                'facility_equipment.responsibility_id'
            )
            ->orderBy('cleaning_task_start_date', 'desc');

        if ($location) {
            $cleaning_schedule_query->where('facility_equipment.location_id', $location);
        }
        if ($sublocation) {
            $cleaning_schedule_query->where('facility_equipment.sub_location', $sublocation);
        }
        if ($responsibilitys) {
            $cleaning_schedule_query->where('facility_equipment.responsibility_id', $responsibilitys);
        }
        if ($equipmentname) {
            $cleaning_schedule_query->where('facility_equipment.name', 'like', "%$equipmentname%");
        }
        if ($s_date && $e_date) {
            $cleaning_schedule_query->whereBetween('pm_schedules.pm_task_start_date', [$s_date, $e_date]);
        }

        $cleaning_schedule = $cleaning_schedule_query->paginate($entries);
    } else {
        $currentPage = $request->get('page', 1);
        $pageSize = $entries; 
        $offset = ($currentPage - 1) * $pageSize;
        $today = Carbon::now()->toDateString();
        $threeDaysAgo = Carbon::now()->subDays(3)->toDateString();

        $cleaning_schedule = DB::table('pm_schedules')
            ->orderByRaw("
                CASE 
                    WHEN pm_task_start_date = ? THEN 0 -- Today's data first
                    WHEN pm_task_start_date BETWEEN ? AND ? THEN 1 -- Last 3 days second
                    ELSE 2 -- The rest
                END", [$today, $threeDaysAgo, $today])
            ->orderBy('pm_task_start_date', 'asc')
            ->paginate($pageSize); 
    }


    return view('admin.fhm.pm_schedule', [
        'cleaning_schedule' => $cleaning_schedule,
        'responsibility' => $responsibility,
        'locations' => $locations,
        'sub_location' => $sub_location,
        'departments' => $departments,
        'equipments' => $equipments
    ]);
}

public function fhmcleaningschedulehistory($id){
    $cleaning_schedules = DB::table('facility_equipment_cleaning_schedules')
    ->where('facility_equipment_cleaning_schedules.facility_equipment_id',$id)
    ->where('facility_equipment_cleaning_schedules.cleaning_task_start_date', '<=', Carbon::today())
    ->join('facility_equipment', 'facility_equipment_cleaning_schedules.facility_equipment_id', '=', 'facility_equipment.id')
    ->leftJoin('authority', 'facility_equipment.responsibility_id', '=', 'authority.id')
    ->leftJoin('departments', 'facility_equipment.department', '=', 'departments.id')
    ->leftJoin('locations', 'facility_equipment.location_id', '=', 'locations.id')
    ->select(
        'facility_equipment_cleaning_schedules.*',
        'facility_equipment.name as equipment_name',
        DB::raw('COALESCE(authority.name, "N/A") as responsibility_name'),
        DB::raw('COALESCE(departments.name, "N/A") as department_name'),
        DB::raw('COALESCE(locations.name, "N/A") as location_name')
    )
    
    ->get();
    
       return view('admin.fhm.cleaning_schedule_history', [
        'cleaning_schedules' => $cleaning_schedules,
        'id' => $id,
    ]);
}

public function fhmpmschedulehistory($id){
    $cleaning_schedules = DB::table('pm_schedules')
    ->where('pm_schedules.facility_equipment_id',$id)
    ->where('pm_schedules.pm_task_start_date', '<=', Carbon::today())
    ->join('facility_equipment', 'pm_schedules.facility_equipment_id', '=', 'facility_equipment.id')
    ->leftJoin('authority', 'facility_equipment.responsibility_id', '=', 'authority.id')
    ->leftJoin('departments', 'facility_equipment.department', '=', 'departments.id')
    ->leftJoin('locations', 'facility_equipment.location_id', '=', 'locations.id')
    ->select(
        'pm_schedules.*',
        'facility_equipment.name as equipment_name',
        DB::raw('COALESCE(authority.name, "N/A") as responsibility_name'),
        DB::raw('COALESCE(departments.name, "N/A") as department_name'),
        DB::raw('COALESCE(locations.name, "N/A") as location_name')
    )
    
    ->get();
    
       return view('admin.fhm.pm_schedule_history', [
        'cleaning_schedules' => $cleaning_schedules,
        'id' => $id,
    ]);
}


public function fhmCleaningEquipmentName($id)
{
    try {
        // Fetch the category data
        $category = DB::table('fhm_category')->where('id', $id)->first();

        // Check if data is found
        if (!$category) {
            return response()->json([
                'status' => false,
                'message' => 'Category not found',
            ], 404);
        }

        // Return data as JSON
        return response()->json([
            'status' => true,
            'data' => $category,
        ]);
    } catch (\Exception $e) {
        // Log the error for debugging
        \Log::error('Error fetching category: ' . $e->getMessage());

        // Return a 500 error response
        return response()->json([
            'status' => false,
            'message' => 'Server error',
        ], 500);
    }
}


public function fhmcleaningscheduleentries()
{
    $facility_equipments = DB::table('facility_equipment')->where('created_by', Auth::user()->id)->where('cleaning_task_start_date' ,'!=' , '')->where('c_frequency','!=','')->get();
    
    foreach ($facility_equipments as $equipment) {
        $frequency = $equipment->c_frequency;
        $future_cleaning_schedules = DB::table('facility_equipment_cleaning_schedules')
            ->where('facility_equipment_id', $equipment->id)
            ->where('cleaning_task_start_date', '>=', Carbon::now()) 
            ->orderBy('cleaning_task_start_date', 'asc') 
            ->get();
        

        $existing_future_entries = $future_cleaning_schedules->count();

        if ($existing_future_entries === 0) {
            $start_date = Carbon::parse($equipment->cleaning_task_start_date);
            
            for ($i = 1; $i <= 10; $i++) {
                if ($i == 1) { 
                    $new_date = $start_date; 
                } else {
                    $new_date = $start_date->copy()->addDays($frequency * ($i - 1));
                }
                
                DB::table('facility_equipment_cleaning_schedules')->insert([
                    'facility_equipment_id' => $equipment->id,
                    'cleaning_task_start_date' => $new_date->toDateString(),
                    'frequency' => $frequency,
                    'created_by' => $equipment->created_by,
                    'created_at' => Carbon::now(),
                ]);
            }
            continue;
        }

       $last_schedule_date = Carbon::createFromFormat('Y-m-d', $future_cleaning_schedules->last()->cleaning_task_start_date); 

        $entries_to_create = (7 - $existing_future_entries) ?? 0;

        for ($i = 0; $i < $entries_to_create; $i++) {
            $last_schedule_date->addDays($frequency);
            DB::table('facility_equipment_cleaning_schedules')->insert([
                'facility_equipment_id' => $equipment->id,
                'cleaning_task_start_date' => $last_schedule_date->toDateString(),
                'frequency' => $frequency,
                'created_by' => $equipment->created_by,
                'created_at' => Carbon::now(),
            ]);
        }
    }
}

public function fhmpmscheduleentries()
{
    $facility_equipments = DB::table('facility_equipment')->where('created_by', Auth::user()->id)->where('pm_task_start_date' ,'!=' , '')->where('p_frequency','!=','')->get();
    
    foreach ($facility_equipments as $equipment) {
        $frequency = $equipment->p_frequency;
        $future_cleaning_schedules = DB::table('pm_schedules')
            ->where('facility_equipment_id', $equipment->id)
            ->where('pm_task_start_date', '>=', Carbon::now()) 
            ->orderBy('pm_task_start_date', 'asc') 
            ->get();
        

        $existing_future_entries = $future_cleaning_schedules->count();

        if ($existing_future_entries === 0) {
            $start_date = Carbon::parse($equipment->pm_task_start_date);
            
            for ($i = 1; $i <= 10; $i++) {
                if ($i == 1) { 
                    $new_date = $start_date; 
                } else {
                    $new_date = $start_date->copy()->addDays($frequency * ($i - 1));
                }
                
                DB::table('pm_schedules')->insert([
                    'facility_equipment_id' => $equipment->id,
                    'pm_task_start_date' => $new_date->toDateString(),
                    'frequency' => $frequency,
                    'created_by' => $equipment->created_by,
                    'created_at' => Carbon::now(),
                ]);
            }
            continue;
        }

       $last_schedule_date = Carbon::createFromFormat('Y-m-d', $future_cleaning_schedules->last()->pm_task_start_date); 

        $entries_to_create = (7 - $existing_future_entries) ?? 0;

        for ($i = 0; $i < $entries_to_create; $i++) {
            $last_schedule_date->addDays($frequency);
            DB::table('pm_schedules')->insert([
                'facility_equipment_id' => $equipment->id,
                'pm_task_start_date' => $last_schedule_date->toDateString(),
                'frequency' => $frequency,
                'created_by' => $equipment->created_by,
                'created_at' => Carbon::now(),
            ]);
        }
    }
}

public function fhmCategoryExport()
{
    // Fetch data to export
    // $data = DB::table('fhm_category')->where('created_by',Auth::id())->get();
      $regionalIds = DB::table('users')->where('id', Auth::id())->pluck('created_by1')->toArray();
      $corporateIds = DB::table('users')->whereIn('id', $regionalIds)->pluck('created_by')->toArray();

    $data = DB::table('fhm_category')->whereIn('created_by',$corporateIds)->get();

    // $data = DB::table('fhm_category')->get();


    // Set CSV filename
    $fileName = 'export_data_fhm_category' . date('Y-m-d_H-i-s') . '.csv';

    $headers = [
        "Content-Type" => "text/csv",
        "Content-Disposition" => "attachment; filename=$fileName",
    ];

    // Callback function to write data
    $callback = function () use ($data) {
        // Open output stream
        $file = fopen('php://output', 'w');

        // Write header row
        fputcsv($file, ['Sno.', 'Name']); // Add your column names here

 $sno = 1;
        // Write data rows
        foreach ($data as $row) {
            fputcsv($file, [
                $sno++, // Replace with actual column names
                $row->name,
            ]);
        }

        // Close output stream
        fclose($file);
    };

    // Return response with streamed data
    return response()->stream($callback, 200, $headers);
}


public function fhmResponsibilityExport()
{
    // Fetch data to export
    $data = DB::table('authority')->where('unit_id',Auth::id())->get();

    // Set CSV filename
    $fileName = 'export_data_responsibility' . date('Y-m-d_H-i-s') . '.csv';

    $headers = [
        "Content-Type" => "text/csv",
        "Content-Disposition" => "attachment; filename=$fileName",
    ];

    // Callback function to write data
    $callback = function () use ($data) {
        // Open output stream
        $file = fopen('php://output', 'w');

        // Write header row
        fputcsv($file, ['Sno.', 'Name']); // Add your column names here

 $sno = 1;
        // Write data rows
        foreach ($data as $row) {
            fputcsv($file, [
                $sno++, // Replace with actual column names
                $row->name,
            ]);
        }

        // Close output stream
        fclose($file);
    };

    // Return response with streamed data
    return response()->stream($callback, 200, $headers);
}


public function fhmDepartmentExport()
{
    // Fetch data to export
    $data = DB::table('departments')->where('unit_id',Auth::id())->get();

    // Set CSV filename
    $fileName = 'export_data_department' . date('Y-m-d_H-i-s') . '.csv';

    $headers = [
        "Content-Type" => "text/csv",
        "Content-Disposition" => "attachment; filename=$fileName",
    ];

    // Callback function to write data
    $callback = function () use ($data) {
        // Open output stream
        $file = fopen('php://output', 'w');

        // Write header row
        fputcsv($file, ['Sno.', 'Name']); // Add your column names here

 $sno = 1;
        // Write data rows
        foreach ($data as $row) {
            fputcsv($file, [
                $sno++, // Replace with actual column names
                $row->name,
            ]);
        }

        // Close output stream
        fclose($file);
    };

    // Return response with streamed data
    return response()->stream($callback, 200, $headers);
}


    public function index(Request $request) {
	
		$is_role = Auth::user()->is_role;
		    $corporate_id = $_GET['corporate_id'] ?? '';
                   $regional_id = $_GET['regional_id'] ?? '';
                     $hotel_name = $_GET['hotel_name'] ?? '';
                       $location_id = $_GET['location_id'] ?? '';
		
		
		
		 $facility_equipment = DB::table('facility_equipment');
		
		                       if(!empty($corporate_id)){
            $facility_equipment =  $facility_equipment->where('corporate_id',$corporate_id);  
          }
		
		                       if(!empty($regional_id)){
            $facility_equipment =  $facility_equipment->where('regional_id',$regional_id);  
          }
		                       if(!empty($hotel_name)){
            $facility_equipment =  $facility_equipment->where('hotel_name',$hotel_name);  
          }
		                       if(!empty($location_id)){
            $facility_equipment =  $facility_equipment->where('location_id',$location_id);  
          
          }
          
            $facility_equipment =  $facility_equipment->where('created_by',Auth::user()->id);  
		$facility_equipment = $facility_equipment->orderBy('id', 'DESC')->paginate(10);

		
		
		        if(!empty(Session::get('unit_id'))  ){
$login_user=  Session::get('unit_id');
}
else{
$login_user=  Auth::user()->id;   
}


	$departments = DB::table('departments')->where('unit_id',$login_user)->get();
		$chemical = DB::table('chemical')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
		$toollist = DB::table('toolselection')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
			$schedulemakerlist = DB::table('cleaning')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->where('type',"1")->get();
			$schedulemakerlist1 = DB::table('cleaning')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->where('type',"2")->get();
		$authority = DB::table('authority')->where('unit_id',Auth::user()->id)->orderBy('id', 'DESC')->get();
		$calibration = DB::table('calibration')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
				// $catlist = DB::table('fhm_category')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
				// 	$catlist = DB::table('fhm_category')->orderBy('id', 'DESC')->get();
					
					$regionalIds = DB::table('users')->where('id', Auth::id())->pluck('created_by1')->toArray();
$corporateIds = DB::table('users')->whereIn('id', $regionalIds)->pluck('created_by')->toArray();

    $catlist = DB::table('fhm_category')->whereIn('created_by',$corporateIds)->get();
 
					
return view('admin.fhm.list',compact('facility_equipment','chemical','toollist','schedulemakerlist','schedulemakerlist1','departments','authority','calibration','is_role','catlist'));
}


    public function fhmcat(Request $request) {

		$list = DB::table('fhm_category')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
return view('admin.fhm.catlist',compact('list'));
}



    public function fhm_details($id) {
        				// $catlist = DB::table('fhm_category')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
        					$catlist = DB::table('fhm_category')->orderBy('id', 'DESC')->get();
		        if(!empty(Session::get('unit_id'))  ){
$login_user=  Session::get('unit_id');
}
else{
$login_user=  Auth::user()->id;   
}


	$departments = DB::table('departments')->where('unit_id',$login_user)->get();	
	$facility_equipments = DB::table('facility_equipment')->where('id',$id)->first();

return view('admin.fhm.fhm_details',compact('facility_equipments','catlist','departments'));
}


    public function fhm_delete($id) {
     
     
     $facility_equipments = DB::table('facility_equipment_calibration')->where('id',$id)->first();
     
     
     
            	 $dataArr['fhm_id']=$facility_equipments->fhm_id;
            	 $dataArr['calibration_id']=$facility_equipments->id;
            	 $dataArr['unique_id']=$facility_equipments->unique_id;
            	 $dataArr['Calibrationstatus']="Deleted";
			$dataArr['calibration_date']=$facility_equipments->calibration_date;
			$dataArr['calibration_due_date']=$facility_equipments->calibration_due_date;
				$dataArr['calibration_expdate']=$facility_equipments->calibration_expdate;
			$dataArr['comments']="Deleted";

                        $dataArr['company_logo']= $facility_equipments->company_logo ?? '';
					          DB::table('calibration_history')->insert($dataArr);
 DB::table('facility_equipment_calibration')->where('id',$id)->delete();
	
    return back()->with('status', 'Deleted successfully');
}


    public function Calibration_details($id) {
        				$catlist = DB::table('fhm_category')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
		        if(!empty(Session::get('unit_id'))  ){
$login_user=  Session::get('unit_id');
}
else{
$login_user=  Auth::user()->id;   
}


	
	$departments = DB::table('departments')->where('unit_id',$login_user)->get();	
	$fhm_id = $id;
	$facility_equipments = DB::table('facility_equipment')->where('id',$fhm_id)->first();
	
		$calibrationList = DB::table('facility_equipment_calibration')->where('fhm_id',$fhm_id)->get();
	$calibration_history = DB::table('calibration_history')->where('fhm_id',$fhm_id)->get();
return view('admin.fhm.calibration_details',compact('facility_equipments','catlist','calibration_history','id','calibrationList'));
}

  public function storeCat(Request $request) {

       $dataArr['created_by']=Auth::user()->id;
    	 $dataArr['name']=$request->name;
    	 $dataArr['c_frequency_hide']=$request->c_frequency_hide;
    	 $dataArr['c_frequency_daily']=$request->c_frequency_daily;
    	 $dataArr['c_frequency_weekly']=$request->c_frequency_weekly;
    	 $dataArr['p_frequency_type']=$request->p_frequency_type;
    	 $dataArr['p_frequency']=$request->p_frequency;
    	 
    	 
    	 if(!empty($request->edit_id)){
    	     
    	                 DB::table('fhm_category')->where('id',$request->edit_id)->update($dataArr);

    	 }else{
    	              DB::table('fhm_category')->insert($dataArr);
   
    	 }
		return redirect()->route('facility_hygiene_fhmcat')->with('add_department', 'Add Successfully');
}
    public function store(Request $request) {

    	 $dataArr['name']=$request->name;
    	 $dataArr['cat_id']=$request->cat_id;
		$dataArr['equipment_id']=$request->equipment_id;
		$dataArr['brand']=$request->brand;
		$dataArr['corporate_id']=$request->corporate_id;
		$dataArr['responsibility_id']=$request->responsibility_id;
		$dataArr['Calibration_status']=$request->Calibration_status;
		$dataArr['regional_id']=$request->regional_id;
		$dataArr['hotel_name']=$request->hotel_name;
		$dataArr['department']=$request->department;
		$dataArr['location_id']=$request->location_id;
		$dataArr['sub_location']=$request->sub_location;
		$dataArr['cleaning_last_completed_on']=$request->cleaning_last_completed_on;
		$dataArr['pm_last_completed_on']=$request->pm_last_completed_on;
		$dataArr['cleaning_task_start_date']=$request->cleaning_task_start_date;
		$dataArr['c_frequency']=$request->c_frequency;
		$dataArr['p_frequency']=$request->p_frequency;
		$dataArr['pm_task_start_date']=$request->pm_task_start_date;
       $dataArr['created_by']=Auth::user()->id;
      
                    	
            DB::table('facility_equipment')->insert($dataArr);
            
            $Lastinsert= DB::getPdo()->lastInsertId();

            
            
                    // Prepare and insert calibration data
        $least_counts = $request->least_count;
        $unique_ids = $request->unique_id;
        $types = $request->type;
        $capacity_ranges = $request->capacity_range;
        $capacity_utility_ranges = $request->capacity_utility_range;
        $calibration_ranges = $request->calibration_range;
        $calibration_dates = $request->calibration_date;
        $calibration_due_dates = $request->calibration_due_date;
        $calibration_expdate = $request->calibration_expdate;
        $company_logos = $request->file('company_logo');

        for ($i = 0; $i < count($least_counts); $i++) {
            $calibrationData = [
                'fhm_id' => $Lastinsert,
                'least_count' => $least_counts[$i],
                'unique_id' => $unique_ids[$i],
                'type' => $types[$i],
                'capacity_range' => $capacity_ranges[$i],
                'capacity_utility_range' => $capacity_utility_ranges[$i],
                'calibration_range' => $calibration_ranges[$i],
                'calibration_date' => $calibration_dates[$i],
                'calibration_expdate' => $calibration_expdate[$i],
                'calibration_due_date' => $calibration_due_dates[$i],
                'created_by' => Auth::user()->id,
            ];

            if ($company_logos && array_key_exists($i, $company_logos)) {
                $company_logo = $company_logos[$i];
                $filename = time() . '_' . $company_logo->getClientOriginalName();
                
                   $company_logo-> move(public_path('companylogo'), $filename);
                   
                   
               // $path = $company_logo->storeAs('uploads', $filename, 'public');
                $calibrationData['company_logo'] = $filename;
            }


	
            DB::table('facility_equipment_calibration')->insert($calibrationData);

        }
		
		
		  $this->fhmcleaningscheduleentries();
		  $this->fhmpmscheduleentries();

		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}





    public function facility_calibration_history(Request $request) {
        
        
            	 $dataArr['fhm_id']=$request->fhm_id;
            	 $dataArr['calibration_id']=$request->calibration_id;
            	 $dataArr['unique_id']=$request->unique_id;
            	 $dataArr['Calibrationstatus']=$request->Calibrationstatus;
			$dataArr['calibration_date']=$request->calibration_date;
			$dataArr['calibration_due_date']=$request->calibration_due_date;
			$dataArr['calibration_expdate']=$request->calibration_expdate;
			$dataArr['comments']=$request->comments;

					
						      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
					          DB::table('calibration_history')->insert($dataArr);
    return redirect()->back()->with('add_department', 'Add Successfully');

}

public function facility_edit(Request $request) {
    // Retrieve the existing equipment record or create a new one
    if($request->edit_id) {
        $facilityEquipment = DB::table('facility_equipment')->where('id', $request->edit_id)->first();
        $update = true;
    } else {
        $facilityEquipment = null;
        $update = false;
    }
    
    // Prepare the main data array
    $dataArr = [
        'name' => $request->name,
        'cat_id' => $request->cat_id,
        'equipment_id' => $request->equipment_id,
        'brand' => $request->brand,
        'responsibility_id' => $request->responsibility_id,
        'department' => $request->department,
        'location_id' => $request->location_id,
        'sub_location' => $request->sub_location,
        'cleaning_task_start_date' => $request->cleaning_task_start_date,
        'c_frequency' => $request->c_frequency,
        'p_frequency' => $request->p_frequency,
        'pm_task_start_date' => $request->pm_task_start_date,
    ];
    
    if($update) {
        DB::table('facility_equipment')->where('id', $request->edit_id)->update($dataArr);
        $Lastinsert = $request->edit_id;
    } else {
        $Lastinsert = DB::table('facility_equipment')->insertGetId($dataArr);
    }

    // Handle calibration data
    $least_counts = $request->least_count;
    $unique_ids = $request->unique_id;
    $types = $request->type;
    $capacity_ranges = $request->capacity_range;
    $capacity_utility_ranges = $request->capacity_utility_range;
    $calibration_ranges = $request->calibration_range;
    $calibration_dates = $request->calibration_date;
    $calibration_due_dates = $request->calibration_due_date;
     $calibration_expdate = $request->calibration_expdate;
    $company_logos = $request->file('company_logo');

    for ($i = 0; $i < count($least_counts); $i++) {
        $calibrationData = [
            'fhm_id' => $Lastinsert,
            'least_count' => $least_counts[$i],
            'unique_id' => $unique_ids[$i],
            'type' => $types[$i],
            'capacity_range' => $capacity_ranges[$i],
            'capacity_utility_range' => $capacity_utility_ranges[$i],
            'calibration_range' => $calibration_ranges[$i],
            'calibration_date' => $calibration_dates[$i],
            'calibration_due_date' => $calibration_due_dates[$i],
            'calibration_expdate' => $calibration_expdate[$i],
            'created_by' => Auth::user()->id,
        ];

        if ($company_logos && array_key_exists($i, $company_logos)) {
            $company_logo = $company_logos[$i];
            $filename = time() . '_' . $company_logo->getClientOriginalName();
            $company_logo->move(public_path('companylogo'), $filename);
            $calibrationData['company_logo'] = $filename;
        }

        if($update) {
            // Update or insert calibration data
            DB::table('facility_equipment_calibration')->updateOrInsert(
                ['unique_id' => $unique_ids[$i], 'fhm_id' => $Lastinsert],
                $calibrationData
            );
        } else {
            DB::table('facility_equipment_calibration')->insert($calibrationData);
        }
    }

    return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}

	
		    public function facility_tool_store(Request $request) {

    	 $dataArr['name']=$request->name;
			$dataArr['purpose']=$request->purpose;
			$dataArr['target_surface']=$request->target_surface;
       $dataArr['created_by']=Auth::user()->id;
				
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
            DB::table('toolselection')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
			    public function facility_tool_update(Request $request) {

    	 $dataArr['name']=$request->name;
			$dataArr['purpose']=$request->purpose;
			$dataArr['target_surface']=$request->target_surface;

					
						      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
					
					
					          DB::table('toolselection')->where('id',$request->tool_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	    public function update(Request $request) {

    	    	 $dataArr['name']=$request->name;
		$dataArr['type']=$request->type;
		$dataArr['brand']=$request->brand;
		$dataArr['capacity_range']=$request->capacity_range;
		$dataArr['capacity_utility_range']=$request->capacity_utility_range;
		$dataArr['corporate_id']=$request->corporate_id;
		$dataArr['regional_id']=$request->regional_id;
		$dataArr['hotel_name']=$request->hotel_name;
		$dataArr['department']=$request->department;
		$dataArr['location_id']=$request->location_id;
		$dataArr['sub_location']=$request->sub_location;

  
		
		
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
			
		
            DB::table('facility_equipment')->where('id',$request->equipments_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	
	
		    public function destory($id) {
    	$retData=DB::table('facility_equipment')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}	


		    public function destory_cat($id) {
    	$retData=DB::table('fhm_category')->where('id',$id)->delete();
return redirect()->route('facility_hygiene_fhmcat')->with('success', 'Delete Successfully');
}






		    public function destoryCalibration($id) {
    	$retData=DB::table('facility_equipment_calibration')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
	
	    public function chemical_store(Request $request) {
  
    	 $dataArr['name']=$request->name;
       $dataArr['created_by']=Auth::user()->id;
    	 $dataArr['nature']=$request->nature;
            $dataArr['target_soil']=$request->target_soil;
            $dataArr['Used_with_solvemt']=$request->Used_with_solvemt;
            $dataArr['contacttime']=$request->contacttime;
            $dataArr['temp_requrement']=$request->temp_requrement;
            $dataArr['Wet']=$request->Wet;
			$dataArr['target_surface_make']=$request->target_surface_make;
		
		      if($request->file('company_logo')){
			
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
			
			else{
			
			}
	
            DB::table('chemical')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
		    public function chemical_edit(Request $request) {
  
    	 $dataArr['name']=$request->name;
    	 $dataArr['nature']=$request->nature;
            $dataArr['target_soil']=$request->target_soil;
            $dataArr['Used_with_solvemt']=$request->Used_with_solvemt;
            $dataArr['contacttime']=$request->contacttime;
            $dataArr['temp_requrement']=$request->temp_requrement;
            $dataArr['Wet']=$request->Wet;
			$dataArr['target_surface_make']=$request->target_surface_make;
		      if($request->file('company_logo')){
			
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
			
			else{
			
			}
	
            DB::table('chemical')->where('id',$request->chemical_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
			    public function destory1($id) {
    	$retData=DB::table('chemical')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
				    public function destory2($id) {
    	$retData=DB::table('toolselection')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
			    public function schedule_maker_store(Request $request) {
			
    	 $dataArr['name']=$request->name;
			$dataArr['location_id']=$request->location_id;
			$dataArr['corporate_id']=$request->corporate_id;
							$dataArr['regional_id']=$request->regional_id;
							$dataArr['hotel_name']=$request->hotel_name;
					$dataArr['frequency']=$request->frequency;
			$dataArr['task_start_date']=$request->task_start_date;
						
						  $dataArr['department']=$request->department;
				   $dataArr['sub_location']=$request->sub_location ?? NULL;
					 $dataArr['responsibility_id']=$request->responsibility_id ?? NULL;
					$dataArr['type']=$request->type;
       $dataArr['created_by']=Auth::user()->id;
            DB::table('cleaning')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
				    public function schedule_maker_edit(Request $request) {
			
    	 $dataArr['name']=$request->name;
			$dataArr['location_id']=$request->location_id;
			$dataArr['corporate_id']=$request->corporate_id;
							$dataArr['regional_id']=$request->regional_id;
							$dataArr['hotel_name']=$request->hotel_name;
					$dataArr['frequency']=$request->frequency;
			$dataArr['task_start_date']=$request->task_start_date;
						
						  $dataArr['department']=$request->department;
				   $dataArr['sub_location']=$request->sub_location ?? NULL;
						 $dataArr['responsibility_id']=$request->responsibility_id ?? NULL;
						
						
						
            DB::table('cleaning')->where('id',$request->schedule_maker_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}

	
					    public function destory3($id) {
    	$retData=DB::table('cleaning')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
	
     public function import(Request $request){
    
            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            
  
            foreach ($data as $key => $value) {
                
          
                if((isset($value['Equipment Name']))  ){
       
                    
        $locationName = DB::table('locations')->where('name',$value['Location'])->value('id');
        $DepartmentName = DB::table('departments')->where('name',$value['Department'])->value('id');
        $responsibilityName = DB::table('authority')->where('name',$value['Cleaning Responsibility'])->value('id');
	    $dataArr2['name']=$value['Equipment Name'];
		$dataArr2['brand']=$value['Brand'];
		$dataArr2['equipment_category']=$value['Equipment Category'];
		$dataArr2['equipment_id']=$value['Equipment ID'];
		$dataArr2['responsibility_id']=$responsibilityName ?? '';
		$dataArr2['cleaning_task_start_date']=$value['Cleaning Starting Date'];
		$dataArr2['pm_task_start_date']=$value['PM Starting Date'];
		$dataArr2['location_id']=$locationName ?? '';
		$dataArr2['department']=$DepartmentName ?? '';
        $dataArr2['created_by']=Auth::user()->id ?? '';
             $enrolled_users= DB::table('facility_equipment')->insert($dataArr2);  
             
             $Lastinsert=  DB::getPdo()->lastInsertId();
             
             if($Lastinsert){
                 
                 
                  $calibrationData = [
                'fhm_id' => $Lastinsert,
                'least_count' => $value['Calibration Least Count'],
                'unique_id' =>$value['Calibration Unique ID'],
                'type' => $value['Calibration Type'],
                'capacity_range' => $value['Capacity Range'],
                'capacity_utility_range' => $value['Calibration Current utility Range'],
                'calibration_due_date' => $value['Calibration Due Date'],
                'calibration_date' => $value['Calibration Date'],
                'calibration_expdate' => $value['Calibration Exp Date'],
                'modal_number' => $value['Modal Number'],
                'sr_number' => $value['Sr Number'],
                'certificate_number' => $value['Certificate number'],
                'created_by' => Auth::user()->id,
            ];
            
            
            //      if((isset($value['Calibration Unique ID 2']))  ){
            //                   $calibrationData2 = [
            //     'fhm_id' => $Lastinsert,
            //     'least_count' => $value['Calibration Least Count 2'],
            //     'unique_id' =>$value['Calibration Unique ID 2'],
            //     'type' => $value['Calibration Type 2'],
            //     'capacity_range' => $value['Capacity Range 2'],
            //     'capacity_utility_range' => $value['Calibration Current utility Range 2'],
            //     'calibration_range' => $value['Calibration Calibration Range 2'],
            //     'calibration_date' => $value['Calibration Date 2'],
            //     'created_by' => Auth::user()->id,
            // ];
            
            //                         DB::table('facility_equipment_calibration')->insert($calibrationData2);
            
            //      }
            
            
                        DB::table('facility_equipment_calibration')->insert($calibrationData);

            
            
             }


              

                    $prdCnt++;
                }
            }
            
        return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
    

    }
    
    
         public function import_equipment2(Request $request){
         
    
            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            
  
            foreach ($data as $key => $value) {
                
          
                if((isset($value['Name']))  ){


               
	        $dataArr['created_by']=Auth::user()->id;
    	 $dataArr['name']=$value['Name'];;
    	 $dataArr['c_frequency_daily']=$value['Cleaning Schedule Daily'];
    	 $dataArr['c_frequency_weekly']=$value['Cleaning Schedule Special'];;
    	 $dataArr['p_frequency']=$value['PM Schedule Frequency'];;
             $enrolled_users= DB::table('fhm_category')->insert($dataArr);  

                    $prdCnt++;
                }
            }
            
        return redirect()->route('facility_hygiene_fhmcat')->with('add_department', 'Add Successfully');
    

    }
	
									    public function delete_all_equpitments(Request $request) {
							     $ids = $request->ids;
								foreach($ids as $idss){
								    DB::table("facility_equipment")->where('id',$idss)->delete();  
								}
        return response()->json(['success'=>" Deleted successfully."]);  
}
	
	
										    public function delete_all_chemicalselection(Request $request) {
							     $ids = $request->ids;
								foreach($ids as $idss){
								    DB::table("chemical")->where('id',$idss)->delete();  
								}
        return response()->json(['success'=>" Deleted successfully."]);  
}
	
	
											    public function delete_all_toolselection(Request $request) {
							     $ids = $request->ids;
								foreach($ids as $idss){
								    DB::table("toolselection")->where('id',$idss)->delete();  
								}
        return response()->json(['success'=>" Deleted successfully."]);  
}
	
												    public function delete_all_cleaning_schedular(Request $request) {
							     $ids = $request->ids;
								foreach($ids as $idss){
								    DB::table("cleaning")->where('id',$idss)->delete();  
								}
        return response()->json(['success'=>" Deleted successfully."]);  
}
	
			    public function calibration_store(Request $request) {
    	 $dataArr['name']=$request->name;
			$dataArr['location_id']=$request->location_id;
			$dataArr['corporate_id']=$request->corporate_id;
							$dataArr['regional_id']=$request->regional_id;
							$dataArr['hotel_name']=$request->hotel_name;
					$dataArr['brand']=$request->brand;
			$dataArr['capacity_range']=$request->capacity_range;
						$dataArr['brand']=$request->brand;
			$dataArr['capacity_range']=$request->capacity_range;
						$dataArr['capacity_utility_range']=$request->capacity_utility_range;
			$dataArr['id_no']=$request->id_no;
						$dataArr['calibration_range']=$request->calibration_range;
			$dataArr['least_count']=$request->least_count;
					$dataArr['calibration_date']=$request->calibration_date;
					$dataArr['calibration_due_date']=$request->calibration_due_date;
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
						  $dataArr['department']=$request->department;
				   $dataArr['sub_location']=$request->sub_location ?? NULL;
					$dataArr['type']=$request->type;
       $dataArr['created_by']=Auth::user()->id;
            DB::table('calibration')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	public function calibration_edit(Request $request) {
    	 $dataArr['name']=$request->name;
			$dataArr['location_id']=$request->location_id;
			$dataArr['corporate_id']=$request->corporate_id;
							$dataArr['regional_id']=$request->regional_id;
							$dataArr['hotel_name']=$request->hotel_name;
					$dataArr['brand']=$request->brand;
			$dataArr['capacity_range']=$request->capacity_range;
						$dataArr['brand']=$request->brand;
			$dataArr['capacity_range']=$request->capacity_range;
						$dataArr['capacity_utility_range']=$request->capacity_utility_range;
			$dataArr['id_no']=$request->id_no;
						$dataArr['calibration_range']=$request->calibration_range;
			$dataArr['least_count']=$request->least_count;
					$dataArr['calibration_date']=$request->calibration_date;
					$dataArr['calibration_due_date']=$request->calibration_due_date;
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
						  $dataArr['department']=$request->department;
				   $dataArr['sub_location']=$request->sub_location ?? NULL;
					$dataArr['type']=$request->type;

            DB::table('calibration')->where('id', $request->calibration_edit_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
				public function equipment_details(Request $request){
$users = DB::table('facility_equipment')->where('id', $request->id)->first();
		return response()->json(['data' => $users]);
	}
	
	
					public function facility_cat_details(Request $request){
$users = DB::table('fhm_category')->where('id', $request->id)->first();
		return response()->json(['data' => $users]);
	}
	
	
						    public function calibration_delete($id) {
    	$retData=DB::table('calibration')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
	
	
	     public function import1(Request $request){

    
       
            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            
  
            foreach ($data as $key => $value) {
			
				$Allergen =  explode(",", $value['Allergen']);

				$ids=array();
				foreach($Allergen as $Allergens){
					$product_Ingredients2 = DB::table('product_Ingredients')->where('name',$Allergens)->first();
					 $ids[] = $product_Ingredients2->id ?? '';
				}
	
				
				$ids = json_encode($ids);
				$product_Ingredients = DB::table('product_Ingredients')->where('name',$value['Ingredients_Symbol'])->first();
				$product_Ingredients1 = DB::table('refrences')->where('name',$value['Refrence'])->first();
		
          
                if((isset($value['Name']))  ){

					   	 		$dataArr['name']=$value['Name'];
							$dataArr['Keyword']=$value['Keyword'];
							$dataArr['Ingredients_Symbol']=$product_Ingredients->id ?? '';
							$dataArr['Refrence']=$product_Ingredients1->id ?? '';
							$dataArr['Energy']=$value['Energy'];
							$dataArr['Protein']=$value['Protein'];
							$dataArr['Allergen']=$ids;
								$dataArr['Carbohydrates']=$value['Carb'];
							$dataArr['Fat']=$value['Fat'];

        					$dataArr['created_by']=Auth::user()->id;
				
				
             $enrolled_users= DB::table('Ingredient')->insert($dataArr);   
              

                    $prdCnt++;
                }
            }
            
            return redirect()->route('nutrilator',['tab_name' => "6"])->with('add_department', 'Add Successfully');
        //return redirect()->route('nutrilator')->with('add_department', 'Add Successfully');
    

    }
	
	
	
	
		
	     public function importDepartment(Request $request){
	                  if(!empty(Session::get('unit_id'))  ){
$login_user=  Session::get('unit_id');
}
else{
$login_user=  Auth::user()->id;   
}
       
            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            
  
            foreach ($data as $key => $value) {
	
                if((isset($value['Name']))  ){
             
					   	 		$dataArr['name']=$value['Name'];
        					$dataArr['unit_id']=$login_user;
        			
				          $enrolled_users = DB::table('departments')->insert($dataArr);



                    $prdCnt++;
                }
            }
            
		return redirect()->route('department')->with('add_location', 'Add Successfully');
        //return redirect()->route('nutrilator')->with('add_department', 'Add Successfully');
    

    }
	
	
			
	     public function importLocation(Request $request){
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                if((isset($value['Name']))  ){
					   	 		$dataArr['name']=$value['Name'];
        					$dataArr['created_by']=$login_user;
        					 $dataArr['department_id']=$request->department_ids;
       
       
				          $enrolled_users = DB::table('locations')->insert($dataArr);
                    $prdCnt++;
                }
            }
		return redirect()->route('department')->with('add_location', 'Add Successfully');
    }
    
    
    public function importUserManagement(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                if((isset($value['Employee ID']))  ){
                    
      $departments = DB::table('departments')->where('name',$value['Department'])->where('unit_id',$login_user)->value('id');
      $Responsibility = DB::table('authority')->where('name',$value['Responsibility'])->where('unit_id',$login_user)->value('id');
$dataArr['employe_id']=$value['Employee ID'];
$dataArr['employer_fullname']=$value['Employee Full Name'];
$dataArr['email']=$value['Email'];
$dataArr['designation']=$value['Designation'];
$dataArr['staff_category']=$value['Staff Category'];
$dataArr['gender']=$value['Gender'] ?? NULL;
$dataArr['contact_number']=$value['Contact Number'];
$dataArr['cat_name']=$value['Food Handlers Category'] ?? NULL;
$dataArr['dog']=date('Y-m-d', strtotime($value['DOJ'])) ?? NULL;
$dataArr['dob']=date('Y-m-d', strtotime($value['DOB'])) ?? NULL;
       $dataArr['department']=$departments ?? NULL;
       $dataArr['responsibility_id']=$Responsibility ?? NULL;
                $dataArr['created_by']=$login_user;
                DB::table('unit_users')->insert($dataArr);
                    $prdCnt++;
                }
            }
		return redirect()->route('department');
    }
    
    public function importConcernManagement(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                  $subconcern_list = DB::table('tbl_concern')->where('name',$value['concern'])->where('created_by',$login_user)->value('id');
                if((isset($value['name']))  ){
    $dataArr['name']=$value['name'];
    $dataArr['parent']=$subconcern_list ?? NULL;
    $dataArr['created_by']=$login_user;
                DB::table('tbl_concern')->insert($dataArr);
                    $prdCnt++;
                }
            }
		return redirect()->route('department');
    }
    
    
    public function importSupplier(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {


        $dataArr['supplier_name']=$value['Supplier Name'];
        $dataArr['address']=$value['Address'];
        $dataArr['name']=$value['Contact Person Name'];
        $dataArr['email']=$value['Email'];
        $dataArr['mobile_number']=$value['Mobile'];
        $dataArr['license_number']=$value['License Number'];
        $dataArr['license_validity']=date('Y-m-d', strtotime($value['License Validity'])); 
        $dataArr['supplier_category']=$value['Supplier Category'];
        $dataArr['risk_category']=$value['Risk Category'];
        $dataArr['Material_Supplied_food']=$value['Material Supplied Food'];
        $dataArr['Material_Supplied']=$value['Material Supplied'];
        $dataArr['created_by']=$login_user;
                DB::table('Supplier_details')->insert($dataArr);
                    $prdCnt++;
          
            }
		return redirect()->route('supplier_details');
    }
    
        public function importCoa(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                
            $supplier_id = DB::table('Supplier_details')->where('supplier_name',$value['Supplier'])->where('created_by',$login_user)->value('supplier_name');
            $product_category = DB::table('product_category')->where('name',$value['Product category'])->where('created_by',$login_user)->value('name');
            if(!empty($supplier_id)){
                
             $supplier_id= $supplier_id;  
            }
            else{
                
                $supplier_id='';
            }



        $dataArr['created_by']=$login_user;
            	 $dataArr['supplier_id']=$supplier_id ?? '';
            $dataArr['type']=2;
            $dataArr['brand_name']=$value['Brand name'];
            $dataArr['Material_description']=$value['Material'];
            $dataArr['Product_category']=$product_category ?? '';
                DB::table('Supplier_details')->insert($dataArr);
                    $prdCnt++;
            }
		return redirect()->route('coa');
    }
    public function importFga(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                
            $supplier_id = DB::table('Supplier_details')->where('supplier_name',$value['Supplier'])->where('created_by',$login_user)->value('supplier_name');
            $product_category = DB::table('product_category')->where('name',$value['Product category'])->where('created_by',$login_user)->value('name');
            if(!empty($supplier_id)){
                
             $supplier_id= $supplier_id;  
            }
            else{
                
                $supplier_id='';
            }



        $dataArr['created_by']=$login_user;
            	 $dataArr['supplier_id']=$supplier_id ?? '';
            $dataArr['type']=3;
            $dataArr['brand_name']=$value['Brand name'];
            $dataArr['Material_description']=$value['Material'];
            $dataArr['Product_category']=$product_category ?? '';
                DB::table('Supplier_details')->insert($dataArr);
                    $prdCnt++;
            }
		return redirect()->route('fgc');
    }
	
}
