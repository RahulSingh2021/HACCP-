

<?php $__env->startSection('content'); ?>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css" rel="stylesheet" />

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>
<!--Start Add Lms Modal-->
                       
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Lms</h5>
                </div>
                <div class="modal-body">
                    <form class="row" action="<?php echo e(route('addlms')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <input type="hidden" name="lms_id" value="<?php echo e($lmsDetails->id); ?>">
                        
                        <div class="mb-2 col-md-6">
                            
                            
                        <label class="form-label">Course Mode:</label>
                        <select class="form-select selectconcern" aria-label="Default select example" name="course_mode">
                        <option value="">Select Course Mode</option>
                        <option value="Classroom" <?php if($lmsDetails->course_mode=="Classroom"): ?> selected <?php endif; ?>>Classroom</option>
                        <option value="Online" <?php if($lmsDetails->course_mode=="Online"): ?> selected <?php endif; ?>>Online</option>
                        <option value="Recorded Video" <?php if($lmsDetails->course_mode=="Recorded Video"): ?> selected <?php endif; ?>>Recorded Video</option>
                        </select>
                        </div>
            
            
            
            <?php if(!empty($lmsDetails->unit_ids)): ?>            
<div class="mb-2 col-md-6">
    <label class="form-label">Unit Name:</label>
    <select class="selectpicker" aria-label="Default select example" data-live-search="true" name="unit_id[]" id="unit_id" multiple="multiple">
        <option value="">Select Unit List</option>

        <?php
            // Retrieve the old input or the unit_ids from $lmsDetails
            $selectedUnitIds = old('unit_id', $lmsDetails->unit_ids ?? []);

            // Ensure $selectedUnitIds is an array
            if (!is_array($selectedUnitIds)) {
                $selectedUnitIds = json_decode($selectedUnitIds, true);
            }

            // Further ensure that if still not an array, initialize it as an empty array
            if (!is_array($selectedUnitIds)) {
                $selectedUnitIds = [];
            }
        ?>

        <?php $__currentLoopData = $UnitList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UnitLists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($UnitLists->id ?? ''); ?>" <?php if(in_array($UnitLists->id, $selectedUnitIds)): ?> selected <?php endif; ?>>
            <?php echo e($UnitLists->company_name ?? ''); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<?php endif; ?>



                        
                          <div class="mb-2 col-md-6">
    <label class="form-label">Training Topic:</label>
       <select class="selectpicker selectconcern"  aria-label="Default select example" data-live-search="true" name="course_titles" id="userlist2"   >
    <!--<select class="form-select selectconcern" aria-label="Default select example" name="course_titles">-->
        <option value="">Select Training Topic</option>
        
        <?php $__currentLoopData = $training_types_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($training_type->id); ?>" <?php if($lmsDetails->course_titles == $training_type->id): ?> selected <?php endif; ?>><?php echo e($training_type->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
  
                   
                        
                       <div class="mb-2 col-md-6">
    <label class="form-label">Training Name:</label>
    <select class="selectpicker" aria-label="Default select example" data-live-search="true" name="trainer" id="userlist" onchange="getval(this);">
        <option value="">Select Training Name</option>
        <option value="Resolved" <?php if(old('trainer', $lmsDetails->trainer ?? '') == 'Resolved'): ?> selected <?php endif; ?>>External Trainer</option>
        <?php $__currentLoopData = $unit_users_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_users_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($unit_users_lists->employer_fullname ?? ''); ?>" <?php if(old('trainer', $lmsDetails->trainer ?? '') == ($unit_users_lists->employer_fullname ?? '')): ?> selected <?php endif; ?>>
            <?php echo e($unit_users_lists->employer_fullname ?? ''); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

                                                <div class="mb-2 col-md-6 hidebox">
                        <label class="form-label">Remark</label>
                      <input type="text" class="form-control" name="remark" value="<?php echo e($lmsDetails->remark ?? ''); ?>">
                        </div>
                        
                                       <div class="mb-2 col-md-6 hidebox">
                        <label class="form-label">Trainer Name</label>
                      <input type="text" class="form-control" name="trainer1" value="<?php echo e($lmsDetails->trainer ?? ''); ?>">
                        </div>
                        
                                        <div class="mb-2 col-md-6 hidebox">
                        <label class="form-label">Company Name</label>
                      <input type="text" class="form-control" name="company_name" value="<?php echo e($lmsDetails->company_name ?? ''); ?>">
                        </div>
                      
                        
                                       <div class="mb-2 col-md-6">
                        <label class="form-label">Time(to)</label>
                      <input type="datetime-local" class="form-control" name="start_time" value="<?php echo e($lmsDetails->start_time ?? ''); ?>">
                        </div>
                        
                                        <div class="mb-2 col-md-6">
                        <label class="form-label">Time(from)</label>
                      <input type="datetime-local" class="form-control" name="end_time" value="<?php echo e($lmsDetails->end_time ?? ''); ?>">
                        </div>
             
                  
                        
                        <div class="mb-3 col-md-12 text-center">
                            <hr>
                            <button type="submit" class="btn btn-primary me-3">Save</button>
                        </div>
                        
                    </form>
                </div>

            </div>
        </div>
        
        <?php $__env->stopSection(); ?>

                    
<?php echo $__env->make('layouts.app2', ['pagetitle' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/training/edit_lms.blade.php ENDPATH**/ ?>