@include('Admin.AddNewCategory.layouts.top1')
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="page-title">
                        <i class="mdi mdi-apple-keyboard-command title_icon"></i>
                        Add New Category
                    </h4>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-body">
                    <h4 class="mb-3 header-title">Category Add Form</h4>
                    <form class="required-form" action="{{url('admin/add-new-category/add-new-category-subcategory')}}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="code">Category Code</label>
                            <input type="text" class="form-control" id="code" name="category_code" value="">
                        </div>

                        <div class="form-group">
                            <label for="name">Category Title <span class="required">*</span></label>
                            <input type="text" class="form-control" id="name" name="category_title" required>
                        </div>

                        <div class="form-group">
                            <label for="parent">Parent</label>
                            <select class="form-control select2" name="parent_picker" id="parent" onchange="checkCategoryType(this.value)">
                                <option value="0">None</option>
                               @if ($data)
                               @foreach ($data as $d)
                                <option value="{{$d->id}}">{{$d->category_title}}</option>
                               @endforeach
                               @endif
                            </select>
                            <small class="form-text text-muted">Select none to create a parent category</small>
                        </div>

                        <div class="form-group icon-picker-container">
                            <label for="font_awesome_class">Icon Picker</label>
                            <div class="dropdown">
                                <button class="btn btn-outline-secondary btn-lg btn-block dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-icons"></i> Select Icon
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <input type="text" id="search" class="search-box" placeholder="Search icons...">
                                    <div id="icon-picker" class="icon-picker">
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="font_awesome_class" name="icon" value="">
                        </div>

                        <div class="form-group" id="thumbnail-picker-areas" style="display: none;">
                            <label>Sub Category Thumbnail <small>(Image size should be: 100 X 100)</small></label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="sub_category_thumbnail" name="sub_category_thumbnail" accept="image/*" onchange="changeTitleOfImageUploader(this)">
                                    <label class="custom-file-label" for="sub_category_thumbnail">Choose thumbnail</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group" id="thumbnail-picker-area">
                            <label>Category Thumbnail <small>(Image size should be: 400 X 255)</small></label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="category_thumbnail" name="category_thumbnail" accept="image/*" onchange="changeTitleOfImageUploader(this)">
                                    <label class="custom-file-label" for="category_thumbnail">Choose thumbnail</label>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@include('Admin.AddNewCategory.layouts.bottom1')
