
<div class="row">
                         <div class="col">
                            <div class="card">
                                <div class="card-body">                              
                                    <ul class="nav nav-pills nav-pills-success mb-3" role="tablist">
                                  
                                        
                         
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 6): ?> active <?php endif; ?>" data-bs-toggle="pill"  href="#Ingredients" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Ingredients</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link <?php if($_GET['tab_name'] == 7): ?> active <?php endif; ?>" data-bs-toggle="pill" href="#Add-Recipe" role="tab" aria-selected="false">
                                                <div class="d-flex align-items-center">
                                                    <div class="tab-title">Add Recipe</div>
                                                </div>
                                            </a>
                                        </li>
                        
                                    </ul>
                                    <div class="tab-content">
										 <?php echo $__env->make('admin.nutrilator.Ingredients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                       <?php echo $__env->make('admin.nutrilator.Recipe.recipe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>



<?php /**PATH /home/safefoodmitra/public_html/efsm/admin/resources/views/admin/nutrilator/unit_menu.blade.php ENDPATH**/ ?>