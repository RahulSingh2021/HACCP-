<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use DB;
use Helper;
use Illuminate\Support\Facades\Session;


use Illuminate\Routing\Controller as BaseController;

class FhmController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;




    public function index(Request $request) {
	
		$is_role = Auth::user()->is_role;
		    $corporate_id = $_GET['corporate_id'] ?? '';
                   $regional_id = $_GET['regional_id'] ?? '';
                     $hotel_name = $_GET['hotel_name'] ?? '';
                       $location_id = $_GET['location_id'] ?? '';
		
		
		
		 $facility_equipment = DB::table('facility_equipment');
		
		                       if(!empty($corporate_id)){
            $facility_equipment =  $facility_equipment->where('corporate_id',$corporate_id);  
          }
		
		                       if(!empty($regional_id)){
            $facility_equipment =  $facility_equipment->where('regional_id',$regional_id);  
          }
		                       if(!empty($hotel_name)){
            $facility_equipment =  $facility_equipment->where('hotel_name',$hotel_name);  
          }
		                       if(!empty($location_id)){
            $facility_equipment =  $facility_equipment->where('location_id',$location_id);  
          
          }
          
            $facility_equipment =  $facility_equipment->where('created_by',Auth::user()->id);  
		$facility_equipment = $facility_equipment->orderBy('id', 'DESC')->get(); 
		
		$departments = DB::table('departments')->orderBy('id', 'DESC')->get();
		$chemical = DB::table('chemical')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
		$toollist = DB::table('toolselection')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
			$schedulemakerlist = DB::table('cleaning')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->where('type',"1")->get();
			$schedulemakerlist1 = DB::table('cleaning')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->where('type',"2")->get();
		$authority = DB::table('authority')->where('unit_id',Auth::user()->id)->orderBy('id', 'DESC')->get();
		$calibration = DB::table('calibration')->where('created_by',Auth::user()->id)->orderBy('id', 'DESC')->get();
return view('admin.fhm.list',compact('facility_equipment','chemical','toollist','schedulemakerlist','schedulemakerlist1','departments','authority','calibration','is_role'));
}
    public function store(Request $request) {

    	 $dataArr['name']=$request->name;
		$dataArr['type']=$request->type;
		$dataArr['brand']=$request->brand;
		$dataArr['capacity_range']=$request->capacity_range;
		$dataArr['capacity_utility_range']=$request->capacity_utility_range;
		$dataArr['corporate_id']=$request->corporate_id;
		$dataArr['regional_id']=$request->regional_id;
		$dataArr['hotel_name']=$request->hotel_name;
		$dataArr['department']=$request->department;
		$dataArr['location_id']=$request->location_id;
		$dataArr['sub_location']=$request->sub_location;
       $dataArr['created_by']=Auth::user()->id;
		
		
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
		
	
            DB::table('facility_equipment')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
		    public function facility_tool_store(Request $request) {

    	 $dataArr['name']=$request->name;
			$dataArr['purpose']=$request->purpose;
			$dataArr['target_surface']=$request->target_surface;
       $dataArr['created_by']=Auth::user()->id;
				
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
            DB::table('toolselection')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
			    public function facility_tool_update(Request $request) {

    	 $dataArr['name']=$request->name;
			$dataArr['purpose']=$request->purpose;
			$dataArr['target_surface']=$request->target_surface;

					
						      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
					
					
					          DB::table('toolselection')->where('id',$request->tool_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	    public function update(Request $request) {

    	    	 $dataArr['name']=$request->name;
		$dataArr['type']=$request->type;
		$dataArr['brand']=$request->brand;
		$dataArr['capacity_range']=$request->capacity_range;
		$dataArr['capacity_utility_range']=$request->capacity_utility_range;
		$dataArr['corporate_id']=$request->corporate_id;
		$dataArr['regional_id']=$request->regional_id;
		$dataArr['hotel_name']=$request->hotel_name;
		$dataArr['department']=$request->department;
		$dataArr['location_id']=$request->location_id;
		$dataArr['sub_location']=$request->sub_location;

  
		
		
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
			
		
            DB::table('facility_equipment')->where('id',$request->equipments_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	
	
		    public function destory($id) {
    	$retData=DB::table('facility_equipment')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}	
	
	
	    public function chemical_store(Request $request) {
  
    	 $dataArr['name']=$request->name;
       $dataArr['created_by']=Auth::user()->id;
    	 $dataArr['nature']=$request->nature;
            $dataArr['target_soil']=$request->target_soil;
            $dataArr['Used_with_solvemt']=$request->Used_with_solvemt;
            $dataArr['contacttime']=$request->contacttime;
            $dataArr['temp_requrement']=$request->temp_requrement;
            $dataArr['Wet']=$request->Wet;
			$dataArr['target_surface_make']=$request->target_surface_make;
		
		      if($request->file('company_logo')){
			
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
			
			else{
			
			}
	
            DB::table('chemical')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
		    public function chemical_edit(Request $request) {
  
    	 $dataArr['name']=$request->name;
    	 $dataArr['nature']=$request->nature;
            $dataArr['target_soil']=$request->target_soil;
            $dataArr['Used_with_solvemt']=$request->Used_with_solvemt;
            $dataArr['contacttime']=$request->contacttime;
            $dataArr['temp_requrement']=$request->temp_requrement;
            $dataArr['Wet']=$request->Wet;
			$dataArr['target_surface_make']=$request->target_surface_make;
		      if($request->file('company_logo')){
			
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
			
			else{
			
			}
	
            DB::table('chemical')->where('id',$request->chemical_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
			    public function destory1($id) {
    	$retData=DB::table('chemical')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
				    public function destory2($id) {
    	$retData=DB::table('toolselection')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
			    public function schedule_maker_store(Request $request) {
			
    	 $dataArr['name']=$request->name;
			$dataArr['location_id']=$request->location_id;
			$dataArr['corporate_id']=$request->corporate_id;
							$dataArr['regional_id']=$request->regional_id;
							$dataArr['hotel_name']=$request->hotel_name;
					$dataArr['frequency']=$request->frequency;
			$dataArr['task_start_date']=$request->task_start_date;
						
						  $dataArr['department']=$request->department;
				   $dataArr['sub_location']=$request->sub_location ?? NULL;
					 $dataArr['responsibility_id']=$request->responsibility_id ?? NULL;
					$dataArr['type']=$request->type;
       $dataArr['created_by']=Auth::user()->id;
            DB::table('cleaning')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
				    public function schedule_maker_edit(Request $request) {
			
    	 $dataArr['name']=$request->name;
			$dataArr['location_id']=$request->location_id;
			$dataArr['corporate_id']=$request->corporate_id;
							$dataArr['regional_id']=$request->regional_id;
							$dataArr['hotel_name']=$request->hotel_name;
					$dataArr['frequency']=$request->frequency;
			$dataArr['task_start_date']=$request->task_start_date;
						
						  $dataArr['department']=$request->department;
				   $dataArr['sub_location']=$request->sub_location ?? NULL;
						 $dataArr['responsibility_id']=$request->responsibility_id ?? NULL;
						
						
						
            DB::table('cleaning')->where('id',$request->schedule_maker_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}

	
					    public function destory3($id) {
    	$retData=DB::table('cleaning')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
	
     public function import(Request $request){


      
       
            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            
  
            foreach ($data as $key => $value) {
                
          
                if((isset($value['name']))  ){


               
	    $dataArr2['name']=$value['name'];
		$dataArr2['type']=$value['type'];
		$dataArr2['brand']=$value['brand'];
						$dataArr2['brand']=$value['brand'];
		$dataArr2['capacity_range']=$value['capacity_range'];
		$dataArr2['capacity_utility_range']=$value['capacity_utility_range'];
							$dataArr2['corporate_id']=$request->corporate_id;
		$dataArr2['regional_id']=$request->regional_id;
		$dataArr2['hotel_name']=$request->hotel_name;
		$dataArr2['department']=$request->department;
		$dataArr2['location_id']=$request->location_id;
		$dataArr2['sub_location']=$request->sub_location;
        $dataArr2['created_by']=Auth::user()->id;
					
				
             $enrolled_users= DB::table('facility_equipment')->insert($dataArr2);   
              

                    $prdCnt++;
                }
            }
            
        return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
    

    }
	
									    public function delete_all_equpitments(Request $request) {
							     $ids = $request->ids;
								foreach($ids as $idss){
								    DB::table("facility_equipment")->where('id',$idss)->delete();  
								}
        return response()->json(['success'=>" Deleted successfully."]);  
}
	
	
										    public function delete_all_chemicalselection(Request $request) {
							     $ids = $request->ids;
								foreach($ids as $idss){
								    DB::table("chemical")->where('id',$idss)->delete();  
								}
        return response()->json(['success'=>" Deleted successfully."]);  
}
	
	
											    public function delete_all_toolselection(Request $request) {
							     $ids = $request->ids;
								foreach($ids as $idss){
								    DB::table("toolselection")->where('id',$idss)->delete();  
								}
        return response()->json(['success'=>" Deleted successfully."]);  
}
	
												    public function delete_all_cleaning_schedular(Request $request) {
							     $ids = $request->ids;
								foreach($ids as $idss){
								    DB::table("cleaning")->where('id',$idss)->delete();  
								}
        return response()->json(['success'=>" Deleted successfully."]);  
}
	
			    public function calibration_store(Request $request) {
    	 $dataArr['name']=$request->name;
			$dataArr['location_id']=$request->location_id;
			$dataArr['corporate_id']=$request->corporate_id;
							$dataArr['regional_id']=$request->regional_id;
							$dataArr['hotel_name']=$request->hotel_name;
					$dataArr['brand']=$request->brand;
			$dataArr['capacity_range']=$request->capacity_range;
						$dataArr['brand']=$request->brand;
			$dataArr['capacity_range']=$request->capacity_range;
						$dataArr['capacity_utility_range']=$request->capacity_utility_range;
			$dataArr['id_no']=$request->id_no;
						$dataArr['calibration_range']=$request->calibration_range;
			$dataArr['least_count']=$request->least_count;
					$dataArr['calibration_date']=$request->calibration_date;
					$dataArr['calibration_due_date']=$request->calibration_due_date;
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
						  $dataArr['department']=$request->department;
				   $dataArr['sub_location']=$request->sub_location ?? NULL;
					$dataArr['type']=$request->type;
       $dataArr['created_by']=Auth::user()->id;
            DB::table('calibration')->insert($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	public function calibration_edit(Request $request) {
    	 $dataArr['name']=$request->name;
			$dataArr['location_id']=$request->location_id;
			$dataArr['corporate_id']=$request->corporate_id;
							$dataArr['regional_id']=$request->regional_id;
							$dataArr['hotel_name']=$request->hotel_name;
					$dataArr['brand']=$request->brand;
			$dataArr['capacity_range']=$request->capacity_range;
						$dataArr['brand']=$request->brand;
			$dataArr['capacity_range']=$request->capacity_range;
						$dataArr['capacity_utility_range']=$request->capacity_utility_range;
			$dataArr['id_no']=$request->id_no;
						$dataArr['calibration_range']=$request->calibration_range;
			$dataArr['least_count']=$request->least_count;
					$dataArr['calibration_date']=$request->calibration_date;
					$dataArr['calibration_due_date']=$request->calibration_due_date;
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
						  $dataArr['department']=$request->department;
				   $dataArr['sub_location']=$request->sub_location ?? NULL;
					$dataArr['type']=$request->type;

            DB::table('calibration')->where('id', $request->calibration_edit_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
				public function equipment_details(Request $request){
$users = DB::table('facility_equipment')->where('id', $request->id)->first();
		return response()->json(['data' => $users]);
	}
	
	
						    public function calibration_delete($id) {
    	$retData=DB::table('calibration')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}
	
	
	
	     public function import1(Request $request){

    
       
            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            
  
            foreach ($data as $key => $value) {
			
				$Allergen =  explode(",", $value['Allergen']);

				$ids=array();
				foreach($Allergen as $Allergens){
					$product_Ingredients2 = DB::table('product_Ingredients')->where('name',$Allergens)->first();
					 $ids[] = $product_Ingredients2->id ?? '';
				}
	
				
				$ids = json_encode($ids);
				$product_Ingredients = DB::table('product_Ingredients')->where('name',$value['Ingredients_Symbol'])->first();
				$product_Ingredients1 = DB::table('refrences')->where('name',$value['Refrence'])->first();
		
          
                if((isset($value['Name']))  ){

					   	 		$dataArr['name']=$value['Name'];
							$dataArr['Keyword']=$value['Keyword'];
							$dataArr['Ingredients_Symbol']=$product_Ingredients->id ?? '';
							$dataArr['Refrence']=$product_Ingredients1->id ?? '';
							$dataArr['Energy']=$value['Energy'];
							$dataArr['Protein']=$value['Protein'];
							$dataArr['Allergen']=$ids;
								$dataArr['Carbohydrates']=$value['Carb'];
							$dataArr['Fat']=$value['Fat'];

        					$dataArr['created_by']=Auth::user()->id;
				
				
             $enrolled_users= DB::table('Ingredient')->insert($dataArr);   
              

                    $prdCnt++;
                }
            }
            
            return redirect()->route('nutrilator',['tab_name' => "6"])->with('add_department', 'Add Successfully');
        //return redirect()->route('nutrilator')->with('add_department', 'Add Successfully');
    

    }
	
	
	
	
		
	     public function importDepartment(Request $request){
	                  if(!empty(Session::get('unit_id'))  ){
$login_user=  Session::get('unit_id');
}
else{
$login_user=  Auth::user()->id;   
}
       
            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            
  
            foreach ($data as $key => $value) {
	
                if((isset($value['Name']))  ){
             
					   	 		$dataArr['name']=$value['Name'];
        					$dataArr['unit_id']=$login_user;
        			
				          $enrolled_users = DB::table('departments')->insert($dataArr);



                    $prdCnt++;
                }
            }
            
		return redirect()->route('department')->with('add_location', 'Add Successfully');
        //return redirect()->route('nutrilator')->with('add_department', 'Add Successfully');
    

    }
	
	
			
	     public function importLocation(Request $request){
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                if((isset($value['Name']))  ){
					   	 		$dataArr['name']=$value['Name'];
        					$dataArr['created_by']=$login_user;
        					 $dataArr['department_id']=$request->department_ids;
       
       
				          $enrolled_users = DB::table('locations')->insert($dataArr);
                    $prdCnt++;
                }
            }
		return redirect()->route('department')->with('add_location', 'Add Successfully');
    }
    
    
    public function importUserManagement(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                if((isset($value['Employee ID']))  ){
                    
      $departments = DB::table('departments')->where('name',$value['Department'])->where('unit_id',$login_user)->value('id');
      $Responsibility = DB::table('authority')->where('name',$value['Responsibility'])->where('unit_id',$login_user)->value('id');
$dataArr['employe_id']=$value['Employee ID'];
$dataArr['employer_fullname']=$value['Employee Full Name'];
$dataArr['email']=$value['Email'];
$dataArr['designation']=$value['Designation'];
$dataArr['staff_category']=$value['Staff Category'];
$dataArr['gender']=$value['Gender'] ?? NULL;
$dataArr['contact_number']=$value['Contact Number'];
$dataArr['cat_name']=$value['Food Handlers Category'] ?? NULL;
$dataArr['dog']=date('Y-m-d', strtotime($value['DOJ'])) ?? NULL;
$dataArr['dob']=date('Y-m-d', strtotime($value['DOB'])) ?? NULL;
       $dataArr['department']=$departments ?? NULL;
       $dataArr['responsibility_id']=$Responsibility ?? NULL;
                $dataArr['created_by']=$login_user;
                DB::table('unit_users')->insert($dataArr);
                    $prdCnt++;
                }
            }
		return redirect()->route('department');
    }
    
    public function importConcernManagement(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                  $subconcern_list = DB::table('tbl_concern')->where('name',$value['concern'])->where('created_by',$login_user)->value('id');
                if((isset($value['name']))  ){
    $dataArr['name']=$value['name'];
    $dataArr['parent']=$subconcern_list ?? NULL;
    $dataArr['created_by']=$login_user;
                DB::table('tbl_concern')->insert($dataArr);
                    $prdCnt++;
                }
            }
		return redirect()->route('department');
    }
    
    
    public function importSupplier(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {


        $dataArr['supplier_name']=$value['Supplier Name'];
        $dataArr['address']=$value['Address'];
        $dataArr['name']=$value['Contact Person Name'];
        $dataArr['email']=$value['Email'];
        $dataArr['mobile_number']=$value['Mobile'];
        $dataArr['license_number']=$value['License Number'];
        $dataArr['license_validity']=date('Y-m-d', strtotime($value['License Validity'])); 
        $dataArr['supplier_category']=$value['Supplier Category'];
        $dataArr['risk_category']=$value['Risk Category'];
        $dataArr['Material_Supplied_food']=$value['Material Supplied Food'];
        $dataArr['Material_Supplied']=$value['Material Supplied'];
        $dataArr['created_by']=$login_user;
                DB::table('Supplier_details')->insert($dataArr);
                    $prdCnt++;
          
            }
		return redirect()->route('supplier_details');
    }
    
        public function importCoa(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                
            $supplier_id = DB::table('Supplier_details')->where('supplier_name',$value['Supplier'])->where('created_by',$login_user)->value('supplier_name');
            $product_category = DB::table('product_category')->where('name',$value['Product category'])->where('created_by',$login_user)->value('name');
            if(!empty($supplier_id)){
                
             $supplier_id= $supplier_id;  
            }
            else{
                
                $supplier_id='';
            }



        $dataArr['created_by']=$login_user;
            	 $dataArr['supplier_id']=$supplier_id ?? '';
            $dataArr['type']=2;
            $dataArr['brand_name']=$value['Brand name'];
            $dataArr['Material_description']=$value['Material'];
            $dataArr['Product_category']=$product_category ?? '';
                DB::table('Supplier_details')->insert($dataArr);
                    $prdCnt++;
            }
		return redirect()->route('coa');
    }
    public function importFga(Request $request){
       
            if(!empty(Session::get('unit_id'))  ){
            $login_user=  Session::get('unit_id');
            }
            else{
            $login_user=  Auth::user()->id;   
            }

            if (!file_exists($request->file('uploaddoc')) || !is_readable($request->file('uploaddoc'))){
                dd('Error');
            }
            $delimiter = ',';
            $header = null;
            $data = array();
            if (($handle = fopen($request->file('uploaddoc'), 'r')) !== false)
            {
                while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
                {
                    if (!$header)
                        $header = $row;
                    else
                        $data[] = array_combine($header, $row);
                }
                fclose($handle);
            }
            $prdCnt=0;
            foreach ($data as $key => $value) {
                
            $supplier_id = DB::table('Supplier_details')->where('supplier_name',$value['Supplier'])->where('created_by',$login_user)->value('supplier_name');
            $product_category = DB::table('product_category')->where('name',$value['Product category'])->where('created_by',$login_user)->value('name');
            if(!empty($supplier_id)){
                
             $supplier_id= $supplier_id;  
            }
            else{
                
                $supplier_id='';
            }



        $dataArr['created_by']=$login_user;
            	 $dataArr['supplier_id']=$supplier_id ?? '';
            $dataArr['type']=3;
            $dataArr['brand_name']=$value['Brand name'];
            $dataArr['Material_description']=$value['Material'];
            $dataArr['Product_category']=$product_category ?? '';
                DB::table('Supplier_details')->insert($dataArr);
                    $prdCnt++;
            }
		return redirect()->route('fgc');
    }
	
}
