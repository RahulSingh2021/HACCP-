<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use DB;
use Helper;
use Illuminate\Support\Facades\Session;


use Illuminate\Routing\Controller as BaseController;

class TemplatesController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;




    public function index(Request $request) {
        
  
return view('admin.training.list');
}
   
   
       public function store(Request $request) {
        
  
return view('admin.training.add');
}
     
	

	
			    public function facility_tool_update(Request $request) {

    	 $dataArr['name']=$request->name;
			$dataArr['purpose']=$request->purpose;
			$dataArr['target_surface']=$request->target_surface;

					
						      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
					
					
					          DB::table('toolselection')->where('id',$request->tool_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	    public function update(Request $request) {

    	    	 $dataArr['name']=$request->name;
		$dataArr['type']=$request->type;
		$dataArr['brand']=$request->brand;
		$dataArr['capacity_range']=$request->capacity_range;
		$dataArr['capacity_utility_range']=$request->capacity_utility_range;
		$dataArr['corporate_id']=$request->corporate_id;
		$dataArr['regional_id']=$request->regional_id;
		$dataArr['hotel_name']=$request->hotel_name;
		$dataArr['department']=$request->department;
		$dataArr['location_id']=$request->location_id;
		$dataArr['sub_location']=$request->sub_location;

  
		
		
				      if($request->file('company_logo')){
                        $file= $request->file('company_logo');
                        $filename= date('YmdHi').$file->getClientOriginalName();
                        $file-> move(public_path('companylogo'), $filename);
                        $dataArr['company_logo']= $filename;
                    }
			
		
            DB::table('facility_equipment')->where('id',$request->equipments_id)->update($dataArr);
		return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
}
	
	
	
	
		    public function destory($id) {
    	$retData=DB::table('facility_equipment')->where('id',$id)->delete();
return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
}	
	
	
	 

	
}
