@extends('layouts.app', ['pagetitle'=>'Dashboard'])

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
           <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2980b9;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
            --info-color: #9b59b6;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
            --gray-color: #95a5a6;
            --border-color: #dfe6e9;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }
        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
        }
        
        h1 {
            color: var(--dark-color);
            font-size: 28px;
            font-weight: 600;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .logo i {
            color: var(--primary-color);
            font-size: 32px;
        }
        
        .action-tabs {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }
        
        .btn-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background-color: #219653;
            transform: translateY(-2px);
        }
        
        .btn-outline {
            background-color: transparent;
            border: 1px solid var(--primary-color);
            color: var(--primary-color);
        }
        
        .btn-outline:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 500;
            position: sticky;
            top: 0;
        }
        
        tr:hover {
            background-color: rgba(52, 152, 219, 0.05);
        }
        
        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-active {
            background-color: rgba(39, 174, 96, 0.1);
            color: var(--success-color);
        }
        
        .status-pending {
            background-color: rgba(241, 196, 15, 0.1);
            color: #f1c40f;
        }
        
        .status-expired {
            background-color: rgba(231, 76, 60, 0.1);
            color: var(--danger-color);
        }
        
        .action-btns {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 4px;
        }
        
        .btn-renew {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-history {
            background-color: var(--info-color);
            color: white;
        }
        
        .btn-save {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-cancel {
            background-color: var(--danger-color);
            color: white;
        }
        
        .editable-row {
            background-color: #fffde7 !important;
        }
        
        .editable-row input, .editable-row select {
            width: 100%;
            padding: 8px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-family: inherit;
        }
        
        .file-upload {
            position: relative;
            display: inline-block;
            padding: 8px 16px;
            background-color: var(--light-color);
            border: 1px dashed var(--gray-color);
            border-radius: 4px;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .file-upload:hover {
            background-color: #e0e0e0;
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .uploaded-file {
            font-size: 12px;
            color: var(--success-color);
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .document-cell {
            max-width: 200px;
        }
        
        .document-preview {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 5px;
            background-color: #f8f9fa;
            border-radius: 4px;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .document-preview:hover {
            background-color: #e9ecef;
        }
        
        .document-icon {
            color: #e74c3c;
            font-size: 20px;
        }
        
        .document-name {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 150px;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            overflow: auto;
            transition: var(--transition);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 700px;
            position: relative;
            animation: modalopen 0.3s;
        }
        
        @keyframes modalopen {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .modal-title {
            font-size: 22px;
            color: var(--dark-color);
            font-weight: 600;
        }
        
        .close {
            color: var(--gray-color);
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .close:hover {
            color: var(--danger-color);
            transform: rotate(90deg);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-family: inherit;
            transition: var(--transition);
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .document-link {
            color: var(--primary-color);
            text-decoration: none;
            transition: var(--transition);
        }
        
        .document-link:hover {
            text-decoration: underline;
            color: var(--secondary-color);
        }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            background-color: var(--light-color);
            color: var(--dark-color);
        }
        
        .badge-primary {
            background-color: rgba(52, 152, 219, 0.1);
            color: var(--primary-color);
        }
        
        .badge-success {
            background-color: rgba(39, 174, 96, 0.1);
            color: var(--success-color);
        }
        
        .badge-warning {
            background-color: rgba(241, 196, 15, 0.1);
            color: #f1c40f;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .action-btns {
                flex-direction: column;
                gap: 5px;
            }
            
            .btn-sm {
                width: 100%;
                justify-content: center;
            }
            
            .modal-content {
                width: 95%;
                margin: 10% auto;
                padding: 15px;
            }
        }
    </style>
@section('content')
 




                          <div class="row">
                         <div class="col">
                            <div class="card">
                                <div class="card-body">
                                     <ul class="nav nav-pills nav-pills-success mb-3" role="tablist">
            <li class="nav-item mr-3" role="presentation" style="margin:5px;">
            <a class="nav-link " href="{{route('linces')}}">
            <div class="d-flex align-items-center">
            <div class="tab-title">FSSAI Dashboard</div>
            </div>
            </a>
            </li>
            
                        <li class="nav-item " role="presentation" style="margin:5px;">
            <a class="nav-link active" href="{{route('fssailinces')}}" >
            <div class="d-flex align-items-center">
            <div class="tab-title"> FSSAI License</div>
            </div>
            </a>

            </li>
            
            
                            <li class="nav-item " role="presentation" style="margin:5px;">
            <a class="nav-link "  href="{{route('food')}}" >
            <div class="d-flex align-items-center">
            <div class="tab-title"> Food Tests</div>
            </div>
            </a>

            </li>
            
            <li class="nav-item " role="presentation" style="margin:5px;">
<a class="nav-link"  href="{{route('medical')}}" >
<div class="d-flex align-items-center">
<div class="tab-title">Medical</div>
</div>
</a>

</li>


            <li class="nav-item " role="presentation" style="margin:5px;">
<a class="nav-link"  href="{{route('fostac')}}" >
<div class="d-flex align-items-center">
<div class="tab-title">fostac</div>
</div>
</a>

</li>
                       
                                        
                                    </ul>
                                    <div class="tab-content">
										
	
											 	 <div class="" id="company-details1" role="tabpanel">
							
		


    
 <div class="main-content">
        

       <div class="container-fluid">
        <header>
            <div class="logo">
                <i class="fas fa-certificate"></i>
                <h1>FSSAI License Management</h1>
            </div>
            <div class="user-info">
                <span class="badge badge-primary"><i class="fas fa-user"></i> Admin User</span>
            </div>
        </header>
        
        <div class="action-tabs">
            <button class="btn btn-primary" onclick="addNewLicense()">
                <i class="fas fa-plus"></i> Add New License
            </button>
            <button class="btn btn-outline">
                <i class="fas fa-download"></i> Export Data
            </button>
        </div>
        
        <div class="table-container">
            <table id="fssaiTable">
                <thead>
                    <tr>
                        <th>SL No</th>
                        <th>Category</th>
                        <th>License Number</th>
                        <th>Expiry Date</th>
                        <th>License Type</th>
                        <th>License Copy</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    
                    @foreach($result as $results)
                    <tr>
                        <td>1</td>
                        <td>{{$results->document_type ?? ''}}</td>
                        <td>{{$results->lincess_number ?? ''}}</td>
                        <td>{{$results->due_date ?? ''}}</td>
                        <td>{{$results->cat_type ?? ''}}</td>
                        <td class="document-cell">
                            
                             <a target="_blank()" href="{{asset('documents')}}/{{$results->image ?? ''}}"><i class="fas fa-file-pdf document-icon"></i></a>
                             
                          
                        </td>
                        <td><span class="status status-active">Active</span></td>
                        <td>
                            <div class="action-btns">
                                <button class="btn btn-sm btn-renew" onclick="openRenewModal('123456789012')">
                                    <i class="fas fa-sync-alt"></i> Renew
                                </button>
                                <button class="btn btn-sm btn-history" onclick="openHistoryModal('123456789012')">
                                    <i class="fas fa-history"></i> History
                                </button>
                            </div>
                        </td>
                    </tr>
                    
                    @endforeach

                </tbody>
            </table>
        </div>
    </div>

    <!-- Document Preview Modal -->
    <div id="documentModal" class="modal">
        <div class="modal-content" style="max-width: 800px;">
            <div class="modal-header">
                <h2 class="modal-title">Document Preview</h2>
                <span class="close" onclick="closeModal('documentModal')">&times;</span>
            </div>
            <div id="documentPreview" style="text-align: center; padding: 20px;">
                <iframe id="documentFrame" style="width: 100%; height: 500px; border: none;"></iframe>
                <div style="margin-top: 20px;">
                    <button class="btn btn-primary" onclick="downloadDocument()">
                        <i class="fas fa-download"></i> Download Document
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Renew License Modal -->
    <div id="renewModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Renew FSSAI License</h2>
                <span class="close" onclick="closeModal('renewModal')">&times;</span>
            </div>
            <form id="renewForm">
                <input type="hidden" id="renewLicenseNumber">
                <div class="form-group">
                    <label class="form-label">Current License Number</label>
                    <p id="displayLicenseNumber" class="form-control" style="background-color: #f8f9fa;"></p>
                </div>
                <div class="form-group">
                    <label class="form-label">Current Expiry Date</label>
                    <p id="currentExpiryDate" class="form-control" style="background-color: #f8f9fa;"></p>
                </div>
                <div class="form-group">
                    <label for="newExpiryDate" class="form-label">New Expiry Date</label>
                    <input type="date" id="newExpiryDate" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Upload Renewal Document</label>
                    <label class="file-upload">
                        <i class="fas fa-cloud-upload-alt"></i> Choose File
                        <input type="file" id="renewalDocument" required>
                    </label>
                    <span id="renewalFileName" class="uploaded-file">
                        <i class="fas fa-file-alt"></i> No file selected
                    </span>
                </div>
                <button type="submit" class="btn btn-success" style="width: 100%;">
                    <i class="fas fa-sync-alt"></i> Submit Renewal
                </button>
            </form>
        </div>
    </div>

    <!-- History Log Modal -->
    <div id="historyModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">License History Log</h2>
                <span class="close" onclick="closeModal('historyModal')">&times;</span>
            </div>
            <p style="margin-bottom: 20px;">License Number: <strong id="historyLicenseNumber"></strong></p>
            
            <div style="overflow-x: auto;">
                <table style="width: 100%;">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Action</th>
                            <th>Details</th>
                            <th>User</th>
                        </tr>
                    </thead>
                    <tbody id="historyTableBody">
                        <!-- History data will be populated here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>



                            
										
                                  </div>      
                                    
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                    <!--end row-->  
                    
                    

@endsection



 <script>
        // Function to open document preview modal
        function viewDocument(filename) {
            document.getElementById('documentFrame').src = `documents/${filename}`;
            document.getElementById('documentModal').style.display = 'block';
        }

        // Function to download the current document
        function downloadDocument() {
            const frameSrc = document.getElementById('documentFrame').src;
            const link = document.createElement('a');
            link.href = frameSrc;
            link.download = frameSrc.split('/').pop();
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        // Function to handle license upload
        function handleLicenseUpload(licenseNumber, input) {
            const file = input.files[0];
            if (file) {
                const statusElement = document.getElementById(`upload-status-${licenseNumber}`);
                statusElement.innerHTML = `<i class="fas fa-check-circle"></i> ${file.name}`;
                
                // In a real application, you would upload the file to the server here
                console.log(`Uploading file for license ${licenseNumber}:`, file.name);
            }
        }

        // Function to handle file upload for new license
        function handleNewLicenseUpload(input) {
            const file = input.files[0];
            if (file) {
                const uploadedFileSpan = input.closest('td').querySelector('.uploaded-file');
                uploadedFileSpan.innerHTML = `<i class="fas fa-check-circle"></i> ${file.name}`;
            }
        }

        // Function to open renew modal
        function openRenewModal(licenseNumber) {
            document.getElementById('renewLicenseNumber').value = licenseNumber;
            document.getElementById('displayLicenseNumber').textContent = licenseNumber;
            
            // Find the expiry date from the table
            const table = document.getElementById('fssaiTable');
            const rows = table.getElementsByTagName('tr');
            let expiryDate = '';
            
            for (let i = 1; i < rows.length; i++) {
                const cells = rows[i].getElementsByTagName('td');
                if (cells[2].textContent === licenseNumber) {
                    expiryDate = cells[3].textContent;
                    break;
                }
            }
            
            document.getElementById('currentExpiryDate').textContent = expiryDate;
            document.getElementById('newExpiryDate').value = '';
            document.getElementById('renewalFileName').innerHTML = '<i class="fas fa-file-alt"></i> No file selected';
            document.getElementById('renewModal').style.display = 'block';
        }

        // Function to open history modal
        function openHistoryModal(licenseNumber) {
            document.getElementById('historyLicenseNumber').textContent = licenseNumber;
            
            // Clear previous history
            const historyBody = document.getElementById('historyTableBody');
            historyBody.innerHTML = '';
            
            // Sample history data
            const sampleHistory = [
                { 
                    date: new Date().toISOString().split('T')[0], 
                    action: 'Created', 
                    details: 'New license record added', 
                    user: 'Admin User' 
                },
                { 
                    date: '2023-05-15', 
                    action: 'Renewal', 
                    details: 'License renewed for 1 year', 
                    user: 'Admin User' 
                },
                { 
                    date: '2022-05-10', 
                    action: 'Document Upload', 
                    details: 'License document uploaded', 
                    user: 'System' 
                }
            ];
            
            // Populate the history table
            sampleHistory.forEach(entry => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${entry.date}</td>
                    <td><span class="badge ${getBadgeClass(entry.action)}">${entry.action}</span></td>
                    <td>${entry.details}</td>
                    <td>${entry.user}</td>
                `;
                historyBody.appendChild(row);
            });
            
            document.getElementById('historyModal').style.display = 'block';
        }

        // Helper function to get badge class based on action type
        function getBadgeClass(action) {
            switch(action) {
                case 'Created':
                    return 'badge-success';
                case 'Renewal':
                    return 'badge-primary';
                case 'Document Upload':
                    return 'badge-warning';
                default:
                    return 'badge-primary';
            }
        }

        // Function to add new editable row to the table
        function addNewLicense() {
    const tableBody = document.querySelector('#fssaiTable tbody');
    const newRow = document.createElement('tr');
    newRow.className = 'editable-row';

    const rowCount = tableBody.rows.length;
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    newRow.innerHTML = `
        <td>${rowCount + 1}</td>
        <td>
            <select class="form-control" name="document_type" form="newTrainingForm">
                <option value="">Select Category</option>
                <option value="License">License</option>
                <option value="HRA">HRA</option>
                <option value="TPA">TPA</option>
                <option value="Other">Other</option>
            </select>
        </td>
        <td>
            <input type="text" class="form-control" name="lincess_number" placeholder="License Number" form="newTrainingForm">
        </td>
        <td>
            <input type="date" class="form-control" name="due_date" form="newTrainingForm">
        </td>
        <td>
            <select class="form-control" name="cat_type" form="newTrainingForm">
                <option value="NA">NA</option>
                <option value="Central License">Central License</option>
                <option value="State License">State License</option>
                <option value="Basic Registration">Basic Registration</option>
            </select>
        </td>
        <td class="document-cell">
            <div class="file-upload">
                <i class="fas fa-cloud-upload-alt"></i> Upload
                <input type="file" name="image" form="newTrainingForm" >
            </div>
            <span class="uploaded-file"></span>
        </td>
        <td><span class="status status-active">Active</span></td>
        <td>
            <form id="newTrainingForm" action="{{route('lincesupload')}}" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="${csrfToken}">
                <button type="submit" class="btn btn-sm btn-save">
                    <i class="fas fa-save"></i> Save
                </button>
                <button type="button" class="btn btn-sm btn-cancel" onclick="cancelNewLicense(this)">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </form>
        </td>
    `;

    tableBody.insertBefore(newRow, tableBody.firstChild);
    updateSerialNumbers();
    newRow.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

        
        // Function to save new license
        function saveNewLicense(button) {
            const row = button.closest('tr');
            const cells = row.cells;
            
            // Get values from inputs
            const category = cells[1].querySelector('select').value;
            const licenseNumber = cells[2].querySelector('input').value;
            const expiryDate = cells[3].querySelector('input').value;
            const licenseType = cells[4].querySelector('select').value;
            const fileInput = cells[5].querySelector('input[type="file"]');
            const fileName = fileInput.files[0] ? fileInput.files[0].name : '';
            
            // Validate required fields
            if (!category || !licenseNumber || !expiryDate) {
                alert('Please fill in all required fields');
                return;
            }
            
            // Replace inputs with plain text
            cells[1].innerHTML = category;
            cells[2].innerHTML = licenseNumber;
            cells[3].innerHTML = expiryDate;
            cells[4].innerHTML = licenseType;
            
            // Update document cell
            if (fileName) {
                cells[5].innerHTML = `
                    <div class="document-preview" onclick="viewDocument('${fileName}')">
                        <i class="fas fa-file-pdf document-icon"></i>
                        <span class="document-name">${fileName}</span>
                    </div>
                `;
            } else {
                cells[5].innerHTML = `
                    <div class="file-upload">
                        <i class="fas fa-cloud-upload-alt"></i> Upload
                        <input type="file" onchange="handleLicenseUpload('${licenseNumber}', this)" accept=".pdf,.jpg,.jpeg,.png">
                    </div>
                    <span id="upload-status-${licenseNumber}" class="uploaded-file"></span>
                `;
            }
            
            // Update action buttons
            cells[7].innerHTML = `
                <div class="action-btns">
                    <button class="btn btn-sm btn-renew" onclick="openRenewModal('${licenseNumber}')">
                        <i class="fas fa-sync-alt"></i> Renew
                    </button>
                    <button class="btn btn-sm btn-history" onclick="openHistoryModal('${licenseNumber}')">
                        <i class="fas fa-history"></i> History
                    </button>
                </div>
            `;
            
            // Remove editable class
            row.classList.remove('editable-row');
            
            // Add to history log
            addHistoryEntry(licenseNumber, 'Created', 'New license record added');
            
            alert('License saved successfully!');
        }
        
        // Function to cancel adding new license
        function cancelNewLicense(button) {
            const row = button.closest('tr');
            row.remove();
            
            // Update serial numbers for all rows
            updateSerialNumbers();
        }
        
        // Function to update serial numbers in the table
        function updateSerialNumbers() {
            const rows = document.querySelectorAll('#fssaiTable tbody tr');
            rows.forEach((row, index) => {
                row.cells[0].textContent = index + 1;
            });
        }
        
        // Function to add history entry
        function addHistoryEntry(licenseNumber, action, details) {
            // In a real app, this would be saved to the server
            console.log(`History entry added for ${licenseNumber}: ${action} - ${details}`);
        }

        // Function to close any modal
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Event listeners for file inputs to show selected file names
        document.getElementById('renewalDocument').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                document.getElementById('renewalFileName').innerHTML = `<i class="fas fa-file-alt"></i> ${file.name}`;
            }
        });

        // Form submission handlers
        document.getElementById('renewForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const licenseNumber = document.getElementById('renewLicenseNumber').value;
            const newExpiryDate = document.getElementById('newExpiryDate').value;
            const file = document.getElementById('renewalDocument').files[0];
            
            // In a real application, you would send this data to the server
            console.log(`Renewing license ${licenseNumber} with new expiry date ${newExpiryDate}`);
            if (file) {
                console.log('With file:', file.name);
            }
            
            // Show success message
            alert('Renewal request submitted successfully!');
            closeModal('renewModal');
        });

        // Close modals when clicking outside
        window.onclick = function(event) {
            const modals = document.getElementsByClassName('modal');
            for (let modal of modals) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            }
        };
    </script>


   