<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Response;

use DB;
use Helper;
use Illuminate\Support\Facades\Session;

use Illuminate\Routing\Controller as BaseController;

class TrainersController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function index(Request $request)
    {
        return view('admin.training.list');
    }

    public function facility_tool_update(Request $request)
    {
        $dataArr['name'] = $request->name;
        $dataArr['purpose'] = $request->purpose;
        $dataArr['target_surface'] = $request->target_surface;

        if ($request->file('company_logo')) {
            $file = $request->file('company_logo');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('companylogo'), $filename);
            $dataArr['company_logo'] = $filename;
        }

        DB::table('toolselection')
            ->where('id', $request->tool_id)
            ->update($dataArr);
        return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
    }

    public function update(Request $request)
    {
        $dataArr['name'] = $request->name;
        $dataArr['type'] = $request->type;
        $dataArr['brand'] = $request->brand;
        $dataArr['capacity_range'] = $request->capacity_range;
        $dataArr['capacity_utility_range'] = $request->capacity_utility_range;
        $dataArr['corporate_id'] = $request->corporate_id;
        $dataArr['regional_id'] = $request->regional_id;
        $dataArr['hotel_name'] = $request->hotel_name;
        $dataArr['department'] = $request->department;
        $dataArr['location_id'] = $request->location_id;
        $dataArr['sub_location'] = $request->sub_location;

        if ($request->file('company_logo')) {
            $file = $request->file('company_logo');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('companylogo'), $filename);
            $dataArr['company_logo'] = $filename;
        }

        DB::table('facility_equipment')
            ->where('id', $request->equipments_id)
            ->update($dataArr);
        return redirect()->route('facility_hygiene')->with('add_department', 'Add Successfully');
    }
	public function destory($id)
    {
        $retData = DB::table('facility_equipment')->where('id', $id)->delete();
        return redirect()->route('facility_hygiene')->with('success', 'Delete Successfully');
    }
	
	// Jaideep Kumawat
	public function training_data_index(Request $request)
    {
        if (!empty(Session::get('unit_id'))) {
            $login_user = Session::get('unit_id');
 
           $parent_user = Helper::getUsersParentList($login_user);
        } else {
            $login_user = Auth::user()->id;
         $parent_user = Helper::getUsersParentList($login_user);
        }
        $name = $_GET['name'] ?? '';
        $frequency = $_GET['frequency'] ?? '';
        $status = $_GET['status'] ?? '';
        $entries = $_GET['entries'] ?? '';
        $responsibility = DB::table('authority')->where('unit_id', $login_user)->get();
        $locations = DB::table('locations')->where('created_by', $login_user)->whereNull('parent')->get();

        if (!empty(Session::get('unit_id'))) {
            $unit_id = Session::get('unit_id');
             $parent_user = Helper::getUsersParentList($login_user);
            
            
        } else {
            $unit_id = Auth::user()->id;
             $parent_user = Helper::getUsersParentList($login_user);
        }

        $training_types_list = DB::table('training_types');

        if (!empty($name)) {
            $training_types_list = $training_types_list->where('name', $name);
        }

        if (!empty($frequency)) {
            $training_types_list = $training_types_list->where('frequency', $frequency);
        }

        if (!empty($status)) {
            $training_types_list = $training_types_list->where('status', $status);
        }

        if (!empty($entries)) {
            if ($entries == 'All') {
                $training_types_list = $training_types_list->where('unit_id', $unit_id)->orwhere('unit_id', $parent_user)->orderBy('id', 'DESC')->get();
            } else {
                $training_types_list = $training_types_list->where('unit_id', $unit_id)->orwhere('unit_id', $parent_user)->orderBy('id', 'DESC')->get();
            }
        } else {
            $training_types_list = $training_types_list->where('unit_id', $unit_id)->orwhere('unit_id', $parent_user)->orderBy('id', 'DESC')->get();
        }


        $url = url()->full();

        return view('admin.training.training_types_list', compact('responsibility', 'locations', 'training_types_list', 'url'));
    }
	public function training_status_update(Request $request)
    {	
        $training_status_update = DB::table('training_types')->where('id', $request->id)->update(['status'=>$request->status]);
		echo "true";
    }
	public function training_data_delete($id)
    {
        $training_data_delete = DB::table('training_types')->where('id', $id)->delete();
		return redirect()->route('training_data_index')->with('success', 'Delete Successfully');
    }
	public function training_data_edit(Request $request)
    {
        $dataArr['name'] = $request->name;
        $dataArr['frequency'] = $request->frequency;
        $dataArr['status'] = $request->status;
        DB::table('training_types')
            ->where('id', $request->id)
            ->update($dataArr);
        return redirect()->route('training_data_index')->with('success', 'Edit Successfully');
    }

    public function trainers_data_index(Request $request)
    {
        
        
  
        if (!empty(Session::get('unit_id'))) {
            $login_user = Session::get('unit_id');
            $parent_user=[];
        } else {
            $login_user = Auth::user()->id;
                          $parent_user = Helper::getUsersParentAndChild($login_user);

        }
        
  
        $name = $_GET['name'] ?? '';
        $frequency = $_GET['frequency'] ?? '';
        $status = $_GET['status'] ?? '';
        $entries = $_GET['entries'] ?? '';
        $responsibility = DB::table('authority')->where('unit_id', $login_user)->get();
        $locations = DB::table('locations')->where('created_by', $login_user)->whereNull('parent')->get();

        if (!empty(Session::get('unit_id'))) {
            $unit_id = Session::get('unit_id');
        } else {
            $unit_id = Auth::user()->id;
        }


        $trainers_list = DB::table('training_types');

        if (!empty($name)) {
            $trainers_list = $trainers_list->where('name', $name);
        }

        if (!empty($frequency)) {
            $trainers_list = $trainers_list->where('frequency', $frequency);
        }

        if (!empty($status)) {
            $trainers_list = $trainers_list->where('status', $status);
        }

        if (!empty($entries)) {
            if ($entries == 'All') {
                $trainers_list = $trainers_list->where('unit_id', $unit_id)->orderBy('id', 'DESC')->paginate(350);
            } else {
                $trainers_list = $trainers_list->where('unit_id', $unit_id)->orderBy('id', 'DESC')->paginate($entries);
            }
        } else {
            $trainers_list = $trainers_list->where('unit_id', $unit_id)->orderBy('id', 'DESC')->paginate(10);
        }

        $url = url()->full();
     

        $is_role = Auth::user()->is_role;
        $unit_users_list = [];
        if ($is_role == 0){
            if($request->search){
                $unit_users_list = DB::table('unit_users')
                                    ->whereNotExists(function ( $query){
                                            $query->select('trainers.id')->from('trainers')
                                            ->whereColumn('trainers.employe_id', '=', 'unit_users.employe_id');
                                        })
                                        ->where(function($query) use ($request){
                                            $query->where('employe_id', 'like', '%'.$request->search.'%')
                                            ->orWhere('employer_fullname', 'like', '%'.$request->search.'%')
                                            ->orWhere('email', 'like', '%'.$request->search.'%')
                                            ->orWhere('gender', 'like', '%'.$request->search.'%');
                                        })->where('unit_users.created_by', $login_user)
                                        ->paginate(50);
            }
            
        }else{
            if($request->search){
                
                $query = DB::table('unit_users')
    ->whereNotExists(function ($query) {
        $query->select('trainers.id')
            ->from('trainers')
            ->whereColumn('trainers.unit_id', '=', 'unit_users.id')
            ->whereColumn('trainers.employe_id', '=', 'unit_users.employe_id');
    })
    ->where('unit_users.created_by', $login_user);

if (!empty($parent_user)) {
    $query->orWhereIn('unit_users.created_by', $parent_user);
}

if ($request->search) {
    $query->where(function ($query) use ($request) {
        $query->where('employe_id', 'like', '%' . $request->search . '%')
            ->orWhere('employer_fullname', 'like', '%' . $request->search . '%')
            ->orWhere('email', 'like', '%' . $request->search . '%')
            ->orWhere('gender', 'like', '%' . $request->search . '%');
    });
}

$unit_users_list = $query->paginate(50);
         
            }
        }


    $trainers_list_datas = DB::table('trainers')
    ->where('trainers.unit_id', $login_user)
    ->when(!empty($parent_user), function ($query) use ($parent_user) {
        $query->orWhereIn('trainers.unit_id', $parent_user);
    })
    ->paginate(50);
       // $trainers_list_datas = DB::table('trainers')->where('trainers.unit_id', $login_user)->paginate(10);

        // return redirect()->route('trainers_data_index')->with('success', 'add Successfully');


// echo "<pre>";
// print_r($trainers_list_datas);
// die();
        return view('admin.training.trainers_list', compact('responsibility', 'locations', 'trainers_list', 'url', 'unit_users_list', 'trainers_list_datas'));
    }

    public function trainers_add(Request $request)
    {
        
         if (!empty(Session::get('unit_id'))) {
            $login_user = Session::get('unit_id');
        } else {
            $login_user = Auth::user()->id;
        }
        
        
        foreach ($request->ids as $value) {
            
     
            $data = DB::table('trainers')->where('unit_id', '=', $login_user)->where('employe_id', '=', $value)->first();
       
            if(empty($data)){
                $dataArr['unit_id'] = $login_user;
                $dataArr['employe_id'] = $value;
                DB::table('trainers')->insert($dataArr);
            }
        }
		echo "true";
    }
    
    public function trainers_delete(Request $request)
    {
        foreach ($request->ids as $value) {
            DB::table('trainers')->where('id', $value)->delete();
        }
		echo "true";
    }

    public function trainers_data_delete($id)
    {
        $retData = DB::table('trainers')->where('id', $id)->delete();
        return redirect()->route('trainers_data_index')->with('success', 'Delete Successfully');
    }

    public function employee_month_training_tracker(Request $request)
    {
        if (!empty(Session::get('unit_id'))) {
            $login_user = Session::get('unit_id');
        } else {
            $login_user = Auth::user()->id;
        }
        $url = url()->full();
        $is_role = Auth::user()->is_role;
        if ($is_role == 0){
                $unit_users_list = DB::table('unit_users')->get();
        }else{
                $unit_users_list = DB::table('unit_users')
                                    ->where('unit_users.created_by', $login_user)
                                    ->get();
        }
        return view('admin.training.employee_month_training_tracker', compact('url', 'unit_users_list'));
    }

    public function employee_topic_training_tracker(Request $request)
    {
        
        $topic_id = $request->topic_id;
   
        if (!empty(Session::get('unit_id'))) {
            $login_user = Session::get('unit_id');
             $parent_user = Helper::getUsersParentList($login_user);
        } else {
            $login_user = Auth::user()->id;
            $parent_user = Helper::getUsersParentList($login_user);
        }
        
$departments = DB::table('departments')->where('unit_id',$login_user)->get();

        $url = url()->full();
        $is_role = Auth::user()->is_role;
        
          $data = $request->all();
     
           
                if (!empty($request->user_id) || 
    !empty($request->topic_id) || 
    !empty($request->attended) || 
    !empty($request->department) || 
    !empty($request->from_date) || 
    !empty($request->to_date) || 
    !empty($request->staff_category) || 
    !empty($request->cat_name) || 
    !empty($request->joining_from) || 
    !empty($request->joining_to)) {
               
   
              
              if($request->attended==2){
                  
          
    
  $student_enrolled_list = DB::table('student_enrolled');


        if(!empty($request->department)  ){
            $student_enrolled_list =  $student_enrolled_list->where('department', $request->department);  
        }
        
          if(!empty($request->attended)  ){
            $student_enrolled_list =  $student_enrolled_list->where('attendance', $request->attended);  
        }
        
              if(!empty($request->staff_category)  ){
         
            $student_enrolled_list =  $student_enrolled_list->where('staff_category', $request->staff_category);  
        }
        
                 if(!empty($request->cat_name)  ){
            $student_enrolled_list =  $student_enrolled_list->where('cat_name', $request->cat_name);  
        }
        
        
                 if(!empty($request->user_id)  ){
            $student_enrolled_list =  $student_enrolled_list->where('user_id', $request->user_id);  
        }
        
       
    
        
                if(!empty($request->from_date && $request->to_date)  ){
                $student_enrolled_list =  $student_enrolled_list->whereDate('from_date', '>=', $request->from_date)->whereDate('to_date', '<=', $request->to_date);  
                }
        
        
       if (!empty($request->joning_from) && !empty($request->joning_to)) {
    $student_enrolled_list = $student_enrolled_list->whereDate('joning_to', '>=', $request->joning_from)
                                                   ->whereDate('joning_to', '<=', $request->joning_to);
}
                  if(!empty($request->topic_id)  ){
            $student_enrolled_list =  $student_enrolled_list->where('topic_id', $request->topic_id);  
        }
                
        $student_enrolled_list = $student_enrolled_list->pluck('user_id');
        
        if(!empty($student_enrolled_list)){
     
                  $unit_users_list = DB::table('unit_users')->whereIn('id', $student_enrolled_list)
            ->where('created_by', $login_user)->orderBy('status', 'ASC')
            ->paginate(10);  
        }
        else{
               $unit_users_list = DB::table('unit_users')
            ->where('created_by', $login_user)->orderBy('status', 'ASC')
            ->paginate(10);     
        }  
}

else{
    

      $student_enrolled_list = DB::table('student_enrolled');

       if(!empty($request->from_date && $request->to_date)  ){
                $student_enrolled_list =  $student_enrolled_list->whereDate('from_date', '>=', $request->from_date)->whereDate('to_date', '<=', $request->to_date);  
                }
                
                
        if(!empty($request->department)  ){
            $student_enrolled_list =  $student_enrolled_list->where('department', $request->department);  
        }
        
          if(!empty($request->attended)  ){
            $student_enrolled_list =  $student_enrolled_list->where('attendance', 2);  
        }
        
              if(!empty($request->staff_category)  ){
         
            $student_enrolled_list =  $student_enrolled_list->where('staff_category', $request->staff_category);  
        }
        
                 if(!empty($request->cat_name)  ){
            $student_enrolled_list =  $student_enrolled_list->where('cat_name', $request->cat_name);  
        }
        
        
                 if(!empty($request->user_id)  ){
            $student_enrolled_list =  $student_enrolled_list->where('user_id', $request->user_id);  
        }
        
    
                if(!empty($request->from_date && $request->to_date)  ){
                $student_enrolled_list =  $student_enrolled_list->whereDate('from_date', '>=', $request->from_date)->whereDate('to_date', '<=', $request->to_date);  
                }
        
        
       if (!empty($request->joning_from) && !empty($request->joning_to)) {
    $student_enrolled_list = $student_enrolled_list->whereDate('joning_to', '>=', $request->joning_from)
                                                   ->whereDate('joning_to', '<=', $request->joning_to);
}
                  if(!empty($request->topic_id)  ){
            $student_enrolled_list =  $student_enrolled_list->where('topic_id', $request->topic_id);  
        }
                
        $student_enrolled_list = $student_enrolled_list->pluck('user_id');
        
        if(!empty($student_enrolled_list)){
            
            
            
              $unit_users = DB::table('unit_users');
            
                  if(!empty($request->department)  ){
            $unit_users =  $unit_users->where('department', $request->department);  
        }
   
        
              if(!empty($request->staff_category)  ){
         
            $unit_users =  $unit_users->where('staff_category', $request->staff_category);  
        }
        
                 if(!empty($request->cat_name)  ){
            $unit_users =  $unit_users->where('cat_name', $request->cat_name);  
        }
        
        
                 if(!empty($request->user_id)  ){
            $unit_users =  $unit_users->where('id', $request->user_id);  
        }
        
   
    
        
                if(!empty($request->joning_from && $request->joning_to)  ){
                $unit_users =  $unit_users->whereDate('dog', '>=', $request->joning_from)->whereDate('dog', '<=', $request->joning_to);  
                }
                    
                  $unit_users_list = $unit_users->whereNotIn('id', $student_enrolled_list)->where('created_by', $login_user)->orderBy('status', 'ASC')->paginate(10);  
        }
        else{
       
               $unit_users_list = DB::table('unit_users')
            ->where('created_by', $login_user)->orderBy('status', 'ASC')
            ->paginate(10);     
        }  
    
} 
           }else{
             
                     $unit_users_list = DB::table('unit_users')
            ->where('created_by', $login_user)->orderBy('status', 'ASC')
            ->paginate(10);     
           }




                                            

        if(!empty($topic_id)){
            
          
                $training_types_list = DB::table('training_types');
            if(!empty($topic_id)  ){
                      echo $topic_id;
            $training_types_list =  $training_types_list->where('id', $topic_id);  
            }
            $training_types_list = $training_types_list
            ->get();  
        }
        else{
       
        $training_types_list = DB::table('training_types');
        $training_types_list = $training_types_list->where('unit_id', $login_user)->orwhere('unit_id', $parent_user)
        ->get();   
        }

  
    $topic_list = DB::table('training_types')->where('unit_id', $login_user)->orwhere('unit_id', $parent_user)->get();
                          $lms_remarylist = DB::table('tbl_lms')->whereNotNull('remark')->where('created_by', $login_user)->get();   
                           $staff_users_list = DB::table('staff_list')->where('created_by',$login_user)->get();

    
    $url = url()->full();

        return view('admin.training.employee_topic_training_tracker', compact('url', 'unit_users_list', 'training_types_list','lms_remarylist','topic_list','url','departments','staff_users_list'));
    }

    public function training_calendra_index(Request $request)
    {
        if (!empty(Session::get('unit_id'))) {
            $login_user = Session::get('unit_id');
        } else {
            $login_user = Auth::user()->id;
        }
        
                if (!empty(Session::get('unit_id'))) {
            $login_user = Session::get('unit_id');
                      $parent_user = Helper::getUsersParentList($login_user);
                       $parent_child=[];
        } else {
            $login_user = Auth::user()->id;
                      $parent_user = Helper::getUsersParentList($login_user);
                       $parent_child = Helper::getUsersParentAndChild($login_user);
                       
                      
        }
        $url = url()->full();
        $is_role = Auth::user()->is_role;
   
  
                $training_types_list = DB::table('training_types')
                                    ->where('unit_id', $login_user)->orwhere('unit_id', $parent_user)->where('status', 1)
                                    ->get();
             
                                            
       $lms_list = DB::table('tbl_lms');

// Apply filters based on request parameters
if (!empty($request->start_date) && !empty($request->end_date)) {
    $lms_list->whereDate('start_time', '>=', $request->start_date)
             ->whereDate('end_time', '<=', $request->end_date);
}

if (!empty($request->course_titles)) {
    $lms_list->where('course_titles', $request->course_titles);
}

if (!empty($request->remark)) {
    $lms_list->where('remark', $request->remark);
}

if (!empty($request->trainer)) {
    $lms_list->where('trainer', $request->trainer);
}



// Additional filter for $is_role == 3
if ($is_role == 3) {
      $lms_list->where(function($query) use ($login_user) {
        $query->where('created_by', $login_user)
              ->orWhereJsonContains('unit_ids', (string) $login_user);
    });
}
elseif($is_role == 2){
    
    $lms_list->where(function($query) use ($login_user, $parent_child) {
    $query->orWhere(function($query) use ($parent_child) {
              foreach ($parent_child as $child) {
                  
        
                  $query->orWhereJsonContains('unit_ids', (string) $child);
              }
          });
});
}else {
    // Apply common filters for other roles
    $lms_list->where('created_by', $login_user);
}

// Order the results
$lms_list->orderBy('start_time', 'desc');

// Paginate the results
$lms_list = $lms_list->paginate(20);


                                              $lms_remarylist = DB::table('tbl_lms')->whereNotNull('remark')->where('created_by', $login_user)->get();
                                            
            

$unit_users_list = DB::table('trainers')
    ->join('unit_users', 'trainers.employe_id', '=', 'unit_users.employe_id')
    ->select(
        'trainers.*',
        'unit_users.employer_fullname',
        'unit_users.email',
        'unit_users.contact_number',
        'unit_users.gender',
        'unit_users.status'
    )
    ->where('trainers.unit_id', $login_user)
    ->when(!empty($parent_child), function ($query) use ($parent_child) {
        $query->orWhereIn('trainers.unit_id', $parent_child);
    })
    ->get();

$filtered_unit_users_list = $unit_users_list->filter(function ($item) {
    return $item->status != 0;
});

// If you want to reset the array keys:
$unit_users_list = $filtered_unit_users_list->values();


if ($is_role == 1) {

    $UnitList1 = Helper::getUsersParentAndChild($login_user);
   $arrayUnitList1 = json_decode(json_encode($UnitList1), true);
   
   
   if (is_array($arrayUnitList1)) {
       
 
    $UnitList = DB::table('users')->whereIn('id', $arrayUnitList1)->get();  
} else {

    $UnitList = DB::table('users')->where('id', $arrayUnitList1)->get(); 
}

// die;

//     if (count($UnitList1) > 1) {
//         $UnitList = DB::table('users')->whereIn('id', $UnitList1)->get();  
//     } else {
//         $UnitList = DB::table('users')->where('id', $UnitList1)->get();  
//     }
}


       else{
          $UnitList=[]; 
       }
       
       
      foreach($lms_list as $lms_lists){
          
//           $course_id = $lms_lists->id;

// // Construct the URL with the course ID
// $url = 'https://efsm.safefoodmitra.com/admin/public/index.php/scanlms/' . $course_id;

// // Create the array with course_id and the URL
// $sdata = array(
//     "course_id" => $course_id,
//     "url" => $url
// );

// // Encode the array to JSON
// $sdata_json = json_encode($sdata);

// // Generate the QR code URL with the encoded JSON data
// $qr_code = 'https://api.qrserver.com/v1/create-qr-code/?size=350x350&data=' . urlencode($sdata_json);

// // Assign the QR code URL to your data array
// $data['qr_code'] = $qr_code;

// Output the QR code URL (for debugging purposes)

            
            // $sdata = array("course_id" => $lms_lists->id);
            // $sdata =  json_encode($sdata);
            // $qr_code = 'https://api.qrserver.com/v1/create-qr-code/?size=350x350&data='.$sdata.'';
            
            // $data['qr_code']=$qr_code;
            
            // Assuming $lms_lists->id contains the course ID
$course_id = $lms_lists->id;

// Construct the URL with the course ID
$url = 'https://efsm.safefoodmitra.com/admin/public/index.php/scanlms/' . $course_id;

// Generate the QR code URL with the constructed URL
$qr_code = 'https://api.qrserver.com/v1/create-qr-code/?size=350x350&data=' . urlencode($url);

// Assign the QR code URL to your data array
$data['qr_code'] = $qr_code;
            
            DB::table('tbl_lms')->where('id',$lms_lists->id)->update($data);
      }
       
    //   die();
    
 
        return view('admin.training.training_calendra_index',compact('unit_users_list', 'training_types_list','lms_list','lms_remarylist','UnitList'));
    }
    
       public function saveDocuments(Request $request)
    {
    if($request->file('image')){
    $file= $request->file('image');
    $filename= date('YmdHi').$file->getClientOriginalName();
    $file-> move(public_path('documents'), $filename);
    $dataArr['image']= $filename;
    }

    
if($request->due_date){
$dataArr['due_date']= $request->due_date ?? '';
}


if($request->edit_id){
         DB::table('pepole_managment_documents')->where('id',$request->edit_id)->update($dataArr);
}else{
    $dataArr['unit_id']= $request->unit_id ?? '';
    $dataArr['topic_id']= $request->topic_id ?? NULL;

           DB::table('pepole_managment_documents')->insert($dataArr);
  
}

		return redirect()->back()->with('success', 'Upload  successfully'); 
    }
    
    
    public function destorypepoleDocuments($id) {
    	$retData=DB::table('pepole_managment_documents')->where('id',$id)->delete();
		 return redirect()->back()->with('success', 'Delete Successfullye');   
}
    public function trainers_card($topic_id,$user_id)
    {
         $unit_users_list = DB::table('unit_users')->where('id', $user_id)->first();
          $lms_list = DB::table('student_enrolled')->where('topic_id', $topic_id)->where('user_id', $user_id)->get();
        return view('admin.training.trainers_card',compact('unit_users_list','lms_list'));
    }
    
        public function trainers_cards($user_id)
    {
         $unit_users_list = DB::table('unit_users')->where('id', $user_id)->first();
          $lms_list = DB::table('student_enrolled')->where('user_id', $user_id)->get();
        return view('admin.training.trainers_cards',compact('unit_users_list','lms_list'));
    } 
    
    
    
        public function exportdatacsv(Request $request)
    {
        
        
  
        $topic_id = $request->topic_id;
   
        if (!empty(Session::get('unit_id'))) {
            $login_user = Session::get('unit_id');
            $parent_user = Helper::getUsersParentList($login_user);
        } else {
            $login_user = Auth::user()->id;
            $parent_user = Helper::getUsersParentList($login_user);
           
        }
        
$departments = DB::table('departments')->where('unit_id',$login_user)->get();

        $url = url()->full();
        $is_role = Auth::user()->is_role;
        
          $data = $request->all();
  
           
      if (!empty($request->user_id) || 
    !empty($request->topic_id) || 
    !empty($request->attended) || 
    !empty($request->department) || 
    !empty($request->from_date) || 
    !empty($request->to_date) || 
    !empty($request->staff_category) || 
    !empty($request->cat_name) || 
    !empty($request->joining_from) || 
    !empty($request->joining_to)) {
 
              
              if($request->attended==2){
    
  $student_enrolled_list = DB::table('student_enrolled');


        if(!empty($request->department)  ){
            $student_enrolled_list =  $student_enrolled_list->where('department', $request->department);  
        }
        
          if(!empty($request->attended)  ){
            $student_enrolled_list =  $student_enrolled_list->where('attendance', $request->attended);  
        }
        
              if(!empty($request->staff_category)  ){
         
            $student_enrolled_list =  $student_enrolled_list->where('staff_category', $request->staff_category);  
        }
        
                 if(!empty($request->cat_name)  ){
            $student_enrolled_list =  $student_enrolled_list->where('cat_name', $request->cat_name);  
        }
        
        
                 if(!empty($request->user_id)  ){
            $student_enrolled_list =  $student_enrolled_list->where('user_id', $request->user_id);  
        }
        
       
    
        
                if(!empty($request->from_date && $request->to_date)  ){
                $student_enrolled_list =  $student_enrolled_list->whereDate('from_date', '>=', $request->from_date)->whereDate('to_date', '<=', $request->to_date);  
                }
        
        
       if (!empty($request->joning_from) && !empty($request->joning_to)) {
    $student_enrolled_list = $student_enrolled_list->whereDate('joning_to', '>=', $request->joning_from)
                                                   ->whereDate('joning_to', '<=', $request->joning_to);
}
                  if(!empty($request->topic_id)  ){
            $student_enrolled_list =  $student_enrolled_list->where('topic_id', $request->topic_id);  
        }
                
        $student_enrolled_list = $student_enrolled_list->pluck('user_id');
        
        if(!empty($student_enrolled_list)){
     
                  $unit_users_list = DB::table('unit_users')->whereIn('id', $student_enrolled_list)
            ->where('created_by', $login_user)->where('status', "1")
            ->get();     
        }
        else{
               $unit_users_list = DB::table('unit_users')
            ->where('created_by', $login_user)->where('status', "1")
           ->get();        
        }  
}

else{
    

    

      $student_enrolled_list = DB::table('student_enrolled');

       if(!empty($request->from_date && $request->to_date)  ){
                $student_enrolled_list =  $student_enrolled_list->whereDate('from_date', '>=', $request->from_date)->whereDate('to_date', '<=', $request->to_date);  
                }
                
                
        if(!empty($request->department)  ){
            $student_enrolled_list =  $student_enrolled_list->where('department', $request->department);  
        }
        
          if(!empty($request->attended)  ){
            $student_enrolled_list =  $student_enrolled_list->where('attendance', 2);  
        }
        
              if(!empty($request->staff_category)  ){
         
            $student_enrolled_list =  $student_enrolled_list->where('staff_category', $request->staff_category);  
        }
        
                 if(!empty($request->cat_name)  ){
            $student_enrolled_list =  $student_enrolled_list->where('cat_name', $request->cat_name);  
        }
        
        
                 if(!empty($request->user_id)  ){
            $student_enrolled_list =  $student_enrolled_list->where('user_id', $request->user_id);  
        }
        
    
                if(!empty($request->from_date && $request->to_date)  ){
                $student_enrolled_list =  $student_enrolled_list->whereDate('from_date', '>=', $request->from_date)->whereDate('to_date', '<=', $request->to_date);  
                }
        
        
       if (!empty($request->joning_from) && !empty($request->joning_to)) {
    $student_enrolled_list = $student_enrolled_list->whereDate('joning_to', '>=', $request->joning_from)
                                                   ->whereDate('joning_to', '<=', $request->joning_to);
}
                  if(!empty($request->topic_id)  ){
            $student_enrolled_list =  $student_enrolled_list->where('topic_id', $request->topic_id);  
        }
                
        $student_enrolled_list = $student_enrolled_list->pluck('user_id');
        
        if(!empty($student_enrolled_list)){
            
            
            
              $unit_users = DB::table('unit_users');
            
                  if(!empty($request->department)  ){
            $unit_users =  $unit_users->where('department', $request->department);  
        }
   
        
              if(!empty($request->staff_category)  ){
         
            $unit_users =  $unit_users->where('staff_category', $request->staff_category);  
        }
        
                 if(!empty($request->cat_name)  ){
            $unit_users =  $unit_users->where('cat_name', $request->cat_name);  
        }
        
        
                 if(!empty($request->user_id)  ){
            $unit_users =  $unit_users->where('id', $request->user_id);  
        }
        
   
    
        
                if(!empty($request->joning_from && $request->joning_to)  ){
                $unit_users =  $unit_users->whereDate('dog', '>=', $request->joning_from)->whereDate('dog', '<=', $request->joning_to);  
                }
                    
                  $unit_users_list = $unit_users->whereNotIn('id', $student_enrolled_list)->where('created_by', $login_user)->orderBy('status', 'DESC')->get(); 
        }
        else{
       
               $unit_users_list = DB::table('unit_users')
            ->where('created_by', $login_user)->where('status', "1")->get();   
             
        }  
    
} 
           }else{
             
                     $unit_users_list = DB::table('unit_users')
            ->where('created_by', $login_user)->where('status', "1")
            ->get();     
           }




                                            

        if(!empty($topic_id)){
            
  
                $training_types_list = DB::table('training_types');
            if(!empty($topic_id)  ){
            $training_types_list =  $training_types_list->where('id', $topic_id);  
            }
            $training_types_list = $training_types_list
            ->get();  
        }
        else{
        $training_types_list = DB::table('training_types');
        $training_types_list = $training_types_list->where('unit_id', $login_user)->orwhere('unit_id', $parent_user)
        ->get();   
        }
   

   
$topic_list = DB::table('training_types')->where('unit_id', $login_user)->orwhere('unit_id', $parent_user)->get();
$lms_remarylist = DB::table('tbl_lms')->whereNotNull('remark')->where('created_by', $login_user)->get();   
$staff_users_list = DB::table('staff_list')->where('created_by', $login_user)->get();



$filename = "employee_topic_training_tracker.csv";
$handle = fopen($filename, 'w+');

// Define your base column names
$column_names = array('employee_id', 'name', 'gender', 'staff_category', 'cat_name', 'doj', 'dob','designation', 'department');

// Assuming $training_types_list and $unit_users_list are defined and populated

// Add columns from the $training_types_list array, including end_time for each training type
foreach ($training_types_list as $training_type) {
    $column_names[] = $training_type->name; // Appending '_status' for clarity
    // $column_names[] = $training_type->name . '_end_time'; // Adding end_time column
}

// Write the column names to the CSV file
fputcsv($handle, $column_names);


$all_end_times = [];


// Write the data rows
foreach ($unit_users_list as $unit_user) {
    
     $department_name = DB::table('departments')->where('id', $unit_user->department)->first();
    
    // echo "<pre>";
    // print_r($unit_user);
    // die();
    // Prepare the row with the basic user information
    $row = array(
        $unit_user->employe_id,
        $unit_user->employer_fullname,
        $unit_user->gender,
        $unit_user->staff_category,
        $unit_user->cat_name,
        $unit_user->dog,
        $unit_user->dob,
         $department_name->name ?? '',
        $unit_user->designation,
       
    );

    $training_end_times = [];


    // Add training types data and end_time for each training type
    foreach ($training_types_list as $training_type) {
        
        // Fetch all end_time for the current training type and unit user
        $result = DB::table('student_enrolled')
            ->join('tbl_lms', 'student_enrolled.course_id', '=', 'tbl_lms.id')
            ->where('student_enrolled.user_id', $unit_user->id)
            ->where('student_enrolled.topic_id', $training_type->id)
            ->where('student_enrolled.attendance', '2')
            ->orderBy('student_enrolled.id', 'DESC')
            ->select('tbl_lms.end_time')
            ->get();

        $datest = [];

        foreach ($result as $results) {
            $datest[] = $results->end_time;
        }

        // Store the dates in the associative array
   $all_end_times[$unit_user->id][$training_type->id] = $datest;        
        
        
        //         $end_times = $all_end_times[$unit_user->id][$training_type->id] ?? ['Not Attended'];
        //          foreach ($end_times as $end_time) {
        //     $row[] = $end_time;
        // }


   $end_times = $all_end_times[$unit_user->id][$training_type->id] ?? ['Not Attended'];
        
        // Add a single string combining all end times for the current training type
        $training_end_times[] = implode(', ', $end_times);
        
        
        
        // Get the end_time for the current training type and unit user
        // $end_time = Helper::AllAttended($training_type->id, $unit_user->id)->end_time ?? 'Not Attended';
        // $row[] = $end_time;

        // // Assuming you have a status indicating whether the training was attended or not
        // $status = Helper::LastAttended($training_type->id, $unit_user->id)->status ?? 'Not Attended';
        // $row[] = $status;
    }
    
        $row = array_merge($row, $training_end_times);


    fputcsv($handle, $row);
}

fclose($handle);
$headers = array(
    'Content-Type' => 'text/csv',
);
return Response::download($filename, 'departments.csv', $headers)->deleteFileAfterSend(true);




    
        return view('admin.training.employee_topic_training_tracker', compact('url', 'unit_users_list', 'training_types_list','lms_remarylist','topic_list','url','departments','staff_users_list'));
    }
    
    public function exportdatacsv1()
    {
        
             if (!empty(Session::get('unit_id'))) {
            $unit_id = Session::get('unit_id');
        } else {
            $unit_id = Auth::user()->id;
        }
        
      $departments = DB::table('departments')->where('unit_id', $unit_id)->get();

$filename = "departments.csv";
$handle = fopen($filename, 'w+');
fputcsv($handle, array('id', 'name')); // Add your column names here

foreach ($departments as $department) {
    fputcsv($handle, array($department->id, $department->name)); // Adjust columns accordingly
}

fclose($handle);

$headers = array(
    'Content-Type' => 'text/csv',
);

return Response::download($filename, 'departments.csv', $headers)->deleteFileAfterSend(true);
    }
}
